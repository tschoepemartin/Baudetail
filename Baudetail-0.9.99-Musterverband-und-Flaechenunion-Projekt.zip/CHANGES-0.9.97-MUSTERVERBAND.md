# BauDetail 0.9.97 – Musterverband-Bedienung (Quellcode-Zwischenstand)

- Separater Schalter »Musterverband aktivieren« in beiden Pflasterdialogen.
- Ohne Aktivierung verwendet die Engine die bisherige Standard-Rasterzeichnung; die große externe .bdlib wird nicht wegen der Verbandauswahl geladen.
- Mehrformat-Eingabe erscheint nur bei aktiviertem Musterverband und passenden Verbänden.
- Steinformat-Längen als semikolongetrennte LxB-Werte gespeichert; bestehende Pattern-JSONs bleiben durch Defaults lesbar.
- Achtung: Die bisherige Engine verwendet bei Mehrformatreihen nur die Längen; unterschiedliche Breiten, korrekte römische Module und der echte externe .bdlib-Geometrieimport sind NOCH NICHT implementiert. Kein APK-Build durchgeführt.
