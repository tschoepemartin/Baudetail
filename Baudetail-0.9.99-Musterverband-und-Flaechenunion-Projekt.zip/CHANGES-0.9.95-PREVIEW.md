# Vorschau-Korrektur (Teilstand)
Die Druck-/Exportvorschau verwirft nicht mehr pauschal alle Asset-Primitive oder lange Pfade. Das Primitive-Budget wurde von 1.800 auf 12.000 erhöht. Dies betrifft nur die interaktive Vorschau, nicht den PDF-Export. Fehlende Rinnen- und Lichtschachtabdeckungen im fertigen PDF, neue Verbände und Texturen sind noch nicht repariert. Kein Android-Build erfolgt.
