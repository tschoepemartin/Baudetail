# BauDetail 0.9.95 – Druckvorschau

Die Vorschau verwendet nun sämtliche von Scene.paper/Scene.paperDual erzeugten Primitiven ohne willkürliche 12.000-Element-Grenze. Vorher konnten Rinnenrost- und Lichtschachtdetails bei komplexen Plänen aus der Vorschau verschwinden. Die bestehende Memoisierung der Grundszene bleibt erhalten.

Nicht verifiziert: Android-Build, Geräteperformance und PDF-Rostdarstellung. Die neuen Verbände sind weiterhin offen.
