# BauDetail 0.9.95 – Teilstand

- Materialliste der oberen Pflasterschicht nach Verwendungszweck gefiltert; Mauer-, Palisaden-, Rasen- und Schüttmaterialien werden aus der Belagsauswahl ausgeschlossen.
- Doppelte Hersteller-Namen in der Auswahlliste unterdrückt; Bibliotheksdaten und bereits gespeicherte Material-IDs bleiben erhalten.
- Version erhöht.

**Nicht implementiert:** Neue Mehrformatverbände (Römisch/Wild etc.), individuelle Naturstein-Texturen, Änderungen an der geometrischen Vereinigungsfunktion und Fugenrenderer. Diese Punkte erfordern zusätzliche Arbeiten und Tests. Die bestehende Funktion „Zusammenführen“ verlangt Mehrfachauswahl kompatibler Flächen.
