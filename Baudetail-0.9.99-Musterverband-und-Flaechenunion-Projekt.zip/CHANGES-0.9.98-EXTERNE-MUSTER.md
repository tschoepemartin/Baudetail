# 0.9.98 – Externe Mustermodule (Quellcode, nicht gebaut)

- Musterverband bleibt standardmäßig deaktiviert.
- Externes Muster wird erst nach expliziter Auswahl aus der externen `.bdlib` gelesen.
- Im Dialog sind nur vom Manifest als konvertiert markierte bzw. freie Muster auswählbar.
- Rechteckige, nicht gedrehte, periodische Mustermodule werden als Steinkoordinaten-Snapshot im Pattern gespeichert, damit bestehende Zeichnungen ohne Bibliothek funktionieren.
- Gemeinsame Scene-Zeichenroutine rendert den Snapshot in Ansicht und PDF.
- Nichtperiodische, polygonale und gedrehte Einzelsteine werden **nicht** stillschweigend als korrekt unterstützt; Auswahl bricht mit Fehlermeldung ab.
- Noch offen: echte polygonale/rotierte Mustermodule, fachliche Prüfung aller 25 Originale, flüssige Lazy-Indexierung, interaktives Steinformat-UI, Android-/GitHub-Build und Gerätetest.
