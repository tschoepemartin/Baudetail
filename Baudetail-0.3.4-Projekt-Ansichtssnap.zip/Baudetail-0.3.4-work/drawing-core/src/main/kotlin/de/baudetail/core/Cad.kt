package de.baudetail.core
import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

val cadLevels=listOf("Oberfläche","Unterbau","Fundament","Leitungen","Untergrund")
val viewProfiles=listOf("Oberflächenplan","Fundamentplan","Entwässerungs-/Leitungsplan","Pflanzplan","Schnitt")
fun Drawing.profile()=(extensions["viewProfile"] as? JsonPrimitive)?.contentOrNull?:if(viewMode()=="section")"Schnitt"else"Oberflächenplan"
fun Drawing.withProfile(value:String)=withViewMode(if(value=="Schnitt")"section"else"top").let{it.copy(extensions=JsonObject(it.extensions+("viewProfile" to JsonPrimitive(value))))}
fun visibleIn(e:Entity,d:Drawing):Boolean {
 if(e.num("hidden")==1.0)return false
 if(d.viewMode()=="section")return e.placement.visibleSection
 if(!e.placement.visibleTop)return false
 val level=if(e.placement.level=="Oberfläche"&&e.kind=="component"&&e.name.contains("fundament",true))"Fundament"else e.placement.level
 return when(d.profile()){"Oberflächenplan","Pflanzplan"->level=="Oberfläche";"Fundamentplan"->level in setOf("Fundament","Unterbau");"Entwässerungs-/Leitungsplan"->level in setOf("Leitungen","Oberfläche");else->true}
}
fun closedContour(e:Entity)=e.kind in setOf("rect","circle","polygon","area","building")||(e.kind=="polyline"&&e.points.size>=4&&e.points.first().distance(e.points.last())<0.001)
fun asArea(e:Entity):Entity {require(closedContour(e)){"Nur geschlossene Konturen sind Flächen"};return if(e.kind=="circle")e.copy(quantityUnit="m²")else e.copy(kind="area",points=if(e.points.size>3&&e.points.first()==e.points.last())e.points.dropLast(1)else e.points,quantityUnit="m²")}
fun surfaceArea(e:Entity)=if(e.kind=="circle")PI*e.num("radiusMm").pow(2)else if(closedContour(e))area(e.points)else 0.0
fun perimeter(e:Entity)=if(e.kind=="circle")2*PI*e.num("radiusMm")else length(e.points,closedContour(e))
fun contour(e:Entity):List<Vec> = if(e.kind=="circle")(0 until 128).map{val t=it*2*PI/128;(e.points.firstOrNull()?:Vec())+Vec(cos(t),sin(t))*e.num("radiusMm")}else e.points
fun LibraryEntry.attribute(key:String,default:Double)=(attributes[key] as? JsonPrimitive)?.doubleOrNull?.takeIf{it.isFinite()&&it>0}?:default
fun materialStyle(entry:LibraryEntry,section:Boolean)=if(section)entry.appearance?.section?:entry.style else entry.appearance?.top?:entry.style
fun LibraryEntry.isGrassSectionComponent():Boolean = type=="component" && (category.contains("Vegetation/Rasen",true)||name.contains("Rasen",true)) && ((attributes["Darstellung"] as? JsonPrimitive)?.contentOrNull?.contains("Schnitt",true)==true || views["top"]==views["section"])
fun componentInstance(entry:LibraryEntry,at:Vec):Entity {
 val depth=entry.attribute("depth_mm",entry.attribute("section_width_mm",entry.attribute("width_mm",400.0)))
 val height=entry.attribute("section_height_mm",entry.attribute("height_mm",150.0))
 val width=entry.attribute("length_mm",entry.attribute("top_height_mm",entry.attribute("width_mm",1000.0)))
 val grass=entry.isGrassSectionComponent()
 val topWidth=entry.attribute("top_width_mm",entry.attribute("width_mm",1000.0))
 val topHeight=entry.attribute("top_height_mm",if(grass)entry.attribute("width_mm",1000.0)else entry.attribute("height_mm",500.0))
 val family=entry.smartFamily()
 return Entity(kind="component",name=entry.name,libraryId=entry.id,view=if(entry.views.containsKey("top")&&entry.geometry.all{it.view=="top"})"top"else"section",points=listOf(at),style=entry.style,children=entry.geometry,params=buildJsonObject{
  put("widthMm",depth);put("heightMm",height);put("depthMm",depth);put("stepHeightMm",height);put("stairWidthMm",width);put("isStep",entry.isStairStep());put("topWidthMm",topWidth);put("topHeightMm",topHeight);put("sectionWidthMm",depth);put("sectionHeightMm",height);put("grassTopFallback",grass);entry.views.forEach{(k,v)->put("asset_"+k,v)};put("libraryViews",true);put("mirrored",0)
  put("componentFamily",family);put("variantGroup",entry.variantGroup());put("libraryCategory",entry.category);put("labelEnabled",false);put("labelMode","auto");put("fillMode","auto");put("snapPriority","normal")
  if(family=="pipe"){put("dnMm",entry.attrNumber("DN","DN_mm","dn_mm",default=height));put("orientation","horizontal");put("verticalDirection","down");put("verticalLengthMm",1000.0)}
  if(family=="retaining_wall"){put("wallHeightMm",entry.attrNumber("wall_height_mm","Höhe_mm","height_mm",default=height));put("footDepthMm",entry.attrNumber("foot_depth_mm","Fußtiefe_mm","Breite_mm","section_width_mm",default=depth));put("wallThicknessMm",entry.attrNumber("wall_thickness_mm","Wandstärke_mm",default=70.0));put("footThicknessMm",entry.attrNumber("foot_thickness_mm","Fußstärke_mm",default=100.0));put("elementLengthMm",entry.attrNumber("element_length_mm","Länge_mm","length_mm","width_mm",default=topWidth));put("footSide","right")}
 })
}
fun stairDepth(e:Entity)=e.num("depthMm",e.children.firstOrNull()?.num("depthMm",400.0)?:400.0)
fun stairLength(e:Entity)=(stairCount(e)-1)*stairGoing(e)+stairDepth(e)
fun templateEntry(name:String,category:String,entities:List<Entity>,origin:Vec,previous:LibraryEntry?=null):LibraryEntry {
 require(entities.isNotEmpty())
 return LibraryEntry(id=previous?.id?:uid(),type="assembly-template",name=name,category=category,version=(previous?.version?:0)+1,geometry=entities.map{transform(it,translation=Vec()-origin).copy(bindings=emptyList(),anchors=emptyList())},attributes=buildJsonObject{put("origin_x_mm",0);put("origin_y_mm",0)},extensions=buildJsonObject{put("previewKind","geometry")})
}
fun instantiateTemplate(entry:LibraryEntry,at:Vec):Entity {
 val copies=entry.geometry.map{it.copy(id=uid(),bindings=emptyList(),anchors=emptyList())}
 return Entity(kind="component",name=entry.name,points=listOf(at),children=copies,params=buildJsonObject{put("frozenTemplate",true);put("templateScale",1.0);put("templateId",entry.id);put("templateVersion",entry.version);put("mirrored",0)})
}
val measureProfiles=listOf("Aus","Minimal","Ausführung","Vollständig","Benutzerdefiniert")
fun metrics(e:Entity):List<String> = when{isStair(e)->listOf("Gesamtlänge","Gesamthöhe","Breite","Stufenhöhe","Stufentiefe","Auftritt","Überdeckung","Stufengefälle","Anzahl");closedContour(e)->listOf("Fläche","Umfang","Länge","Breite","Gefälle");else->listOf("Länge","Breite","Höhe","DN","Gefälle")}
fun metricValue(e:Entity,key:String):Double = when(key){"Fläche"->surfaceArea(e);"Umfang"->perimeter(e);"Gesamtlänge"->stairLength(e);"Gesamthöhe"->stairTotalHeight(e);"Stufenhöhe"->stairRise(e);"Stufentiefe"->stairDepth(e);"Auftritt"->stairGoing(e);"Überdeckung"->stairDepth(e)-stairGoing(e);"Anzahl"->stairCount(e).toDouble();"Stufengefälle","Gefälle"->e.num("slope",e.num("percent"));"Breite"->e.num("widthMm",entityBounds(e).width);"Höhe"->e.num("heightMm",entityBounds(e).height);"DN"->e.num("dnMm",e.num("DN"));else->if(closedContour(e))entityBounds(e).height else if(e.points.size>1)length(e.points)else e.num("widthMm")}
fun automaticMeasures(e:Entity,d:Drawing,profile:String):List<Entity>{
 val keys=when(profile){"Aus"->emptyList();"Minimal"->metrics(e).take(2);"Ausführung"->metrics(e).take(6);else->metrics(e)}
 return keys.mapIndexed{i,key->val at=entityBounds(e).max+Vec(d.sheet.scale*4,d.sheet.scale*(6+i*5));Entity(kind="dimension",points=listOf(at),layerId=e.layerId,placement=e.placement,params=buildJsonObject{put("sourceId",e.id);put("metric",key);put("prefix",key+" ");put("unit",when(key){"Fläche"->"m²";"Gefälle","Stufengefälle"->"%";"Anzahl"->"Stk";else->"cm"});put("decimals",2);put("auto",1);put("metricOriginX",at.x);put("metricOriginY",at.y)})}
}
fun dimensionLabel(e:Entity,d:Drawing):String {
 val source=d.entities.find{it.id==e.str("sourceId")};val value=if(source!=null&&e.str("metric").isNotEmpty())metricValue(source.copy(points=resolvedPoints(source,d)),e.str("metric"))else dimensionValue(e,d)
 val unit=e.str("unit","mm");val factor=when(unit){"cm"->10.0;"m"->1000.0;"m²"->1e6;else->1.0}
 return e.str("prefix",e.text)+fmt(value/factor,e.num("decimals",2.0).toInt().coerceIn(0,6))+e.str("suffix",if(unit.isEmpty())""else" $unit")
}
fun viewEntity(e:Entity,d:Drawing):Entity {
 var result=e.copy(points=resolvedPoints(e,d))
 if(e.kind=="component"){val off=smartViewOffset(e,d.viewMode());result=result.copy(points=result.points.map{it+off},rotation=smartViewRotation(e,d.viewMode()))}
 if(e.str("libraryViews")=="true")result=if(e.str("isStep")=="true")result.withNum("widthMm",stairDepth(e)).withNum("heightMm",e.num(if(d.viewMode()=="section")"stepHeightMm"else"stairWidthMm",1000.0))else result.withNum("widthMm",e.num(if(d.viewMode()=="section")"sectionWidthMm"else"topWidthMm",1000.0)).withNum("heightMm",e.num(if(d.viewMode()=="section")"sectionHeightMm"else"topHeightMm",500.0))
 if(isRetainingWall(e))result=if(d.viewMode()=="section")result.withNum("widthMm",e.num("footDepthMm",400.0)).withNum("heightMm",e.num("wallHeightMm",800.0))else result.withNum("widthMm",e.num("elementLengthMm",1000.0)).withNum("heightMm",e.num("footDepthMm",400.0))
 if(isPipe(e)){val dn=e.num("dnMm",100.0);val vertical=e.str("orientation","horizontal")=="vertical";result=if(d.viewMode()=="section")result.withNum("widthMm",dn).withNum("heightMm",if(vertical)e.num("verticalLengthMm",1000.0)else dn)else result.withNum("widthMm",if(vertical)dn else e.num("topWidthMm",1000.0)).withNum("heightMm",dn)}
 return result
}
fun viewBounds(e:Entity,d:Drawing)=when{isStair(e)->Bounds.of(stairReferencePoints(e,d.viewMode()));e.kind=="component"->Bounds.of(componentReferencePoints(e,d));else->entityBounds(viewEntity(e,d))}
fun objectLabelPosition(e:Entity,d:Drawing):Vec {
 val b=viewBounds(e,d);val center=b.center
 return if("labelDx" in e.params||"labelDy" in e.params)center+Vec(e.num("labelDx"),e.num("labelDy")) else Vec(center.x,b.min.y-d.sheet.scale*8.0)
}
fun componentReferencePoints(e:Entity,d:Drawing):List<Vec>{val v=viewEntity(e,d);val origin=v.points.firstOrNull()?:Vec();val b=entityBounds(v);return (rectangle(b.min,b.max)+b.center).map{val q=it-origin;origin+Vec(q.x,if(v.num("mirrored")==1.0)-q.y else q.y).rotate(v.rotation)}}
fun metricWitnesses(e:Entity,key:String,d:Drawing):List<Vec>? {
 if(isStair(e)){
  val pair=when(key){"Gesamtlänge"->Vec() to Vec(stairLength(e),0.0);"Gesamthöhe"->if(d.viewMode()=="section")Vec() to Vec(0.0,-stairTotalHeight(e))else return null;"Breite"->if(d.viewMode()=="top")Vec() to Vec(0.0,e.num("widthMm",1200.0))else return null;"Stufenhöhe"->if(d.viewMode()=="section")Vec() to Vec(0.0,-stairRise(e))else return null;"Stufentiefe"->Vec() to Vec(stairDepth(e),0.0);"Auftritt"->Vec() to Vec(stairGoing(e),0.0);"Überdeckung"->Vec(stairGoing(e),0.0) to Vec(stairDepth(e),0.0);else->return null}
  return listOf(assemblyPoint(e,pair.first,d.viewMode()),assemblyPoint(e,pair.second,d.viewMode()))
 }
 val pts=resolvedPoints(e,d);if(key=="Länge"&&!closedContour(e)&&pts.size==2)return pts
 val b=entityBounds(viewEntity(e,d));return when(key){"Breite"->listOf(b.min,Vec(b.max.x,b.min.y));"Länge","Höhe"->listOf(b.min,Vec(b.min.x,b.max.y));else->null}
}
