package de.baudetail.ui

import android.app.Application
import de.baudetail.ui.diagnostics.Diagnostics
import android.content.Intent
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.format.*
import de.baudetail.projects.*
import de.baudetail.libraries.*
import de.baudetail.export.*
import de.baudetail.ui.data.MetadataIndex
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import java.io.*

class BaudetailViewModel(app:Application):AndroidViewModel(app) {
 val store=ProjectStore(File(app.filesDir,"baudetail"))
 private val prefs=app.getSharedPreferences("baudetail",0)
 private val index=MetadataIndex(app)
 private val saveQueue=Channel<StoredProject>(Channel.UNLIMITED)
 private val histories=mutableMapOf<String,EditorHistory>()
 var project by mutableStateOf<Project?>(null);private set
 var drawingId by mutableStateOf("");private set
 val drawing:Drawing? get()=project?.drawings?.find{it.id==drawingId}
 var records by mutableStateOf<List<ProjectRecord>>(emptyList());private set
 var catalog by mutableStateOf(Catalog());private set
 var libraryVersion by mutableIntStateOf(0);private set
 var loading by mutableStateOf(true);private set
 var error by mutableStateOf<String?>(null)
 var notice by mutableStateOf<String?>(null)
 var setupComplete by mutableStateOf(prefs.getBoolean("setup",false));private set
 var theme by mutableStateOf(prefs.getString("theme","System")?:"System");private set
 var treeUri by mutableStateOf(prefs.getString("tree",null));private set
 var treeProblem by mutableStateOf(false);private set
 var treeStatus by mutableStateOf("Kein externer Ordner gewählt");private set
 var selected by mutableStateOf<Set<String>>(emptySet())
 var tool by mutableStateOf("select")
 var entryToPlace by mutableStateOf<LibraryEntry?>(null)
 var exportFormat by mutableStateOf("pdf")
 var exportDpi by mutableIntStateOf(300)
 var exportScale by mutableDoubleStateOf(50.0)
 var exportWidthMm by mutableDoubleStateOf(297.0)
 var exportHeightMm by mutableDoubleStateOf(210.0)
 var exportOriginX by mutableDoubleStateOf(0.0)
 var exportOriginY by mutableDoubleStateOf(0.0)
 private var exportDrawingId by mutableStateOf("")
 var transparent by mutableStateOf(false)
 var fullExport by mutableStateOf(true)
 var pendingPackage by mutableStateOf<OpenedPackage?>(null)
 var saving by mutableStateOf(false);private set
 private var dirtySaves=0
 val canUndo get()=histories[drawingId]?.canUndo==true
 val canRedo get()=histories[drawingId]?.canRedo==true
 init {
  viewModelScope.launch(Dispatchers.IO) {
   for(item in saveQueue) {
    try {store.save(item.project,item.histories);index.replace(store.list())}
    catch(e:Exception){withContext(Dispatchers.Main){error="Speichern fehlgeschlagen: ${e.message}. Projekt bleibt im Arbeitsspeicher."}}
    finally {withContext(Dispatchers.Main){dirtySaves--;saving=dirtySaves>0}}
   }
  }
  work {
   val result=withContext(Dispatchers.IO){
    var state=store.loadCatalog()
    index.replace(store.list());state to index.list()
   }
   catalog=Catalog(result.first);records=result.second;checkTree()
  }
 }
 fun work(block:suspend ()->Unit){viewModelScope.launch{loading=true;try{block()}catch(e:Exception){error=e.message?:"Vorgang fehlgeschlagen"}finally{loading=false}}}
 fun report(e:Throwable){Diagnostics.log("Fehler: ${e.javaClass.simpleName}");error=e.message?:"Vorgang fehlgeschlagen"}
 fun changeTheme(value:String){theme=value;prefs.edit().putString("theme",value).apply()}
 fun finishSetup(example:Boolean){work{if(example) installExample();prefs.edit().putBoolean("setup",true).commit();setupComplete=true;refresh()}}
 private suspend fun installExample(){val p=withContext(Dispatchers.IO){getApplication<Application>().assets.open("sample-project.bproject").use(Packages::read).let{pack->store.remap(pack.project(),store.importResources(pack))}};withContext(Dispatchers.IO){if(store.list().none{it.id==p.id})store.save(p)}}
 fun refresh(){work{records=withContext(Dispatchers.IO){index.replace(store.list());index.list()}}}
 fun open(id:String){work{val value=withContext(Dispatchers.IO){store.load(id)};activate(value)}}
 private fun activate(value:StoredProject){Diagnostics.projectId=value.project.id;Diagnostics.log("Projekt geöffnet");if(store.lastRecoveryCount>0)notice="${store.lastRecoveryCount} fehlerhafte Objekte wurden repariert oder übersprungen. Eine Kopie der Originaldatei wurde gesichert.";project=value.project;histories.clear();value.project.drawings.forEach{histories[it.id]=EditorHistory(value.histories[it.id]?:DrawingHistory(it))};drawingId=value.project.drawings.firstOrNull()?.id?:"";selected=emptySet()}
 fun createProject(name:String){val p=Project(name=name.trim().ifEmpty{"Neues Projekt"},createdAt=System.currentTimeMillis(),drawings=listOf(Drawing(createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis())));activate(StoredProject(p));persist()}
 fun openDrawing(id:String){if(project?.drawings?.any{it.id==id}==true){drawingId=id;Diagnostics.drawingId=id;Diagnostics.view=drawing?.type.orEmpty();Diagnostics.log("Zeichnung geöffnet");selected=emptySet();tool="select"}}
 var linkedSnap by mutableStateOf(false)
 fun edit(value:Drawing){try{val old=drawing?:return;if(value==old)return;val next=syncSmartFollowers(value).copy(updatedAt=System.currentTimeMillis());if(histories.getOrPut(old.id){EditorHistory(DrawingHistory(old))}.commit(next)){project=project?.copy(drawings=project!!.drawings.map{if(it.id==next.id)next else it});persist()}}catch(e:Exception){report(e)}}
 fun add(input:Entity){val shape=if(input.kind=="polyline"&&closedContour(input))asArea(input)else input;val e=if(linkedSnap&&shape.kind!="dimension"&&drawing!=null)shape.copy(bindings=shape.points.mapIndexedNotNull{i,p->anchorAt(p,drawing!!)?.let{PointBinding(i,it)}})else shape;Diagnostics.log("Objekt einfügen: ${e.kind}");val d=drawing?:return;if(d.layers.find{it.id==e.layerId}?.locked==true){error="Layer ist gesperrt";return};edit(d.copy(entities=d.entities+e));selected=setOf(e.id)}
 fun update(e:Entity){val d=drawing?:return;val old=d.entities.find{it.id==e.id}?:return;if(d.layers.find{it.id==old.layerId}?.locked==true){error="Layer ist gesperrt. Zuerst den Layer entsperren.";return};edit(d.copy(entities=d.entities.map{if(it.id==e.id)e else it}))}
 fun removeSelected(){val d=drawing?:return;val deletable=d.entities.filter{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true}.map{it.id}.toSet();edit(d.copy(entities=d.entities.filterNot{it.id in deletable}));selected=emptySet()}
 fun modifySelected(change:(Entity)->Entity){val d=drawing?:return;edit(d.copy(entities=d.entities.map{if(it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true)change(it)else it}))}
 fun moveSelected(delta:Vec,snap:SnapResult?=null,sourceOffset:Vec?=null){
  val d=drawing?:return;val one=selected.singleOrNull();val snapAnchor=snap?.anchor
  edit(d.copy(entities=d.entities.map{obj->
   if(obj.id !in selected||obj.locked||d.layers.find{it.id==obj.layerId}?.locked==true)obj else {
    var moved=if(obj.kind=="component"||isStair(obj)) moveSmartInView(obj,d.viewMode(),delta) else transform(obj,translation=delta)
    if(obj.id==one&&snapAnchor!=null&&moved.points.isNotEmpty()){
     val target=d.entities.find{it.id==snapAnchor.entityId}
     val smart=obj.kind=="component"||isStair(obj)
     fun prioRank(x:Entity?)=when(x?.str("snapPriority","normal")){"high"->0;"low"->2;else->1}
     val targetLeads=target!=null&&prioRank(target)<prioRank(obj)
     val origin=if(smart)smartViewOrigin(obj,d.viewMode()) else (obj.points.firstOrNull()?:Vec());val refs=if(smart)smartSnapReferencePoints(obj,d)else emptyList()
     val sourceIndex=sourceOffset?.let{off->refs.indexOfFirst{(it-origin).distance(off)<1e-4}}?:-1
     val sourceEdge=smartSnapEdgeIndexFromReferenceIndex(sourceIndex)
     val targetEdge=when(snapAnchor.reference){"smart","component"->smartSnapEdgeIndexFromReferenceIndex(snapAnchor.vertex);"smartEdge","edge"->snapAnchor.vertex.takeIf{it in 0..3};else->null}
     if(smart&&target!=null&&targetLeads&&sourceEdge!=null&&targetEdge!=null){
      val targetOutline=smartSnapOutline(target,d);val sourceOutline=smartSnapOutline(obj,d)
      if(targetOutline.size>=4&&sourceOutline.size>=4){
       val tv=targetOutline[(targetEdge+1)%4]-targetOutline[targetEdge];val sv=sourceOutline[(sourceEdge+1)%4]-sourceOutline[sourceEdge]
       fun parallelDelta(a:Double):Double{var x=((a+90.0)%180.0+180.0)%180.0-90.0;return x}
       val angle=parallelDelta(Math.toDegrees(kotlin.math.atan2(tv.y,tv.x)-kotlin.math.atan2(sv.y,sv.x)))
       moved=rotateSmartInView(moved,d.viewMode(),angle)
       moved=withSmartEdgeLength(moved,sourceEdge,tv.length(),d.viewMode())
       val sourceAfter=smartSnapOutline(moved,d);val sa=sourceAfter[sourceEdge];val sb=sourceAfter[(sourceEdge+1)%4]
       val ta=targetOutline[targetEdge];val tb=targetOutline[(targetEdge+1)%4]
       val reversed=sa.distance(tb)+sb.distance(ta)<sa.distance(ta)+sb.distance(tb)
       // Anchor the endpoint that does not move when this edge's length changes.
       val stableSourceCorner=intArrayOf(0,1,3,0)[sourceEdge];val sourceStarts=stableSourceCorner==sourceEdge
       val targetCorner=if(!reversed){if(sourceStarts)targetEdge else (targetEdge+1)%4}else{if(sourceStarts)(targetEdge+1)%4 else targetEdge}
       val targetPoint=targetOutline[targetCorner];val sourcePoint=sourceAfter[stableSourceCorner]
       val correction=targetPoint-sourcePoint;moved=moveSmartInView(moved,d.viewMode(),correction)
       moved=moved.withStr("followTargetId",target.id).withNum("followTargetEdge",targetEdge.toDouble()).withNum("followSourceEdge",sourceEdge.toDouble()).withNum("followSourceCorner",stableSourceCorner.toDouble()).withNum("followTargetCorner",targetCorner.toDouble()).withStr("followView",d.viewMode())
       // Smart links are represented by the semantic edge/corner relation above.
       // A global PointBinding would move both views together and is therefore
       // deliberately not created for these view-aware objects.
      }
     } else if(linkedSnap){
      val off=sourceOffset?:Vec();val binding=PointBinding(0,snapAnchor.copy(offset=Vec(-off.x,-off.y)));moved=moved.copy(bindings=moved.bindings.filterNot{it.vertex==0}+binding)
     }
    }
    moved
   }
  }))
 }

 fun duplicateSelected(){val d=drawing?:return;val map=selected.associateWith{uid()};val copies=d.entities.filter{it.id in selected}.map{e->transform(e,Vec(d.gridMm,d.gridMm)).copy(id=map.getValue(e.id),anchors=e.anchors.map{it.copy(entityId=map[it.entityId]?:it.entityId)},groupId=null)};edit(d.copy(entities=d.entities+copies));selected=copies.map{it.id}.toSet()}
 fun orderSelected(front:Boolean){val d=drawing?:return;val sel=d.entities.filter{it.id in selected};val rest=d.entities.filterNot{it.id in selected};edit(d.copy(entities=if(front)rest+sel else sel+rest))}
 fun undo(){histories[drawingId]?.let{it.undo();replaceCurrent(it.current)}}
 fun redo(){histories[drawingId]?.let{it.redo();replaceCurrent(it.current)}}
 private fun replaceCurrent(d:Drawing){project=project?.copy(drawings=project!!.drawings.map{if(it.id==d.id)d else it});selected=emptySet();persist()}
 fun backups()=histories[drawingId]?.persisted()?.backups.orEmpty()
 fun restoreBackup(index:Int){histories[drawingId]?.let{it.restore(index);replaceCurrent(it.current)}}
 fun persist(){val p=project?:return;dirtySaves++;saving=true;saveQueue.trySend(StoredProject(p,histories.mapValues{it.value.persisted()}))}
 fun updateProject(name:String,metadata:Map<String,String>,notes:String){project=project?.copy(name=name,metadata=metadata,notes=notes);persist()}
 fun addDrawing(name:String,type:String,variant:Boolean=false){val p=project?:return;val d=if(variant&&drawing!=null)drawing!!.copy(id=uid(),name=name,variantOf=drawingId,createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis())else Drawing(name=name,type=type,createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis());project=p.copy(drawings=p.drawings+d);histories[d.id]=EditorHistory(DrawingHistory(d));drawingId=d.id;selected=emptySet();persist()}
 fun renameHistory(redo:Boolean=false):Boolean = ((project?.extensions?.get(if(redo)"nameRedo"else"nameUndo") as? JsonArray)?.isNotEmpty()==true)
 fun undoProjectName(redo:Boolean=false){val p=project?:return;val from=if(redo)"nameRedo"else"nameUndo";val to=if(redo)"nameUndo"else"nameRedo";val names=(p.extensions[from] as? JsonArray).orEmpty();val name=(names.lastOrNull() as? JsonPrimitive)?.contentOrNull?:return
  project=p.copy(name=name,extensions=JsonObject(p.extensions+mapOf(from to JsonArray(names.dropLast(1)),to to JsonArray(((p.extensions[to] as? JsonArray).orEmpty()+JsonPrimitive(p.name)).takeLast(5)))))
  persist()
 }
 fun renameDrawing(id:String,name:String){val d=project?.drawings?.find{it.id==id}?:return;openDrawing(id);edit(d.copy(name=name.trim().ifBlank{d.name}))}
 fun duplicateDrawing(id:String){val d=project?.drawings?.find{it.id==id}?:return;val copy=d.copy(id=uid(),name=d.name+" (Kopie)",createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis());project=project?.copy(drawings=project!!.drawings+copy);histories[copy.id]=EditorHistory(DrawingHistory(copy));persist()}
 fun deleteDrawing(id:String){val p=project?:return;project=p.copy(drawings=p.drawings.filterNot{it.id==id}.map{d->d.copy(sourceDrawingId=d.sourceDrawingId?.takeUnless{it==id},entities=d.entities.map{e->if(e.targetDrawingId==id)e.copy(targetDrawingId=null)else e})});histories.remove(id);if(drawingId==id)drawingId=project?.drawings?.firstOrNull()?.id.orEmpty();persist()}
 fun projectAction(id:String,action:String,name:String=""){work{
  while(saving)delay(50)
  val stored=withContext(Dispatchers.IO){store.load(id)}
  when(action){
   "rename"->{val changed=stored.copy(project=stored.project.copy(name=name.trim().ifBlank{stored.project.name},extensions=JsonObject(stored.project.extensions+mapOf("nameUndo" to JsonArray(((stored.project.extensions["nameUndo"] as? JsonArray).orEmpty()+JsonPrimitive(stored.project.name)).takeLast(5)),"nameRedo" to JsonArray(emptyList())))));withContext(Dispatchers.IO){store.save(changed.project,changed.histories)};if(project?.id==id)activate(changed)}
   "duplicate"->{val p=stored.project;val mapping=p.drawings.associate{it.id to uid()};val copy=p.copy(id=uid(),name=p.name+" (Kopie)",drawings=p.drawings.map{d->d.copy(id=mapping.getValue(d.id),sourceDrawingId=mapping[d.sourceDrawingId],entities=d.entities.map{it.copy(targetDrawingId=mapping[it.targetDrawingId]?:it.targetDrawingId)})});withContext(Dispatchers.IO){store.save(copy)}}
   "delete"->{withContext(Dispatchers.IO){store.deleteProject(id)};if(project?.id==id){project=null;drawingId="";histories.clear()}}
  }
  records=withContext(Dispatchers.IO){store.list()}
 }}
 fun moveDrawing(id:String,targetId:String){work{
  while(saving)delay(50)
  val source=project?:return@work;val d=source.drawings.find{it.id==id}?:return@work
  require(source.id!=targetId){"Zielprojekt ist bereits das aktuelle Projekt"}
  withContext(Dispatchers.IO){val target=store.load(targetId);require(target.project.drawings.none{it.id==id}){"Zeichnungs-ID im Ziel vorhanden"};store.save(target.project.copy(drawings=target.project.drawings+d,libraryEntries=(target.project.libraryEntries+source.libraryEntries).distinctBy{it.id}),target.histories+(id to (histories[id]?.persisted()?:DrawingHistory(d))))}
  deleteDrawing(id)
 }}
 fun addRevision(title:String){val p=project?:return;project=p.copy(revisions=p.revisions+Revision(title=title,drawings=p.drawings));persist();notice="Revision unveränderbar gespeichert"}
 fun restoreRevision(id:String){val p=project?:return;val revision=p.revisions.find{it.id==id}?:return;val map=revision.drawings.associate{it.id to uid()};val copies=revision.drawings.map{d->d.copy(id=map.getValue(d.id),name=d.name+" · "+revision.title,sourceDrawingId=map[d.sourceDrawingId],entities=d.entities.map{it.copy(targetDrawingId=map[it.targetDrawingId]?:it.targetDrawingId)})};project=p.copy(drawings=p.drawings+copies);copies.forEach{histories[it.id]=EditorHistory(DrawingHistory(it))};drawingId=copies.firstOrNull()?.id?:drawingId;persist()}
 fun addSection(points:List<Vec>,label:String="A–A") {
  val p=project?:return;val d=drawing?:return;val cut=Drawing(name="Schnitt $label",type="Schnitt",createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis(),sourceDrawingId=d.id,sheet=Sheet(scale=10.0))
  project=p.copy(drawings=p.drawings+cut);histories[cut.id]=EditorHistory(DrawingHistory(cut))
  add(Entity(kind="section",points=points,text=label,targetDrawingId=cut.id))
 }
 fun attachLibraryForPlacedVariant(entry:LibraryEntry){val p=project?:return;project=p.copy(libraryEntries=p.libraryEntries.filterNot{it.id==entry.id}+entry);catalog.used(entry.id);saveCatalog();persist()}
 fun attachEntry(entry:LibraryEntry) {
  val p=project?:return;project=p.copy(libraryEntries=p.libraryEntries.filterNot{it.id==entry.id}+entry);catalog.used(entry.id);saveCatalog()
  if(entry.type=="material"){if(drawing?.entities?.none{it.id in selected&&closedContour(it)}!=false){notice="Zuerst eine geschlossene Fläche auswählen.";return};modifySelected{if(closedContour(it))it.copy(materialId=entry.id,materialSnapshot=null,quantityUnit="m²")else it}}
  else if(entry.type=="titleblock"||entry.type=="text-template") {if(entry.type=="titleblock")drawing?.let{edit(it.copy(sheet=it.sheet.copy(titleTemplate=entry.template?:"")))}else{entryToPlace=entry;tool="library"}}
  else {entryToPlace=entry;tool="library"}
 }
 fun saveStair(input:Entity,entry:LibraryEntry){val e=input.copy(children=listOf(componentInstance(entry,Vec())));require(stairGoing(e)>0&&stairGoing(e)<=stairDepth(e)){"Auftritt größer als Stufentiefe"};
  val p=project?:return
  project=p.copy(libraryEntries=p.libraryEntries.filterNot{it.id==entry.id}+entry)
  if(drawing?.entities?.any{it.id==e.id}==true)update(e)else add(e)
 }
 fun dissolveStair(e:Entity){val d=drawing?:return;val p=project?:return
  val steps=stairSteps(e,d,p)
  val refs=d.entities.map{obj->if(obj.id==e.id)obj else if(obj.anchors.any{it.entityId==e.id}||obj.bindings.any{it.anchor.entityId==e.id}||obj.str("sourceId")==e.id)obj.copy(points=resolvedPoints(obj,d),anchors=emptyList(),bindings=emptyList(),text=if(obj.kind=="dimension")dimensionLabel(obj,d)else obj.text,kind=if(obj.kind=="dimension")"text"else obj.kind,params=JsonObject(obj.params-setOf("sourceId","metric")))else obj}
  edit(d.copy(entities=refs.filterNot{it.id==e.id}+steps));selected=steps.map{it.id}.toSet()
 }
 fun placeEntry(at:Vec){val entry=entryToPlace?:return;add(when(entry.type){"text-template"->Entity(kind="text",points=listOf(at),text=entry.template?:entry.name);"assembly-template"->instantiateTemplate(entry,at);else->componentInstance(entry,at)})}
 fun saveAssembly(name:String,category:String="Eigene Bauwerke",updateId:String?=null){val d=drawing?:return;val items=d.entities.filter{it.id in selected};require(items.isNotEmpty()){"Objekte auswählen"};val origin=Bounds.of(items.flatMap{resolvedPoints(it,d)}).min
  fun freeze(e:Entity):Entity{val m=project?.libraryEntries?.find{it.id==e.materialId};val lib=project?.libraryEntries?.find{it.id==e.libraryId};var result=e.copy(points=resolvedPoints(e,d),bindings=emptyList(),materialSnapshot=m?.appearance?:m?.let{MaterialAppearance(top=it.style,section=it.style,sectionPattern=it.views["section"])},children=e.children.map(::freeze));lib?.views?.forEach{(k,v)->result=result.withStr("asset_"+k,v)};if(isStair(result)&&result.children.isEmpty()&&lib!=null)result=result.copy(children=listOf(componentInstance(lib,Vec())));return result}
  val entry=templateEntry(name,category,items.map(::freeze),origin,catalog.entries().find{it.id==updateId});catalog.import(LibraryPackage(entries=listOf(entry)),ConflictPolicy.REPLACE);saveCatalog();notice="Bauwerksvorlage gespeichert; vorhandene Instanzen bleiben unverändert."
 }
 fun editAssembly(entry:LibraryEntry){if(project==null)createProject("Vorlagenwerkstatt");addDrawing(entry.name+" · Vorlagen-Arbeitskopie","Freies Blatt");val d=drawing?:return;edit(d.copy(entities=entry.geometry,extensions=JsonObject(d.extensions+("editingTemplateId" to JsonPrimitive(entry.id)))));selected=entry.geometry.map{it.id}.toSet()}
 fun exportEntry(entry:LibraryEntry,uri:Uri){work{withContext(Dispatchers.IO){val resources=store.resources(Project(drawings=emptyList(),libraryEntries=listOf(entry)));getApplication<Application>().contentResolver.openOutputStream(uri,"wt")?.use{Packages.library(it,LibraryPackage(name=entry.name,entries=listOf(entry)),resources)}?:error("Datei nicht schreibbar")};notice="Bauwerk exportiert"}}
 fun setAutoMeasures(e:Entity,profile:String){val d=drawing?:return;val existing=d.entities.filter{it.str("sourceId")==e.id&&it.num("auto")==1.0};val fresh=automaticMeasures(e,d,profile).map{new->existing.find{it.str("metric")==new.str("metric")}?.withNum("hidden",0.0)?:new};edit(d.copy(entities=d.entities.filterNot{it in existing}+fresh))}
 fun detachConnections(e:Entity){val d=drawing?:return;update(e.copy(points=resolvedPoints(e,d),bindings=emptyList(),anchors=emptyList()))}
 fun saveSymbol(name:String){val d=drawing?:return;val entities=d.entities.filter{it.id in selected};if(entities.isEmpty())return
  val bounds=Bounds.of(entities.flatMap{listOf(entityBounds(it).min,entityBounds(it).max)})
  val entry=LibraryEntry(id=uid(),type="component",category="Eigene Bauteile",name=name,attributes=buildJsonObject{put("width_mm",bounds.width.coerceAtLeast(1.0));put("height_mm",bounds.height.coerceAtLeast(1.0))},geometry=entities.map{transform(it,translation=Vec()-bounds.min).copy(anchors=emptyList())})
  catalog.import(LibraryPackage(entries=listOf(entry)),ConflictPolicy.REPLACE);saveCatalog();work{writeEntryToTree(entry)}
 }
 private suspend fun writeEntryToTree(entry:LibraryEntry){withContext(Dispatchers.IO){val tree=treeUri?.let{DocumentFile.fromTreeUri(getApplication(),Uri.parse(it))};if(tree==null||!tree.canWrite()){withContext(Dispatchers.Main){notice="Bauteil intern gespeichert. Externen Ordner zum Synchronisieren einrichten."};return@withContext}
  val resources=store.resources(Project(drawings=emptyList(),libraryEntries=listOf(entry)))
  for((path,bytes) in resources) {
   require(Packages.safeName(path))
   val parts=path.split('/');var folder:DocumentFile=requireNotNull(tree)
   for(segment in parts.dropLast(1)) folder=folder.findFile(segment)?.takeIf{it.isDirectory} ?: folder.createDirectory(segment) ?: error("Ressourcenordner kann nicht angelegt werden")
   val target=folder.findFile(parts.last()) ?: folder.createFile("application/octet-stream",parts.last()) ?: error("Ressource kann nicht angelegt werden")
   getApplication<Application>().contentResolver.openOutputStream(target.uri,"wt")?.use{it.write(bytes)} ?: error("Ressource kann nicht geschrieben werden")
  }
  val file=tree.findFile("${entry.id}.json") ?: tree.createFile("application/json","${entry.id}.json")?:error("Bibliotheksdatei konnte nicht angelegt werden")
  getApplication<Application>().contentResolver.openOutputStream(file.uri,"wt")!!.use{it.write(BaudetailJson.encodeToString(entry).toByteArray())}
 }}
 fun saveCatalog(){libraryVersion++;val snapshot=catalog.state;viewModelScope.launch(Dispatchers.IO){runCatching{store.saveCatalog(snapshot)}.onFailure{withContext(Dispatchers.Main){report(it)}}}}
 fun chooseTree(uri:Uri){work{
  withContext(Dispatchers.IO){val cr=getApplication<Application>().contentResolver;val flags=Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
   try{cr.takePersistableUriPermission(uri,flags)}catch(e:SecurityException){cr.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
  }
  treeUri=uri.toString();prefs.edit().putString("tree",uri.toString()).commit();checkTree();reloadTree()
 }}
 suspend fun checkTree(){treeStatus=withContext(Dispatchers.IO){try{val u=treeUri?:return@withContext "Kein externer Ordner gewählt";val cr=getApplication<Application>().contentResolver;if(cr.persistedUriPermissions.none{it.uri.toString()==u&&it.isReadPermission})return@withContext "Zugriff verloren – Ordner erneut wählen";val doc=DocumentFile.fromTreeUri(getApplication(),Uri.parse(u));if(doc?.canRead()!=true)"Ordner nicht erreichbar – erneut wählen" else if(doc.canWrite())"Ordner erreichbar · Lesen und Schreiben"else"Ordner erreichbar · Nur Lesen"}catch(e:Exception){"Zugriff verloren – Ordner erneut wählen"}};treeProblem=treeUri!=null&&!treeStatus.startsWith("Ordner erreichbar")}
 fun reloadLibrary(){work{checkTree();reloadTree()}}
 private suspend fun reloadTree(){val u=treeUri?:return;val collected=withContext(Dispatchers.IO){
  val root=DocumentFile.fromTreeUri(getApplication(),Uri.parse(u))?:error("Bibliotheksordner fehlt");require(root.canRead()){ "Zugriff verloren. Ordner bitte erneut auswählen." }
  val found=mutableListOf<LibraryEntry>();val errors=mutableListOf<String>();var visited=0
  fun walk(dir:DocumentFile,depth:Int){require(depth<=64){"Bibliothek tiefer als 64 Ebenen"};for(f in dir.listFiles()){visited++;require(visited<=50000){"Bibliothek enthält zu viele Dateien"};if(f.isDirectory)walk(f,depth+1)else if(f.name?.endsWith(".bdlib",true)==true){runCatching{val pack=readPackage(f.uri);val mapping=store.importResources(pack);found.addAll(pack.library().entries.map{store.remap(it,mapping)})}.onFailure{errors.add("${f.name}: ${it.message}")}}else if(f.name?.endsWith(".json",true)==true){runCatching{
   val entry=BaudetailJson.decodeFromString<LibraryEntry>(readBytes(f.uri).toString(Charsets.UTF_8));val paths=mutableListOf<String>();paths.addAll(entry.views.values);entry.preview?.let(paths::add)
   entry.appearance?.sectionPattern?.let(paths::add)
   fun collect(e:Entity){e.materialSnapshot?.sectionPattern?.let(paths::add);e.params.filterKeys{it.startsWith("asset_")}.values.forEach{(it as? JsonPrimitive)?.contentOrNull?.let(paths::add)};e.asset?.let(paths::add);e.children.forEach(::collect)}
   entry.geometry.forEach(::collect)
   val mapping=paths.distinct().associateWith{path->require(Packages.safeName(path));var resource=dir;for(segment in path.split('/'))resource=resource.findFile(segment)?:error("Ressource fehlt: $path");store.putAsset(readBytes(resource.uri),path.substringAfterLast('.'))};found.add(store.remap(entry,mapping))
  }.onFailure{errors.add("${f.name}: ${it.message}")}}
  }}
  walk(root,0);found to errors
 }
 catalog.import(LibraryPackage(entries=collected.first),ConflictPolicy.REPLACE);saveCatalog();notice="${collected.first.size} Einträge eingelesen";if(collected.second.isNotEmpty())error=collected.second.take(8).joinToString("\n")
 }
 private fun readBytes(uri:Uri,limit:Int=64*1024*1024):ByteArray {
  val input=getApplication<Application>().contentResolver.openInputStream(uri)?:error("Datei nicht lesbar")
  input.use{val out=ByteArrayOutputStream();val buffer=ByteArray(8192);while(true){val n=it.read(buffer);if(n<0)break;require(out.size()+n<=limit){ "Datei zu groß" };out.write(buffer,0,n)};return out.toByteArray()}
 }
 private fun readPackage(uri:Uri):OpenedPackage = getApplication<Application>().contentResolver.openInputStream(uri)?.use(Packages::read)?:error("Datei nicht lesbar")
 fun stagePackage(uri:Uri){work{pendingPackage=withContext(Dispatchers.IO){readPackage(uri)}}}
 fun importPending(asCopy:Boolean=false,policy:ConflictPolicy=ConflictPolicy.KEEP){val pack=pendingPackage?:return;work{
  val mapping=withContext(Dispatchers.IO){store.importResources(pack)}
  when(pack.manifest.kind){
   "project"->{var p=store.remap(pack.project(),mapping);if(asCopy)p=p.copy(id=uid(),name=p.name+" (Kopie)");val existing=withContext(Dispatchers.IO){store.list().find{it.id==p.id}};if(existing!=null&&!asCopy){open(existing.id)}else{activate(StoredProject(p));persist()}}
   "drawing"->{val d=pack.drawing().let{it.copy(id=uid(),entities=it.entities.map{e->store.remap(e,mapping)})};if(project==null)createProject(pack.manifest.name);project=project!!.copy(drawings=project!!.drawings+d,libraryEntries=(project!!.libraryEntries+pack.drawingEntries().map{store.remap(it,mapping)}).distinctBy{it.id});histories[d.id]=EditorHistory(DrawingHistory(d));drawingId=d.id;persist()}
   "library"->{val lib=pack.library();catalog.import(lib.copy(entries=lib.entries.map{store.remap(it,mapping)}),policy);saveCatalog();notice="Bibliothek importiert"}
  };pendingPackage=null
 }}
 fun importBackground(uri:Uri,page:Int=0){work{
  val e=withContext(Dispatchers.IO){
   val bytes=readBytes(uri);val cr=getApplication<Application>().contentResolver;val mime=cr.getType(uri).orEmpty();var extension=when{mime.contains("pdf")||bytes.take(4).toByteArray().toString(Charsets.US_ASCII)=="%PDF"->"pdf";mime.contains("svg")||bytes.toString(Charsets.UTF_8).trimStart().startsWith("<")->"svg";else->"png"}
   var width=1000.0;var height=1000.0;var data=bytes;var originalAsset:String?=null
   if(extension=="pdf") {
    val original=store.putAsset(bytes,"pdf");originalAsset=original;val f=store.assetFile(original)
    ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY).use{fd->PdfRenderer(fd).use{r->require(page in 0 until r.pageCount){"PDF enthält ${r.pageCount} Seiten"};r.openPage(page).use{pg->val factor=minOf(2.0,4096.0/maxOf(pg.width,pg.height));val bmp=Bitmap.createBitmap((pg.width*factor).toInt().coerceAtLeast(1),(pg.height*factor).toInt().coerceAtLeast(1),Bitmap.Config.ARGB_8888);bmp.eraseColor(android.graphics.Color.WHITE);pg.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);val out=ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.PNG,100,out);data=out.toByteArray();width=pg.width.toDouble();height=pg.height.toDouble();bmp.recycle()}}};extension="png"
   } else if(extension=="svg"){sanitizeSvg(bytes.toString(Charsets.UTF_8));val svg=com.caverock.androidsvg.SVG.getFromString(bytes.toString(Charsets.UTF_8));val box=svg.documentViewBox;width=box?.width()?.toDouble()?:1000.0;height=box?.height()?.toDouble()?:1000.0}
   else {val options=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,options);require(options.outWidth>0){"Bildformat ungültig"};require(options.outWidth.toLong()*options.outHeight<=32000000){"Bild über 32 Megapixel. Bitte verkleinern."};width=options.outWidth.toDouble();height=options.outHeight.toDouble();extension=if(options.outMimeType=="image/jpeg")"jpg"else"png"}
   val path=store.putAsset(data,extension);Entity(kind="image",points=listOf(Vec()),asset=path,name="Hintergrund",locked=false,params=buildJsonObject{put("widthMm",width);put("heightMm",height);originalAsset?.let{put("sourceAsset",it)}},style=Style(opacity=0.7))
  };add(e);notice="Hintergrund eingefügt. Zwei Punkte über Kalibrieren auswählen."
 }}
 fun prepareExport(){val d=drawing?:return;if(exportDrawingId!=d.id){exportDrawingId=d.id;exportScale=d.sheet.scale;exportWidthMm=d.sheet.widthMm;exportHeightMm=d.sheet.heightMm;exportOriginX=d.sheet.origin.x;exportOriginY=d.sheet.origin.y}}
 fun exportDrawing():Drawing?{val d=drawing?:return null;prepareExport();return d.copy(sheet=d.sheet.copy(scale=exportScale.coerceAtLeast(.1),widthMm=exportWidthMm.coerceAtLeast(20.0),heightMm=exportHeightMm.coerceAtLeast(20.0),origin=Vec(exportOriginX,exportOriginY),showPaper=true))}
 fun setExportPaper(width:Double,height:Double){exportWidthMm=width;exportHeightMm=height}
 fun centerExport(){val d=exportDrawing()?:return;val visible=d.entities.filter{visibleIn(it,d)};if(visible.isEmpty())return;val b=Bounds.of(visible.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)});val printableW=(d.sheet.widthMm-20.0).coerceAtLeast(1.0)*d.sheet.scale;val printableH=(d.sheet.heightMm-42.0).coerceAtLeast(1.0)*d.sheet.scale;exportOriginX=b.center.x-printableW/2;exportOriginY=b.center.y-printableH/2}
 fun exportOverflow():Boolean{val d=exportDrawing()?:return false;val visible=d.entities.filter{visibleIn(it,d)};if(visible.isEmpty())return false;val b=Bounds.of(visible.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)});val box=Bounds(Vec(exportOriginX,exportOriginY),Vec(exportOriginX+(d.sheet.widthMm-20.0)*d.sheet.scale,exportOriginY+(d.sheet.heightMm-42.0)*d.sheet.scale));return !box.contains(b.min)||!box.contains(b.max)}
 private fun uriWithExtension(uri:Uri,format:String):Uri{val resolver=getApplication<Application>().contentResolver;val name=runCatching{resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())c.getString(0)else null}}.getOrNull().orEmpty();if(name.endsWith(".$format",true))return uri;val fixed=(name.substringBeforeLast('.',name).ifBlank{drawing?.name?:"Baudetail"})+".$format";return runCatching{DocumentsContract.renameDocument(resolver,uri,fixed)?:uri}.getOrDefault(uri)}
 fun exportTo(uri:Uri){val p=project?:return;val d=exportDrawing()?:return;val format=exportFormat;work{withContext(Dispatchers.IO){val target=uriWithExtension(uri,format);getApplication<Application>().contentResolver.openOutputStream(target,"wt")?.use{writeExport(it,format,p,d)}?:error("Datei kann nicht geschrieben werden")};notice="Export gespeichert"}}
 private fun writeExport(out:OutputStream,format:String,p:Project,d:Drawing){val service=ExportService(store::assetFile);when(format){"pdf"->service.pdf(out,d,p);"png"->service.png(out,d,p,exportDpi,transparent);"svg"->service.svg(out,d,p);"bproject"->Packages.project(out,p,if(fullExport)store.resources(p)else emptyMap(),fullExport);"bdetail"->Packages.drawing(out,d,store.resources(p.copy(drawings=listOf(d),revisions=emptyList())),p.libraryEntries);"bdlib"->{val entries=catalog.entries();val lib=LibraryPackage(name="Baudetail Bibliothek",entries=entries);val resources=store.resources(Project(drawings=emptyList(),libraryEntries=entries));Packages.library(out,lib,resources)};else->error("Unbekanntes Exportformat")}}
 fun share(onReady:(File)->Unit){val p=project?:return;val d=exportDrawing()?:return;work{val safe=d.name.replace(Regex("[\\/:*?\"<>|]"),"_").ifBlank{"Baudetail"};val file=withContext(Dispatchers.IO){File(getApplication<Application>().cacheDir,"exports/$safe.$exportFormat").also{it.parentFile!!.mkdirs();it.outputStream().use{out->writeExport(out,exportFormat,p,d)}}};onReady(file)}}
 override fun onCleared(){saveQueue.close();index.close();super.onCleared()}
}
