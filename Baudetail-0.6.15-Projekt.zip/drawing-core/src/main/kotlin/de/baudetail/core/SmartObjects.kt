package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*

/** Shared semantic family used for intelligent component replacement/rendering. */
fun LibraryEntry.smartFamily():String {
 val explicit=(attributes["component_family"] as? JsonPrimitive)?.contentOrNull.orEmpty()
 if(explicit.isNotBlank()) return explicit
 val key=(category+"/"+name).lowercase()
 return when {
  "rohre/" in key || "rohr" in key || "leitung" in key -> "pipe"
  "mauerbau" in key && ("l-stein" in key || "winkel" in key || "mauerscheib" in key) -> "retaining_wall"
  "einfassungen/borde" in key || "bord " in key -> "curb"
  "sinkkasten" in key || "einlaufkasten" in key -> "channel_box"
  "rinne" in key -> "channel"
  "rasen" in key -> "grass"
  else -> "component"
 }
}

fun Entity.smartFamily():String = str("componentFamily").ifBlank {
 when {
  isStair(this) -> "stair"
  else -> "component"
 }
}

fun LibraryEntry.attrNumber(vararg keys:String, default:Double=0.0):Double {
 for(key in keys) {
  val p=attributes[key] as? JsonPrimitive ?: continue
  p.doubleOrNull?.let { if(it.isFinite()) return it }
 }
 return default
}

fun LibraryEntry.variantGroup():String = (attributes["variant_group"] as? JsonPrimitive)?.contentOrNull
 ?: when(smartFamily()) {
  "pipe" -> category
  "curb" -> category
  "retaining_wall" -> "Mauerbau/Mauerscheiben"
  "channel" -> category
  "grass" -> category
  else -> category
 }

/** Swap a placed smart component to another compatible library entry while preserving its anchor/OK and editing state. */
fun replaceComponentVariant(old:Entity,entry:LibraryEntry):Entity {
 require(old.kind=="component") { "Nur Bauteile können typgleich ersetzt werden" }
 require(old.smartFamily()==entry.smartFamily() || old.smartFamily()=="component") { "Bauteil gehört zu einer anderen Kategorie" }
 val at=old.points.firstOrNull()?:Vec()
 val fresh=componentInstance(entry,at)
 val keepKeys=setOf("orientation","verticalDirection","verticalLengthMm","labelEnabled","labelMode","labelText","labelDx","labelDy","fillMode","fillTop","fillSection","snapPriority","withoutChamfer","chamferWidthMm","chamferDepthMm")
 val merged=fresh.params.toMutableMap()
 old.params.forEach { (k,v) -> if(k in keepKeys) merged[k]=v }
 return fresh.copy(
  id=old.id, layerId=old.layerId, status=old.status, rotation=old.rotation,
  locked=old.locked, groupId=old.groupId, placement=old.placement,
  style=old.style, materialId=old.materialId, materialSnapshot=old.materialSnapshot,
  quantityUnit=old.quantityUnit, extensions=old.extensions, bindings=old.bindings, anchors=old.anchors,
  params=JsonObject(merged)
 )
}

fun smartPivot(e:Entity):Vec = if((e.kind=="component" || isStair(e)) && e.points.isNotEmpty()) e.points.first() else entityBounds(e).center

/** Smart objects keep a separate 2D presentation pose per view.
 * Moving/rotating a component in plan therefore no longer destroys the already
 * arranged section (and vice versa). The base point remains the semantic model
 * origin; only the view offset/rotation is changed. */
fun smartViewOffset(e:Entity,view:String)=Vec(e.num("${view}Dx"),e.num("${view}Dy"))
fun smartViewRotation(e:Entity,view:String)=e.rotation+e.num("${view}RotationDelta")
fun smartViewOrigin(e:Entity,view:String)=(e.points.firstOrNull()?:Vec())+smartViewOffset(e,view)
fun smartPivot(e:Entity,d:Drawing):Vec = if(e.kind=="component"||isStair(e)) smartViewOrigin(e,d.viewMode()) else smartPivot(e)


fun curbHasChamfer(e:Entity):Boolean = e.smartFamily()=="curb" && e.str("withoutChamfer","false")!="true"
fun curbChamferWidthMm(e:Entity)=e.num("chamferWidthMm",3.0).coerceAtLeast(0.0)
fun curbChamferDepthMm(e:Entity)=e.num("chamferDepthMm",4.0).coerceAtLeast(0.0)

/** Visible curb cross-section. The chamfer is a drawing detail; snap geometry is
 * handled separately by curbSnapEndpointPoints/curbSnapReferencePoints. */
fun curbLocalOutline(e:Entity,view:String):List<Vec> {
 val w=if(view=="section")e.num("sectionWidthMm",e.num("widthMm",100.0)) else e.num("topWidthMm",e.num("widthMm",1000.0))
 val h=if(view=="section")e.num("sectionHeightMm",e.num("heightMm",200.0)) else e.num("topHeightMm",e.num("heightMm",100.0))
 if(view!="section"||!curbHasChamfer(e))return rectangle(Vec(),Vec(w,h))
 val cw=curbChamferWidthMm(e).coerceAtMost(w)
 val cd=curbChamferDepthMm(e).coerceAtMost(h)
 if(cw<=1e-9||cd<=1e-9)return rectangle(Vec(),Vec(w,h))
 return listOf(Vec(0.0,0.0),Vec(w-cw,0.0),Vec(w,cd),Vec(w,h),Vec(0.0,h))
}
fun curbWorldOutline(e:Entity,d:Drawing):List<Vec> {
 val v=viewEntity(e,d);val origin=v.points.firstOrNull()?:Vec();val mirrored=v.num("mirrored")==1.0
 return curbLocalOutline(v,d.viewMode()).map{q->origin+Vec(q.x,if(mirrored)-q.y else q.y).rotate(v.rotation)}
}


/** Snap geometry for curbs is deliberately simpler than the visible chamfer.
 * The chamfer remains a drawing detail. Logically the curb keeps its rectangular
 * installation edge plus exactly two useful height levels on the chamfer side:
 * OK curb and the lower chamfer level. */
fun curbCriticalSnapPoints(e:Entity,d:Drawing):List<Vec> {
 if(e.smartFamily()!="curb"||d.viewMode()!="section"||!curbHasChamfer(e))return emptyList()
 val v=viewEntity(e,d);val origin=v.points.firstOrNull()?:Vec();val mirrored=v.num("mirrored")==1.0
 val w=v.num("sectionWidthMm",v.num("widthMm",100.0));val h=v.num("sectionHeightMm",v.num("heightMm",200.0))
 val cw=curbChamferWidthMm(v).coerceIn(0.0,w);val cd=curbChamferDepthMm(v).coerceIn(0.0,h)
 fun world(q:Vec)=origin+Vec(q.x,if(mirrored)-q.y else q.y).rotate(v.rotation)
 // Exactly the two construction levels required in section: OK curb at the
 // start of the chamfer and the lower chamfer point. The diagonal itself is
 // deliberately not a snap segment.
 return listOf(world(Vec(w-cw,0.0)),world(Vec(w,cd))).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
}
fun curbSnapEndpointPoints(e:Entity,d:Drawing):List<Vec> {
 val r=componentReferencePoints(e,d).take(4)
 if(r.size<4)return r
 return (r+curbCriticalSnapPoints(e,d)).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
}
fun curbSnapReferencePoints(e:Entity,d:Drawing):List<Vec> {
 val r=componentReferencePoints(e,d).take(4);if(r.size<4)return r
 val b=Bounds.of(r);val mids=(0..3).map{i->(r[i]+r[(i+1)%4])*0.5}
 val extra=curbSnapEndpointPoints(e,d).drop(4)
 // Preserve the historic reference slots: corners 0..3, center 4, mids 5..8.
 // The optional lower chamfer level is appended after those stable slots.
 return (r+listOf(b.center)+mids+extra).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
}

fun isFrozenTemplate(e:Entity)=e.kind=="component"&&e.str("frozenTemplate")=="true"&&e.children.isNotEmpty()
private fun frozenTemplateScale(e:Entity)=e.num("templateScale",1.0).coerceAtLeast(1e-9)
fun frozenTemplatePoint(e:Entity,local:Vec,d:Drawing):Vec {
 val mirrored=if(e.num("mirrored")==1.0)Vec(local.x,-local.y)else local
 return smartViewOrigin(e,d.viewMode())+(mirrored*frozenTemplateScale(e)).rotate(smartViewRotation(e,d.viewMode()))
}
fun frozenTemplateBounds(e:Entity,d:Drawing):Bounds {
 if(!isFrozenTemplate(e))return entityBounds(e)
 val pts=e.children.filter{visibleIn(it,d)}.flatMap{child->
  val b=viewBounds(child,d)
  rectangle(b.min,b.max).map{frozenTemplatePoint(e,it,d)}
 }
 return if(pts.isEmpty())Bounds(smartViewOrigin(e,d.viewMode()),smartViewOrigin(e,d.viewMode())) else Bounds.of(pts)
}
fun frozenTemplateReferencePoints(e:Entity,d:Drawing):List<Vec> {
 val bounds=frozenTemplateBounds(e,d);val tol=1e-3
 val childRefs=e.children.filter{visibleIn(it,d)}.flatMap{child->
  val local=when{isStair(child)||child.kind=="component"->smartSnapReferencePoints(child,d);else->{val b=viewBounds(child,d);val c=rectangle(b.min,b.max);c+listOf(b.center)+c.indices.map{i->(c[i]+c[(i+1)%4])*0.5}}}
  local.map{frozenTemplatePoint(e,it,d)}
 }.filter{p->kotlin.math.abs(p.x-bounds.min.x)<tol||kotlin.math.abs(p.x-bounds.max.x)<tol||kotlin.math.abs(p.y-bounds.min.y)<tol||kotlin.math.abs(p.y-bounds.max.y)<tol}
 val c=rectangle(bounds.min,bounds.max);val mids=c.indices.map{i->(c[i]+c[(i+1)%4])*0.5}
 return (childRefs+c+mids+listOf(bounds.center)).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
}
fun moveSmartInView(e:Entity,view:String,delta:Vec):Entity =
 if(e.kind=="component"||isStair(e)) e.withNum("${view}Dx",e.num("${view}Dx")+delta.x).withNum("${view}Dy",e.num("${view}Dy")+delta.y) else transform(e,translation=delta)
fun rotateSmartInView(e:Entity,view:String,deltaDegrees:Double):Entity =
 if(e.kind=="component"||isStair(e)) e.withNum("${view}RotationDelta",e.num("${view}RotationDelta")+deltaDegrees) else transform(e,angle=deltaDegrees,center=smartPivot(e))

/** Outer construction rectangle used for intelligent component-to-component snapping.
 * Unlike the former generic point list this deliberately contains only the real
 * outside edges that may be used as an installation/reference edge. */
fun smartSnapOutline(e:Entity,d:Drawing):List<Vec> {
 val origin=e.points.firstOrNull()?:Vec()
 if(isStair(e)) {
  val local=if(d.viewMode()=="top") rectangle(Vec(),Vec(stairLength(e),e.num("widthMm",1200.0)))
   else stairVisibleSectionOutline(e)
  return local.map{assemblyPoint(e,it,d.viewMode())}
 }
 if(isFrozenTemplate(e)){val b=frozenTemplateBounds(e,d);return rectangle(b.min,b.max)}
 if(e.kind=="component") return componentReferencePoints(e,d).take(4)
 return rectangle(entityBounds(e).min,entityBounds(e).max)
}
fun smartSnapReferencePoints(e:Entity,d:Drawing):List<Vec> {
 if(isFrozenTemplate(e))return frozenTemplateReferencePoints(e,d)
 if(e.smartFamily()=="curb")return curbSnapReferencePoints(e,d)
 if(isKg2000(e))return kg2000Connectors(e,d).map{it.at}+listOf(viewBounds(e,d).center)
 if(isStair(e)){
  if(d.viewMode()=="section"){val seg=smartSnapSegments(e,d);val real=seg.flatMap{listOf(it.first,it.second)};val mids=seg.map{(a,b)->(a+b)*0.5};return (real+mids).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}}
  val real=stairReferencePoints(e,d.viewMode());val mids=real.zipWithNext().map{(a,b)->(a+b)*0.5}
  return (real+mids).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
 }
 val c=smartSnapOutline(e,d);if(c.size<2)return c
 val mids=c.indices.map{i->(c[i]+c[(i+1)%c.size])*0.5}
 return (c+Bounds.of(c).center+mids).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
}

/** Stable semantic snap points shared between plan and section.
 * These keys describe the *meaning* of a connection, not a screen coordinate.
 * A snap created in one view can therefore be resolved again in the other view. */
fun smartSemanticSnapPoints(e:Entity,d:Drawing):List<Pair<String,Vec>> {
 val out=mutableListOf<Pair<String,Vec>>()
 fun add(key:String,p:Vec){if(out.none{it.first==key})out+=key to p}
 if(isKg2000(e)){kg2000Connectors(e,d).forEachIndexed{i,c->add("connector:$i",c.at)}}
 if(isChannelBox(e)){channelBoxPipeConnectors(e,d).forEachIndexed{i,c->add("pipe:$i",c.at)}}
 val outline=smartSnapOutline(e,d)
 if(outline.size>=4){
  val c=outline.take(4)
  c.forEachIndexed{i,p->add("corner:$i",p)}
  c.indices.forEach{i->add("edgeMid:$i",(c[i]+c[(i+1)%4])*0.5)}
  add("center",Bounds.of(c).center)
 } else if(outline.isNotEmpty()) {
  outline.forEachIndexed{i,p->add("point:$i",p)}
  add("center",Bounds.of(outline).center)
 }
 if(isStair(e)){
  val b=Bounds.of(stairReferencePoints(e,d.viewMode()))
  add("stair:start",Vec(b.min.x,b.center.y));add("stair:end",Vec(b.max.x,b.center.y))
 }
 return out
}

/** Resolve an exact rendered snap to a stable semantic key.  Extra detail points
 * (for example the 3x4 mm curb chamfer) deliberately collapse to the nearest
 * construction key so the same connection still exists in plan. */
private fun smartRunFrame(e:Entity,d:Drawing):Triple<Vec,Vec,Vec>? {
 if(isStair(e)){
  val view=d.viewMode();val o=assemblyPoint(e,Vec(0.0,0.0),view);val x=assemblyPoint(e,Vec(stairLength(e),0.0),view)-o
  val y=if(view=="top")assemblyPoint(e,Vec(0.0,e.num("widthMm",1200.0)),view)-o else Vec(-x.y,x.x)
  return if(x.length()>1e-9)Triple(o,x,y)else null
 }
 if(e.kind=="component"){
  val c=componentReferencePoints(e,d).take(4);if(c.size<4)return null
  return Triple(c[0],c[1]-c[0],c[3]-c[0])
 }
 return null
}
private fun runSnapKey(e:Entity,d:Drawing,point:Vec):String? {
 val (o,x,_)=smartRunFrame(e,d)?:return null;val den=x.x*x.x+x.y*x.y;if(den<=1e-9)return null
 val q=point-o;val t=((q.x*x.x+q.y*x.y)/den).coerceIn(0.0,1.0)
 return "run:"+kotlin.math.round(t*1000000.0).toLong()
}
private fun crossSnapKey(e:Entity,d:Drawing,point:Vec):String? {
 if(e.kind!="component")return null
 val (o,x,_)=smartRunFrame(e,d)?:return null
 // In section the horizontal axis is the component width/cross direction.
 // This is the dimension that corresponds to the plan's lateral axis.
 val den=x.x*x.x+x.y*x.y;if(den<=1e-9)return null
 val q=point-o;val t=((q.x*x.x+q.y*x.y)/den).coerceIn(0.0,1.0)
 return "cross:"+kotlin.math.round(t*1000000.0).toLong()
}
private fun runSnapPoint(e:Entity,d:Drawing,key:String):Vec? {
 if(!key.startsWith("run:"))return null
 val t=key.substringAfter("run:").toLongOrNull()?.div(1000000.0)?.coerceIn(0.0,1.0)?:return null
 val (o,x,y)=smartRunFrame(e,d)?:return null
 return if(d.viewMode()=="top")o+x*t+y*0.5 else o+x*t
}
private fun crossSnapPoint(e:Entity,d:Drawing,key:String):Vec? {
 if(!key.startsWith("cross:")||e.kind!="component")return null
 val t=key.substringAfter("cross:").toLongOrNull()?.div(1000000.0)?.coerceIn(0.0,1.0)?:return null
 val (o,x,y)=smartRunFrame(e,d)?:return null
 return if(d.viewMode()=="section")o+x*t else o+y*t
}
private fun topCrossAxis(e:Entity,d:Drawing):Vec? {
 if(e.kind!="component")return null
 val frame=smartRunFrame(e,d.withViewMode("top"))?:return null
 return frame.third.takeIf{it.length()>1e-9}
}
private fun faceSnapKey(e:Entity,d:Drawing,point:Vec):String? {
 if(e.kind!="component")return null
 val frame=smartRunFrame(e,d)?:return null
 val (o,x,y)=frame
 val det=x.x*y.y-x.y*y.x
 if(kotlin.math.abs(det)<=1e-9)return null
 val q=point-o
 val tx=(q.x*y.y-q.y*y.x)/det
 val ty=(x.x*q.y-x.y*q.x)/det
 val ds=listOf(kotlin.math.abs(ty),kotlin.math.abs(1.0-tx),kotlin.math.abs(1.0-ty),kotlin.math.abs(tx))
 val side=ds.indices.minByOrNull{ds[it]}?:return null
 return "face:$side"
}
private fun faceSnapPoint(e:Entity,d:Drawing,key:String):Vec? {
 if(!key.startsWith("face:")||e.kind!="component")return null
 val side=key.substringAfter("face:").toIntOrNull()?.takeIf{it in 0..3}?:return null
 val c=componentReferencePoints(e,d).take(4);if(c.size<4)return null
 return (c[side]+c[(side+1)%4])*0.5
}
fun smartSemanticSnapKey(e:Entity,d:Drawing,point:Vec):String? {
 val semantic=smartSemanticSnapPoints(e,d)
 val named=semantic.filter{it.first.startsWith("connector:")||it.first.startsWith("pipe:")}.minByOrNull{it.second.distance(point)}
 if(named!=null&&named.second.distance(point)<1e-4)return named.first
 if(d.viewMode()=="section"){
  if(isStair(e))runSnapKey(e,d,point)?.let{return it}
  // A curb chamfer endpoint represents the lateral/cross side of the stone.
  // Resolve it semantically before the generic rectangular face mapping so the
  // same physical side survives a switch from section to plan.
  if(e.smartFamily()=="curb" && curbCriticalSnapPoints(e,d).any{it.distance(point)<1e-4})
   crossSnapKey(e,d,point)?.let{return it}
  if(e.kind=="component")faceSnapKey(e,d,point)?.let{return it}
 }
 if(semantic.isEmpty())return null
 return semantic.minByOrNull{it.second.distance(point)}?.first
}
fun smartSemanticSnapPoint(e:Entity,d:Drawing,key:String):Vec? = faceSnapPoint(e,d,key)?:runSnapPoint(e,d,key)?:crossSnapPoint(e,d,key)?:smartSemanticSnapPoints(e,d).firstOrNull{it.first==key}?.second

/** Source geometry used while dragging. Center points are deliberately excluded
 * for curbs/channel boxes: when a visible installation edge is brought to a
 * target, that edge must remain the reference instead of the whole component
 * suddenly jumping by its center/origin. */
fun smartDragSnapReferencePoints(e:Entity,d:Drawing):List<Vec> {
 if(e.smartFamily()=="curb"){
  // Dragging must use the physical five-point chamfer outline.  The old
  // rectangular top-right ghost corner must never become a drag reference.
  val r=curbWorldOutline(e,d)
  val mids=if(r.size>=2)r.indices.map{i->(r[i]+r[(i+1)%r.size])*.5}else emptyList()
  return (r+mids).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
 }
 if(isChannelBox(e)){
  val c=smartSnapOutline(e,d);val mids=if(c.size>=2)c.indices.map{i->(c[i]+c[(i+1)%c.size])*0.5}else emptyList()
  val pipes=channelBoxPipeConnectors(e,d).map{it.at}
  return (c+mids+pipes).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
 }
 return smartSnapReferencePoints(e,d)
}
fun smartDragSnapSegments(e:Entity,d:Drawing):List<Pair<Vec,Vec>> = smartSnapSegments(e,d)

fun smartSnapSegments(e:Entity,d:Drawing):List<Pair<Vec,Vec>> {
 if(e.smartFamily()=="curb"){
  val c=curbWorldOutline(e,d)
  return if(c.size>=3)c.indices.map{i->c[i] to c[(i+1)%c.size]}else c.zipWithNext()
 }
 if(isFrozenTemplate(e)){val c=smartSnapOutline(e,d);return if(c.size>=4)(0..3).map{i->c[i] to c[(i+1)%4]}else c.zipWithNext()}
 if(isStair(e)){
  val p=if(d.viewMode()=="section")stairVisibleSectionSegments(e).map{(a,b)->assemblyPoint(e,a,"section") to assemblyPoint(e,b,"section")} else stairReferencePoints(e,d.viewMode()).zipWithNext()
  return p
 }
 val c=smartSnapOutline(e,d);return if(c.size>=3)c.indices.map{i->c[i] to c[(i+1)%c.size]} else c.zipWithNext()
}
fun smartSnapEdgeIndexFromReferenceIndex(index:Int):Int? = if(index in 5..8) index-5 else null
fun smartEdgeLength(e:Entity,d:Drawing,index:Int):Double {val c=smartSnapOutline(e,d);return if(c.size>=4)c[index.mod(4)].distance(c[(index+1).mod(4)]) else 0.0}

/** Match the plan dimension represented by one outside edge. DN/pipe diameter is
 * intentionally never stretched by this mechanism. */
fun withSmartEdgeLength(e:Entity,edge:Int,length:Double,view:String):Entity {
 if(length<=0||!length.isFinite())return e
 if(isStair(e)) return if(edge%2==1)e.withNum("widthMm",length) else e
 if(e.kind!="component"||isPipe(e))return e
 val horizontal=edge%2==0
 return when {
  isRetainingWall(e)&&view=="top" -> if(horizontal)e.withNum("elementLengthMm",length).withNum("topWidthMm",length) else e.withNum("footDepthMm",length).withNum("topHeightMm",length)
  view=="top" -> if(horizontal)e.withNum("topWidthMm",length) else e.withNum("topHeightMm",length)
  else -> if(horizontal)e.withNum("sectionWidthMm",length) else e.withNum("sectionHeightMm",length)
 }
}


private fun sectionFaceToTopEdge(key:String):Int? {
 if(!key.startsWith("face:"))return null
 // A component's section rectangle and plan rectangle share the same logical
 // outside faces. In particular left/right in section are the longitudinal
 // start/end faces in plan. The previous 90° remap stacked curb/channel chains
 // beside the stair instead of preserving their installation order.
 return key.substringAfter("face:").toIntOrNull()?.takeIf{it in 0..3}
}
private fun topCornerForEdgeEnd(edge:Int,end:Int):Int = when(edge.mod(4)){
 0->if(end==0)0 else 1
 1->if(end==0)1 else 2
 2->if(end==0)3 else 2
 else->if(end==0)0 else 3
}
private fun parallelDeltaDegrees(a:Vec,b:Vec):Double {
 if(a.length()<=1e-9||b.length()<=1e-9)return 0.0
 val raw=Math.toDegrees(kotlin.math.atan2(b.y,b.x)-kotlin.math.atan2(a.y,a.x))
 return ((raw+90.0)%180.0+180.0)%180.0-90.0
}

private fun directedDeltaDegrees(a:Vec,b:Vec):Double {
 if(a.length()<=1e-9||b.length()<=1e-9)return 0.0
 var raw=Math.toDegrees(kotlin.math.atan2(b.y,b.x)-kotlin.math.atan2(a.y,a.x))
 while(raw>180.0)raw-=360.0
 while(raw<=-180.0)raw+=360.0
 return raw
}
private fun projectedExtent(points:List<Vec>,axis:Vec):Double {
 val u=axis*(1.0/axis.length().coerceAtLeast(1e-9))
 val q=points.map{it.x*u.x+it.y*u.y}
 return (q.maxOrNull()?:0.0)-(q.minOrNull()?:0.0)
}

/** Rebuild the plan arrangement of a smart detail from the relations that were
 * actually created in section.  A section is an installation chain: its run
 * coordinate becomes the stair run coordinate in plan, while each component is
 * rotated so the plan dimension matching its section thickness lies on that
 * run.  This is intentionally relation based -- old arbitrary top-view offsets
 * are not reused. */
private fun normalizeSectionLinkedPlanLayout(input:Drawing):Drawing {
 var d=input
 val sec=d.withViewMode("section");val top=d.withViewMode("top")
 val byId=d.entities.associateBy{it.id}
 val graph=mutableMapOf<String,MutableSet<String>>()
 d.entities.forEach{e->
  if(e.str("viewLinkCreatedView")=="section"){
   val t=e.str("viewLinkTargetId")
   if(t.isNotBlank()&&t in byId){graph.getOrPut(e.id){mutableSetOf()}.add(t);graph.getOrPut(t){mutableSetOf()}.add(e.id)}
  }
 }
 val processed=mutableSetOf<String>()
 for(stair in d.entities.filter(::isStair)){
  if(stair.id in processed)continue
  val ids=mutableSetOf(stair.id);val queue=java.util.ArrayDeque<String>();queue.add(stair.id)
  while(queue.isNotEmpty()){val id=queue.removeFirst();graph[id].orEmpty().forEach{if(ids.add(it))queue.add(it)}}
  if(ids.size<=1)continue
  processed+=ids
  val secFrame=smartRunFrame(stair,sec)?:continue;val topFrame=smartRunFrame(stair,top)?:continue
  val secRun=secFrame.second;val topRun=topFrame.second;if(secRun.length()<=1e-9||topRun.length()<=1e-9)continue
  val secUnit=secRun*(1.0/secRun.length());val runUnit=topRun*(1.0/topRun.length())
  val cross=topFrame.third;val crossUnit=if(cross.length()>1e-9)cross*(1.0/cross.length()) else Vec(-runUnit.y,runUnit.x)
  val topCrossCenter=topFrame.first+cross*.5
  fun secScalar(e:Entity):Double{val c=Bounds.of(smartSnapOutline(e,sec)).center;val q=c-secFrame.first;return q.x*secUnit.x+q.y*secUnit.y}

  // First place all solid smart components.  The section thickness decides
  // which plan dimension runs along the stair axis.  For a curb this naturally
  // rotates its long 1 m axis across the stair, leaving its 8 cm thickness in
  // the Bord -> Kasten -> Bord -> Treppe chain.
  var entities=d.entities
  for(id in ids){
   val original=entities.find{it.id==id}?:continue
   if(id==stair.id||original.kind!="component"||isKg2000(original))continue
   var e=original
   val secOutline=smartSnapOutline(e,sec);if(secOutline.size<4)continue
   val secExtent=projectedExtent(secOutline,secRun)
   val frame=smartRunFrame(e,top)?:continue
   val useX=kotlin.math.abs(frame.second.length()-secExtent)<=kotlin.math.abs(frame.third.length()-secExtent)
   val desiredX=if(useX)runUnit else crossUnit
   val angle=parallelDeltaDegrees(frame.second,desiredX)
   if(kotlin.math.abs(angle)>1e-7)e=rotateSmartInView(e,"top",angle)
   val scalar=secScalar(e)
   val desiredCenter=topCrossCenter+runUnit*scalar
   val center=Bounds.of(smartSnapOutline(e,top)).center
   val correction=desiredCenter-center
   if(correction.length()>1e-7)e=moveSmartInView(e,"top",correction)
   entities=entities.map{if(it.id==id)e else it}
   d=d.copy(entities=entities)
  }

  // Pipes are infrastructure behind the visible kerb/channel detail.  Their
  // semantic connector remains exact, but in plan the first pipe leaves from
  // the box centre and runs away from the stair. Subsequent pieces continue in
  // that same direction instead of inheriting a mirrored section orientation.
  repeat(6){
   var pipeChanged=false
   for(id in ids){
    val original=d.entities.find{it.id==id}?:continue
    if(!isKg2000(original))continue
    val target=d.entities.find{it.id==original.str("viewLinkTargetId")}?:continue
    if(target.id !in ids)continue
    val sourceIndex=original.str("viewLinkSourceKey").substringAfter("connector:","").toIntOrNull()?:continue
    var e=original
    val sourceBefore=kg2000Connectors(e,top).getOrNull(sourceIndex)?:continue
    val rootBox=when{isChannelBox(target)->target;else->ids.asSequence().mapNotNull{rid->d.entities.find{it.id==rid}}.firstOrNull(::isChannelBox)}
    val sign=if(rootBox!=null&&secScalar(rootBox)>=0.0)1.0 else -1.0
    val away=runUnit*sign
    val centerBefore=viewBounds(e,top).center
    val fromConnector=centerBefore-sourceBefore.at
    if(fromConnector.length()>1e-9){
     val angle=directedDeltaDegrees(fromConnector,away)
     if(kotlin.math.abs(angle)>1e-7)e=rotateSmartInView(e,"top",angle)
    }
    val sc=kg2000Connectors(e,top).getOrNull(sourceIndex)?:continue
    val targetPoint=if(isChannelBox(target))viewBounds(target,top).center else {
     val tk=original.str("viewLinkTargetKey")
     val ti=tk.substringAfter("connector:","").toIntOrNull()
     if(ti!=null&&isKg2000(target))kg2000Connectors(target,top).getOrNull(ti)?.at else null
    }?:continue
    val correction=targetPoint-sc.at
    if(correction.length()>1e-7)e=moveSmartInView(e,"top",correction)
    if(e!=original){d=d.copy(entities=d.entities.map{if(it.id==id)e else it});pipeChanged=true}
   }
   if(!pipeChanged)return@repeat
  }
 }
 return d
}

/** Keep linked smart objects connected in BOTH plan and section while preserving
 * their independent view layout. Plan edges may inherit the leading edge length
 * (e.g. 1000 mm stair width -> 1000 mm lawn connection); section thicknesses
 * are never stretched to a stair height. */
fun syncSmartFollowers(input:Drawing):Drawing {
 var d=input
 repeat(4){
  var changed=false
  val next=d.entities.map{e->
   val edgeTargetId=e.str("followTargetId")
   val semanticTargetId=e.str("viewLinkTargetId")
   val targetId=semanticTargetId.ifBlank{edgeTargetId}
   if(targetId.isBlank())return@map e
   val target=d.entities.find{it.id==targetId}?:return@map e
   val sourceEdge=e.num("followSourceEdge",-1.0).toInt()
   val targetEdge=e.num("followTargetEdge",-1.0).toInt()
   val sourceKey=e.str("viewLinkSourceKey")
   val targetKey=e.str("viewLinkTargetKey")
   val createdView=e.str("viewLinkCreatedView")
   val semanticSectionFaces=createdView=="section"&&sourceKey.startsWith("face:")&&targetKey.startsWith("face:")
   var n=e
   for(view in listOf("top","section")){
    val vd=d.withViewMode(view)
    // Keep classic edge-follow behaviour, except where a newer semantic section
    // relation explicitly owns the plan placement. This prevents two competing
    // systems from moving the same curb/rain-channel chain in plan.
    if(edgeTargetId.isNotBlank()&&sourceEdge in 0..3&&targetEdge in 0..3&&!(view=="top"&&semanticSectionFaces)){
     var sourceOutline=smartSnapOutline(n,vd);val targetOutline=smartSnapOutline(target,vd)
     if(sourceOutline.size>=4&&targetOutline.size>=4){
      val tv=targetOutline[(targetEdge+1)%4]-targetOutline[targetEdge]
      val sv=sourceOutline[(sourceEdge+1)%4]-sourceOutline[sourceEdge]
      if(tv.length()>1e-9&&sv.length()>1e-9){
       val angle=parallelDeltaDegrees(sv,tv)
       if(kotlin.math.abs(angle)>1e-7)n=rotateSmartInView(n,view,angle)
      }
      if(view=="top")n=withSmartEdgeLength(n,sourceEdge,tv.length(),view)
      sourceOutline=smartSnapOutline(n,vd)
      val sourceCorner=e.num("followSourceCorner",sourceEdge.toDouble()).toInt().coerceIn(0,3)
      val targetCorner=e.num("followTargetCorner",targetEdge.toDouble()).toInt().coerceIn(0,3)
      val correction=targetOutline[targetCorner]-sourceOutline[sourceCorner]
      if(correction.length()>1e-7)n=moveSmartInView(n,view,correction)
     }
    }

    if(view=="top"&&createdView=="section"&&isKg2000(n)&&(isChannelBox(target)||isKg2000(target))&&sourceKey.startsWith("connector:")){
     // A pipe connection made in section remains a real connector connection
     // in plan.  Align connector directions as opposites, then put the two
     // connector points exactly on top of each other.  For a sink box with the
     // default left outlet this produces the required 90° branch to the left.
     val sourceIndex=sourceKey.substringAfter("connector:").toIntOrNull()
     val targetIndex=when{
      targetKey.startsWith("pipe:")->targetKey.substringAfter("pipe:").toIntOrNull()
      targetKey.startsWith("connector:")->targetKey.substringAfter("connector:").toIntOrNull()
      else->null
     }
     if(sourceIndex!=null&&targetIndex!=null){
      var sc=kg2000Connectors(n,vd).getOrNull(sourceIndex)
      val tc=if(isChannelBox(target))channelBoxPipeConnectors(target,vd).getOrNull(targetIndex) else kg2000Connectors(target,vd).getOrNull(targetIndex)
      if(sc!=null&&tc!=null){
       if(isChannelBox(target)){
        // For a sink/inlet box the plan branch leaves from the box centre and
        // runs at 90° to the curb/channel chain. With a stair in the connected
        // detail this is the negative stair-run direction (left in the normal
        // plan view), exactly as the real KG outlet is expected to leave.
        val boxCenter=viewBounds(target,vd).center
        // In plan the outlet leaves the sink/inlet box from its centre to the
        // left. This is independent of the longitudinal section orientation;
        // subsequent KG2000 pieces then inherit the connector chain end-to-end.
        val away=viewBounds(n,vd).center-sc.at
        val desired=Vec(-1.0,0.0)
        var angle=Math.toDegrees(kotlin.math.atan2(desired.y,desired.x)-kotlin.math.atan2(away.y,away.x))
        while(angle>180.0)angle-=360.0;while(angle<=-180.0)angle+=360.0
        if(kotlin.math.abs(angle)>1e-7)n=rotateSmartInView(n,"top",angle)
        sc=kg2000Connectors(n,vd).getOrNull(sourceIndex)
        if(sc!=null){val correction=boxCenter-sc.at;if(correction.length()>1e-7)n=moveSmartInView(n,"top",correction)}
       }else{
        var delta=(tc.direction+180.0)-sc.direction
        while(delta>180.0)delta-=360.0;while(delta<=-180.0)delta+=360.0
        if(kotlin.math.abs(delta)>1e-7)n=rotateSmartInView(n,"top",delta)
        sc=kg2000Connectors(n,vd).getOrNull(sourceIndex)
        if(sc!=null){val correction=tc.at-sc.at;if(correction.length()>1e-7)n=moveSmartInView(n,"top",correction)}
       }
      }
     }
    } else if(view=="top"&&createdView=="section"&&target.let(::isStair)&&n.kind=="component"){
     // Section order becomes the real installation order in plan. A curb/channel
     // that touches the stair is placed in front of the stair, on the same run
     // axis, rather than being rotated onto the stair-width axis.
     val frame=smartRunFrame(target,vd)
     val sourceEdge=sectionFaceToTopEdge(sourceKey)
     if(frame!=null&&sourceEdge!=null){
      val (o,run,_)=frame
      var sourceOutline=smartSnapOutline(n,vd)
      if(sourceOutline.size>=4&&run.length()>1e-9){
       val sourceLong=sourceOutline[1]-sourceOutline[0]
       val angle=parallelDeltaDegrees(sourceLong,run)
       if(kotlin.math.abs(angle)>1e-7)n=rotateSmartInView(n,"top",angle)
       sourceOutline=smartSnapOutline(n,vd)
       val a=sourceOutline[sourceEdge];val b=sourceOutline[(sourceEdge+1)%4]
       val sourceContact=(a+b)*0.5
       val targetContact=when(targetKey){
        "stair:end"->o+run
        else->o
       }
       val correction=targetContact-sourceContact
       if(correction.length()>1e-7)n=moveSmartInView(n,"top",correction)
      }
     }
    } else if(view=="top"&&semanticSectionFaces){
     val se=sectionFaceToTopEdge(sourceKey)
     val te=sectionFaceToTopEdge(targetKey)
     if(se!=null&&te!=null){
      var sourceOutline=smartSnapOutline(n,vd);val targetOutline=smartSnapOutline(target,vd)
      if(sourceOutline.size>=4&&targetOutline.size>=4){
       // Preserve the exact installation chain from the section in plan:
       // right face -> left face stays right -> left, left -> right stays left
       // -> right.  Align the longitudinal axes first, then snap face midpoints.
       val sv=sourceOutline[1]-sourceOutline[0]
       val tv=targetOutline[1]-targetOutline[0]
       val angle=parallelDeltaDegrees(sv,tv)
       if(kotlin.math.abs(angle)>1e-7)n=rotateSmartInView(n,"top",angle)
       sourceOutline=smartSnapOutline(n,vd)
       val sourceContact=(sourceOutline[se]+sourceOutline[(se+1)%4])*.5
       val targetContact=(targetOutline[te]+targetOutline[(te+1)%4])*.5
       val correction=targetContact-sourceContact
       if(correction.length()>1e-7)n=moveSmartInView(n,"top",correction)
      }
     }
    } else if(view=="top"&&createdView=="section"&&sourceKey.isNotBlank()&&targetKey.isNotBlank()){
     // Remaining semantic links keep the point-based helper.
     val sourcePoint=smartSemanticSnapPoint(n,vd,sourceKey)
     val targetPoint=smartSemanticSnapPoint(target,vd,targetKey)
     if(sourcePoint!=null&&targetPoint!=null){
      val correction=targetPoint-sourcePoint
      if(correction.length()>1e-7)n=moveSmartInView(n,view,correction)
     }
    }
   }
   if(n!=e)changed=true
   n
  }
  d=d.copy(entities=next)
  if(!changed)return normalizeSectionLinkedPlanLayout(d)
 }
 return normalizeSectionLinkedPlanLayout(d)
}

fun retainingWallSection(e:Entity):List<Vec> {
 val h=e.num("wallHeightMm",e.num("sectionHeightMm",800.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("sectionWidthMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val slab=e.num("footThicknessMm",100.0).coerceIn(1.0,h)
 val side=e.str("footSide","right")
 val pts=if(side=="left") listOf(Vec(foot,0.0),Vec(foot-wall,0.0),Vec(foot-wall,h-slab),Vec(0.0,h-slab),Vec(0.0,h),Vec(foot,h))
 else listOf(Vec(0.0,0.0),Vec(wall,0.0),Vec(wall,h-slab),Vec(foot,h-slab),Vec(foot,h),Vec(0.0,h))
 return pts
}

fun retainingWallTop(e:Entity):Pair<List<Vec>,List<Vec>> {
 val length=e.num("elementLengthMm",e.num("topWidthMm",1000.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("topHeightMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val wallRect=rectangle(Vec(),Vec(length,wall))
 val footRect=rectangle(Vec(),Vec(length,foot))
 return wallRect to footRect
}

fun isPipe(e:Entity)=e.kind=="component"&&e.smartFamily()=="pipe"
fun isKg2000(e:Entity)=isPipe(e)&&e.str("pipeSystem").equals("KG2000",true)
data class PipeConnector(val at:Vec,val kind:String,val dnMm:Double,val direction:Double)
fun kg2000DnValues()=listOf(110.0,125.0,160.0,200.0,250.0,315.0,400.0,500.0,630.0)
/** Manufacturer-drawing envelope values used only for the visible socket collar.
 * The semantic connector remains at the socket mouth so the installed length
 * is exactly the user-entered pipe length on a scaled print. */
fun kg2000SocketOuterDnMm(dn:Double)=when(dn.toInt()){110->129.2;125->147.8;160->186.1;200->229.0;250->285.2;315->361.5;400->455.0;500->569.0;630->715.0;else->dn*1.15}
fun kg2000SocketProjectionMm(dn:Double)=when(dn.toInt()){110->74.0;125->82.0;160->95.0;200->108.0;250->132.0;315->144.0;400->175.0;500->200.0;630->220.0;else->dn*.65}
fun kg2000ReducerPairs()=listOf(125 to 110,160 to 110,160 to 125,200 to 160,250 to 200,315 to 250,400 to 315,500 to 400,630 to 500)
fun kg2000Y45Pairs()=listOf(110 to 110,125 to 110,160 to 110,200 to 110,125 to 125,160 to 125,160 to 160,200 to 160,200 to 200,250 to 160,250 to 250,315 to 160,315 to 200,315 to 315,400 to 160,400 to 200,400 to 315,400 to 400,500 to 160,500 to 315,500 to 500,630 to 160,630 to 200)
fun kg2000BendAngles(dn:Int)=when(dn){110,125,160->listOf(15.0,30.0,45.0,67.5,87.5);200,250,315,400->listOf(15.0,30.0,45.0,87.5);500->listOf(15.0,30.0,45.0);630->listOf(15.0,45.0);else->listOf(15.0,30.0,45.0,87.5)}

data class Kg2000BendGeometry(val path:List<Vec>,val socket:Vec,val spigot:Vec,val socketDirection:Double,val spigotDirection:Double)
private fun bendDesiredDirection(e:Entity,view:String):Double? {
 if(view!="section") return null
 return when(e.str("bendDirection",e.str("verticalDirection","down"))){
  "up","oben" -> -90.0
  "left","links" -> 180.0
  "right","rechts" -> 0.0
  else -> 90.0
 }
}
fun kg2000BendGeometry(e:Entity,view:String):Kg2000BendGeometry{
 val dn=e.num("dnMm",160.0).coerceAtLeast(1.0)
 val thetaDeg=e.num("bendAngle",45.0).coerceIn(1.0,179.0)
 val theta=Math.toRadians(thetaDeg)
 // A KG2000 bend is modelled as the same pipe centreline, only curved.
 // Keep a short straight socket/spigot leg and use a circular centreline arc between them.
 val leg=maxOf(dn*.42,45.0)
 val radius=maxOf(dn*.9,e.num("bendRadiusMm",dn*1.25))
 val steps=maxOf(8,kotlin.math.ceil(thetaDeg/5.0).toInt())
 val base=mutableListOf(Vec(),Vec(leg,0.0))
 for(i in 1..steps){
  val t=theta*i/steps
  base+=Vec(leg+radius*kotlin.math.sin(t),radius*(1.0-kotlin.math.cos(t)))
 }
 val arcEnd=base.last()
 val end=arcEnd+Vec(leg*kotlin.math.cos(theta),leg*kotlin.math.sin(theta))
 base+=end
 val desired=bendDesiredDirection(e,view)
 val rotateBy=if(desired==null)0.0 else desired-thetaDeg
 val pts=if(kotlin.math.abs(rotateBy)<1e-9)base else base.map{it.rotate(rotateBy)}
 val socket=pts.first();val spigot=pts.last()
 return Kg2000BendGeometry(pts,socket,spigot,180.0+rotateBy,thetaDeg+rotateBy)
}
fun kg2000ReducerLengthMm(big:Int,small:Int)=mapOf(125 to 110 to 176.5,160 to 110 to 210.5,160 to 125 to 211.0,200 to 160 to 254.0,250 to 200 to 303.0,315 to 250 to 349.0,400 to 315 to 425.0,500 to 400 to 691.0,630 to 500 to 660.0)[big to small]
fun kg2000Connectors(e:Entity,d:Drawing):List<PipeConnector>{
 if(!isKg2000(e))return emptyList()
 val origin=smartViewOrigin(e,d.viewMode())
 fun world(v:Vec):Vec{val m=if(e.num("mirrored")==1.0)Vec(v.x,-v.y)else v;return origin+m.rotate(smartViewRotation(e,d.viewMode()))}
 val dn=e.num("dnMm",160.0);val type=e.str("fittingType","pipe")
 val len=if(type=="reducer")kg2000ReducerLengthMm(e.num("inletDnMm",160.0).toInt(),e.num("outletDnMm",110.0).toInt())?:e.num("pipeLengthMm",250.0) else e.num("pipeLengthMm",1000.0).coerceAtLeast(1.0)
 val local=when(type){
  "bend"->{val g=kg2000BendGeometry(e,d.viewMode());listOf(PipeConnector(g.socket,"socket",dn,g.socketDirection),PipeConnector(g.spigot,"spigot",dn,g.spigotDirection))}
  "y"->{val a=Math.toRadians(45.0);listOf(PipeConnector(Vec(),"socket",dn,180.0),PipeConnector(Vec(len,0.0),"spigot",dn,0.0),PipeConnector(Vec(len*.55+len*.45*kotlin.math.cos(a),len*.45*kotlin.math.sin(a)),"spigot",e.num("branchDnMm",dn),45.0))}
  // Real KG2000 eccentric reducer: large side = spigot, small side = socket.
  "reducer"->{val big=e.num("inletDnMm",160.0);val small=e.num("outletDnMm",110.0);val offset=(big-small)/2.0;listOf(PipeConnector(Vec(),"spigot",big,180.0),PipeConnector(Vec(len,offset),"socket",small,0.0))}
  // The visual pipe rectangle starts at y=0, therefore its physical centreline is dn/2.
  "double_spigot"->listOf(PipeConnector(Vec(0.0,dn/2.0),"spigot",dn,180.0),PipeConnector(Vec(len,dn/2.0),"spigot",dn,0.0))
  else->listOf(PipeConnector(Vec(0.0,dn/2.0),"socket",dn,180.0),PipeConnector(Vec(len,dn/2.0),"spigot",dn,0.0))
 }
 return local.map{val localDir=if(e.num("mirrored")==1.0)-it.direction else it.direction;it.copy(at=world(it.at),direction=localDir+smartViewRotation(e,d.viewMode()))}
}
fun channelBoxPipeConnectors(e:Entity,d:Drawing):List<PipeConnector>{
 if(!isChannelBox(e))return emptyList();val side=e.str("pipeOutlet","left");if(side=="none")return emptyList()
 val origin=smartViewOrigin(e,d.viewMode());val dn=e.num("pipeDnMm",160.0);val local=if(d.viewMode()=="section"){
  val x=if(side=="left")0.0 else e.num("boxWidthMm",185.0);Vec(x,e.num("pipeAxisFromTopMm",500.0))
 }else{
  val x=if(side=="left")0.0 else e.num("boxLengthMm",500.0);Vec(x,e.num("boxWidthMm",185.0)/2)
 }
 val dir=if(side=="left")180.0 else 0.0;return listOf(PipeConnector(origin+local.rotate(smartViewRotation(e,d.viewMode())),"socket",dn,dir+smartViewRotation(e,d.viewMode())))
}
fun kg2000Compatible(a:PipeConnector,b:PipeConnector)=a.kind!=b.kind&&kotlin.math.abs(a.dnMm-b.dnMm)<0.5
fun kg2000ConnectorOccupied(target:PipeConnector,targetEntityId:String,d:Drawing,ignore:Set<String> = emptySet()):Boolean{
 val eps=1.0
 return d.entities.asSequence().filter{it.id!=targetEntityId&&it.id !in ignore&&(isKg2000(it)||isChannelBox(it))}.flatMap{other->
  (if(isKg2000(other))kg2000Connectors(other,d)else channelBoxPipeConnectors(other,d)).asSequence()
 }.any{other->other.at.distance(target.at)<=eps&&kg2000Compatible(other,target)}
}
fun kg2000Bounds(e:Entity,d:Drawing):Bounds{
 val cons=kg2000Connectors(e,d);if(cons.isEmpty())return Bounds.of(componentReferencePoints(e,d))
 val dn=maxOf(e.num("dnMm",110.0),e.num("inletDnMm",0.0),e.num("outletDnMm",0.0),e.num("branchDnMm",0.0));val pad=dn*.75
 val pts=when(e.str("fittingType","pipe")){
  "bend"->kg2000BendGeometry(e,d.viewMode()).path.map{local->smartViewOrigin(e,d.viewMode())+(if(e.num("mirrored")==1.0)Vec(local.x,-local.y)else local).rotate(smartViewRotation(e,d.viewMode()))}
  else->cons.map{it.at}
 }
 val b=Bounds.of(pts);return Bounds(b.min-Vec(pad,pad),b.max+Vec(pad,pad))
}
fun isChannelBox(e:Entity)=e.kind=="component"&&e.smartFamily()=="channel_box"
fun isRetainingWall(e:Entity)=e.kind=="component"&&e.smartFamily()=="retaining_wall"
