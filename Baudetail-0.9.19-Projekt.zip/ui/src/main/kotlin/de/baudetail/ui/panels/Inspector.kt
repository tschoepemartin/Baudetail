package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

private data class GodelmannVariant(val id:String,val product:String,val color:String,val surface:String,val image:String)
private fun loadGodelmannVariants(vm:BaudetailViewModel):List<GodelmannVariant> =
 (vm.catalog.entries()+vm.project?.libraryEntries.orEmpty()).distinctBy{it.id}.mapNotNull { entry ->
  val meta=entry.extensions["baudetailManufacturer"] as? JsonObject ?: return@mapNotNull null
  fun field(key:String)=(meta[key] as? JsonPrimitive)?.contentOrNull.orEmpty()
  if(!field("manufacturer").equals("Godelmann",true))return@mapNotNull null
  val asset=(entry.extensions["baudetailTextureTop"] as? JsonPrimitive)?.contentOrNull.orEmpty()
  if(asset.isBlank())return@mapNotNull null
  GodelmannVariant(entry.id,field("product"),field("color"),field("surface"),asset)
 }.distinctBy{it.id}.sortedWith(compareBy({it.product},{it.color},{it.surface}))

/** Identical dimension/slope controls for paving and grass construction sections. */
private fun buildUpMeasureFields(e:Entity,grass:Boolean=false):List<Field> {
 val section=e.num("buildUpSectionLengthMm",if(grass)e.num("grassSectionLengthMm",Bounds.of(e.points).width) else e.num("topDepthMm",1000.0))
 return listOf(
  Field("sectionWidth","Grafische Breite Schnitt mm (Querschnitt)",fmt(e.num("buildUpSectionWidthMm",if(grass)Bounds.of(e.points).height else e.num("widthMm",1500.0))),true,true),
  Field("realWidth","Tatsächliche Breite mm",fmt(e.num("buildUpRealWidthMm",if(grass)Bounds.of(e.points).height else e.num("widthMm",1500.0))),true,true),
  Field("sectionLength","Grafische Länge Schnitt mm",fmt(section),true,true),
  Field("realLengthEnabled","Realmaß abweichend",if(e.str("buildUpRealLengthEnabled","false")=="true")"ja" else "nein",checkbox=true),
  Field("realLength","Tatsächliche Länge mm",fmt(buildUpRealLengthMm(e.withNum("buildUpSectionLengthMm",section))),true,true),
  Field("slopePct","Gefälle % (0 = eben)",fmt(kotlin.math.abs(buildUpSlopePercent(e))),true),
  Field("slopeDirection","Gefällerichtung im Schnitt",if(buildUpSlopePercent(e)<0)"Nach links fallend" else "Nach rechts fallend",choices=listOf("Nach links fallend","Nach rechts fallend")),
  Field("slopeFixedSide",if(grass)"Fixpunkt der Rasenoberkante" else "Fixpunkt der Pflasteroberkante",if(e.str("buildUpSlopeFixedSide","left")=="right")"Rechts" else "Links",choices=listOf("Links","Rechts")),
  Field("slopeLabelDx","Gefällepfeil verschieben X mm",fmt(e.num("buildUpSlopeLabelDx")),true),
  Field("slopeLabelDy","Gefällepfeil verschieben Y mm",fmt(e.num("buildUpSlopeLabelDy")),true)
 )
}

@Composable fun Inspector(vm:BaudetailViewModel,onCalibrate:()->Unit,onResizeChange:(Boolean)->Unit={},onAddCut:(String)->Unit={}){val d=vm.drawing?:return;val e=d.entities.find{it.id in vm.selected}
 val godelmannVariants=remember(vm.libraryVersion){loadGodelmannVariants(vm)};var dialog by remember{mutableStateOf("")};var resizing by remember{mutableStateOf(false)};val selectedCount=vm.selected.size
 val libraryEntry=e?.libraryId?.let{id->(vm.catalog.entries()+vm.project!!.libraryEntries).distinctBy{it.id}.find{it.id==id}}
 val buildUp=e?.withBuildUpDefaults(libraryEntry)
 // Keep the slider in its original layout slot throughout the gesture.
 // Hiding other controls with alpha (rather than removing their layout) prevents
 // the slider from jumping underneath the user's thumb.
 Column(Modifier.fillMaxWidth().background(if(resizing)Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow).heightIn(max=650.dp).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
 if(e!=null&&!e.locked&&(e.kind in setOf("elevation","text","leader","dimension","slope")||labelActive(e,d)||e.isParametricBuildUp())){
  val slopeLabelMode=((e.isParametricBuildUp() || e.str("grassObject")=="true") && d.viewMode()=="section" && kotlin.math.abs(buildUpSlopePercent(e))>1e-8) || (e.kind=="dimension" && e.str("metric")=="Stufengefälle") || e.kind=="slope"
  val sizeKey=if((e.isParametricBuildUp() || e.str("grassObject")=="true") && slopeLabelMode)"buildUpSlopeLabelScalePct" else "annotationScalePct"
  val pct=e.num(sizeKey,if(e.kind=="elevation")35.0 else if(e.kind=="dimension"&&e.str("metric")=="Stufengefälle")50.0 else 100.0).toFloat().coerceIn(1f,100f)
  Text("${if(slopeLabelMode)"Gefällepfeilgröße" else "Beschriftungsgröße"}: ${pct.toInt()} %")
  Slider(value=pct,onValueChange={if(!resizing){resizing=true;onResizeChange(true)};vm.update(e.withNum(sizeKey,it.toDouble()))},onValueChangeFinished={resizing=false;onResizeChange(false)},valueRange=1f..100f)
 }
 Column(Modifier.alpha(if(resizing)0f else 1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Text(if(e==null)"Eigenschaften"else"${e.name.ifBlank{e.kind}} · $selectedCount gewählt",style=MaterialTheme.typography.titleLarge)
 if(e==null){Text("Tippe ein Objekt an. Lange tippen erweitert die Auswahl.");return@Column}
 Row{Checkbox(e.locked,{vm.update(e.copy(locked=it))});Text("Objekt sperren",Modifier.padding(top=12.dp))}
 Row{Checkbox(e.placement.visibleSection,{vm.update(e.copy(placement=e.placement.copy(visibleSection=it)))});Text("Im Schnitt anzeigen",Modifier.padding(top=12.dp))}
 Row{Checkbox(e.placement.visibleTop,{vm.update(e.copy(placement=e.placement.copy(visibleTop=it)))});Text("In Draufsicht anzeigen",Modifier.padding(top=12.dp))}
 if(e.kind=="component"||isStair(e)||isFoundation(e)){Row{Checkbox(e.str("editMode","false")=="true",{vm.update(e.withStr("editMode",it.toString()))});Text("Bearbeiten · Geometriegriffe",Modifier.padding(top=12.dp))}}
 if(e.smartFamily()=="curb"){Row{Checkbox(e.str("withoutChamfer","false")=="true",{vm.update(e.withStr("withoutChamfer",it.toString()))});Text("Ohne Phase",Modifier.padding(top=12.dp))}}
 if(e.kind in setOf("area","polygon","rect","building"))Text("Fläche ${fmt(area(e.points)/1e6)} m² · Umfang ${fmt(length(e.points,true)/1000)} m")
 if(e.kind=="hedge")Text("${hedgeCount(length(e.points),e.num("spacingMm",400.0))} Pflanzen · ${fmt(length(e.points)/1000)} m")
 if(e.kind=="dimension")Text("Maß: ${fmt(dimensionValue(e,d))}")
 if(e.kind=="slope")Text("Gefälle: ${slopeLabel(e,d)}")
 if(e.kind=="section")e.targetDrawingId?.let{target->Button(onClick={vm.openDrawing(target)}){Text("Verknüpften Schnitt öffnen")}}
 if(!e.locked && d.viewMode()=="top" && planFootprint(e,d).size>=3 && e.kind !in setOf("plan-height","elevation")) {
  HorizontalDivider()
  Text("Höhen Draufsicht",style=MaterialTheme.typography.titleMedium)
  val cornerKeys=listOf("planZTopLeftMm","planZTopRightMm","planZBottomLeftMm","planZBottomRightMm")
  val cornerLabels=listOf("Höhe oben links (m)","Höhe oben rechts (m)","Höhe unten links (m)","Höhe unten rechts (m)")
  var all by remember(e.id){mutableStateOf(e.str("planZOverallEnabled","false")=="true")}
  var overall by remember(e.id){mutableStateOf(fmt(e.num("planZOverallMm",e.num("planHeightMm",0.0))/1000.0))}
  var corners by remember(e.id){mutableStateOf(cornerKeys.map{key->fmt(e.num(key,e.num("planHeightMm",0.0))/1000.0)})}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
   Checkbox(checked=all,onCheckedChange={checked->all=checked;if(checked)corners=List(4){overall}})
   Text("Gesamt – einheitliche Höhe")
  }
  OutlinedTextField(value=overall,onValueChange={value->overall=value;if(all)corners=List(4){value}},label={Text("Gesamthöhe (m)")},enabled=all,singleLine=true,modifier=Modifier.fillMaxWidth())
  cornerLabels.forEachIndexed{index,label->
   OutlinedTextField(value=corners[index],onValueChange={value->corners=corners.toMutableList().also{it[index]=value}},label={Text(label)},enabled=!all,singleLine=true,modifier=Modifier.fillMaxWidth())
  }
  Button(onClick={
   val numbers=if(all)List(4){parseNumber(overall)}else corners.map{parseNumber(it)}
   if(numbers.all{it!=null}){
    var updated=e.withStr("planZOverallEnabled",all.toString())
    if(all)updated=updated.withNum("planZOverallMm",numbers[0]!!*1000.0)
    cornerKeys.forEachIndexed{index,key->updated=updated.withNum(key,numbers[index]!!*1000.0)}
    vm.update(updated)
   }
  },modifier=Modifier.fillMaxWidth()){Text("Höhen übernehmen")}
 }
 if(!e.locked){
  OutlinedButton(onClick={dialog="level"}){Text("Ebene / Höhen / Sichtbarkeit")}
  if(closedContour(e)){Text("${fmt(surfaceArea(e)/1e6)} m² · ${fmt(perimeter(e)/1000)} m");OutlinedButton(onClick={vm.update(asArea(e))}){Text("In Fläche umwandeln")}}
  OutlinedButton(onClick={dialog="autoMeasuresSection"}){Text("Automatische Maße – Schnitt")}
  OutlinedButton(onClick={dialog="autoMeasuresTop"}){Text("Automatische Maße – Draufsicht")}
  if(e.kind=="dimension"){OutlinedButton(onClick={dialog="measureFormat"}){Text("Maßtext und Maßlinie bearbeiten")};OutlinedButton(onClick={dialog="dimensionRotation"}){Text("Drehmodus / Winkelsnap")}}

  
  if(e.kind=="legend")OutlinedButton(onClick={dialog="legendEdit"},modifier=Modifier.fillMaxWidth()){Text("Legende bearbeiten")}
  if(isFoundation(e))Text(if(e.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil")
  if(e.bindings.isNotEmpty())OutlinedButton(onClick={vm.detachConnections(e)}){Text("Dauerhafte Anschlüsse lösen")}
  OutlinedButton(onClick={dialog="saveAssembly"}){Text("Als Bauwerk speichern")}
  if(d.extensions["editingTemplateId"]!=null)OutlinedButton(onClick={dialog="updateAssembly"}){Text("Globale Vorlage aktualisieren")}

  if(isStair(e))OutlinedButton(onClick={vm.dissolveStair(e)}){Text("Baugruppe auflösen")}
  if(isFrozenTemplate(e))OutlinedButton(onClick={vm.dissolveTemplate(e)},modifier=Modifier.fillMaxWidth()){Text("Bauwerk auflösen")}

  if(e.kind=="component")OutlinedButton(onClick={dialog="variant"},modifier=Modifier.fillMaxWidth()){Text("Bauteiltyp / Variante ändern")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(if(isStair(e)&&e.str("labelExplicit")!="true")true else e.str("labelEnabled")=="true",{vm.update(e.withStr("labelEnabled",it.toString()).withStr("labelExplicit","true"))});Text("Beschriftung aktiv")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(e.str("labelVisibleSection","true")=="true",{vm.update(e.withStr("labelVisibleSection",it.toString()))});Text("Beschriftung im Schnitt")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(e.str("labelVisibleTop",if(e.isParametricBuildUp()||isStair(e))"false" else "true")=="true",{vm.update(e.withStr("labelVisibleTop",it.toString()))});Text("Beschriftung in Draufsicht")}
  OutlinedButton(onClick={dialog="label"},modifier=Modifier.fillMaxWidth()){Text("Beschriftung bearbeiten / positionieren")}
  if(e.kind=="component"||isStair(e))OutlinedButton(onClick={dialog="snapPriority"},modifier=Modifier.fillMaxWidth()){Text("Snap-Priorität / Referenz")}
  if(supportsFoundation(e)){
   val foundation=foundationFor(e,d);Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(foundation!=null,{vm.setUnderfoundation(e,it)});Text("Unterfundament C20/25")}

  }
  if(closedContour(e))OutlinedButton(onClick={dialog="fillMaterial"},modifier=Modifier.fillMaxWidth()){Text("Füllung / Material zuordnen")}
  if(closedContour(e))OutlinedButton(onClick={dialog="fillSettings"},modifier=Modifier.fillMaxWidth()){Text("Füllungsdarstellung in Ansichten")}
  if(isPipe(e))OutlinedButton(onClick={dialog="pipe"},modifier=Modifier.fillMaxWidth()){Text("Rohr-/Leitungsorientierung")}
  if(isKg2000(e))OutlinedButton(onClick={dialog="kg2000"},modifier=Modifier.fillMaxWidth()){Text("KG 2000 · DN / Formstück / Gefälle")}
  if(isRetainingWall(e))OutlinedButton(onClick={dialog="retaining"},modifier=Modifier.fillMaxWidth()){Text("Mauerscheiben-Abmessungen")}
  if(e.kind in setOf("text","leader","arrow","legend","section")||e.text.isNotBlank())OutlinedButton(onClick={dialog="textEdit"},modifier=Modifier.fillMaxWidth()){Text("Text bearbeiten")}
  if(e.kind in setOf("rect","building","circle","line")&&(e.kind!="building"||e.points.size==4))Button(onClick={dialog="geometry"},modifier=Modifier.fillMaxWidth()){Text("Geometrie: Maße und Position")}
  Button(onClick={dialog="properties"},modifier=Modifier.fillMaxWidth()){Text("Maße, Position und Attribute")}
  OutlinedButton(onClick={dialog="points"},modifier=Modifier.fillMaxWidth()){Text("Eckpunkte numerisch bearbeiten")}
  OutlinedButton(onClick={dialog="style"},modifier=Modifier.fillMaxWidth()){Text("Darstellung und Text")}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={dialog="layer"}){Text("Layer")};OutlinedButton(onClick={dialog="transform"}){Text("Transformieren")}}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=vm::duplicateSelected){Text("Duplizieren")};OutlinedButton(onClick=vm::removeSelected){Text("Löschen")}}
  Text("Ebenenreihenfolge")
  Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
   TextButton(onClick={vm.modifySelected{it.withStr("layerOrderMode","auto")}}){Text("Automatisch")}
   TextButton(onClick={vm.modifySelected{it.withStr("layerOrderMode","back")};vm.orderSelected(false)}){Text("Nach hinten")}
   TextButton(onClick={vm.modifySelected{it.withStr("layerOrderMode","front")};vm.orderSelected(true)}){Text("Nach vorne")}
  }
  Text("Aktuell: "+when(e.str("layerOrderMode","auto")){"front"->"Nach vorne";"back"->"Nach hinten";else->"Automatisch"})
  Row{TextButton(onClick={val id=uid();vm.modifySelected{it.copy(groupId=id)}}){Text("Gruppieren")};TextButton(onClick={vm.modifySelected{it.copy(groupId=null)}}){Text("Gruppe lösen")}}
  if(isSteelEdge(e))Button(onClick={dialog="steelEdgeSettings"},modifier=Modifier.fillMaxWidth()){Text("Stahlkante anpassen")}
  if(e.str("masonryWall")=="true")Button(onClick={dialog="masonryWallSettings"},modifier=Modifier.fillMaxWidth()){Text("Mauer anpassen")}
  if(e.kind=="hedge"){
   Button(onClick={dialog="hedgeSettings"},modifier=Modifier.fillMaxWidth()){Text("Hecke anpassen")}
   Button(onClick={dialog="brunsPicker"},modifier=Modifier.fillMaxWidth()){Text("Pflanzenart aus Bruns-Katalog wählen")}
  }
  if(e.str("plantingArea")=="true")Button(onClick={dialog="plantingSettings"},modifier=Modifier.fillMaxWidth()){Text("Pflanzfläche · Schichtaufbau bearbeiten")}
  if(e.str("eavesStrip")=="true")Button(onClick={dialog="eavesSettings"},modifier=Modifier.fillMaxWidth()){Text("Traufe · Kiesstreifen und Schichten bearbeiten")}
  if(e.str("grassObject")=="true")Button(onClick={dialog="grassSettings"},modifier=Modifier.fillMaxWidth()){Text("Rasen bearbeiten")}
  if(e.kind=="elevation")Button(onClick={dialog="elevationEdit"},modifier=Modifier.fillMaxWidth()){Text("Höhenkote bearbeiten")}
  OutlinedButton(onClick={dialog="symbol"}){Text("Als Bauteil speichern")}
  if(e.kind=="text")OutlinedButton(onClick={dialog="textLink"}){Text("Text an Objekt koppeln")}
  if(e.kind=="image")OutlinedButton(onClick=onCalibrate){Text("Kalibrieren: 2 Punkte")}
  if(e.kind in setOf("area","rect","polygon"))OutlinedButton(onClick={dialog="pattern"}){Text("Verlegemuster")}
  if(isStair(e))Button(onClick={dialog="stair"},modifier=Modifier.fillMaxWidth()){Text("Treppe anpassen")}
  if(isFoundation(e))Button(onClick={dialog="foundationObjectSettings"},modifier=Modifier.fillMaxWidth()){Text("Unterfundament anpassen")}
  if(supportsFoundation(e)&&foundationFor(e,d)!=null)Button(onClick={dialog="foundationSettings"},modifier=Modifier.fillMaxWidth()){Text("Unterfundament einstellen")}
  if(isPlanter(e))Button(onClick={dialog="planter"},modifier=Modifier.fillMaxWidth()){Text("Pflanztrog einstellen")}
  if(isLightwell(e))Button(onClick={dialog="lightwell"},modifier=Modifier.fillMaxWidth()){Text("Lichtschacht einstellen")}
  if(isChannelBox(e))Button(onClick={dialog="channelBox"},modifier=Modifier.fillMaxWidth()){Text(if(e.str("channelType","box")=="facade" || e.name.contains("Fassadenrinne",true))"Rinne einstellen" else "Einlauf-/Sinkkasten einstellen")}
  if(buildUp?.isParametricBuildUp(libraryEntry)==true)Button(onClick={dialog="stackEdit"},modifier=Modifier.fillMaxWidth()){Text(libraryEntry?.buildUpEditorTitle()?:e.str("buildUpEditorTitle","Aufbau anpassen"))}
  if(e.str("pavingCutOwner").isNotBlank())Button(onClick={dialog="cutSettings"},modifier=Modifier.fillMaxWidth()){Text("Schnittkante anpassen")}
 }
 }
 }
 if(e==null)return
 when(dialog){
 "brunsPicker"->BrunsPlantPicker(onDismiss={dialog=""},onSelect={plant->vm.update(e.withStr("hedgePlant",plant));dialog=""})
 "hedgeSettings"->{
  val bounds=Bounds.of(e.points)
  val currentLength=if(e.points.size>=2)e.points.first().distance(e.points.last()) else bounds.width
  FormDialog("Hecke anpassen",listOf(
   Field("length","Länge m",fmt(currentLength/1000.0),true,true),
   Field("width","Breite m",fmt(e.num("widthMm",600.0)/1000.0),true,true),
   Field("plant","Pflanze (botanischer/deutscher Name)",e.str("hedgePlant","Carpinus betulus")),
   Field("density","Pflanzen je laufendem Meter",fmt(1000.0/e.num("spacingMm",400.0).coerceAtLeast(1.0)),true,true),
   Field("height","Pflanzenhöhe m",fmt(e.num("plantHeightMm",1500.0)/1000.0),true,true)
  ),{dialog=""}){v->
   val newLength=(parseNumber(v["length"].orEmpty())?:currentLength/1000.0).coerceAtLeast(0.01)*1000.0
   val newWidth=(parseNumber(v["width"].orEmpty())?:0.6).coerceAtLeast(0.01)*1000.0
   val density=(parseNumber(v["density"].orEmpty())?:2.5).coerceAtLeast(0.01)
   val start=e.points.firstOrNull()?:Vec()
   val end=e.points.lastOrNull()?:start+Vec(1000.0,0.0)
   val dx=end.x-start.x;val dy=end.y-start.y
   val dist=kotlin.math.hypot(dx,dy).coerceAtLeast(0.0001)
   val finish=Vec(start.x+dx/dist*newLength,start.y+dy/dist*newLength)
   vm.update(e.copy(points=listOf(start,finish)).withNum("widthMm",newWidth).withNum("spacingMm",1000.0/density).withNum("plantHeightMm",(parseNumber(v["height"].orEmpty())?:1.5)*1000.0).withStr("hedgePlant",v["plant"].orEmpty()))
  }
 }
 "cutSettings"->{
  val owner=d.entities.find{it.id==e.str("pavingCutOwner")}
  val inherited=(owner?.pattern?.jointMm?:4.0).coerceAtLeast(0.1)
  val mode=e.str("cutJointMode","auto")
  FormDialog("Schnittkante anpassen",listOf(
   Field("mode","Fugenbreite",if(mode=="manual")"Manuell einstellen" else "Vom Pflasteraufbau übernehmen",choices=listOf("Vom Pflasteraufbau übernehmen","Manuell einstellen")),
   Field("width","Manuelle Fugenbreite (mm)",fmt(e.num("cutJointWidthMm",inherited)),true,true,visibleChoiceKey="mode",visibleChoiceValue="Manuell einstellen"),
   Field("colorMode","Fugenfarbe",if(e.str("cutColorMode","auto")=="manual")"Manuell einstellen" else "Wie bestehende Pflasterfugen",choices=listOf("Wie bestehende Pflasterfugen","Manuell einstellen")),
   Field("color","Manuelle Fugenfarbe (#RRGGBB)",e.str("cutColor",owner?.style?.stroke?:e.style.stroke),visibleChoiceKey="colorMode",visibleChoiceValue="Manuell einstellen")
  ),{dialog=""}){v->
   val manual=v["mode"]=="Manuell einstellen"
   val custom=if(manual)(parseNumber(v["width"].orEmpty())?:inherited) else inherited
   require(custom>0.0 && custom<=100.0){"Fugenbreite muss zwischen 0 und 100 mm liegen"}
   val customColor=v["colorMode"]=="Manuell einstellen"
   val chosen=v["color"].orEmpty()
   require(!customColor||Regex("#[0-9a-fA-F]{6}").matches(chosen)){"Fugenfarbe als #RRGGBB eingeben"}
   vm.update(e.withStr("cutJointMode",if(manual)"manual" else "auto")
    .withNum("cutJointWidthMm",custom)
    .withStr("cutColorMode",if(customColor)"manual" else "auto")
    .withStr("cutColor",if(customColor)chosen else (owner?.style?.stroke?:e.style.stroke)))
  }
 }
 "level"->LevelDialog(e,{dialog=""},vm::update)
 "measureFormat"->MeasureDialog(e,{dialog=""},vm::update)
 "autoMeasures","autoMeasuresSection","autoMeasuresTop"->{val section=dialog!="autoMeasuresTop";val key=if(section)"autoMeasureSection" else "autoMeasureTop";val current=e.str(key,e.str("autoMeasureProfile").ifBlank{"Aus"});ChoiceDialog(if(section)"Automatische Maße – Schnitt" else "Automatische Maße – Draufsicht",measureProfiles,{dialog=""},selectedIndex=measureProfiles.indexOf(current).takeIf{it>=0}){vm.setAutoMeasures(e,measureProfiles[it],if(section)"section" else "top")}}
 "saveAssembly","updateAssembly"->FormDialog("Bauwerksvorlage",listOf(Field("name","Name",e.name.ifBlank{"Eigenes Bauwerk"}),Field("category","Kategorie","Eigene Bauwerke")),{dialog=""}){v->vm.saveAssembly(v.getValue("name"),v.getValue("category"),if(dialog=="updateAssembly")(d.extensions["editingTemplateId"] as? JsonPrimitive)?.contentOrNull else null)}

 "masonryWallSettings"->FormDialog("Mauer anpassen",listOf(
  Field("manufacturer","Hersteller / Materialquelle",e.str("wallManufacturer","Standard"),choices=listOf("Standard","Godelmann")),
  Field("series","Godelmann Produktserie",e.str("wallSeries",""),choices=godelmannVariants.map{it.product}.distinct()),
  Field("variant","Original-Farbkarte / Oberfläche",e.str("wallManufacturerVariant", ""),choices=godelmannVariants.map{it.product+" | "+it.color+" | "+it.surface}.distinct()),
  Field("type","Steinart",e.str("wallStoneType","Betonmauerstein"),choices=listOf("Betonmauerstein","Naturstein","Klinker","Kalksandstein","Granit","Jurakalk")),
  Field("bond","Verband",e.str("wallBond","Halbverband"),choices=listOf("Halbverband","Drittelverband","Kreuzfuge")),
  Field("color","Farbe",e.str("wallColor","Grau"),choices=listOf("Grau","Anthrazit","Beige","Weiß","Rotbraun","Sandstein","Eigene HEX-Farbe")),
  Field("hex","HEX-Farbe",e.str("wallCustomHex","#B6B6B2")),
  Field("length","Mauerlänge mm",fmt(e.num("wallLengthMm",3000.0)),true,true),
  Field("height","Mauerhöhe mm",fmt(e.num("wallHeightMm",1200.0)),true,true),
  Field("thickness","Mauerdicke mm",fmt(e.num("wallThicknessMm",240.0)),true,true),
  Field("stoneLength","Steinlänge mm",fmt(e.num("wallStoneLengthMm",400.0)),true,true),
  Field("stoneHeight","Steinhöhe mm",fmt(e.num("wallStoneHeightMm",200.0)),true,true),
  Field("stoneDepth","Steintiefe mm",fmt(e.num("wallStoneDepthMm",240.0)),true,true),
  Field("joint","Fugenbreite mm",fmt(e.num("wallJointMm",10.0)),true,true)
 ),{dialog=""}){v->
  fun positive(key:String)= (parseNumber(v[key].orEmpty())?:error("Ungültiges Maß: $key")).also{require(it>0){"Maß muss größer als null sein"}}
  val len=positive("length");val h=positive("height");val thick=positive("thickness")
  val sl=positive("stoneLength");val sh=positive("stoneHeight");val sd=positive("stoneDepth")
  val joint=(parseNumber(v["joint"].orEmpty())?:0.0).also{require(it in 0.0..50.0){"Fugenbreite 0–50 mm"}}
  val color=when(v["color"]){"Anthrazit"->"#555759";"Beige"->"#C3B49A";"Weiß"->"#E4E2DA";"Rotbraun"->"#A06B54";"Sandstein"->"#CEB58F";"Eigene HEX-Farbe"->v["hex"].orEmpty();else->"#B6B6B2"}
  require(color.matches(Regex("#[0-9a-fA-F]{6}"))){"HEX-Farbe muss #RRGGBB sein"}
  val selectedVariant=if(v["manufacturer"]=="Godelmann")godelmannVariants.find{it.product+" | "+it.color+" | "+it.surface==v["variant"] && it.product==v["series"]} else null
  if(v["manufacturer"]=="Godelmann")require(selectedVariant!=null){"Bitte eine vorhandene Godelmann-Serie und passende Farbe/Oberfläche auswählen. Bibliothek gegebenenfalls aktualisieren."}
  vm.update(e.withStr("wallManufacturer",v["manufacturer"].orEmpty()).withStr("wallSeries",selectedVariant?.product?:v["series"].orEmpty())
   .withStr("wallManufacturerVariant",v["variant"].orEmpty()).withStr("wallManufacturerVariantId",selectedVariant?.id?:"")
   .withStr("wallManufacturerTexture",selectedVariant?.image?:"")
   .withStr("wallStoneType",v["type"].orEmpty()).withStr("wallBond",v["bond"].orEmpty())
   .withStr("wallColor",v["color"].orEmpty()).withStr("wallCustomHex",color)
   .withNum("wallLengthMm",len).withNum("wallHeightMm",h).withNum("wallThicknessMm",thick)
   .withNum("wallStoneLengthMm",sl).withNum("wallStoneHeightMm",sh).withNum("wallStoneDepthMm",sd)
   .withNum("wallJointMm",joint).withNum("topWidthMm",len).withNum("topHeightMm",thick)
   .withNum("sectionWidthMm",len).withNum("sectionHeightMm",h).withNum("widthMm",len).withNum("heightMm",h)
   .copy(style=e.style.copy(fill=color),name="Mauer"))
 }
 "steelEdgeSettings"->FormDialog("Stahlkante anpassen",listOf(
  Field("type","Art",e.str("steelType","Verzinkter Stahl"),choices=listOf("Stahl roh","Verzinkter Stahl","Edelstahl","Cortenstahl","Pulverbeschichtet")),
  Field("color","Farbe",e.str("steelColor","Silbergrau"),choices=listOf("Silbergrau","Anthrazit","Schwarz","Rostbraun","Weiß","Farbpalette")),
  Field("customHex","HEX-Farbe",e.str("steelCustomHex",e.style.fill?:"#92979A")),
  Field("length","Länge mm",fmt(e.num("edgeLengthMm",1000.0)),true,true),
  Field("thickness","Dicke mm",fmt(e.num("edgeThicknessMm",8.0)),true,true),
  Field("height","Höhe mm",fmt(e.num("edgeHeightMm",150.0)),true,true),
  Field("foundation","Unterfundament C20/25",e.str("steelFoundation","false"),checkbox=true),
  Field("foundationWidth","Fundamentbreite mm",fmt(e.num("steelFoundationWidthMm",200.0)),true,true),
  Field("foundationHeight","Fundamenthöhe mm",fmt(e.num("steelFoundationHeightMm",200.0)),true,true),
  Field("backing","Rückenstütze",e.str("steelBacking","false"),checkbox=true),
  Field("backingWidth","Rückenstützenbreite mm",fmt(e.num("steelBackingWidthMm",100.0)),true,true),
  Field("backingHeight","Rückenstützenhöhe mm",fmt(e.num("steelBackingHeightMm",100.0)),true,true)
 ),{dialog=""}){v->
  val len=parseNumber(v["length"].orEmpty())?:1000.0
  val thick=parseNumber(v["thickness"].orEmpty())?:8.0
  val h=parseNumber(v["height"].orEmpty())?:150.0
  require(len>0&&thick>0&&h>0){"Länge, Dicke und Höhe müssen größer als null sein"}
  val col=when(v["color"]){"Anthrazit"->"#474A4E";"Schwarz"->"#25272A";"Rostbraun"->"#985D48";"Weiß"->"#E1E1DF";"Farbpalette"->v["customHex"].orEmpty();else->"#92979A"}
  vm.update(e.withStr("steelEdge","true").withStr("steelCustomHex",v["customHex"].orEmpty()).withStr("steelType",v["type"].orEmpty()).withStr("steelColor",v["color"].orEmpty())
   .withStr("steelFoundation",(v["foundation"].orEmpty().lowercase() in setOf("ja","true")).toString()).withStr("steelBacking",(v["backing"].orEmpty().lowercase() in setOf("ja","true")).toString())
   .withNum("edgeLengthMm",len).withNum("edgeThicknessMm",thick).withNum("edgeHeightMm",h)
   .withNum("steelFoundationWidthMm",(parseNumber(v["foundationWidth"].orEmpty())?:200.0).coerceAtLeast(1.0))
   .withNum("steelFoundationHeightMm",(parseNumber(v["foundationHeight"].orEmpty())?:200.0).coerceAtLeast(1.0))
   .withNum("steelBackingWidthMm",(parseNumber(v["backingWidth"].orEmpty())?:100.0).coerceAtLeast(1.0))
   .withNum("steelBackingHeightMm",(parseNumber(v["backingHeight"].orEmpty())?:100.0).coerceAtLeast(1.0))
   .copy(style=e.style.copy(fill=col,stroke=col),name="Stahlkante",libraryId="cmp-einfassungen-kanten-stahlkante"))
 }
 "stair"->if(e!=null)StairDialog(vm.catalog.entries()+vm.project!!.libraryEntries,e,{dialog=""},vm::saveStair)
 "variant"->{
  val all=(vm.catalog.entries()+vm.project!!.libraryEntries).distinctBy{it.id};val source=all.find{it.id==e.libraryId};val family=if(e.smartFamily()!="component")e.smartFamily() else source?.smartFamily() ?: "component";val group=e.str("variantGroup").ifBlank{source?.variantGroup().orEmpty()}
  val options=all.filter{it.type=="component"&&it.smartFamily()==family&&(group.isBlank()||it.variantGroup()==group)}.sortedBy{it.name}
  if(options.isEmpty())AlertDialog(onDismissRequest={dialog=""},text={Text("Keine kompatiblen Varianten in der geladenen Bibliothek.")},confirmButton={TextButton(onClick={dialog=""}){Text("OK")}})
  else ChoiceDialog("Bauteiltyp ändern · Bezugspunkt bleibt erhalten",options.map{it.name},{dialog=""}){i->val base=if(e.smartFamily()=="component")e.withStr("componentFamily",family).withStr("variantGroup",group)else e;val changed=replaceComponentVariant(base,options[i]);vm.project?.let{p->vm.update(changed);if(p.libraryEntries.none{it.id==options[i].id})vm.attachLibraryForPlacedVariant(options[i])}}
 }
 "label"->{val b=viewBounds(e,d);val center=b.center;val auto=objectLabelPosition(e,d)-center;val section=d.viewMode()=="section";val dxKey=if(section)"labelSectionDx"else"labelTopDx";val dyKey=if(section)"labelSectionDy"else"labelTopDy";FormDialog("Objektbeschriftung",listOf(Field("mode","Textmodus",e.str("labelMode","auto"),choices=listOf("auto","manuell")),Field("text","Manueller Text",e.str("labelText")),Field("dx","Textabstand X mm",fmt(e.num(dxKey,auto.x)),true),Field("dy","Textabstand Y mm",fmt(e.num(dyKey,auto.y)),true)),{dialog=""}){v->var n=e.withStr("labelMode",v["mode"].orEmpty()).withStr("labelText",v["text"].orEmpty());n=n.withNum(dxKey,parseNumber(v["dx"]!!)!!).withNum(dyKey,parseNumber(v["dy"]!!)!!);vm.update(n)}}
 "snapPriority"->ChoiceDialog("Snap-Priorität · Führende Bauteile werden beim Fangen bevorzugt",listOf("Führend","Normal","Folgend"),{dialog=""},selectedIndex=when(e.str("snapPriority","normal")){"high"->0;"low"->2;else->1}){i->vm.update(e.withStr("snapPriority",listOf("high","normal","low")[i]))}
 "dimensionRotation"->{val labels=listOf("Winkelsnap 15°","Winkelsnap 30°","Winkelsnap 45°","Winkelsnap 90°","Frei drehbar");val idx=if(e.str("rotationMode","snap")=="free")4 else when(e.num("angleSnapStep",15.0).toInt()){30->1;45->2;90->3;else->0};ChoiceDialog("Drehmodus · aktueller Modus ist markiert",labels,{dialog=""},selectedIndex=idx){i->vm.update(if(i==4)e.withStr("rotationMode","free") else e.withStr("rotationMode","snap").withNum("angleSnapStep",listOf(15.0,30.0,45.0,90.0)[i]))}}
 "plantingSettings"->{
  val names=listOf("Tragschicht","Oberboden grob","Oberboden fein","Deckschicht")
  val materials=listOf(listOf("FS-Kies","Auffüllkies","Rotlage","Schotter 0/32","Sonstiges"),listOf("Oberboden 0/35","Oberboden","Sonstiges"),listOf("Oberboden 0/20","Oberboden","Sonstiges"),listOf("Rindenkompost","Rindenmulch","Lavamulch","Keine","Sonstiges"))
  val defaults=listOf(200.0,200.0,150.0,50.0)
  val bounds=Bounds.of(e.points)
  val localLength=if(e.points.size==4)e.points[0].distance(e.points[1]) else bounds.width
  val localWidth=if(e.points.size==4)e.points[0].distance(e.points[3]) else bounds.height
  val fields=mutableListOf(Field("length","Länge (mm)",fmt(localLength),true,true),Field("width","Breite (mm)",fmt(localWidth),true,true),Field("type","Pflanzflächentyp",e.str("plantingType","Staudenfläche"),choices=listOf("Staudenfläche","Gehölzfläche","Bodendeckerfläche","Mischpflanzung","Freie Pflanzfläche")))
  names.indices.reversed().forEach{i->
   val name=names[i]
   val layer=e.strata.getOrNull(i)
   val current=layer?.materialId?.ifBlank{layer.name}?:materials[i].first()
   fields.add(Field("material$i","$name · Material",if(current in materials[i])current else "Sonstiges",choices=materials[i]))
   fields.add(Field("custom$i","$name · freie Materialbezeichnung",if(current in materials[i])"" else current,visibleChoiceKey="material$i",visibleChoiceValue="Sonstiges"))
   fields.add(Field("label$i","$name · Beschriftung",layer?.name?:name))
   fields.add(Field("grading$i","$name · Körnung",layer?.grading.orEmpty()))
   fields.add(Field("thickness$i","$name · Dicke (mm)",fmt(layer?.thicknessMm?:defaults[i]),true,true))
  }
  FormDialog("Pflanzfläche · vier Schichten",fields,{dialog=""}){v->
   val colors=listOf("#C7BDAA","#947B5B","#A18A68","#785438")
   val updated=names.mapIndexed{i,name->
    val selected=v["material$i"].orEmpty()
    val material=if(selected=="Sonstiges")v["custom$i"].orEmpty().ifBlank{name}else selected
    val thickness=(parseNumber(v["thickness$i"].orEmpty())?:defaults[i]).coerceAtLeast(0.0)
    val surfaceColor=when {
     material.contains("Rindenkompost",true)->"#483225"
     material.contains("Rindenmulch",true)->"#785038"
     material.contains("Lavamulch",true)->"#754C43"
     material.contains("Oberboden",true)->"#947B5B"
     material.contains("Rotlage",true)->"#9C735E"
     material.contains("Kies",true)||material.contains("Schotter",true)->"#B8AEA0"
     else->colors[i]
    }
    Stratum(material,v["label$i"].orEmpty().ifBlank{name},if(material=="Keine")0.0 else thickness,surfaceColor,v["grading$i"].orEmpty())
   }
   val length=(parseNumber(v["length"].orEmpty())?:localLength).coerceAtLeast(1.0)
   val width=(parseNumber(v["width"].orEmpty())?:localWidth).coerceAtLeast(1.0)
   require(length.isFinite()&&width.isFinite()&&length<=1e7&&width<=1e7){"Länge/Breite ungültig"}
   val resized=if(e.points.size==4)resizeParametricRectangle(e,length,width) else e.copy(points=rectangle(bounds.min,bounds.min+Vec(length,width)))
   vm.update(resized.copy(strata=updated).withStr("plantingType",v["type"].orEmpty()))
  }
 }
 "eavesSettings"->{
  val names=listOf("Tragschicht","Deckschicht")
  val materials=listOf(
   listOf("Schotter 0/32","FS-Kies 0/32","Kies 0/32","Splitt 2/5","Sonstiges"),
   listOf("Kies 16/32 Grau","Kies 16/32 Anthrazit","Kies 16/32 Weiß","Kies 16/32 Beige","Kies 8/16 Grau","Zierschotter Anthrazit","Zierschotter Rotbraun","Zierschotter Weiß","Schotter 16/32","Splitt 8/16","Sonstiges")
  )
  val defaults=listOf(150.0,100.0)
  val bounds=Bounds.of(e.points)
  val fields=mutableListOf(Field("length","Länge (mm)",fmt(bounds.width),true,true),Field("width","Breite (mm)",fmt(bounds.height),true,true),Field("type","Traufenart",e.str("eavesType","Kiesstreifen"),choices=listOf("Kiesstreifen","Spritzschutzstreifen","Zierkiesstreifen","Schotterstreifen")))
  names.indices.reversed().forEach{i->
   val name=names[i]
   val layer=e.strata.getOrNull(i)
   val current=layer?.materialId?.ifBlank{layer.name}?:materials[i].first()
   fields.add(Field("material$i","$name · Material",if(current in materials[i])current else "Sonstiges",choices=materials[i]))
   fields.add(Field("custom$i","$name · freie Materialbezeichnung",if(current in materials[i])"" else current,visibleChoiceKey="material$i",visibleChoiceValue="Sonstiges"))
   fields.add(Field("label$i","$name · Beschriftung",layer?.name?:name))
   fields.add(Field("grading$i","$name · Körnung",layer?.grading.orEmpty()))
   fields.add(Field("thickness$i","$name · Dicke (mm)",fmt(layer?.thicknessMm?:defaults[i]),true,true))
  }
  FormDialog("Traufe · Schichtaufbau",fields,{dialog=""}){v->
   val colors=listOf("#9F9F99","#B6B5AD")
   val updated=names.mapIndexed{i,name->
    val selected=v["material$i"].orEmpty()
    val material=if(selected=="Sonstiges")v["custom$i"].orEmpty().ifBlank{name}else selected
    val thickness=(parseNumber(v["thickness$i"].orEmpty())?:defaults[i]).coerceAtLeast(0.0)
    val surfaceColor=when {
     material.contains("Anthrazit",true)->"#505154"
     material.contains("Weiß",true)->"#E3E1D9"
     material.contains("Beige",true)->"#C6B69A"
     material.contains("Rotbraun",true)->"#985D48"
     material.contains("Oberboden",true)->"#947B5B"
     material.contains("Rotlage",true)->"#9C735E"
     material.contains("Kies",true)||material.contains("Schotter",true)->"#B8AEA0"
     else->colors[i]
    }
    Stratum(material,v["label$i"].orEmpty().ifBlank{name},if(material=="Keine")0.0 else thickness,surfaceColor,v["grading$i"].orEmpty())
   }
   val length=(parseNumber(v["length"].orEmpty())?:bounds.width).coerceAtLeast(1.0)
   val width=(parseNumber(v["width"].orEmpty())?:bounds.height).coerceAtLeast(1.0)
   require(length.isFinite()&&width.isFinite()&&length<=1e7&&width<=1e7){"Länge/Breite ungültig"}
   val resized=if(e.points.size==4)resizeParametricRectangle(e,length,width) else e.copy(points=rectangle(bounds.min,bounds.min+Vec(length,width)))
   vm.update(resized.copy(strata=updated).withStr("eavesType",v["type"].orEmpty()))
  }
 }
 "grassSettings"->FormDialog("Rasen · Aufbau und Form",listOf(
 Field("type","Rasenart",e.str("grassType","Gebrauchsrasen"),choices=listOf("Gebrauchsrasen","Zierrasen","Landschaftsrasen","Sportrasen","Golfrasen","Kräuterrasen","Blumenwiese","Kunstrasen","Sonstige")),
 Field("rsm","RSM / Sorte",e.str("grassRsm","RSM 2.3")),
 Field("method","Herstellung",e.str("grassMethod","Saatrasen"),choices=listOf("Saatrasen","Rollrasen","Kunstrasen")),
 Field("shape","Form",e.str("grassShape","Rechteckig"),choices=listOf("Rechteckig","Quadratisch","Rund")),
 Field("length","Länge mm / Durchmesser bei Rund",fmt(viewBounds(e,d).width),true,true),
 Field("width","Breite mm",fmt(viewBounds(e,d).height),true,true),
 Field("blade","Halmlänge mm (oberhalb OK Grasnarbe)",fmt(e.num("grassBladeMm",40.0)),true,true),
 Field("layer1","Schicht 1 · Material",e.str("grassLayer1Name","Oberboden")),
 Field("grading1","Schicht 1 · Körnung",e.str("grassLayer1Grading","0/15")),
 Field("depth1","Schicht 1 · Dicke mm",fmt(e.num("grassLayer1Mm",50.0)),true),
 Field("layer2","Schicht 2 · Material",e.str("grassLayer2Name","Oberboden")),
 Field("grading2","Schicht 2 · Körnung",e.str("grassLayer2Grading","0/25")),
 Field("depth2","Schicht 2 · Dicke mm",fmt(e.num("grassLayer2Mm",150.0)),true)
 )+buildUpMeasureFields(e,true),{dialog=""}){v->
 val b=viewBounds(e,d);val l=(parseNumber(v["length"].orEmpty())?:b.width).coerceAtLeast(1.0);val w=(parseNumber(v["width"].orEmpty())?:b.height).coerceAtLeast(1.0)
 val shape=v["shape"].orEmpty();val newPoints=if(shape=="Rund") (0..63).map{i->val a=i*2.0*Math.PI/64.0;Vec(b.min.x+l/2.0+kotlin.math.cos(a)*l/2.0,b.min.y+l/2.0+kotlin.math.sin(a)*l/2.0)} else rectangle(b.min,b.min+Vec(l,if(shape=="Quadratisch")l else w))
 var n=e.withStr("grassType",v["type"].orEmpty()).withStr("grassRsm",v["rsm"].orEmpty()).withStr("grassMethod",v["method"].orEmpty()).withStr("grassShape",shape)
 val sectionLength=(parseNumber(v["sectionLength"].orEmpty())?:e.num("grassSectionLengthMm",l))
 val realLength=(parseNumber(v["realLength"].orEmpty())?:sectionLength)
 val sectionWidth=(parseNumber(v["sectionWidth"].orEmpty())?:w)
 val realWidth=(parseNumber(v["realWidth"].orEmpty())?:w)
 val slope=kotlin.math.abs(parseNumber(v["slopePct"].orEmpty())?:0.0)
 require(sectionLength>0.0 && realLength>0.0 && sectionWidth>0.0 && realWidth>0.0 && slope<=100.0){"Schnittlänge, Realmaß oder Gefälle ungültig"}
 n=n.withNum("grassSectionLengthMm",sectionLength).withNum("buildUpSectionLengthMm",sectionLength)
  .withNum("buildUpSectionWidthMm",sectionWidth).withNum("buildUpRealWidthMm",realWidth)
  .withStr("buildUpRealLengthEnabled",if(v["realLengthEnabled"]=="ja" || kotlin.math.abs(realLength-sectionLength)>0.01)"true" else "false")
  .withNum("buildUpRealLengthMm",realLength)
  .withNum("buildUpSlopePct",if(v["slopeDirection"]=="Nach links fallend")-slope else slope)
  .withStr("buildUpSlopeFixedSide",if(v["slopeFixedSide"]=="Rechts")"right" else "left")
  .withNum("buildUpSlopeLabelDx",parseNumber(v["slopeLabelDx"].orEmpty())?:0.0)
  .withNum("buildUpSlopeLabelDy",parseNumber(v["slopeLabelDy"].orEmpty())?:0.0)
 n=n.withNum("grassBladeMm",(parseNumber(v["blade"].orEmpty())?:40.0).coerceAtLeast(0.0))
 for(i in 1..2){n=n.withStr("grassLayer${i}Name",v["layer$i"].orEmpty()).withStr("grassLayer${i}Grading",v["grading$i"].orEmpty()).withNum("grassLayer${i}Mm",(parseNumber(v["depth$i"].orEmpty())?:0.0).coerceAtLeast(0.0))}
 vm.update(n.copy(points=newPoints))
 }

 "elevationEdit"->ElevationDialog("Höhenkote bearbeiten",e.str("elevationRole","manual"),fmt((if(e.str("elevationRole")=="relative")e.num("heightOffsetMm") else e.num("heightMm"))/1000.0),e.str("elevationPrefix"),e.num("elevationFontPaperMm",3.0),e.num("elevationArrowPaperMm",2.5),{dialog=""}){role,value,prefix,fontMm,arrowMm->var n=e.withStr("elevationRole",role).withStr("elevationPrefix",prefix).withNum("elevationFontPaperMm",fontMm).withNum("elevationArrowPaperMm",arrowMm);n=if(role=="relative")n.withNum("heightOffsetMm",value*1000.0)else n.withNum("heightMm",value*1000.0);vm.update(n)}
 "legendEdit"->{
  val items=legendItems(d,vm.project!!.libraryEntries)
  val fields=mutableListOf(Field("title","Überschrift",e.text))
  items.forEachIndexed{i,item->
   fields.add(Field("show$i","${item.label} anzeigen",if(e.str("legendVisible:${item.key}","true")!="false")"ja"else"nein",checkbox=true))
   fields.add(Field("label$i","Text",e.str("legendLabel:${item.key}").ifBlank{item.label}))
   fields.add(Field("color$i","Farbe #RRGGBB",e.str("legendColor:${item.key}").ifBlank{item.style.fill?:"#D0D0D0"}))
   fields.add(Field("order$i","Reihenfolge",fmt(e.num("legendOrder:${item.key}",i.toDouble())),true))
  }
  FormDialog("Legende bearbeiten",fields,{dialog=""}){v->
   var n=e.copy(text=v["title"].orEmpty())
   items.forEachIndexed{i,item->
    val color=v["color$i"].orEmpty();require(Regex("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?").matches(color)){"Ungültige Farbe bei ${item.label}"}
    n=n.withStr("legendVisible:${item.key}",(v["show$i"]=="ja").toString()).withStr("legendLabel:${item.key}",v["label$i"].orEmpty()).withStr("legendColor:${item.key}",color).withNum("legendOrder:${item.key}",parseNumber(v["order$i"]!!)!!)
   }
   vm.update(n)
  }
 }
 "foundationSettings"->{val f=foundationFor(e,d);if(f!=null){val sb=viewBounds(e,d);val fields=mutableListOf(Field("type","Ausführung",if(f.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil",choices=listOf("Fundament mit Keil","Fundament ohne Keil")),Field("width","Breite cm",fmt(f.num("foundationWidthMm",sb.width+200.0)/10.0),true,true),Field("thickness",if(isStair(e))"Dicke unter VK Stufe cm" else "Dicke ab Unterkante cm",fmt(f.num("thicknessMm",200.0)/10.0),true,true),Field("embedMode","Einbindung",if(f.str("embedMode","auto")=="manual")"manuell" else "automatisch 1/3",choices=listOf("automatisch 1/3","manuell")),Field("embed","Einbindung cm (bei manuell)",fmt(f.num("embedMm",sb.height/3.0)/10.0),true),Field("side","Keilseite",when(f.str("wedgeSide","both")){"left"->"links";"right"->"rechts";else->"beidseitig"},choices=listOf("beidseitig","links","rechts")));if(isStair(e))fields.add(1,Field("stairExecution","Treppenfundament",if(f.str("stairFoundationExecution","separate")=="sloped")"schräg" else "getrennt",choices=listOf("schräg","getrennt")));FormDialog("Unterfundament",fields,{dialog=""}){v->val type=if(v["type"].orEmpty().contains("mit Keil"))"with_wedge" else "without_wedge";val mode=if(v["embedMode"]=="manuell")"manual" else "auto";val side=when(v["side"]){"links"->"left";"rechts"->"right";else->"both"};val stairExecution=if(v["stairExecution"]=="getrennt")"separate" else "sloped";vm.updateFoundation(e,parseNumber(v["thickness"]!!)!!*10.0,parseNumber(v["width"]!!)!!*10.0,type,mode,parseNumber(v["embed"]!!)!!*10.0,side,stairExecution)}}}
 "foundationObjectSettings"->{val source=d.entities.find{it.id==e.str("sourceId")};val sb=source?.let{viewBounds(it,d)}?:viewBounds(e,d);val fields=mutableListOf(Field("type","Ausführung",if(e.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil",choices=listOf("Fundament mit Keil","Fundament ohne Keil")),Field("width","Breite cm",fmt(e.num("foundationWidthMm",sb.width+200.0)/10.0),true,true),Field("thickness",if(source?.let(::isStair)==true)"Dicke unter VK Stufe cm" else "Dicke ab Unterkante cm",fmt(e.num("thicknessMm",200.0)/10.0),true,true),Field("embedMode","Einbindung",if(e.str("embedMode","auto")=="manual")"manuell" else "automatisch 1/3",choices=listOf("automatisch 1/3","manuell")),Field("embed","Einbindung cm (bei manuell)",fmt(e.num("embedMm",sb.height/3.0)/10.0),true),Field("side","Keilseite",when(e.str("wedgeSide","both")){"left"->"links";"right"->"rechts";else->"beidseitig"},choices=listOf("beidseitig","links","rechts")));if(source?.let(::isStair)==true)fields.add(1,Field("stairExecution","Treppenfundament",if(e.str("stairFoundationExecution","separate")=="sloped")"schräg" else "getrennt",choices=listOf("schräg","getrennt")));FormDialog("Unterfundament",fields,{dialog=""}){v->val type=if(v["type"].orEmpty().contains("mit Keil"))"with_wedge" else "without_wedge";val mode=if(v["embedMode"]=="manuell")"manual" else "auto";val side=when(v["side"]){"links"->"left";"rechts"->"right";else->"both"};val stairExecution=if(v["stairExecution"]=="getrennt")"separate" else "sloped";vm.update(e.withNum("thicknessMm",parseNumber(v["thickness"]!!)!!*10.0).withNum("foundationWidthMm",parseNumber(v["width"]!!)!!*10.0).withStr("foundationType",type).withStr("wedgeEnabled",(type=="with_wedge").toString()).withStr("embedMode",mode).withNum("embedMm",parseNumber(v["embed"]!!)!!*10.0).withStr("wedgeSide",side).withStr("stairFoundationExecution",stairExecution))}}
 "textEdit"->FormDialog("Text bearbeiten",listOf(Field("text","Text",e.text)),{dialog=""}){v->vm.update(e.copy(text=v["text"].orEmpty()))}
 "fillMaterial"->{val materials=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material"}.distinctBy{it.id}.sortedBy{it.name};val labels=listOf("Keine Füllung")+materials.map{it.name};val selected=if(e.materialId==null)0 else materials.indexOfFirst{it.id==e.materialId}.let{if(it<0)null else it+1};ChoiceDialog("Füllung / Material",labels,{dialog=""},selectedIndex=selected){i->if(i==0)vm.update(e.copy(materialId=null,materialSnapshot=null))else{val m=materials[i-1];vm.attachLibraryForPlacedVariant(m);vm.update(e.copy(materialId=m.id,materialSnapshot=null,quantityUnit=e.quantityUnit?:"m²"))}}}
 "fillSettings"->FormDialog("Füllungsdarstellung",listOf(Field("mode","Draufsicht",when(e.str("fillMode","auto")){"area"->"flächig";"vertical"->"senkrecht";else->"auto"},choices=listOf("auto","flächig","senkrecht")),Field("top","In Draufsicht sichtbar",if(e.placement.visibleTop)"ja"else"nein",checkbox=true),Field("section","Im Schnitt sichtbar",if(e.placement.visibleSection)"ja"else"nein",checkbox=true)),{dialog=""}){v->val mode=when(v["mode"].orEmpty().lowercase()){"flächig","flaechig","area"->"area";"senkrecht","vertical"->"vertical";else->"auto"};vm.update(e.withStr("fillMode",mode).copy(placement=e.placement.copy(visibleTop=v["top"]!="nein",visibleSection=v["section"]!="nein")))}
 "pipe"->FormDialog("Rohr-/Leitungsorientierung",listOf(Field("orientation","Orientierung",if(e.str("orientation","horizontal")=="vertical")"vertikal"else"horizontal",choices=listOf("horizontal","vertikal")),Field("direction","Bei vertikal",if(e.str("verticalDirection","down")=="up")"oben"else"unten",choices=listOf("unten","oben")),Field("length","Vertikale dargestellte Länge mm",fmt(e.num("verticalLengthMm",1000.0)),true,true)),{dialog=""}){v->vm.update(e.withStr("orientation",if(v["orientation"].orEmpty().startsWith("v",true))"vertical"else"horizontal").withStr("verticalDirection",if(v["direction"].orEmpty().startsWith("o",true))"up"else"down").withNum("verticalLengthMm",parseNumber(v["length"]!!)!!))}
 "planter"->{
  val manufacturerEntries=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material" && it.extensions.containsKey("baudetailManufacturer")}.distinctBy{it.id}
  fun manufacturerMeta(entry:de.baudetail.core.LibraryEntry):JsonObject?=entry.extensions["baudetailManufacturer"] as? JsonObject
  fun metaValue(entry:de.baudetail.core.LibraryEntry,key:String)=(manufacturerMeta(entry)?.get(key) as? JsonPrimitive)?.contentOrNull.orEmpty()
  val byManufacturer=manufacturerEntries.groupBy{metaValue(it,"manufacturer")}.filterKeys{it.isNotBlank()}
  val manufacturerNames=listOf("Ohne Hersteller")+byManufacturer.keys.sorted()
  val seriesByManufacturer=byManufacturer.mapValues{(_,items)->items.map{metaValue(it,"product")}.filter{it.isNotBlank()}.distinct().sorted()}
  val colorBySeries=manufacturerEntries.groupBy{metaValue(it,"manufacturer")+"|"+metaValue(it,"product")}.mapValues{(_,items)->items.map{listOf(metaValue(it,"color"),metaValue(it,"surface")).filter{v->v.isNotBlank()}.joinToString(" · ")}.distinct().sorted()}
  val chosenManufacturer=e.str("planterManufacturer","Ohne Hersteller").takeIf{it in manufacturerNames}?:"Ohne Hersteller"
  val chosenSeries=e.str("planterSeries").takeIf{it in seriesByManufacturer[chosenManufacturer].orEmpty()}?:seriesByManufacturer[chosenManufacturer].orEmpty().firstOrNull().orEmpty()
  val chosenVariant=e.str("planterVariant").takeIf{it in colorBySeries[chosenManufacturer+"|"+chosenSeries].orEmpty()}?:colorBySeries[chosenManufacturer+"|"+chosenSeries].orEmpty().firstOrNull().orEmpty()
  FormDialog("Pflanztrog einstellen",listOf(
  Field("shape","Form",e.str("planterShape","Rechteckig"),choices=listOf("Rechteckig","Quadratisch","Rund")),
  Field("width","Breite mm (rechteckig/quadratisch)",fmt(e.num("planterWidthMm",1200.0)),true,true),
  Field("depth","Tiefe mm (rechteckig)",fmt(e.num("planterDepthMm",500.0)),true,true),
  Field("diameter","Durchmesser mm (rund)",fmt(e.num("planterDiameterMm",500.0)),true,true),
  Field("height","Höhe mm",fmt(e.num("planterHeightMm",600.0)),true,true),
  Field("wall","Wandstärke mm",fmt(e.num("planterWallMm",5.0)),true,true),
  Field("material","Material",e.str("planterMaterial","Cortenstahl"),choices=listOf("Cortenstahl","Beton","Holz","Stahl","Aluminium","Mauersteine")),
  Field("stoneType","Mauerstein",e.str("planterStoneType","Betonmauerstein"),choices=listOf("Betonmauerstein","Naturmauerstein","Klinker"),visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("manufacturer","Hersteller",chosenManufacturer,choices=manufacturerNames,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("series","Steinart / Produktserie",chosenSeries,choices=seriesByManufacturer.values.flatten().distinct().ifEmpty{listOf("Keine Serien vorhanden")},visibleChoiceKey="material",visibleChoiceValue="Mauersteine",choiceDependsOn="manufacturer",choiceMap=seriesByManufacturer),
  Field("variant","Farbe / Oberfläche (Hersteller)",chosenVariant,choices=colorBySeries.values.flatten().distinct().ifEmpty{listOf("Keine Varianten vorhanden")},visibleChoiceKey="material",visibleChoiceValue="Mauersteine",choiceDependsOn="series",choiceMap=manufacturerEntries.groupBy{metaValue(it,"product")}.mapValues{(_,items)->items.map{listOf(metaValue(it,"color"),metaValue(it,"surface")).filter{v->v.isNotBlank()}.joinToString(" · ")}.distinct().sorted()}),
  Field("stoneLength","Steinlänge mm",fmt(e.num("planterStoneLengthMm",400.0)),true,true,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("stoneHeight","Steinhöhe mm",fmt(e.num("planterStoneHeightMm",200.0)),true,true,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("stoneDepth","Steintiefe mm",fmt(e.num("planterStoneDepthMm",200.0)),true,true,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("finish","Farbe / Oberfläche",e.str("planterFinish","Naturrost"),choices=listOf("Naturrost","Dunkelrost","Betongrau","Hellgrau","Anthrazit","Weiß","Lärche natur","Douglasie","Eiche","Braun lasiert","Anthrazit lasiert","Verzinkt","Silber","Schwarz"),visibleChoiceKey="material",visibleChoiceValue="Cortenstahl"),
  Field("ok","Oberkante / Höhenkote m",fmt(e.num("planterTopElevationMm",0.0)/1000.0),true),
  Field("fill","Substrat anzeigen",if(e.str("planterFill","true")=="true")"ja"else"nein",checkbox=true),
  Field("planting","Substrat mit Pflanzung anzeigen",if(e.str("planterPlanting","true")=="true")"ja"else"nein",checkbox=true)
 ),{dialog=""}){v->
  val shape=v["shape"].orEmpty();val width=parseNumber(v["width"]!!)!!;val depth=parseNumber(v["depth"]!!)!!;val dia=parseNumber(v["diameter"]!!)!!;val height=parseNumber(v["height"]!!)!!;val wall=parseNumber(v["wall"]!!)!!
  val minDim=if(shape=="Rund")dia else minOf(width,if(shape=="Quadratisch")width else depth)
  require(width>0&&depth>0&&dia>0&&height>0&&wall>0&&wall*2<minOf(minDim,height)){"Ungültige Maße / Wandstärke"}
  val matching=manufacturerEntries.firstOrNull{v["material"]=="Mauersteine" && metaValue(it,"manufacturer")==v["manufacturer"] && metaValue(it,"product")==v["series"] && listOf(metaValue(it,"color"),metaValue(it,"surface")).filter{it.isNotBlank()}.joinToString(" · ")==v["variant"]}
  if(matching!=null)vm.attachLibraryForPlacedVariant(matching)
  vm.update(e.copy(materialId=matching?.id,materialSnapshot=null).withStr("planterManufacturer",if(v["material"]=="Mauersteine")v["manufacturer"].orEmpty() else "Ohne Hersteller").withStr("planterSeries",if(matching!=null)v["series"].orEmpty() else "").withStr("planterVariant",if(matching!=null)v["variant"].orEmpty() else "").withStr("planterManufacturerMaterialId",matching?.id.orEmpty()).withStr("planterShape",shape).withNum("planterWidthMm",width).withNum("planterDepthMm",if(shape=="Quadratisch")width else depth).withNum("planterDiameterMm",dia).withNum("planterHeightMm",height).withNum("planterWallMm",wall).withStr("planterMaterial",v["material"].orEmpty()).withStr("planterStoneType",v["stoneType"].orEmpty()).withNum("planterStoneLengthMm",parseNumber(v["stoneLength"].orEmpty())?:400.0).withNum("planterStoneHeightMm",parseNumber(v["stoneHeight"].orEmpty())?:200.0).withNum("planterStoneDepthMm",parseNumber(v["stoneDepth"].orEmpty())?:200.0).withStr("planterFinish",v["finish"].orEmpty()).withNum("planterTopElevationMm",parseNumber(v["ok"]!!)!!*1000.0).withStr("planterFill",(v["fill"]!="nein").toString()).withStr("planterPlanting",(v["planting"]!="nein").toString()))
 }
 }
 "lightwell"->FormDialog("Lichtschacht einstellen",listOf(
  Field("width","Breite mm",fmt(e.num("lightwellWidthMm",1000.0)),true,true),
  Field("depth","Tiefe mm",fmt(e.num("lightwellDepthMm",500.0)),true,true),
  Field("height","Höhe mm",fmt(e.num("lightwellHeightMm",1000.0)),true,true),
  Field("wall","Wandstärke mm",fmt(e.num("lightwellWallMm",80.0)),true,true),
  Field("cover","Abdeckung",e.str("lightwellCover","Gitterrost"),choices=listOf("Gitterrost","Längsstabrost","Gitter mit Insektenschutz")),
  Field("color","Farbe",e.str("lightwellColor","Silber"),choices=listOf("Edelstahl silber","Silber","Cortenstahl","Anthrazit","Grau","Schwarz")),
  Field("ok","Oberkante / Höhenkote m",fmt(e.num("lightwellTopElevationMm",0.0)/1000.0),true)
 ),{dialog=""}){v->
  val w=parseNumber(v["width"]!!)!!;val depth=parseNumber(v["depth"]!!)!!;val h=parseNumber(v["height"]!!)!!;val wall=parseNumber(v["wall"]!!)!!
  require(w>0&&depth>0&&h>0&&wall>0&&wall*2<minOf(w,depth)) {"Ungültige Abmessungen / Wandstärke"}
  vm.update(e.withNum("lightwellWidthMm",w).withNum("lightwellDepthMm",depth).withNum("lightwellHeightMm",h).withNum("lightwellWallMm",wall).withStr("lightwellCover",v["cover"].orEmpty()).withStr("lightwellColor",v["color"].orEmpty()).withNum("lightwellTopElevationMm",parseNumber(v["ok"]!!)!!*1000.0))
 }
 "channelBox"->FormDialog("Rinne / Einlaufkasten",listOf(
  Field("type","Rinnentyp",when(e.str("channelType","box")){"facade"->"Fassadenrinne";"slot"->"Schlitzrinne";else->"Kastenrinne"},choices=listOf("Kastenrinne","Fassadenrinne","Schlitzrinne")),
  Field("class","Belastungsklasse",e.str("loadClass","B 125"),choices=listOf("A 15","B 125","C 250","D 400","E 600","F 900")),
  Field("grateType","Rost / Abdeckung",e.str("grateType",when(e.str("channelType","box")){"slot"->"Schlitz";"facade"->"Längsstab";else->"Gitterrost"}),choices=listOf("Stabgitter","Gitterrost","Längsstäbe","Stegrost","Schlitz")),
  Field("width","Kastenbreite cm",fmt(e.num("boxWidthMm",185.0)/10.0),true,true),
  Field("height","Kastenhöhe cm",fmt(e.num("boxHeightMm",610.0)/10.0),true,true),
  Field("length","Kastenlänge cm",fmt(e.num("boxLengthMm",500.0)/10.0),true,true),
  Field("nw","Rinnen-Nennweite cm",fmt(e.num("channelNominalWidthMm",150.0)/10.0),true,true),
  Field("outlet","Rohranschluss",when(e.str("pipeOutlet","none")){"left"->"links";"right"->"rechts";"bottom"->"unten";else->"keiner"},choices=listOf("keiner","links","rechts","unten")),
  Field("dn","Rohranschluss DN",("DN "+e.num("pipeDnMm",160.0).toInt()),choices=listOf("DN 110","DN 125","DN 160","DN 200","DN 250","DN 315","DN 400","DN 500","DN 630")),
  Field("axis","Rohrachse ab OK cm",fmt(e.num("pipeAxisFromTopMm",500.0)/10.0),true,true),
  Field("basket","Laubfangkorb",if(e.str("leafBasket","true")=="true")"ja"else"nein",checkbox=true),
  Field("grate","Rost sichtbar",if(e.str("grateVisible","true")=="true")"ja"else"nein",checkbox=true)
 ),{dialog=""}){v->vm.update(e.withStr("channelType",when(v["type"]){"Fassadenrinne"->"facade";"Schlitzrinne"->"slot";else->"box"}).withStr("loadClass",v["class"].orEmpty().ifBlank{"B 125"}).withStr("grateType",v["grateType"].orEmpty().ifBlank{"Gitterrost"}).withNum("boxWidthMm",parseNumber(v["width"]!!)!!*10).withNum("boxHeightMm",parseNumber(v["height"]!!)!!*10).withNum("boxLengthMm",parseNumber(v["length"]!!)!!*10).withNum("channelNominalWidthMm",parseNumber(v["nw"]!!)!!*10).withStr("pipeOutlet",when(v["outlet"]){"links"->"left";"rechts"->"right";"unten"->"bottom";else->"none"}).withNum("pipeDnMm",v["dn"].orEmpty().filter{it.isDigit()}.toDoubleOrNull()?:160.0).withNum("pipeAxisFromTopMm",parseNumber(v["axis"]!!)!!*10).withStr("leafBasket",(v["basket"]!="nein").toString()).withStr("grateVisible",(v["grate"]!="nein").toString()))}
 "kg2000"->{
  val dns=listOf("DN 110","DN 125","DN 160","DN 200","DN 250","DN 315","DN 400","DN 500","DN 630")
  val type=e.str("fittingType","pipe")
  val fields=mutableListOf<Field>()
  if(type !in setOf("reducer","y"))fields.add(Field("dn","DN","DN "+e.num("dnMm",160.0).toInt(),choices=dns))
  fields.add(Field("length","Länge cm",fmt(e.num("pipeLengthMm",if(type=="double_spigot")500.0 else 1000.0)/10.0),true,true))
  fields.add(Field("slope","Gefälle %",fmt(e.num("slope",0.0)),true))
  fields.add(Field("flowDirection","Fließrichtung",if(e.str("flowDirection","forward")=="reverse")"rückwärts" else "vorwärts",choices=listOf("vorwärts","rückwärts")))
  fields.add(Field("flow","Fließrichtung anzeigen",if(e.str("flowArrow","true")=="true")"ja"else"nein",checkbox=true))
  if(type=="bend"){fields.add(Field("angle","Bogenwinkel",fmt(e.num("bendAngle",45.0))+"°",choices=kg2000BendAngles(e.num("dnMm",160.0).toInt()).map{fmt(it,1)+"°"}));if(d.viewMode()=="section"){val current=when(e.str("bendDirection",e.str("verticalDirection","down"))){"up","oben"->"oben";"left","links"->"links";"right","rechts"->"rechts";else->"unten"};fields.add(Field("bendDirection","Weiterführung im Schnitt",current,choices=listOf("oben","unten","rechts","links")))}}
  if(type=="y"){
   val pairs=kg2000Y45Pairs().map{"DN ${it.first} / DN ${it.second}"}
   fields.add(Field("pair","Y-Stück 45° (Haupt / Abzweig)","DN ${e.num("dnMm",160.0).toInt()} / DN ${e.num("branchDnMm",110.0).toInt()}",choices=pairs))
  }
  if(type=="reducer"){
   val pairs=kg2000ReducerPairs().map{"DN ${it.first} / DN ${it.second}"}
   fields.add(Field("pair","Reduzierung (groß / klein)","DN ${e.num("inletDnMm",160.0).toInt()} / DN ${e.num("outletDnMm",110.0).toInt()}",choices=pairs))
  }
  FormDialog("KG 2000",fields,{dialog=""}){v->
   fun selectedDn(key:String,def:Double):Double=v[key].orEmpty().filter{ch->ch.isDigit()}.toDoubleOrNull()?:def
   var r=e.withNum("dnMm",if(type in setOf("reducer","y"))e.num("dnMm",160.0)else selectedDn("dn",160.0)).withNum("pipeLengthMm",parseNumber(v["length"]!!)!!*10).withNum("slope",parseNumber(v["slope"]!!)!!).withStr("flowArrow",(v["flow"]!="nein").toString()).withStr("flowDirection",if(v["flowDirection"]=="rückwärts")"reverse"else"forward")
   if(type=="bend"){r=r.withNum("bendAngle",v["angle"].orEmpty().replace(",",".").filter{ch->ch.isDigit()||ch=='.'}.toDoubleOrNull()?:45.0);if(d.viewMode()=="section"){val dir=when(v["bendDirection"]){"oben"->"up";"links"->"left";"rechts"->"right";else->"down"};r=r.withStr("bendDirection",dir).withStr("verticalDirection",if(dir=="up")"up"else"down")}}
   if(type=="y"){val nums=Regex("""\d+""").findAll(v["pair"].orEmpty()).map{it.value.toDouble()}.toList();if(nums.size>=2)r=r.withNum("dnMm",nums[0]).withNum("branchDnMm",nums[1])}
   if(type=="reducer"){val nums=Regex("""\d+""").findAll(v["pair"].orEmpty()).map{it.value.toDouble()}.toList();if(nums.size>=2){val official=kg2000ReducerLengthMm(nums[0].toInt(),nums[1].toInt());r=r.withNum("inletDnMm",nums[0]).withNum("outletDnMm",nums[1]).withNum("dnMm",nums[0]);if(official!=null)r=r.withNum("pipeLengthMm",official)}}
   vm.update(r)
  }
 }
 "retaining"->FormDialog("Mauerscheibe / Winkelstützelement",listOf(Field("height","Höhe mm",fmt(e.num("wallHeightMm",800.0)),true,true),Field("foot","Fußtiefe mm",fmt(e.num("footDepthMm",400.0)),true,true),Field("wall","Wandstärke mm",fmt(e.num("wallThicknessMm",70.0)),true,true),Field("slab","Fußstärke mm",fmt(e.num("footThicknessMm",100.0)),true,true),Field("length","Elementlänge mm",fmt(e.num("elementLengthMm",1000.0)),true,true),Field("side","Fußseite",if(e.str("footSide","right")=="left")"links"else"rechts",choices=listOf("rechts","links"))),{dialog=""}){v->val h=parseNumber(v["height"]!!)!!;val f=parseNumber(v["foot"]!!)!!;val w=parseNumber(v["wall"]!!)!!;val slab=parseNumber(v["slab"]!!)!!;val len=parseNumber(v["length"]!!)!!;require(w<=f&&slab<=h){"Wand-/Fußstärke darf Gesamtmaß nicht überschreiten"};vm.update(e.withNum("wallHeightMm",h).withNum("sectionHeightMm",h).withNum("footDepthMm",f).withNum("sectionWidthMm",f).withNum("wallThicknessMm",w).withNum("footThicknessMm",slab).withNum("elementLengthMm",len).withNum("topWidthMm",len).withNum("topHeightMm",f).withStr("footSide",if(v["side"].orEmpty().startsWith("l",true))"left"else"right"))}
 "geometry"->{val origin=e.points.firstOrNull()?:Vec();val circle=e.kind=="circle";val line=e.kind=="line"
 val fields=listOf(Field("x",if(circle)"Mittelpunkt X mm"else"Position X mm",fmt(origin.x),true),Field("y",if(circle)"Mittelpunkt Y mm"else"Position Y mm",fmt(origin.y),true))+if(circle)listOf(Field("radius","Radius mm",fmt(e.num("radiusMm")),true,true))else listOf(Field("width",if(line)"Länge mm"else"Breite mm",fmt(e.points.getOrElse(1){origin}.distance(origin)),true,true),Field("angle","Drehwinkel Grad",fmt(rectangleAngle(e)),true))+(if(line)emptyList()else listOf(Field("height","Höhe / Tiefe mm",fmt(e.points.getOrElse(3){origin}.distance(origin)),true,true)))
 FormDialog("Geometrie bearbeiten",fields,{dialog=""}){v->fun n(k:String)=parseNumber(v.getValue(k))!!
 val at=Vec(n("x"),n("y"));vm.update(if(circle)resizeCircle(e,n("radius"),at)else if(line)resizeLine(e,n("width"),n("angle"),at)else resizeRectangle(e,n("width"),n("height"),at,n("angle")))}}
 "properties"->{val fields=mutableListOf(Field("name","Bezeichnung",e.name),Field("x","X in mm",fmt(e.points.firstOrNull()?.x?:0.0),true),Field("y","Y in mm",fmt(e.points.firstOrNull()?.y?:0.0),true),Field("status","Status",e.status,choices=listOf("Bestand","Planung","Abbruch")),Field("quantity","Mengeneinheit",e.quantityUnit.orEmpty(),choices=listOf("","m²","m","Stk","m³")))
 e.params.forEach{(k,v)->fields.add(Field(k,paramLabel(k),(v as? JsonPrimitive)?.content?:v.toString(),v is JsonPrimitive&&v.doubleOrNull!=null))}
 if(e.kind=="text"||e.kind=="leader"||e.kind=="dimension"||e.kind=="section"||e.kind=="legend")fields.add(Field("text","Text / manuelle Überschreibung",e.text))
 FormDialog("Objekteigenschaften",fields,{dialog=""}){v->var result=transform(e,translation=Vec(parseNumber(v.getValue("x"))!!,parseNumber(v.getValue("y"))!!)-(e.points.firstOrNull()?:Vec())).copy(name=v["name"].orEmpty(),status=v["status"].orEmpty(),quantityUnit=v["quantity"]?.takeIf{it.isNotBlank()},text=v["text"]?:e.text)
 e.params.forEach{(k,value)->result=if(value is JsonPrimitive&&value.doubleOrNull!=null)result.withNum(k,parseNumber(v.getValue(k))!!)else result.withStr(k,v[k].orEmpty())}
 require(listOf("widthMm","heightMm","radiusMm","spacingMm","crownMm").all{!result.params.containsKey(it)||(it=="heightMm"&&result.kind=="elevation")||result.num(it)>0}){"Maße und Pflanzabstände müssen positiv sein"};vm.update(result)
 }}
 "points"->FormDialog("Eckpunkte (mm)",e.points.flatMapIndexed{i,p->listOf(Field("x$i","Punkt ${i+1}: X",fmt(p.x),true),Field("y$i","Punkt ${i+1}: Y",fmt(p.y),true))},{dialog=""}){v->vm.update(e.copy(points=e.points.indices.map{i->Vec(parseNumber(v.getValue("x$i"))!!,parseNumber(v.getValue("y$i"))!!)}))}
 "style"->FormDialog("Linien und Texte",listOf(Field("stroke","Linienfarbe (#RRGGBB)",e.style.stroke),Field("fill","Füllfarbe (#RRGGBB, leer = keine)",e.style.fill.orEmpty()),Field("width","Linienstärke Papier in mm",fmt(e.style.widthMm),true,true),Field("opacity","Deckkraft 0–1",fmt(e.style.opacity),true),Field("textSize","Texthöhe Papier in mm",fmt(e.style.textPaperMm),true,true),Field("rotation","Drehung in Grad",fmt(e.rotation),true),Field("align","Textausrichtung",e.style.align,choices=listOf("left","center","right")),Field("font","Schrift",if(e.style.bold&&e.style.italic)"bolditalic"else if(e.style.bold)"bold"else if(e.style.italic)"italic"else"normal",choices=listOf("normal","bold","italic","bolditalic")),Field("frame","Rahmen",if(e.style.frame)"ja"else"nein",checkbox=true),Field("background","Texthintergrund (#RRGGBB, optional)",e.style.background.orEmpty())),{dialog=""}){v->listOf("stroke","fill","background").forEach{require(v[it].isNullOrBlank()||Regex("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?").matches(v[it]!!)){"Ungültige Farbe"}};require(parseNumber(v["opacity"]!!)!! in 0.0..1.0);vm.update(transform(e,angle=parseNumber(v.getValue("rotation"))!!-e.rotation,center=e.points.firstOrNull()?:Vec()).copy(style=e.style.copy(stroke=v.getValue("stroke"),fill=v["fill"]?.takeIf{it.isNotBlank()},widthMm=parseNumber(v.getValue("width"))!!,opacity=parseNumber(v.getValue("opacity"))!!,textPaperMm=parseNumber(v.getValue("textSize"))!!,align=v.getValue("align"),bold=v["font"].orEmpty().contains("bold"),italic=v["font"].orEmpty().contains("italic"),frame=v["frame"]=="ja",background=v["background"]?.takeIf{it.isNotBlank()})))}
 "textLink"->ChoiceDialog("Textquelle ({name}, {widthMm}, {flaeche_m2}, {dicke_mm})",d.entities.filter{it.id!=e.id}.map{it.name.ifBlank{it.kind}},{dialog=""}){i->vm.update(e.withStr("sourceId",d.entities.filter{it.id!=e.id}[i].id))}
 "layer"->ChoiceDialog("Layer",d.layers.map{it.name},{dialog=""},selectedIndex=d.layers.indexOfFirst{it.id==e.layerId}.takeIf{it>=0}){i->vm.modifySelected{it.copy(layerId=d.layers[i].id)}}
 "transform"->FormDialog("Auswahl transformieren",listOf(Field("dx","Verschieben X (mm)","0",true),Field("dy","Verschieben Y (mm)","0",true),Field("angle","Drehen (Grad)","0",true),Field("scale","Skalierungsfaktor","1",true,true),Field("mirror","Spiegeln an vertikaler Achse","nein",checkbox=true)),{dialog=""}){v->val chosen=d.entities.filter{it.id in vm.selected};val groupCenter=Bounds.of(chosen.flatMap{it.points}).center;vm.modifySelected{obj->val center=if(chosen.size==1)smartPivot(obj)else groupCenter;transform(obj,Vec(parseNumber(v["dx"]!!)!!,parseNumber(v["dy"]!!)!!),parseNumber(v["angle"]!!)!!,parseNumber(v["scale"]!!)!!,v["mirror"]=="ja",center)}}
 "symbol"->FormDialog("Als Bauteil speichern",listOf(Field("name","Bauteilname",e.name.ifBlank{"Eigenes Bauteil"})),{dialog=""}){vm.saveSymbol(it.getValue("name"))}
 "pattern"->{val pattern=e.pattern?:Pattern();FormDialog("Verlegemuster",listOf(Field("width","Plattenlänge mm",fmt(pattern.widthMm),true,true),Field("height","Plattenbreite mm",fmt(pattern.heightMm),true,true),Field("joint","Fuge mm",fmt(pattern.jointMm),true),Field("angle","Winkel: 45 = diagonal",fmt(pattern.angle),true),Field("offset","Versatz: 0 = Kreuzfuge, 0,5 = Läufer",fmt(pattern.offset),true),Field("x","Ursprung X mm",fmt(pattern.origin.x),true),Field("y","Ursprung Y mm",fmt(pattern.origin.y),true),Field("cutX","Zuschnitt Breite",when(pattern.cutX){"left"->"Links";"both"->"Beidseitig";else->"Rechts"},choices=listOf("Links","Rechts","Beidseitig")),Field("cutY","Zuschnitt Länge",when(pattern.cutY){"top"->"Oben";"both"->"Beidseitig";else->"Unten"},choices=listOf("Oben","Unten","Beidseitig"))),{dialog=""}){v->fun n(k:String):Double { return parseNumber(v.getValue(k))!! }
require(n("joint")>=0);vm.update(e.copy(pattern=Pattern(n("width"),n("height"),n("joint"),n("angle"),n("offset"),Vec(n("x"),n("y")),when(v["cutX"]){"Links"->"left";"Beidseitig"->"both";else->"right"},when(v["cutY"]){"Oben"->"top";"Beidseitig"->"both";else->"bottom"})))}}
 "stackEdit"->{
  val target=buildUp?:e;val p=target.pattern?:Pattern();val fields=mutableListOf<Field>()
  val libraryMaterials=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material"}.distinctBy{it.id}.sortedBy{it.name}
  val pavingLibrary=libraryMaterials.filter{it.category.startsWith("Beläge/") || it.category.startsWith("Belaege/") || it.category.startsWith("Materialien/")}
  fields.add(Field("buildUpVariant","Aufbauart",if(target.str("buildUpVariant") == "waterbound")"Wassergebundene Wegedecke" else "Pflaster / Platten",choices=listOf("Pflaster / Platten","Wassergebundene Wegedecke")))
  target.strata.forEachIndexed{i,layer->
   val water=target.str("buildUpVariant")=="waterbound"
   val choices=if(water)when(i){0->listOf("Brechsand 0/3","Kies gewaschen 4/8","Edelsplitt gewaschen 2/5","Sand","Sonstiges");1->listOf("Sand-Splitt-Gemisch 0/16","Sonstiges");else->frostMaterialChoices}else if(i==0)(buildUpMaterialChoices(i).filterNot{it=="Sonstiges"}+pavingLibrary.map{it.name}+"Sonstiges").distinct() else buildUpMaterialChoices(i)
   val saved=layer.materialId.ifBlank{layer.name}
   val libraryName=libraryMaterials.find{it.id==saved}?.name
   val current=(libraryName?:saved).takeIf{it in choices}?:"Sonstiges"
   fields.add(Field("material$i","Material Schicht ${i+1}",current,choices=choices))
   if(current=="Sonstiges")fields.add(Field("custom$i","Eigene Bezeichnung",layer.materialId.ifBlank{layer.name}))
   fields.add(Field("thickness$i","Dicke mm",fmt(layer.thicknessMm),true,true))
  }
  fields.addAll(listOf(
   Field("pathWidth","Grafische Breite Draufsicht mm",fmt(target.num("widthMm",1500.0)),true,true),
   Field("pathLength","Grafische Länge Draufsicht mm",fmt(target.num("topDepthMm",1000.0)),true,true),
   *buildUpMeasureFields(target).toTypedArray(),
   Field("pavingModeRaster","Rastermaß (einschließlich Fuge)",if(target.str("pavingDimensionMode","stone")=="raster")"ja" else "nein",checkbox=true),
   Field("pavingModeStone","Steinmaß (ohne Fuge)",if(target.str("pavingDimensionMode","stone")!="raster")"ja" else "nein",checkbox=true),
   Field("rasterWidth","Rasterlänge mm",fmt(p.widthMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("rasterHeight","Rasterbreite mm",fmt(p.heightMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("width","Steinlänge mm",fmt(p.widthMm),true,true,enabledWhen="pavingModeStone"),Field("height","Steinbreite mm",fmt(p.heightMm),true,true,enabledWhen="pavingModeStone"),Field("joint","Fugenbreite mm",fmt(p.jointMm),true),
   Field("bond","Verband",when{kotlin.math.abs(p.offset-1.0/3.0)<0.01->"Reihenverband 1/3";kotlin.math.abs(p.offset-.5)<0.01->"Reihenverband 1/2";kotlin.math.abs(p.offset-.25)<0.01->"Reihenverband 1/4";kotlin.math.abs(p.offset)<0.01->"Kreuzfuge";else->"freier Versatz"},choices=listOf("Kreuzfuge","Reihenverband 1/2","Reihenverband 1/3","Reihenverband 1/4","freier Versatz")),
   Field("offset","Freier Versatz 0–1",fmt(p.offset),true),Field("angle","Ausrichtung °",fmt(p.angle),true),
   Field("cutX","Zuschnitt Breite",when(p.cutX){"left"->"Links";"both"->"Beidseitig";else->"Rechts"},choices=listOf("Links","Rechts","Beidseitig")),
   Field("cutY","Zuschnitt Länge",when(p.cutY){"top"->"Oben";"both"->"Beidseitig";else->"Unten"},choices=listOf("Oben","Unten","Beidseitig"))))
  FormDialog(if(target.str("buildUpVariant")=="waterbound")"Wegeaufbau anpassen" else "Pflasteraufbau anpassen",fields,{dialog=""},onAddCut=if(d.viewMode()=="top")({dialog="";onAddCut(target.id)})else null){v->
   val off=when(v["bond"]){"Kreuzfuge"->0.0;"Reihenverband 1/2"->.5;"Reihenverband 1/3"->1.0/3.0;"Reihenverband 1/4"->.25;else->parseNumber(v["offset"].orEmpty())?:p.offset};require(off in 0.0..1.0)
   val jointMm=parseNumber(v["joint"]!!)!!
   require(jointMm>=0){"Fugenbreite darf nicht negativ sein"}
   val rasterMode=v["pavingModeRaster"]=="ja"
   val stoneWidth=if(rasterMode)(parseNumber(v["rasterWidth"]!!)!!-jointMm)else parseNumber(v["width"]!!)!!
   val stoneHeight=if(rasterMode)(parseNumber(v["rasterHeight"]!!)!!-jointMm)else parseNumber(v["height"]!!)!!
   require(stoneWidth>0 && stoneHeight>0){"Rastermaß muss größer als die Fugenbreite sein"}
   val waterbound=v["buildUpVariant"]=="Wassergebundene Wegedecke"
   val strata=target.strata.mapIndexed{i,layer->val chosen=v["material$i"].orEmpty();val material=if(chosen=="Sonstiges")v["custom$i"].orEmpty().ifBlank{layer.materialId.ifBlank{layer.name}}else pavingLibrary.find{it.name==chosen}?.id?:chosen;layer.copy(materialId=material,name=if(waterbound)when(i){0->"Deckschicht";1->"Tragschicht";2->"Frostschutz";else->layer.name}else when(i){0->"Pflaster";1->"Bettung";2->"Frostschutz";else->layer.name},thicknessMm=parseNumber(v.getValue("thickness$i"))!!,grading=buildUpGrading(chosen))}
   var result=target.copy(strata=strata,pattern=Pattern(stoneWidth,stoneHeight,jointMm,parseNumber(v["angle"]!!)!!,off,p.origin,when(v["cutX"]){"Links"->"left";"Beidseitig"->"both";else->"right"},when(v["cutY"]){"Oben"->"top";"Beidseitig"->"both";else->"bottom"}))
   val newWidth=parseNumber(v["pathWidth"]!!)!!
   val oldWidth=target.num("widthMm",1500.0)
   val sectionWidth=parseNumber(v["sectionWidth"]!!)!!
   val actualWidth=parseNumber(v["realWidth"]!!)!!
   require(newWidth>0 && sectionWidth>0 && actualWidth>0){"Breiten müssen größer als null sein"}
   // Keep the centerline fixed when resizing; the local near end stays at x=0.
   // Presentation offset belongs only to plan view, never to the section elevation.
   result=result.withNum("buildUpTopLengthOffsetMm",target.num("buildUpTopLengthOffsetMm")+(oldWidth-newWidth)/2.0)
   val graphicLength=parseNumber(v["pathLength"]!!)!!
   val sectionLength=parseNumber(v["sectionLength"]!!)!!
   val actualLength=parseNumber(v["realLength"]!!)!!
   require(graphicLength>0 && sectionLength>0 && actualLength>0){"Längen müssen größer als null sein"}
   result=result.withNum("widthMm",newWidth).withNum("buildUpSectionWidthMm",sectionWidth).withNum("buildUpRealWidthMm",actualWidth).withNum("topDepthMm",graphicLength).withNum("buildUpSectionLengthMm",sectionLength).withStr("labelEnabled","true")
    .withStr("buildUpRealLengthEnabled",if(v["realLengthEnabled"]=="ja" || kotlin.math.abs(actualLength-sectionLength)>0.01)"true" else "false")
    .withNum("buildUpRealLengthMm",actualLength)
   val slope=kotlin.math.abs(parseNumber(v["slopePct"].orEmpty())?:0.0)
   require(slope<=100.0){"Gefälle muss zwischen 0 und 100 % liegen"}
   result=result.withStr("buildUpSlopeFixedSide",if(v["slopeFixedSide"]=="Rechts")"right" else "left")
   result=result.withNum("buildUpSlopePct",if(v["slopeDirection"]=="Nach links fallend")-slope else slope)
    .withNum("buildUpSlopeLabelDx",parseNumber(v["slopeLabelDx"].orEmpty())?:0.0)
    .withNum("buildUpSlopeLabelDy",parseNumber(v["slopeLabelDy"].orEmpty())?:0.0)
   // Store the selected material definitions in the project so existing drawings
   // retain their appearance even when the external library is disconnected.
   strata.forEach{layer->libraryMaterials.find{it.id==layer.materialId}?.let{vm.attachLibraryForPlacedVariant(it)}}
   vm.update(result.withStr("pavingDimensionMode",if(rasterMode)"raster" else "stone").withStr("buildUpVariant",if(waterbound)"waterbound" else "paving"))
  }
 }
  "strata"->FormDialog("Pflasteraufbau",e.strata.flatMapIndexed{i,s->listOf(Field("name$i","Schicht ${i+1}: Name",s.name),Field("thickness$i","Dicke mm",fmt(s.thicknessMm),true,true),Field("grading$i","Körnung (z. B. 2/5 oder 0/32)",s.grading))},{dialog=""}){v->vm.update(e.copy(strata=e.strata.mapIndexed{i,s->s.copy(name=v.getValue("name$i"),thicknessMm=parseNumber(v.getValue("thickness$i"))!!,grading=v["grading$i"].orEmpty())}))}
 "stackPattern"->{val p=e.pattern?:Pattern();FormDialog("Pflaster · Draufsicht",listOf(Field("pavingModeRaster","Rastermaß (einschließlich Fuge)",if(e.str("pavingDimensionMode","stone")=="raster")"ja" else "nein",checkbox=true),
   Field("pavingModeStone","Steinmaß (ohne Fuge)",if(e.str("pavingDimensionMode","stone")!="raster")"ja" else "nein",checkbox=true),
   Field("rasterWidth","Rasterlänge mm",fmt(p.widthMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("rasterHeight","Rasterbreite mm",fmt(p.heightMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("width","Steinlänge mm",fmt(p.widthMm),true,true,enabledWhen="pavingModeStone"),Field("height","Steinbreite mm",fmt(p.heightMm),true,true,enabledWhen="pavingModeStone"),Field("joint","Fugenbreite mm",fmt(p.jointMm),true),Field("bond","Verband",when{ kotlin.math.abs(p.offset-1.0/3.0)<0.01->"Reihenverband 1/3";kotlin.math.abs(p.offset-.5)<0.01->"Reihenverband 1/2";kotlin.math.abs(p.offset-.25)<0.01->"Reihenverband 1/4";kotlin.math.abs(p.offset)<0.01->"Kreuzfuge";else->"freier Versatz"},choices=listOf("Kreuzfuge","Reihenverband 1/2","Reihenverband 1/3","Reihenverband 1/4","freier Versatz")),Field("offset","Freier Versatz 0–1",fmt(p.offset),true),Field("angle","Ausrichtung °",fmt(p.angle),true),Field("depth","Darstellungsbreite Draufsicht mm",fmt(e.num("topDepthMm",1000.0)),true,true),Field("cutX","Zuschnitt Breite",when(p.cutX){"left"->"Links";"both"->"Beidseitig";else->"Rechts"},choices=listOf("Links","Rechts","Beidseitig")),Field("cutY","Zuschnitt Länge",when(p.cutY){"top"->"Oben";"both"->"Beidseitig";else->"Unten"},choices=listOf("Oben","Unten","Beidseitig"))),{dialog=""}){v->val off=when(v["bond"]){"Kreuzfuge"->0.0;"Reihenverband 1/2"->.5;"Reihenverband 1/3"->1.0/3.0;"Reihenverband 1/4"->.25;else->parseNumber(v["offset"].orEmpty())?:p.offset};require(off in 0.0..1.0);val jointMm=parseNumber(v["joint"]!!)!!
   require(jointMm>=0){"Fugenbreite darf nicht negativ sein"}
   val rasterMode=v["pavingModeRaster"]=="ja"
   val stoneWidth=if(rasterMode)(parseNumber(v["rasterWidth"]!!)!!-jointMm)else parseNumber(v["width"]!!)!!
   val stoneHeight=if(rasterMode)(parseNumber(v["rasterHeight"]!!)!!-jointMm)else parseNumber(v["height"]!!)!!
   require(stoneWidth>0 && stoneHeight>0){"Rastermaß muss größer als die Fugenbreite sein"}
   vm.update(e.copy(pattern=Pattern(stoneWidth,stoneHeight,jointMm,parseNumber(v["angle"]!!)!!,off,p.origin,when(v["cutX"]){"Links"->"left";"Beidseitig"->"both";else->"right"},when(v["cutY"]){"Oben"->"top";"Beidseitig"->"both";else->"bottom"})).withNum("topDepthMm",parseNumber(v["depth"]!!)!!).withStr("pavingDimensionMode",if(rasterMode)"raster" else "stone"))}}
 }
}
fun paramLabel(key:String)=mapOf("radiusMm" to "Radius mm","widthMm" to "Breite mm","heightMm" to "Höhe mm / Kote mm","crownMm" to "Kronendurchmesser mm","rootMm" to "Wurzelschutzdurchmesser mm (0 = aus)","pitMm" to "Baumgrube mm (0 = aus)","trunkMm" to "Stammdurchmesser mm","spacingMm" to "Pflanzabstand mm","percent" to "Manuelles Gefälle %","mode" to "Modus","unit" to "Anzeige: % / cm/m / 1:x","startHeightMm" to "Starthöhe mm","endHeightMm" to "Endhöhe mm","offsetMm" to "Maßlinienabstand mm","startAngle" to "Startwinkel Grad","sweepAngle" to "Bogenwinkel Grad","direction" to "Blickrichtung: 1 / -1","depthMm" to "Tiefe mm","plantName" to "Pflanzenname","plantHeightMm" to "Pflanzenhöhe mm","trunkCircumferenceMm" to "Stammumfang mm","rootBallMm" to "Ballengröße mm","count" to "Stückzahl")[key]?:key
