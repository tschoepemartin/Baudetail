package de.baudetail.core
import kotlinx.serialization.json.*

import de.baudetail.geometry.*
import kotlin.math.*

fun dimensionTextPosition(a:Vec,b:Vec,aa:Vec,bb:Vec,label:String,textSize:Double,textDx:Double=0.0,textDy:Double=0.0):Vec {
 val mid=(aa+bb)*0.5
 val line=bb-aa
 val len=line.length()
 if(len<1e-9)return mid+Vec(textDx,textDy)
 val u=line*(1.0/len);val n=Vec(-u.y,u.x)
 val witnessMid=(a+b)*0.5;val side=mid-witnessMid
 val sign=if(side.x*n.x+side.y*n.y>=0)1.0 else -1.0
 val approxWidth=label.length*textSize*.62
 val vertical=kotlin.math.abs(line.y)>kotlin.math.abs(line.x)
 // Primitive.Text uses a start anchor. Compensate that here so the number is
 // actually centred on horizontal dimensions. Vertical dimension text stays
 // horizontal but sits close to the dimension line instead of half a label
 // width away from it.
 val auto=if(vertical){
  Vec(mid.x+n.x*(sign*textSize*.85),mid.y-textSize*.34)
 }else{
  Vec(mid.x-approxWidth/2,mid.y+n.y*(sign*textSize*.95))
 }
 return auto+Vec(textDx,textDy)
}

sealed interface Primitive {
 data class Path(val points:List<Vec>,val closed:Boolean=false,val style:Style=Style()):Primitive
 data class Circle(val center:Vec,val radius:Double,val style:Style=Style()):Primitive
 data class Text(val at:Vec,val value:String,val size:Double,val style:Style=Style(),val angle:Double=0.0):Primitive
 data class Asset(val at:Vec,val width:Double,val height:Double,val path:String,val opacity:Double=1.0,val angle:Double=0.0):Primitive
 data class Group(val nodes:List<Primitive>,val translate:Vec=Vec(),val scale:Double=1.0,val angle:Double=0.0,val clip:List<Vec>?=null,val mirrorY:Boolean=false):Primitive
}
/** Compact dimension arrowheads in paper units, not proportional to the measured span. */
fun dimensionArrows(a:Vec,b:Vec,s:Style,scale:Double):List<Primitive> {
 val v=b-a;val len=v.length();if(len<1e-8)return emptyList()
 val u=v*(1.0/len);val n=Vec(-u.y,u.x)
 val head=minOf(1.3*scale,len*.18)
 fun tip(p:Vec,dir:Vec)=Primitive.Path(listOf(p+dir*head+n*(head*.30),p,p+dir*head-n*(head*.30)),style=s)
 return listOf(Primitive.Path(listOf(a,b),style=s),tip(a,u),tip(b,u*(-1.0)))
}
object Scene {
 fun drawing(d:Drawing,p:Project,printing:Boolean=false):List<Primitive> = d.entities.filter {e->val l=d.layers.find {it.id==e.layerId};l?.visible!=false&&visibleIn(e,d)&&(!printing||l?.printable!=false)}.sortedBy{if(isFoundation(it))0 else if(isPipe(it))1 else if(it.kind in setOf("dimension","text","leader","elevation"))3 else 2}.flatMap {entity(it,d,p)}
 fun entity(input:Entity,d:Drawing,p:Project):List<Primitive> {
  val entry=p.libraryEntries.find{it.id==input.libraryId}
  val sourceMaterial=input.materialSnapshot?.let{LibraryEntry(id="snapshot",type="material",name="",category="",appearance=it)}?:p.libraryEntries.find{it.id==input.materialId}
  val material=if(d.viewMode()=="top"&&input.str("fillMode","auto")=="vertical")null else sourceMaterial
  var e=viewEntity((if(material!=null&&closedContour(input))input.copy(style=materialStyle(material,d.viewMode()=="section"))else input).withBuildUpDefaults(entry),d)
  if(e.kind=="component"&&e.str("frozenTemplate")!="true"){
   val rawAsset=e.str("asset_"+d.viewMode()).ifBlank{entry?.views?.get(d.viewMode()).orEmpty()}
   val asset=if(d.viewMode()=="top"&&e.str("grassTopFallback")=="true")"" else rawAsset
   e=e.copy(asset=asset.ifBlank{if(e.view==d.viewMode()&&(d.viewMode()!="top"||e.str("libraryViews")!="true"))e.asset else null})
  }
  val pts=resolvedPoints(e,d);val a=pts.firstOrNull()?:Vec();val b=pts.getOrNull(1)?:a;val s=e.style.copy(widthMm=e.style.widthMm*d.sheet.scale,dashed=e.style.dashed||e.status=="Abbruch"||e.placement.hidden||(d.viewMode()=="top"&&isPipe(input)))
  val textSize=e.style.textPaperMm*d.sheet.scale
  fun text(at:Vec,value:String,size:Double=textSize)=Primitive.Text(at,value,size,s,e.rotation)
  fun textFlat(at:Vec,value:String,size:Double=textSize)=Primitive.Text(at,value,size,s,0.0)
  fun arrow(start:Vec,end:Vec):List<Primitive> {
   val delta=end-start;val dist=delta.length();if(dist<1e-6)return emptyList();val u=delta*(1/dist);val v=Vec(-u.y,u.x);val head=min(2.5*d.sheet.scale,dist/3)
   return listOf(Primitive.Path(listOf(start,end),style=s),Primitive.Path(listOf(end-u*head+v*(head/2),end,end-u*head-v*(head/2)),style=s))
  }
  val rendered=when(if(e.isParametricBuildUp(entry)) "stack" else e.kind) {
   "assembly" -> {
    if(!isStair(e))return emptyList()
    // The assembly always renders the same real library-step instances that are
    // used when a step is inserted individually. The plan view only adds the
    // conventional flight annotation on top.
    val refs=stairReferencePoints(e,d.viewMode())
    val nodes=if(d.viewMode()=="section") stairSteps(e,d,p).flatMap{entity(it.withStr("labelEnabled","false").withStr("labelExplicit","true"),d,p)}.toMutableList() else mutableListOf<Primitive>()
    if(d.viewMode()!="section") {
     val width=e.num("widthMm",1200.0);val total=stairLength(e)
     // Plan convention: the complete flight is one continuous grey footprint.
     // Individual tread/front lines are drawn on top; no library-step top asset
     // may shift or leave half of the stair white.
     val footprint=rectangle(Vec(),Vec(total,width)).map{assemblyPoint(e,it,d.viewMode())}
     nodes.add(Primitive.Path(footprint,true,s.copy(fill="#D0CEC6")))
     refs.chunked(2).filter{it.size==2}.forEach{nodes.add(Primitive.Path(it,style=s.copy(fill=null)))}
     for(y in listOf(0.0,width))nodes.add(Primitive.Path(listOf(assemblyPoint(e,Vec(0.0,y),d.viewMode()),assemblyPoint(e,Vec(total,y),d.viewMode())),style=s.copy(fill=null)))
     val start=assemblyPoint(e,Vec(0.0,width/2),d.viewMode());val end=assemblyPoint(e,Vec(total,width/2),d.viewMode())
     nodes.addAll(arrow(start,end))
     val stairText=(textSize*.34).coerceAtLeast(d.sheet.scale*.85)
     val leftInset=maxOf(d.sheet.scale*1.2,stairText*.45)
     // Primitive.Text is left anchored. Reserve enough room for the four
     // letters of OBEN so the label can never protrude beyond the last tread.
     val rightInset=maxOf(d.sheet.scale*1.2,stairText*3.15)
     val labelY=width*.23
     nodes.add(text(assemblyPoint(e,Vec(leftInset,labelY),d.viewMode()),"UNTEN",stairText))
     nodes.add(text(assemblyPoint(e,Vec((total-rightInset).coerceAtLeast(leftInset),labelY),d.viewMode()),"OBEN",stairText))
    }
    nodes
   }
   "circle" -> listOf(Primitive.Circle(a,e.num("radiusMm",a.distance(b)),s))+materialHatch(e,material,d)
   "arc" -> {val r=e.num("radiusMm",500.0);val from=e.num("startAngle",0.0);val sweep=e.num("sweepAngle",90.0);listOf(Primitive.Path((0..96).map {val t=Math.toRadians(from+sweep*it/96);a+Vec(cos(t),sin(t))*r},style=s))}
   "polyline","area","rect","polygon","building" -> {
    if(!closedContour(e))return listOf(Primitive.Path(pts,style=s))
    val out=mutableListOf<Primitive>(Primitive.Path(pts,true,s));e.pattern?.let {out.add(pattern(pts,it,s,d.sheet.scale))};out.addAll(materialHatch(e.copy(points=pts),material,d));out
   }
   "arrow","leader" -> arrow(a,b)+(if(e.text.isNotEmpty())listOf(text(a,interpolate(e.text,textVariables(e,d,p))))else emptyList())
   "text" -> listOf(text(a,interpolate(e.text,textVariables(e,d,p))))
   "elevation" -> {
    val h=elevationValueMm(input,d);val label=if(abs(h)<0.001)"±0,00" else (if(h>0)"+" else "")+String.format(java.util.Locale.GERMANY,"%.2f",h/1000)
    val prefix=input.str("elevationPrefix").trim().let { if(it.isBlank()) "" else "$it " }
    val arrowPaperMm=input.num("elevationArrowPaperMm",2.5).coerceIn(1.0,12.0)
    val fontPaperMm=input.num("elevationFontPaperMm",3.0).coerceIn(1.5,12.0)
    val r=arrowPaperMm*d.sheet.scale
    // Filled downward-pointing level marker; paper-sized independently of the model scale.
    val tip=a
    val triangle=Primitive.Path(listOf(tip,tip+Vec(-r*.65,-r),tip+Vec(r*.65,-r)),true,s.copy(fill=s.stroke))
    val line=Primitive.Path(listOf(tip+Vec(-r*.65,-r),tip+Vec(r*3.0,-r)),style=s)
    val labelAt=tip+Vec(r*1.0,-r*1.35)+elevationLabelOffset(input,d.viewMode())
    listOf(triangle,line,textFlat(labelAt,prefix+label,fontPaperMm*d.sheet.scale))
   }
   "foundation" -> {
    val outline=foundationOutline(input,d);val fill=s.fill?:"#C8C8C3"
    val b=if(outline.size>=3)Bounds.of(outline)else Bounds(Vec(),Vec())
    val overlaps=d.entities.any{it.id!=input.id&&isFoundation(it)&&visibleIn(it,d)&&runCatching{val ob=Bounds.of(foundationOutline(it,d));!(ob.max.x<b.min.x||ob.min.x>b.max.x||ob.max.y<b.min.y||ob.min.y>b.max.y)}.getOrDefault(false)}
    // When foundations overlap they remain separate model objects but visually merge.
    val concrete=s.copy(fill=fill,stroke=if(overlaps)fill else s.stroke)
    val nodes=mutableListOf<Primitive>();if(outline.size>=3){nodes.add(Primitive.Path(outline,true,concrete));nodes.addAll(materialHatch(input.copy(kind="polygon",points=outline),material,d))};nodes
   }
   "slope" -> arrow(a,b)+text((a+b)*0.5+Vec(0.0,-textSize),slopeLabel(e,d))
   "dimension" -> {
    if(e.str("metric").isNotEmpty()){
     val source=d.entities.find{it.id==e.str("sourceId")};val witnesses=source?.let{metricWitnesses(it,e.str("metric"),d)}
     if(witnesses==null)return emptyList()
     if(e.str("metric")=="Stufengefälle") {
      val value=dimensionLabel(e,d);val shift=Vec(e.num("dimDx"),e.num("dimDy"));val start=witnesses[0]+shift;val end=witnesses[1]+shift
      // Point the slope arrow toward the lower/front side of the step.
      val downhillStart=if((source?.num("slope") ?: 0.0)>=0.0) end else start
      val downhillEnd=if((source?.num("slope") ?: 0.0)>=0.0) start else end
      return arrow(downhillStart,downhillEnd)+listOf(textFlat((start+end)*.5+Vec(0.0,-textSize*.65),value))
     }
     val stairHeight=isStair(source?:e)&&e.str("metric") in setOf("Gesamthöhe","Stufenhöhe")
     val actualWitnesses=if(stairHeight && source!=null) {
      val right=e.num("dimDx")+a.x-e.num("metricOriginX",a.x) > (witnesses[0].x+witnesses[1].x)/2 - a.x
      stairHeightWitnesses(source,if(e.str("metric")=="Gesamthöhe")stairCount(source)-1 else 0,e.str("metric")=="Gesamthöhe",right)
     }else witnesses
     val annotation=e.copy(points=actualWitnesses,anchors=emptyList(),bindings=emptyList(),params=JsonObject(e.params-setOf("metric","sourceId"))).withStr("renderLabel",dimensionLabel(e,d)).withStr("shortWitness",if(false)"true" else "false").withNum("dimDx",e.num("dimDx")+a.x-e.num("metricOriginX",a.x)).withNum("dimDy",e.num("dimDy")+a.y-e.num("metricOriginY",a.y))
     return entity(annotation,d,p)
    }
    val mode=e.str("mode","aligned")
    if(mode=="chain") return pts.zipWithNext().flatMap { (start,end) -> entity(e.copy(points=listOf(start,end),anchors=emptyList()).withStr("mode","aligned"),d,p) }
    if(mode=="angle" && pts.size>=3) {
     val center=pts[1];val first=pts[0]-center;val last=pts[2]-center;val from=atan2(first.y,first.x);var sweep=atan2(last.y,last.x)-from
     while(sweep>PI)sweep-=2*PI;while(sweep< -PI)sweep+=2*PI
     val r=abs(e.num("offsetMm",8*d.sheet.scale)).coerceAtLeast(textSize*2)
     val arc=(0..64).map { val t=from+sweep*it/64;center+Vec(cos(t),sin(t))*r }
     return listOf(Primitive.Path(listOf(pts[0],center,pts[2]),style=s),Primitive.Path(arc,style=s),text(center+Vec(cos(from+sweep/2),sin(from+sweep/2))*(r+textSize),"${fmt(dimensionValue(e,d))}°"))
    }
    val rawDelta=b-a;val dist=rawDelta.length();val off=e.num("offsetMm",d.sheet.scale*8)
    val base=when(mode){"horizontal"->Vec(0.0,off);"vertical"->Vec(off,0.0);else->if(dist>0)Vec(-rawDelta.y/dist,rawDelta.x/dist)*off else Vec(0.0,off)}
    val shift=Vec(e.num("dimDx"),e.num("dimDy"));val aa=a+base+shift;val bb=when(mode){"horizontal"->Vec(b.x+shift.x,aa.y);"vertical"->Vec(aa.x,b.y+shift.y);else->b+base+shift}
    val label=e.str("renderLabel",dimensionLabel(e,d))
    val labelAt=dimensionTextPosition(a,b,aa,bb,label,textSize,e.num("textDx"),e.num("textDy"))
    run {
     val witnessGap=textSize*.35
     fun trim(from:Vec,to:Vec):List<Vec> {val delta=to-from;val len=delta.length();return if(len<witnessGap)emptyList() else listOf(from+delta*(witnessGap/len),to)}
     val guides=if(e.str("shortWitness")=="true") {
      val maxLen=textSize*4.0
      listOf(a to aa,b to bb).mapNotNull{(from,to)->val delta=to-from;val len=delta.length();if(len<1e-9)null else Primitive.Path(listOf(to-delta*(minOf(len,maxLen)/len),to),style=s)}
     }else listOf(trim(a,aa),trim(b,bb)).filter{it.size==2}.map{Primitive.Path(it,style=s)}
     guides+dimensionArrows(aa,bb,s,d.sheet.scale)+text(labelAt,label)
    }
   }
   "section" -> {
    val delta=b-a;val u=if(delta.length()>0)delta*(1/delta.length())else Vec(1.0,0.0);val v=Vec(-u.y,u.x)*(e.num("direction",1.0)*d.sheet.scale*7)
    listOf(Primitive.Path(listOf(a,b),style=s.copy(dashed=true)))+arrow(a,a+v)+arrow(b,b+v)+text(a+v*1.4,e.text.ifBlank {"A–A"})+text(b+v*1.4,e.text.ifBlank {"A–A"})
   }
   "tree" -> {
    val r=e.num("crownMm",2000.0)/2;val out=mutableListOf<Primitive>(Primitive.Circle(a,r,s),Primitive.Circle(a,e.num("trunkMm",120.0)/2,s.copy(fill=s.stroke)),Primitive.Path(listOf(a-Vec(r,0.0),a+Vec(r,0.0)),style=s),Primitive.Path(listOf(a-Vec(0.0,r),a+Vec(0.0,r)),style=s))
    if(e.num("rootMm")>0)out.add(Primitive.Circle(a,e.num("rootMm")/2,s.copy(fill=null,dashed=true)))
    if(e.num("pitMm")>0)out.add(Primitive.Path(rectangle(a-Vec(e.num("pitMm")/2,e.num("pitMm")/2),a+Vec(e.num("pitMm")/2,e.num("pitMm")/2)),true,s.copy(fill=null,dashed=true)))
    if(e.name.isNotEmpty())out.add(text(a+Vec(r*0.6,-r),e.name));out
   }
   "hedge" -> {
    val spacing=e.num("spacingMm",400.0).coerceAtLeast(1.0);val len=length(pts);val n=hedgeCount(len,spacing);val r=e.num("widthMm",600.0)/2
    val nodes=mutableListOf<Primitive>(Primitive.Path(pts,style=s.copy(widthMm=r*2,opacity=0.25)))
    if(n<=1500)for(i in 0 until n)nodes.add(Primitive.Circle(pointAt(pts,if(n<=1)0.0 else len*i/(n-1)),r,s))
    nodes.add(text(a+Vec(0.0,-r-textSize),"${e.name.ifBlank {"Hecke"}} · $n Stk"));nodes
   }
   "stack" -> {
    val w=if(d.viewMode()=="section")e.num("topDepthMm",e.num("widthMm",1500.0))else e.num("widthMm",1500.0);val nodes=mutableListOf<Primitive>()
    // Every non-section view is a plan/top representation. This deliberately
    // avoids falling back to the layer section when an older drawing carries a
    // legacy plan-view token in extensions.
    if(d.viewMode()!="section"){
     val depth=e.num("topDepthMm",1000.0).coerceAtLeast(1.0);val poly=rectangle(Vec(),Vec(w,depth));val paving=e.strata.firstOrNull()
     nodes.add(Primitive.Path(poly,true,s.copy(fill=paving?.color?:"#B6BBB7")))
     nodes.add(pattern(poly,e.pattern?:Pattern(200.0,100.0,4.0,0.0,1.0/3.0),s,d.sheet.scale))
    }else{
     var y=0.0
     e.strata.forEachIndexed{i,layer->
      val top=y;val bottom=y+layer.thicknessMm
      nodes.add(Primitive.Path(rectangle(Vec(0.0,top),Vec(w,bottom)),true,s.copy(fill=layer.color)))
      if(i==0){
       val stone=(e.pattern?.widthMm?:200.0).coerceAtLeast(20.0);var x=stone
       while(x<w){nodes.add(Primitive.Path(listOf(Vec(x,top),Vec(x,bottom)),style=s.copy(fill=null,widthMm=.16*d.sheet.scale)));x+=stone}
      }else{
       val grading=layer.grading.ifBlank{if(layer.name.contains("Bett",true))"2/5" else if(layer.name.contains("Frost",true)||layer.name.contains("Trag",true))"0/32" else ""}
       val maxGrain=grading.substringAfter('/',"").replace(',','.').toDoubleOrNull()?:if(i==1)5.0 else 32.0
       val step=(maxGrain*2.2).coerceIn(18.0,85.0);var gy=top+step*.55;var row=0
       while(gy<bottom){var gx=step*.45+(row%2)*step*.4;while(gx<w){val r=(maxGrain*.22).coerceIn(1.2,7.0);nodes.add(Primitive.Circle(Vec(gx,gy),r,s.copy(fill=null,widthMm=.10*d.sheet.scale)));gx+=step};gy+=step*.8;row++}
      }
      y=bottom
     }
    }
    listOf(Primitive.Group(nodes,if(d.viewMode()=="section")a else buildUpPlanOrigin(e),angle=if(d.viewMode()=="section")e.rotation else buildUpPlanAngle(e)))
   }
   "legend" -> {
    val base=legendItems(d,p.libraryEntries)
    fun order(item:LegendItem)=e.num("legendOrder:${item.key}",base.indexOf(item).toDouble())
    val items=base.filter{e.str("legendVisible:${it.key}","true")!="false"}.sortedBy(::order)
    val nodes=mutableListOf<Primitive>();var y=0.0
    if(e.text.isNotBlank()){nodes.add(Primitive.Text(Vec(0.0,y),e.text,textSize,s.copy(bold=true)));y+=textSize*1.7}
    items.forEach {item->
     val label=e.str("legendLabel:${item.key}").ifBlank{item.label}
     val fill=e.str("legendColor:${item.key}").ifBlank{item.style.fill?:"#D0D0D0"}
     nodes.add(Primitive.Path(rectangle(Vec(0.0,y-textSize),Vec(textSize*1.6,y)),true,s.copy(fill=fill)))
     nodes.add(Primitive.Text(Vec(textSize*2,y),label,textSize,s));y+=textSize*1.7
    }
    listOf(Primitive.Group(nodes,a))
   }
   "component" -> {
    when {
     e.smartFamily()=="curb" -> {
      // The chamfer is rendered visually here. Snap geometry intentionally remains
      // rectangular with two explicit height levels (OK and lower chamfer level).
      val outer=curbLocalOutline(e,d.viewMode())
      val w=if(d.viewMode()=="section")e.num("sectionWidthMm",e.num("widthMm",100.0)) else e.num("topWidthMm",e.num("widthMm",1000.0))
      val h=if(d.viewMode()=="section")e.num("sectionHeightMm",e.num("heightMm",200.0)) else e.num("topHeightMm",e.num("heightMm",100.0))
      val edge=(minOf(1.5,w*.025,h*.025)).coerceAtLeast(.35)
      val body=s.fill?:"#CFCFC8"
      val edgeStyle=s.copy(stroke=body,fill="#4B5652",widthMm=.01)
      val bodyStyle=s.copy(stroke=body,fill=body,widthMm=.01)
      val nodes=mutableListOf<Primitive>()
      nodes.add(Primitive.Path(outer,true,edgeStyle))
      if(w>edge*2&&h>edge*2){
       val inner=if(d.viewMode()=="section"&&curbHasChamfer(e)){
        val cw=curbChamferWidthMm(e).coerceAtMost(w);val cd=curbChamferDepthMm(e).coerceAtMost(h)
        listOf(Vec(edge,edge),Vec((w-cw-edge).coerceAtLeast(edge),edge),Vec(w-edge,(cd+edge).coerceAtMost(h-edge)),Vec(w-edge,h-edge),Vec(edge,h-edge))
       }else rectangle(Vec(edge,edge),Vec(w-edge,h-edge))
       nodes.add(Primitive.Path(inner,true,bodyStyle))
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isChannelBox(e) -> {
      val bw=e.num("boxWidthMm",185.0);val bh=e.num("boxHeightMm",610.0);val bl=e.num("boxLengthMm",500.0);val nw=e.num("channelNominalWidthMm",150.0);val dn=e.num("pipeDnMm",160.0);val axis=e.num("pipeAxisFromTopMm",500.0);val side=e.str("pipeOutlet","none")
      val channelType=e.str("channelType","box")
      val loadClass=e.str("loadClass","B 125")
      val grateType=e.str("grateType",when(channelType){"slot"->"Schlitz";"facade"->"Längsstab";else->"Gitterrost"})
      // The parametric dimensions are the single source of truth. Decorative
      // strokes are drawn *inside* those millimetre bounds so screen graphics,
      // hit box, dimensions and print/PDF all describe the same real geometry.
      val outlineW=0.25*d.sheet.scale
      val detailW=0.22*d.sheet.scale
      val halfOutline=outlineW/2.0
      val bodyFill=s.copy(stroke="#D9C27C",fill=s.fill?:"#D9C27C",widthMm=0.01*d.sheet.scale)
      val outline=s.copy(stroke="#6A603F",fill=null,widthMm=outlineW)
      val dark=s.copy(stroke="#42484A",fill="#596164",widthMm=detailW)
      val metal=s.copy(stroke="#50575A",fill="#AAB0B2",widthMm=detailW)
      val nodes=mutableListOf<Primitive>()
      if(d.viewMode()=="top"){
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(bl,bw)),true,bodyFill))
       nodes.add(Primitive.Path(rectangle(Vec(halfOutline,halfOutline),Vec(bl-halfOutline,bw-halfOutline)),true,outline))
       val grateW=nw.coerceAtMost(bw);val y0=(bw-grateW)/2
       val inset=(detailW/2).coerceAtMost(grateW/8)
       if(channelType=="slot"||grateType=="Schlitz"){
        val slotW=minOf(grateW*.16,30.0).coerceAtLeast(12.0);val sx=bl/2-slotW/2
        nodes.add(Primitive.Path(rectangle(Vec(sx,y0+inset),Vec(sx+slotW,y0+grateW-inset)),true,dark.copy(fill="#596164",widthMm=0.01*d.sheet.scale)))
       }else{
        nodes.add(Primitive.Path(rectangle(Vec(inset,y0+inset),Vec(bl-inset,y0+grateW-inset)),true,metal))
        when(grateType){
         "Längsstäbe","Längsstab"->{for(i in 1..7){val y=y0+grateW*i/8;nodes.add(Primitive.Path(listOf(Vec(inset,y),Vec(bl-inset,y)),style=dark.copy(fill=null)))}}
         "Stegrost"->{for(i in 1..10){val x=bl*i/11;nodes.add(Primitive.Path(listOf(Vec(x,y0+inset),Vec(x,y0+grateW-inset)),style=dark.copy(fill=null,widthMm=.38*d.sheet.scale)))}}
         "Stabgitter"->{for(i in 1..16){val x=bl*i/17;nodes.add(Primitive.Path(listOf(Vec(x,y0+inset),Vec(x,y0+grateW-inset)),style=dark.copy(fill=null)))};for(i in 1..3){val y=y0+grateW*i/4;nodes.add(Primitive.Path(listOf(Vec(inset,y),Vec(bl-inset,y)),style=dark.copy(fill=null,widthMm=.32*d.sheet.scale)))}}
         else->{for(i in 1..12){val x=bl*i/13;nodes.add(Primitive.Path(listOf(Vec(x,y0+inset),Vec(x,y0+grateW-inset)),style=dark.copy(fill=null)))};for(i in 1..5){val y=y0+grateW*i/6;nodes.add(Primitive.Path(listOf(Vec(inset,y),Vec(bl-inset,y)),style=dark.copy(fill=null)))}}
        }
       }
       if(e.str("leafBasket","true")=="true"&&channelType!="slot")nodes.add(Primitive.Path(rectangle(Vec(bl*.25,y0+grateW*.15),Vec(bl*.75,y0+grateW*.85)),true,dark.copy(fill=null,dashed=true)))
      } else {
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(bw,bh)),true,bodyFill))
       nodes.add(Primitive.Path(rectangle(Vec(halfOutline,halfOutline),Vec(bw-halfOutline,bh-halfOutline)),true,outline))
       val cx=bw/2;val cutW=nw.coerceAtMost(bw);val cutD=minOf(150.0,bh*.26)
       val frameH=if(e.str("grateVisible","true")=="true")minOf(24.0,bh*.04) else 0.0
       when(channelType){
        "slot"->{
         val slotW=minOf(cutW*.16,24.0).coerceAtLeast(10.0)
         nodes.add(Primitive.Path(rectangle(Vec(cx-slotW/2,0.0),Vec(cx+slotW/2,frameH.coerceAtLeast(18.0))),true,dark.copy(widthMm=0.01*d.sheet.scale)))
        }
        "facade"->{
         val sideW=(cutW*.28).coerceAtLeast(24.0)
         nodes.add(Primitive.Path(rectangle(Vec((bw-cutW)/2,0.0),Vec((bw-cutW)/2+sideW,frameH.coerceAtLeast(20.0))),true,dark.copy(widthMm=0.01*d.sheet.scale)))
        }
        else->{
         if(e.str("grateVisible","true")=="true")nodes.add(Primitive.Path(rectangle(Vec((bw-cutW)/2,0.0),Vec((bw+cutW)/2,frameH)),true,dark.copy(widthMm=0.01*d.sheet.scale)))
        }
       }
       val topY=frameH
       nodes.add(Primitive.Path(listOf(Vec(cx-cutW/2,topY),Vec(cx-cutW/2,topY+cutD*.35),Vec(cx,topY+cutD*.88),Vec(cx+cutW/2,topY+cutD*.35),Vec(cx+cutW/2,topY)),style=dark.copy(fill=null)))
       if(e.str("leafBasket","true")=="true"&&channelType!="slot")nodes.add(Primitive.Path(rectangle(Vec(cx-cutW*.32,topY+cutD+20),Vec(cx+cutW*.32,(topY+cutD+170).coerceAtMost(bh-halfOutline))),true,metal.copy(fill=null,dashed=true)))
       if(side!="none"){
        val y=if(side=="bottom")bh else axis.coerceIn(dn/2,bh-dn/2);val x=when(side){"left"->0.0;"right"->bw;else->bw/2.0}
        val outletStroke=0.22*d.sheet.scale
        val outletRadius=(dn/2-outletStroke/2).coerceAtLeast(dn*.40)
        nodes.add(Primitive.Circle(Vec(x,y),outletRadius,dark.copy(fill="#5B6D78",widthMm=outletStroke)))
       }
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isRetainingWall(e) -> {
      if(d.viewMode()=="section") listOf(Primitive.Group(listOf(Primitive.Path(retainingWallSection(e),true,s.copy(fill=s.fill?:"#D0CEC6"))),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      else {val (wall,foot)=retainingWallTop(e);listOf(Primitive.Group(listOf(Primitive.Path(foot,true,s.copy(fill=null,dashed=true)),Primitive.Path(wall,true,s.copy(fill=s.fill?:"#D0CEC6"))),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))}
     }
     isPipe(e) -> {
      val dn=e.num("dnMm",e.num("sectionHeightMm",160.0)).coerceAtLeast(1.0);val vertical=e.str("orientation","horizontal")=="vertical";val dir=if(e.str("verticalDirection","down")=="up")-1.0 else 1.0;val len=e.num("pipeLengthMm",e.num("verticalLengthMm",1000.0)).coerceAtLeast(dn)
      if(isKg2000(e)&&!vertical){
       val green=s.copy(stroke="#0B5F34",fill="#149447",widthMm=0.5*d.sheet.scale);val dark=s.copy(stroke="#063E23",fill="#0C6E3B",widthMm=0.45*d.sheet.scale);val type=e.str("fittingType","pipe");val nodes=mutableListOf<Primitive>()
       when(type){
        "bend"->{val g=kg2000BendGeometry(e,d.viewMode());val socketLen=minOf(g.path.getOrElse(1){Vec(dn*.4,0.0)}.x.coerceAtLeast(dn*.25),dn*.55);nodes.add(Primitive.Path(g.path,style=green.copy(fill=null,widthMm=dn)));nodes.add(Primitive.Path(listOf(Vec(),Vec(socketLen,0.0)),style=dark.copy(fill=null,widthMm=dn*1.12)));nodes.add(Primitive.Path(listOf(Vec(socketLen*.18,0.0),Vec(socketLen,0.0)),style=green.copy(fill=null,widthMm=dn)));}
        "y"->{val branch=e.num("branchDnMm",dn);nodes.add(Primitive.Path(listOf(Vec(),Vec(len,0.0)),style=green.copy(fill=null,widthMm=dn)));nodes.add(Primitive.Path(listOf(Vec(len*.52,0.0),Vec(len*.88,len*.36)),style=green.copy(fill=null,widthMm=branch)));nodes.add(Primitive.Circle(Vec(),dn*.62,dark))}
        "reducer"->{val big=e.num("inletDnMm",dn);val small=e.num("outletDnMm",dn);val actualLen=kg2000ReducerLengthMm(big.toInt(),small.toInt())?:len;val sy=(big-small)/2.0;nodes.add(Primitive.Path(listOf(Vec(0.0,-big/2),Vec(actualLen,sy-small/2),Vec(actualLen,sy+small/2),Vec(0.0,big/2)),true,green));val od=kg2000SocketOuterDnMm(small);val socketLen=minOf(kg2000SocketProjectionMm(small),actualLen*.45);nodes.add(Primitive.Path(rectangle(Vec(actualLen-socketLen,sy-od/2),Vec(actualLen,sy+od/2)),true,dark))}
        "double_spigot"->{nodes.add(Primitive.Path(rectangle(Vec(),Vec(len,dn)),true,green))}
        else->{nodes.add(Primitive.Path(rectangle(Vec(),Vec(len,dn)),true,green));val od=kg2000SocketOuterDnMm(dn);val socketLen=minOf(kg2000SocketProjectionMm(dn),len*.45);nodes.add(Primitive.Path(rectangle(Vec(0.0,(dn-od)/2),Vec(socketLen,(dn+od)/2)),true,dark))}
       }
       if(e.str("flowArrow","true")=="true"){if(type=="bend"){val path=kg2000BendGeometry(e,d.viewMode()).path;val a=path[(path.size*.35).toInt().coerceIn(0,path.lastIndex)];val b=path[(path.size*.65).toInt().coerceIn(0,path.lastIndex)];val reverse=e.str("flowDirection","forward")=="reverse";nodes.addAll(arrow(if(reverse)b else a,if(reverse)a else b))}else{val cy=if(type in setOf("pipe","double_spigot"))dn*.5 else 0.0;val from=if(e.str("flowDirection","forward")=="reverse")Vec(len*.65,cy)else Vec(len*.35,cy);val to=if(e.str("flowDirection","forward")=="reverse")Vec(len*.35,cy)else Vec(len*.65,cy);nodes.addAll(arrow(from,to))}}
       listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      } else {
       val node=if(d.viewMode()=="section") {if(vertical)Primitive.Path(rectangle(Vec(-dn/2,0.0),Vec(dn/2,dir*len)),true,s.copy(fill=s.fill)) else Primitive.Circle(Vec(),dn/2,s.copy(fill=s.fill))} else {if(vertical)Primitive.Circle(Vec(),dn/2,s.copy(fill=s.fill)) else Primitive.Path(rectangle(Vec(),Vec(e.num("topWidthMm",len),dn)),true,s.copy(fill=s.fill))}
       listOf(Primitive.Group(listOf(node),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      }
     }
     e.smartFamily()=="grass" && d.viewMode()=="section" && e.asset==null -> {
      val w=e.num("sectionWidthMm",1000.0);val h=e.num("sectionHeightMm",150.0);val grassStyle=s.copy(fill=s.fill?:"#B79B72");val blades=(0..(w/35).toInt().coerceAtMost(200)).map{i->val x=i*35.0;Primitive.Path(listOf(Vec(x,0.0),Vec(x+7,-20.0),Vec(x+13,0.0)),style=s.copy(stroke="#6F9B55"))};listOf(Primitive.Group(listOf(Primitive.Path(rectangle(Vec(),Vec(w,h)),true,grassStyle))+blades,a,angle=e.rotation))
     }
     e.children.isNotEmpty()&&(e.str("frozenTemplate")=="true"||(e.asset==null&&e.view==d.viewMode()&&(e.str("libraryViews")!="true"||d.viewMode()=="section"))) -> {
      val bounds=Bounds.of(e.children.flatMap {it.points});val base=e.num("baseWidthMm",bounds.width.coerceAtLeast(1.0));val scale=if(e.str("frozenTemplate")=="true")e.num("templateScale",1.0)else e.num("widthMm",base)/base
      listOf(Primitive.Group(e.children.flatMap {entity(it,d,p)},a,scale,e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     e.asset!=null -> listOf(Primitive.Group(listOf(Primitive.Asset(Vec(),e.num("widthMm",500.0),e.num("heightMm",500.0),e.asset,s.opacity)),a,angle=e.rotation+(if(d.viewMode()=="section")-Math.toDegrees(atan(e.num("slope")/100))else 0.0),mirrorY=e.num("mirrored")==1.0))
     else -> listOf(Primitive.Group(listOf(Primitive.Path(rectangle(Vec(),Vec(e.num("widthMm",500.0),e.num("heightMm",500.0))),true,s)),a,angle=e.rotation+(if(d.viewMode()=="section")-Math.toDegrees(atan(e.num("slope")/100))else 0.0),mirrorY=e.num("mirrored")==1.0))
    }
   }
   "image" -> if(e.asset!=null)listOf(Primitive.Asset(a,e.num("widthMm",1000.0),e.num("heightMm",1000.0),e.asset,s.opacity,e.rotation))else listOf(text(a,"Ressource fehlt"))
   else -> listOf(Primitive.Path(pts,style=s))
  }
  if(labelActive(e,d)) {
   val atLabel=objectLabelPosition(input,d)
   val target=objectLabelTarget(input,d,atLabel)
   val value=if(input.str("labelMode","auto")=="manual"&&input.str("labelText").isNotBlank())input.str("labelText") else {
    when {
     isChannelBox(input) && input.name.contains("Einlaufkasten",ignoreCase=true) -> "Einlaufkasten"
     input.isParametricBuildUp(entry) -> buildUpLabel(input)
     isStair(input) -> "Blockstufenanlage"
     else -> input.name.ifBlank{input.kind}
    }
   }
   val lines=value.split("\n")
   val lineHeight=textSize*1.4
   val maxWidth=(lines.maxOfOrNull{it.length}?:0)*textSize*.57
   // Text origin is a baseline; leader connects to the nearest outer edge of its bounding box.
   val labelLeft=atLabel.x;val labelRight=atLabel.x+maxWidth
   val labelTop=atLabel.y-textSize;val labelBottom=atLabel.y+(lines.size-1)*lineHeight+textSize*.3
   val attach=Vec(target.x.coerceIn(labelLeft,labelRight),target.y.coerceIn(labelTop,labelBottom))
   val left=Vec(labelLeft,target.y.coerceIn(labelTop,labelBottom));val right=Vec(labelRight,target.y.coerceIn(labelTop,labelBottom))
   val top=Vec(target.x.coerceIn(labelLeft,labelRight),labelTop);val bottom=Vec(target.x.coerceIn(labelLeft,labelRight),labelBottom)
   val boundary=listOf(left,right,top,bottom).minByOrNull{it.distance(target)}?:attach
   return rendered+arrow(boundary,target)+lines.flatMapIndexed{i,line->listOf(textFlat(atLabel+Vec(0.0,i*lineHeight),line))}
  }
  return rendered
 }
 fun materialHatch(e:Entity,entry:LibraryEntry?,d:Drawing):List<Primitive>{
  if(entry==null||d.viewMode()!="section")return emptyList()
  val asset=entry.appearance?.sectionPattern?:entry.views["section"]?:return emptyList()
  val polygon=contour(e);if(polygon.size<3)return emptyList();val b=Bounds.of(polygon)
  val gravel=(entry.name+" "+entry.category).lowercase().let{it.contains("kies")||it.contains("schotter")||it.contains("schütt")||it.contains("frostschutz")||it.contains("rc ")}
  if(gravel){
   val step=38.0;val dots=mutableListOf<Primitive>();var y=b.min.y+step*.45;var row=0
   while(y<b.max.y){var x=b.min.x+step*.4+(row%2)*step*.35;while(x<b.max.x){dots.add(Primitive.Circle(Vec(x,y),4.0,style=Style(stroke=e.style.stroke,fill=null,widthMm=.10*d.sheet.scale)));x+=step};y+=step*.72;row++}
   return listOf(Primitive.Group(dots,clip=polygon))
  }
  val w=(entry.appearance?.tileWidthMm?:entry.attribute("pattern_width_mm",200.0)).coerceAtLeast(1.0);val h=(entry.appearance?.tileHeightMm?:entry.attribute("pattern_height_mm",200.0)).coerceAtLeast(1.0)
  val cols=ceil(b.width/w).toInt().coerceAtLeast(1);val rows=ceil(b.height/h).toInt().coerceAtLeast(1)
  if(cols.toLong()*rows>10000)return listOf(Primitive.Text(b.min,"Schraffur: Fläche teilen (mehr als 10.000 Kacheln)",3*d.sheet.scale))
  return listOf(Primitive.Group((0 until rows).flatMap{y->(0 until cols).map{x->Primitive.Asset(b.min+Vec(x*w,y*h),w,h,asset)}},clip=polygon))
 }
 fun pattern(poly:List<Vec>,p:Pattern,style:Style,scale:Double):Primitive {
  val dx=(p.widthMm+p.jointMm).coerceAtLeast(1.0);val dy=(p.heightMm+p.jointMm).coerceAtLeast(1.0)
  val bounds=Bounds.of(poly.map {(it-p.origin).rotate(-p.angle)})
  val minX=floor(bounds.min.x/dx).toInt()-2;val maxX=ceil(bounds.max.x/dx).toInt()+2;val minY=floor(bounds.min.y/dy).toInt()-2;val maxY=ceil(bounds.max.y/dy).toInt()+2
  val nodes=mutableListOf<Primitive>();val count=(maxX.toLong()-minX+1)*(maxY.toLong()-minY+1)
  if(count<=40000)for(row in minY..maxY)for(col in minX..maxX){val offset=if(row%2==0)0.0 else p.offset*dx;val a=Vec(col*dx+offset,row*dy);nodes.add(Primitive.Path(rectangle(a,a+Vec(p.widthMm,p.heightMm)),true,style.copy(fill=null,widthMm=0.12*scale)))}
  return Primitive.Group(listOf(Primitive.Group(nodes,p.origin,angle=p.angle)),clip=poly)
 }
 /** Two independent scale-preserving viewports on one physical sheet. */
 fun paperDual(d:Drawing,p:Project,sectionPos:Vec,topPos:Vec,sectionScale:Double,topScale:Double,sectionOrigin:Vec,topOrigin:Vec):List<Primitive> {
  val sh=d.sheet
  val margin=10.0
  val bottom=sh.heightMm-32.0
  val frame=Style(stroke="#69756F",widthMm=0.18)
  val paneW=(sh.widthMm-3*margin)/2.0
  val paneH=(bottom-2*margin).coerceAtLeast(5.0)
  fun pane(view:String,pos:Vec,scale:Double,origin:Vec):List<Primitive> {
   val v=d.copy(extensions=JsonObject(d.extensions.toMutableMap().apply{put("viewMode",JsonPrimitive(view))}))
   val nodes=drawing(v,p,true)
   val group=Primitive.Group(nodes,Vec(pos.x-origin.x/scale,pos.y-origin.y/scale),1/scale)
   val border=Primitive.Path(rectangle(pos,pos+Vec(paneW,paneH)),true,frame.copy(fill=null))
   val caption=Primitive.Text(pos+Vec(2.0,5.0),if(view=="section")"Schnitt · 1:${scale.toInt()}" else "Draufsicht · 1:${scale.toInt()}",2.8,frame)
   return listOf(Primitive.Group(listOf(group),clip=rectangle(pos+Vec(1.0,8.0),pos+Vec(paneW-1.0,paneH-1.0))),border,caption)
  }
  val title=Primitive.Path(rectangle(Vec(margin,bottom+2.0),Vec(sh.widthMm-margin,sh.heightMm-margin)),true,frame)
  val titleText=Primitive.Text(Vec(margin+3,bottom+9),"${p.name} · Schnitt und Draufsicht",3.0,frame)
  return pane("section",sectionPos,sectionScale,sectionOrigin)+pane("top",topPos,topScale,topOrigin)+listOf(title,titleText)
 }
 fun paper(d:Drawing,p:Project):List<Primitive> {
  val sh=d.sheet;val margin=10.0;val bottom=sh.heightMm-32.0
  val printableW=(sh.widthMm-2*margin).coerceAtLeast(1.0)*sh.scale
  val printableH=(bottom-margin).coerceAtLeast(1.0)*sh.scale
  val visible=d.entities.filter { e ->
   val l=d.layers.find{it.id==e.layerId};l?.visible!=false&&l?.printable!=false&&visibleIn(e,d)
  }
  // sheet.origin is the fixed lower-left world anchor of the printable area.
  // Changing A4/A3/A2 therefore grows/shrinks the sheet to the right and upward
  // without moving the drawing. Only translation changes placement; scale stays exact.
  val exportOrigin=sh.origin
  val content=Primitive.Group(drawing(d,p,true),Vec(margin-exportOrigin.x/sh.scale,bottom-exportOrigin.y/sh.scale),1/sh.scale)
  val style=Style(widthMm=0.2)
  val titleLines=interpolate(sh.titleTemplate,variables(p,d)).lines().map{it.trimEnd()}.filter{it.isNotBlank()}
  val titleSize=2.6
  val frameTop=bottom+2
  val head=mutableListOf<Primitive>(
   Primitive.Group(listOf(content),clip=rectangle(Vec(margin,margin),Vec(sh.widthMm-margin,bottom))),
   Primitive.Path(rectangle(Vec(margin,frameTop),Vec(sh.widthMm-margin,sh.heightMm-margin)),true,style)
  )
  titleLines.take(4).forEachIndexed{i,line->head.add(Primitive.Text(Vec(margin+3,frameTop+5+i*3.8),line,titleSize,style))}
  head.add(Primitive.Path(listOf(Vec(sh.widthMm-115,sh.heightMm-15),Vec(sh.widthMm-15,sh.heightMm-15)),style=style))
  head.add(Primitive.Text(Vec(sh.widthMm-115,sh.heightMm-17),"Kontrollmaß 100 mm · Druck 100 %",2.2,style))
  return head
 }
}
