# 0.9.123

- A1 (594 × 841 mm) und A0 (841 × 1189 mm) als Papierformat-Schaltflächen im Export ergänzt.
- Formatleiste horizontal scrollbar, um alle Formate auch auf schmalen Displays zu erreichen.
- Papierformat-Hinweis im Zeichenblatt-Dialog erweitert.
- PDF-Export übernimmt bereits beliebige Blattmaße in mm; keine Änderung an der Rendering-Engine.
- PNG-Export bleibt bei bestehender 24-Megapixel-Grenze; für große Blätter PDF verwenden.
