package de.baudetail.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import de.baudetail.export.CanvasRenderer
import de.baudetail.geometry.Vec
import de.baudetail.geometry.parseNumber

@Composable fun SetupScreen(vm:BaudetailViewModel,chooseFolder:()->Unit){var example by remember{mutableStateOf(false)};Page("Willkommen bei Baudetail"){
 Text("Maßhaltig planen. Details verständlich zeichnen.",style=MaterialTheme.typography.headlineMedium)
 Text("Bibliotheken werden als externe .bdlib-Dateien importiert. Vorhandene Bibliotheken bleiben erhalten.")
 OutlinedButton(onClick=chooseFolder){Text("Optional: externen Bibliotheksordner wählen")}
 Text(vm.treeStatus);Row{Checkbox(example,{example=it});Text("Beispielprojekt mit Gartenplan und Schnitt installieren",Modifier.padding(top=12.dp))}
 Button(onClick={vm.finishSetup(example)},enabled=!vm.loading){Text("Einrichtung abschließen")}
}}
@OptIn(ExperimentalFoundationApi::class)
@Composable fun HomeScreen(vm:BaudetailViewModel,onProject:()->Unit,onNew:(String)->Unit,onOpen:()->Unit,onLibrary:()->Unit,onSettings:()->Unit,onExport:()->Unit,onAssemblies:()->Unit={}){var sort by remember{mutableStateOf("zuletzt geändert")};var menu by remember{mutableStateOf<de.baudetail.projects.ProjectRecord?>(null)};var create by remember{mutableStateOf(false)}
 LaunchedEffect(Unit){vm.refresh()}
 Page("Baudetail"){
 Text("Vom Gartenplan bis ins Detail.",style=MaterialTheme.typography.headlineMedium)
 Text("Dein Zeichenbüro für Außenanlagen · Lokal auf diesem Gerät",style=MaterialTheme.typography.bodyLarge)
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={create=true}){Icon(Icons.Default.Add,null);Text("Neues Projekt")};OutlinedButton(onClick=onOpen){Text("Datei öffnen")}}
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=onLibrary){Text("Bibliotheken")};OutlinedButton(onClick=onSettings){Text("Einstellungen")}}
 OutlinedButton(onClick=onAssemblies){Text("Bauwerke verwalten")}
 Row{listOf("zuletzt geändert","Name","erstellt").forEach{key->TextButton(onClick={sort=key}){Text(key)}}}
 Text("Zuletzt bearbeitet",style=MaterialTheme.typography.titleLarge)
 if(vm.records.isEmpty())Text("Noch keine Projektakte. Lege ein Projekt an oder importiere eine .bproject-Datei.")
 (when(sort){"Name"->vm.records.sortedBy{it.name.lowercase()};"erstellt"->vm.records.sortedByDescending{it.createdAt};else->vm.records.sortedByDescending{it.updatedAt}}).forEach{r->ElevatedCard(Modifier.fillMaxWidth().combinedClickable(onClick={vm.open(r.id);onProject()},onLongClick={menu=r})){Column(Modifier.padding(16.dp)){Text(r.name,style=MaterialTheme.typography.titleMedium);Text("${r.drawings} Zeichnungen · Zuletzt geändert: ${timestamp(r.updatedAt)}")}}}
 vm.project?.let{OutlinedButton(onClick=onProject){Text("Aktuelle Projektakte: ${it.name}")}}
 }
 menu?.let{r->OverviewMenu(vm,r.id,r.name,false,{menu=null},{vm.open(r.id);onProject()},{vm.open(r.id);vm.exportFormat="bproject";onExport()})}
 if(create)FormDialog("Neues Projekt",listOf(Field("name","Projektname")),{create=false}){onNew(it["name"].orEmpty())}
}
@OptIn(ExperimentalFoundationApi::class)
@Composable fun ProjectsScreen(vm:BaudetailViewModel,onBack:()->Unit,onDraw:()->Unit,onSettings:()->Unit,onExport:()->Unit){var sort by remember{mutableStateOf("zuletzt geändert")};var menu by remember{mutableStateOf<Drawing?>(null)};var new by remember{mutableStateOf(false)};var revision by remember{mutableStateOf(false)};var variant by remember{mutableStateOf(false)};var type by remember{mutableStateOf("Lageplan")}
 Page(vm.project?.name?:"Projektakte",onBack){val p=vm.project
 if(p==null){Text("Projekt wird geladen oder noch keines geöffnet.");return@Page}
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={new=true}){Text("Neue Zeichnung")};OutlinedButton(onClick=onSettings){Text("Projektdaten")}}
 Row{if(vm.renameHistory())TextButton(onClick={vm.undoProjectName()}){Text("Projektname rückgängig")};if(vm.renameHistory(true))TextButton(onClick={vm.undoProjectName(true)}){Text("Projektname wiederholen")}}
 Row{listOf("zuletzt geändert","Name","erstellt").forEach{key->TextButton(onClick={sort=key}){Text(key)}}}
 (when(sort){"Name"->p.drawings.sortedBy{it.name.lowercase()};"erstellt"->p.drawings.sortedByDescending{it.createdAt};else->p.drawings.sortedByDescending{it.updatedAt}}).forEach{d->Card(Modifier.fillMaxWidth().combinedClickable(onClick={vm.openDrawing(d.id);onDraw()},onLongClick={menu=d})){Column(Modifier.padding(16.dp)){Text(d.name,style=MaterialTheme.typography.titleMedium);Text("Zuletzt geändert: ${timestamp(d.updatedAt)}");Text("${d.type} · 1:${fmt(d.sheet.scale)} · ${d.entities.size} Objekte${if(d.variantOf!=null)" · Variante"else""}")}}}
 Text("Revisionen",style=MaterialTheme.typography.titleLarge)
 OutlinedButton(onClick={revision=true}){Text("Revision anlegen")}
 p.revisions.forEach{r->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(r.title,Modifier.weight(1f));TextButton(onClick={vm.restoreRevision(r.id)}){Text("Als Kopie wiederherstellen")}}}
 if(p.notes.isNotBlank())Text(p.notes)
 }
 menu?.let{d->OverviewMenu(vm,d.id,d.name,true,{menu=null},{vm.openDrawing(d.id);onDraw()},{vm.openDrawing(d.id);vm.exportFormat="bdetail";onExport()})}
 if(new)AlertDialog(onDismissRequest={new=false},title={Text("Dokumenttyp")},text={Column{listOf("Lageplan","Hausgartenentwurf","Technische Draufsicht","Schnitt","Detailzeichnung","Freies Blatt").forEach{t->TextButton(onClick={type=t;new=false;variant=true}){Text(t)}}}},confirmButton={TextButton(onClick={new=false}){Text("Abbrechen")}})
 if(variant)FormDialog("$type anlegen",listOf(Field("name","Zeichnungsname",type)),{variant=false}){vm.addDrawing(it["name"].orEmpty(),type);onDraw()}
 if(revision)FormDialog("Revision sichern",listOf(Field("title","Bezeichnung / Änderung","Revision B – ")),{revision=false}){vm.addRevision(it["title"].orEmpty())}
}
@Composable fun ProjectSettingsScreen(vm:BaudetailViewModel,onBack:()->Unit){val p=vm.project?:return
 var name by remember(p.id){mutableStateOf(p.name)};var notes by remember(p.id){mutableStateOf(p.notes)}
 val fields=listOf("bauvorhaben" to "Bauvorhaben","auftraggeber" to "Auftraggeber","planer" to "Planer / Architekt","projektnummer" to "Projektnummer","baustelle" to "Baustelle","bearbeiter" to "Bearbeiter","detailnummer" to "Detailnummer")
 val values=remember(p.id){mutableStateMapOf<String,String>().apply{putAll(p.metadata)}}
 Page("Projektstammdaten",onBack){OutlinedTextField(name,{name=it},label={Text("Projektname")},modifier=Modifier.fillMaxWidth());fields.forEach{(key,label)->OutlinedTextField(values[key].orEmpty(),{values[key]=it},label={Text(label)},modifier=Modifier.fillMaxWidth())};OutlinedTextField(notes,{notes=it},label={Text("Notizen")},minLines=4,modifier=Modifier.fillMaxWidth());Button(onClick={vm.updateProject(name,values.toMap(),notes);onBack()}){Text("Speichern")}}
}
@Composable fun SettingsScreen(vm:BaudetailViewModel,onBack:()->Unit,onFolder:()->Unit,onDiagnostics:()->Unit){Page("App-Einstellungen",onBack){Text("Darstellung",style=MaterialTheme.typography.titleLarge);listOf("System","Hell","Dunkel","Hoher Kontrast").forEach{s->Row{RadioButton(vm.theme==s,{vm.changeTheme(s)});Text(s,Modifier.padding(top=12.dp))}}
 Text("Externe Bibliothek",style=MaterialTheme.typography.titleLarge);Text(vm.treeStatus);Button(onClick=onFolder){Text("Bibliotheksordner wählen / ändern")};OutlinedButton(onClick=vm::reloadLibrary,enabled=vm.treeUri!=null){Text("Bibliothek neu einlesen")};Text("Baudetail speichert eigene Materialien, Bauteile und Vorlagen im gewählten Ordner. Du kannst die Auswahl jederzeit ändern.")
 OutlinedButton(onClick=onDiagnostics){Text("Diagnose / Crashberichte")}
 Text("Version ${androidx.compose.ui.platform.LocalContext.current.packageManager.getPackageInfo(androidx.compose.ui.platform.LocalContext.current.packageName,0).versionName} · Offline · Keine Konten",style=MaterialTheme.typography.bodySmall)
}}
/** Lightweight interactive sheet preview. Final PDF uses the original full scene. */
private fun simplifyExportPreview(nodes:List<Primitive>):List<Primitive> {
 // Preserve all plan details. Culling the first N primitives caused missing
 // drainage grates, cover details and even complete objects in larger plans.
 // Geometry is already memoized by ExportPreview; do not truncate the scene.
 return nodes
}
@Composable fun ExportPreview(vm:BaudetailViewModel){
 val d=vm.exportDrawing()?:return;val p=vm.project?:return;val renderer=remember{CanvasRenderer(vm.store::assetFile)}
 val dual=vm.exportFormat=="pdf"&&vm.exportDual&&d.type!="Lageplan"
 // Keep the expensive geometry independent of finger-driven paper translation.
 // The scene is built once for a stable reference origin and only cheap group
 // transforms change during dragging. The final PDF still uses Scene.paper/paperDual.
 val stableDrawing=d.copy(sheet=d.sheet.copy(origin=Vec()))
 val baseDrawing=remember(stableDrawing,p,dual,vm.exportSectionScale,vm.exportTopScale,vm.exportSectionOriginX,vm.exportSectionOriginY,vm.exportTopOriginX,vm.exportTopOriginY){
  if(dual) Scene.paperDual(stableDrawing,p,Vec(),Vec(),vm.exportSectionScale.coerceAtLeast(1.0),vm.exportTopScale.coerceAtLeast(1.0),Vec(vm.exportSectionOriginX,vm.exportSectionOriginY),Vec(vm.exportTopOriginX,vm.exportTopOriginY))
  else Scene.paper(stableDrawing,p)
 }
 val reducedBase=remember(baseDrawing){simplifyExportPreview(baseDrawing)}
 val previewScene=if(dual){
  val paneW=(d.sheet.widthMm-30.0)/2.0
  val section=Vec(vm.exportSectionX.coerceIn(0.0,d.sheet.widthMm-paneW),vm.exportSectionY)
  val top=Vec(vm.exportTopX.coerceIn(0.0,d.sheet.widthMm-paneW),vm.exportTopY)
  reducedBase.mapIndexed{index,node->
   if(index<4)Primitive.Group(listOf(node),translate=if(index<2)section else top) else node
  }
 }else{
  val offset=Vec(-d.sheet.origin.x/d.sheet.scale,-d.sheet.origin.y/d.sheet.scale)
  reducedBase.mapIndexed{index,node->
   if(index==0 && node is Primitive.Group){
    node.copy(nodes=node.nodes.map{child->if(child is Primitive.Group)child.copy(translate=child.translate+offset) else child})
   }else node
  }
 }
 var previewW by remember{mutableIntStateOf(1)};var previewH by remember{mutableIntStateOf(1)}
 val gesture=Modifier.onSizeChanged{previewW=it.width;previewH=it.height}.pointerInput(d.id,d.sheet.widthMm,d.sheet.heightMm,d.sheet.scale){detectDragGestures(onDragStart={start->if(vm.exportFormat=="pdf"&&vm.exportDual&&d.type!="Lageplan"){val sc=minOf(previewW/d.sheet.widthMm,previewH/d.sheet.heightMm).coerceAtLeast(1e-9);val dx=(previewW-d.sheet.widthMm*sc)/2;val dy=(previewH-d.sheet.heightMm*sc)/2;vm.selectDualAtPaper((start.x-dx)/sc,(start.y-dy)/sc)}},onDrag={change,drag->change.consume();val sc=minOf(previewW/d.sheet.widthMm,previewH/d.sheet.heightMm).coerceAtLeast(1e-9);if(vm.exportFormat=="pdf"&&vm.exportDual&&d.type!="Lageplan")vm.moveDualOnPaper(drag.x/sc,drag.y/sc)else vm.moveExportOnPaper(drag.x/sc,drag.y/sc)})}
 Card(Modifier.fillMaxWidth().height(260.dp)){Canvas(Modifier.fillMaxSize().then(gesture)){val sx=size.width/d.sheet.widthMm.toFloat();val sy=size.height/d.sheet.heightMm.toFloat();val sc=minOf(sx,sy);val dx=(size.width-d.sheet.widthMm.toFloat()*sc)/2;val dy=(size.height-d.sheet.heightMm.toFloat()*sc)/2;val c=drawContext.canvas.nativeCanvas;c.save();c.drawColor(android.graphics.Color.WHITE);c.translate(dx,dy);c.scale(sc,sc)
 val page=android.graphics.RectF(0f,0f,d.sheet.widthMm.toFloat(),d.sheet.heightMm.toFloat())
 val pagePaint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.WHITE}
 c.drawRect(page,pagePaint)
 c.save();c.clipRect(page);renderer.draw(c,previewScene);c.restore()
 val outlinePaint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{
  color=android.graphics.Color.rgb(105,115,125);style=android.graphics.Paint.Style.STROKE;strokeWidth=1.2f/sc
 }
 c.drawRect(page,outlinePaint)
 c.restore()}}
}

@Composable fun ExportScreen(vm:BaudetailViewModel,onBack:()->Unit,onSave:()->Unit,onShare:()->Unit){Page("Exportieren und teilen",onBack){
 val drawing=vm.drawing
 if(vm.project==null||drawing==null){Text("Öffne zuerst ein Projekt mit einer Zeichnung.");return@Page}
 LaunchedEffect(drawing.id){vm.prepareExport()}
 Text(drawing.name,style=MaterialTheme.typography.titleLarge)
 listOf("pdf","png","svg","bdetail","bproject","bdlib").forEach{format->Row{RadioButton(vm.exportFormat==format,{vm.exportFormat=format});Text(format.uppercase(),Modifier.padding(top=12.dp))}}
 if(vm.exportFormat in listOf("pdf","png","svg")){
  if(vm.exportFormat=="pdf") {
   if(drawing.type!="Lageplan")Row(verticalAlignment=Alignment.CenterVertically){Checkbox(vm.exportDual,{vm.exportDual=it});Text("Schnitt und Draufsicht auf einem Planblatt")}
   if(vm.exportDual && drawing.type!="Lageplan"){
    Text("Planfenster unabhängig verschieben: Ansicht wählen und in der Vorschau ziehen.")
    Row { listOf("section" to "Schnitt","top" to "Draufsicht").forEach{(key,name)->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(vm.exportDualSelection==key,{vm.exportDualSelection=key});Text(name)}} }
    val section=vm.exportDualSelection=="section"
    var scale by remember(section){mutableStateOf((if(section)vm.exportSectionScale else vm.exportTopScale).toString())}
    OutlinedTextField(scale,{scale=it;parseNumber(it)?.takeIf{n->n>0}?.let{n->if(section)vm.exportSectionScale=n else vm.exportTopScale=n}},label={Text("Maßstab der ausgewählten Ansicht 1:x")})
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     var x by remember(section){mutableStateOf(fmt(if(section)vm.exportSectionX else vm.exportTopX))}
     var y by remember(section){mutableStateOf(fmt(if(section)vm.exportSectionY else vm.exportTopY))}
     OutlinedTextField(x,{x=it;parseNumber(it)?.let{n->if(section)vm.exportSectionX=n else vm.exportTopX=n}},label={Text("Planfenster X mm")},modifier=Modifier.weight(1f))
     OutlinedTextField(y,{y=it;parseNumber(it)?.let{n->if(section)vm.exportSectionY=n else vm.exportTopY=n}},label={Text("Planfenster Y mm")},modifier=Modifier.weight(1f))
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     var x by remember(section){mutableStateOf(fmt(if(section)vm.exportSectionOriginX else vm.exportTopOriginX))}
     var y by remember(section){mutableStateOf(fmt(if(section)vm.exportSectionOriginY else vm.exportTopOriginY))}
     OutlinedTextField(x,{x=it;parseNumber(it)?.let{n->if(section)vm.exportSectionOriginX=n else vm.exportTopOriginX=n}},label={Text("Ausschnitt X mm")},modifier=Modifier.weight(1f))
     OutlinedTextField(y,{y=it;parseNumber(it)?.let{n->if(section)vm.exportSectionOriginY=n else vm.exportTopOriginY=n}},label={Text("Ausschnitt Y mm")},modifier=Modifier.weight(1f))
    }
   }
  }
  Text("Druck-/Exportvorschau",style=MaterialTheme.typography.titleMedium)
  ExportPreview(vm)
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.horizontalScroll(rememberScrollState())){listOf("A4" to (210.0 to 297.0),"A3" to (297.0 to 420.0),"A2" to (420.0 to 594.0),"A1" to (594.0 to 841.0),"A0" to (841.0 to 1189.0)).forEach{(name,wh)->OutlinedButton(onClick={val landscape=vm.exportWidthMm>vm.exportHeightMm;vm.setExportPaper(if(landscape)wh.second else wh.first,if(landscape)wh.first else wh.second)}){Text(name)}}}
  if(!vm.exportDual||vm.exportFormat!="pdf"||drawing.type=="Lageplan") {
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){var orientationExpanded by remember{mutableStateOf(false)}
  Box {
   OutlinedButton(onClick={orientationExpanded=true}){Text("Ausrichtung: "+if(vm.exportWidthMm>vm.exportHeightMm)"Querformat"else"Hochformat");Icon(Icons.Default.ArrowDropDown,null)}
   DropdownMenu(expanded=orientationExpanded,onDismissRequest={orientationExpanded=false}){
    listOf("Hochformat" to false,"Querformat" to true).forEach{(label,landscape)->
     DropdownMenuItem(text={Text(label+if((vm.exportWidthMm>vm.exportHeightMm)==landscape)" ✓"else"")},onClick={
      orientationExpanded=false
      if((vm.exportWidthMm>vm.exportHeightMm)!=landscape){val w=vm.exportWidthMm;vm.exportWidthMm=vm.exportHeightMm;vm.exportHeightMm=w}
     })
    }
   }
  };OutlinedButton(onClick=vm::centerExport){Text("Zeichnung zentrieren")};OutlinedButton(onClick=vm::resetExportPosition){Text("Position zurücksetzen")}}
  var scaleText by remember(drawing.id){mutableStateOf(vm.exportScale.toString())};OutlinedTextField(scaleText,{scaleText=it;parseNumber(it)?.takeIf{n->n>0}?.let{n->vm.exportScale=n}},label={Text("Maßstab 1:x")},singleLine=true)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){var x by remember(drawing.id){mutableStateOf(vm.exportOriginX.toString())};var y by remember(drawing.id){mutableStateOf(vm.exportOriginY.toString())};OutlinedTextField(x,{x=it;parseNumber(it)?.let{n->vm.exportOriginX=n}},label={Text("Ausschnitt X mm")},modifier=Modifier.weight(1f));OutlinedTextField(y,{y=it;parseNumber(it)?.let{n->vm.exportOriginY=n}},label={Text("Ausschnitt Y mm")},modifier=Modifier.weight(1f))}
  }
  Text(if(vm.exportDual&&vm.exportFormat=="pdf"&&drawing.type!="Lageplan")"Papier ${fmt(vm.exportWidthMm)} × ${fmt(vm.exportHeightMm)} mm · Beide Planfenster sind einzeln verschiebbar und maßstäblich." else "Papier ${fmt(vm.exportWidthMm)} × ${fmt(vm.exportHeightMm)} mm · Ausgabe 1:${fmt(vm.exportScale)} · Vorschau entspricht dem Export. Zeichnung per Drag verschiebbar; Maßstab bleibt unverändert.")
  if((!vm.exportDual||vm.exportFormat!="pdf"||drawing.type=="Lageplan")&&vm.exportOverflow())Text("Achtung: Teile der Zeichnung liegen außerhalb des gewählten Blatts.",color=MaterialTheme.colorScheme.error)
 }
 if(vm.exportFormat=="png"){var dpi by remember{mutableStateOf(vm.exportDpi.toString())};OutlinedTextField(dpi,{dpi=it;it.toIntOrNull()?.takeIf{n->n in 36..600}?.let{n->vm.exportDpi=n}},label={Text("DPI (36–600), aktuell ${vm.exportDpi}")});Row{Checkbox(vm.transparent,{vm.transparent=it});Text("Transparenter Hintergrund",Modifier.padding(top=12.dp))}}
 if(vm.exportFormat=="bproject")Row{Checkbox(vm.fullExport,{vm.fullExport=it});Text("Vollständig paketieren, einschließlich Ressourcen",Modifier.weight(1f).padding(top=12.dp))}
 if(vm.exportFormat in listOf("pdf","png","svg"))Text("Beim Speichern wird die Dateiendung automatisch wiederhergestellt, falls sie im Android-Dateidialog entfernt wird.",style=MaterialTheme.typography.bodySmall)
 Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Button(onClick=onSave){Text("Datei speichern")};OutlinedButton(onClick=onShare){Text("Teilen")}}
}}

fun timestamp(value:Long)=if(value<=0)"unbekannt (Altbestand)"else java.time.Instant.ofEpochMilli(value).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"))
