# BauDetail 0.9.124 – Schnittansicht Blockstufen / Treppen

- Neue objektspezifische Auswahl „Ansichtsrichtung im Schnitt“: Seitlich / Frontal im Eigenschaftenmenü für Blockstufen und Treppen.
- Die Treppenbearbeitung bietet dieselbe Auswahl; Speicherung im Parameter `sectionFace` (`side` als Standard für ältere Projekte, `front` als neue Option).
- Frontalansicht der Treppe: sichtbare Stufenfronten über die gesamte Treppenbreite, inklusive versetzter Stoßfugen aus Elementlänge und Reihenwechsel. Die bisherige Seitenansicht bleibt erhalten.
- Frontalansicht einzelner Blockstufen: rechteckige Vorderfläche mit Stufenbreite und Stufenhöhe; entsprechende Schnitt-Snap-Kontur.
- Draufsicht und bestehende Treppenparameter bleiben unverändert. PDF-Export verwendet dieselben Zeichenprimitiven wie die Zeichenansicht.

Hinweis: Nicht auf Android kompiliert oder visuell getestet. Frontale Fundament-/automatische Bemaßungslogik bedarf weiterer fachlicher Prüfung.
