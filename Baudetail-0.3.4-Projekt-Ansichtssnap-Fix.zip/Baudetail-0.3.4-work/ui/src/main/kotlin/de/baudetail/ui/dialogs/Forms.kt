package de.baudetail.ui.dialogs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import de.baudetail.geometry.parseNumber

data class Field(val key:String,val label:String,val initial:String="",val numeric:Boolean=false,val positive:Boolean=false)
@Composable fun FormDialog(title:String,fields:List<Field>,onDismiss:()->Unit,onSubmit:(Map<String,String>)->Unit){
 val values=remember(fields){mutableStateMapOf<String,String>().apply{fields.forEach{put(it.key,it.initial)}}}
 var error by remember{mutableStateOf<String?>(null)}
 AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  fields.forEach{f->OutlinedTextField(values[f.key].orEmpty(),{values[f.key]=it},label={Text(f.label)},keyboardOptions=KeyboardOptions(keyboardType=if(f.numeric)KeyboardType.Decimal else KeyboardType.Text),modifier=Modifier.fillMaxWidth(),minLines=if(f.key=="notes"||f.key=="text"||f.key=="template")3 else 1)}
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 }},confirmButton={TextButton(onClick={val bad=fields.firstOrNull{it.numeric&&(parseNumber(values[it.key].orEmpty())==null||(it.positive&&(parseNumber(values[it.key].orEmpty())?:0.0)<=0))};if(bad!=null)error="${bad.label}: gültige ${if(bad.positive)"positive "else""}Zahl eingeben"else try{onSubmit(values.toMap());onDismiss()}catch(e:Exception){error=e.message}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
@Composable fun ChoiceDialog(title:String,choices:List<String>,onDismiss:()->Unit,selectedIndex:Int?=null,onChoose:(Int)->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())){choices.forEachIndexed{i,s->TextButton(onClick={onDismiss();onChoose(i)},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text(s);Spacer(Modifier.weight(1f));if(selectedIndex==i)Text("✓")}}}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})}
