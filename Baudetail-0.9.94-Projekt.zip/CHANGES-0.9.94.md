# 0.9.94
- Separate Richtungsschlösser für jede Grundstückskante über der Vorschau.
- Gesperrte Kantenrichtungen werden als absolute Zeichenflächenwinkel beim Lösen der Geometrie berücksichtigt.
- Widersprüchliche Vorgaben werden abgelehnt statt gesperrte Kanten zu verdrehen.
- Richtungssperren werden in den Objektattributen gespeichert.
- Keine automatische dauerhafte Snap-Verknüpfung in dieser Version; dies erfordert ein eigenes Referenzmodell.
- Android-Build und Gerätetest ausstehend.
