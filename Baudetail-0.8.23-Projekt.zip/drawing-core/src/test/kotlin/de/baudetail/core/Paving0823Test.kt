package de.baudetail.core

import kotlin.test.Test
import kotlin.test.assertTrue
import kotlin.test.assertNotEquals

class Paving0823Test {
 @Test fun extendedMaterialsHaveDifferentVisuals() {
  assertTrue(pavingMaterialChoices.containsAll(listOf("Feinsteinzeug","Dränpflaster","Großkopfsteinpflaster","Kleinsteinpflaster","Mosaikpflaster")))
  assertNotEquals(pavingVisualColor("Jurakalk"),pavingVisualColor("Betonpflaster"))
  assertNotEquals(pavingStoneSize("Mosaikpflaster"),pavingStoneSize("Feinsteinzeug"))
 }
}
