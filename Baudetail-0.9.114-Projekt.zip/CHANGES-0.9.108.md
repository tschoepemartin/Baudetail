# 0.9.108 – Zwischenstand, kein abgeschlossener Verbands-Neubau

- Versteckt Verbandsauswahl bei deaktiviertem Musterverband.
- Versteckt freien Versatz außer im passenden Modus und externe Muster bei Römischem Verband.
- Separate vektorbasierte Jurakalk-Oberflächenzeichnung (keine Original-Fototextur).

Offen: vollständiger neuer parametrischer Verlegegenerator, getrennte Dialogstruktur, Build und Gerätetest.
