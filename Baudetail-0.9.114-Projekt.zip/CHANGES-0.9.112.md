# 0.9.112 – Römischer Verband 60/40 und Jurakalk

- Neue direkt wählbare Variante „Römischer Verband 60/40 (4 Formate)“ mit festen Formaten 600×400, 400×400, 400×200 und 200×200 mm.
- Das feste Preset arbeitet geometrisch ohne Zwischenfuge, damit die explizit verlangten Nennmaße exakt zusammenpassen. Sichtbare Konturen werden separat gezeichnet.
- Jura-/Kalkstein-Vektortextur sichtbarer ausgeführt. Keine Hersteller-Fototextur.
- Das Preset verwendet weiterhin die flächenweite Platzierungslogik von 0.9.111, keinen validierten 12-Stein-Herstellerverlegeplan.
- Android-Build und Geräteprüfung ausstehend.
