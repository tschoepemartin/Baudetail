# BauDetail 0.9.113

- Festes Muster „Römischer Verband 60/40 (4 Formate)“: exakt zwölf Platten je Grundmuster (2 × 600×400, 4 × 400×400, 2 × 400×200, 4 × 200×200 mm).
- Exakte, deterministische Steinkoordinaten statt heuristischer Platzierung. Alle zwölf Platten füllen das 1200×1200-mm-Grundmuster lücken- und überlappungsfrei.
- Der bestehende Polygon-Clip schneidet den Verband entlang der realen Wegränder; keine Randläufer.
- Für das feste Muster ist die geometrische Fuge 0 mm, um die vorgegebenen Nennmaße exakt zu erhalten.
- Jurakalk-Vektortextur aus 0.9.112 bleibt erhalten; keine Originalfototextur enthalten.

Noch nicht auf Android gebaut oder auf dem Gerät visuell getestet. Der 12-teilige Modulplan ist geometrisch valide, aber nicht pixelgenau aus dem fotografierten Herstellerplan digitalisiert.
