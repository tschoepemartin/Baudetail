# BauDetail 0.9.107 – Parametrischer Römischer Verband

- Recherche: BayWa, Hornbach, Alpha Stone, Webro, Seltra – klassische 3-/4-Format-Verbände und Fugenregeln.
- 3-Format-Muster mit 8 Steinen auf 4×4 Einheiten und 4-Format-Muster mit 12 Steinen auf 6×6 Einheiten.
- Rechtecke greifen geometrisch auf dem gemeinsamen Fugenraster ineinander; keine separaten Randläufer.
- Maßabhängige Steinformate statt harter 4-mm-/624×416-mm-Bibliotheksgeometrie.
- Veraltete gespeicherte Roman-Bibliotheksmodule werden für die Darstellung nicht mehr verwendet.
- 4-Format-Beispiel bei 4 mm Fuge: 200×200; 404×200; 404×404; 608×404 mm (Reihenfolge beliebig).
- 3-Format-Beispiel bei 4 mm Fuge: 200×200; 404×200; 404×404 mm.
- Bei nicht zueinander passenden Maßen wird ein Hinweis gezeichnet, kein falscher Verband erfunden.
- Die Kacheln werden schachbrettartig um 180° gedreht, um Wiederholung zu reduzieren.

## Einschränkungen
- Nur geometrisch abgestimmte 3- oder 4-Format-Sets; beliebige, nicht modulkompatible Abmessungen können keinen lückenlosen Verband bilden.
- Keine lokale Android-Kompilierung/physische Prüfung durchgeführt.
- Die Verteilung der Modulübergänge muss am Gerät visuell geprüft werden; die Validierung hier bestätigt nur lückenlose, überlappungsfreie interne Module.
