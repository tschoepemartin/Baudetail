# BauDetail 0.9.114

- Musterverband-Schalter und externe Musterauswahl aus Pflasterdialogen entfernt; gespeicherte externe Module werden im Pflasterrenderer ignoriert, aber Datenmodellfelder bleiben für Kompatibilität erhalten.
- Verband-Auswahl unabhängig vom ehemaligen Muster-Schalter.
- Römischer Verband: ein Eintrag, festes 12-Stein-Modul aus 600×400, 400×400, 400×200 und 200×200 mm; alte feste Varianten rendern weiterhin.
- Jura-Textur-Erkennung bei Materialnamen verbessert.
- Versionierung korrigiert.

Status: Quellcodeänderung; kein bestätigter Android-Build oder Gerätetest.
