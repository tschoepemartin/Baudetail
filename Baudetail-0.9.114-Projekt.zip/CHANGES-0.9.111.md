# BauDetail 0.9.111 – Zwischenstand

- Römischer Verband: starre wiederholte Grundmodule durch eine deterministische flächenweite Steinplatzierung ersetzt.
- Steinpositionen basieren auf dem Fugenraster und den drei bzw. vier kompatiblen Formatgrößen.
- Keine zusätzliche Randläuferreihe; keine regelmäßigen Modulgrenzen.
- Begrenzung auf 40.000 Rasterzellen.

Offen: kein Android-Build und kein visueller Gerätetest; die Verteilung ist heuristisch, nicht als herstellerkonformer Verlegeplan validiert. Jura-Materialzuordnung in diesem Schritt unverändert.
