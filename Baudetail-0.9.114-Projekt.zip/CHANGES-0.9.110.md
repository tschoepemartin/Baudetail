# BauDetail 0.9.110 – Zwischenstand

- Römischer Verband: Modulvarianten mit vier geometrisch gültigen 90°-Drehungen statt bloßem 180°-Schachbrettwechsel.
- Deterministische Koordinaten-Hashwahl, sodass Anzeige und PDF dieselbe Anordnung erhalten.
- Steinformate und Fugenraster bleiben unverändert, keine zusätzlichen Randläufer.

**Noch offen:** Dies ist noch kein vollständig neu entwickelter, nahtlos variabler Römischer Verband. Modulgrenzen können weiterhin erkennbar sein. Jurakalk-Textur nicht final validiert. Kein APK-Build durchgeführt.
