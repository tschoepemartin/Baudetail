package de.baudetail.core

import de.baudetail.geometry.*
import kotlin.math.*

class EditorHistory(initial:DrawingHistory) {
 private val past=initial.past.toMutableList(); private val future=initial.future.toMutableList(); private val backups=initial.backups.toMutableList()
 var current=initial.current; private set
 val canUndo get()=past.isNotEmpty()
 val canRedo get()=future.isNotEmpty()
 fun commit(next:Drawing):Boolean { validateDrawing(next); if(next==current)return false; past.add(current); if(past.size>200)past.removeAt(0); future.clear(); checkpoint();current=next;return true }
 private fun checkpoint() { backups.add(current);while(backups.size>10)backups.removeAt(0) }
 fun undo() { if(canUndo) {future.add(current);checkpoint(); current=past.removeAt(past.lastIndex)} }
 fun redo() { if(canRedo) {past.add(current);checkpoint();current=future.removeAt(future.lastIndex)} }
 fun persisted()=DrawingHistory(current,past.takeLast(5),future.takeLast(5),backups.toList())
 fun restore(index:Int) { val d=backups[index]; commit(d) }
}
data class SnapOptions(val grid:Boolean=true,val geometry:Boolean=true,val ortho:Boolean=false,val angleStep:Double=0.0,val gridMm:Double=100.0,val toleranceMm:Double=100.0,val modes:Set<String> = setOf("Raster","Endpunkt","Mitte","Schnittpunkt","Kante","Zentrum"))
data class SnapResult(val point:Vec,val reason:String,val anchor:Anchor?=null,val priority:String="normal")
private data class SnapCandidate(val point:Vec,val reason:String,val entityId:String?=null,val priority:Int=1)
private fun snapPriority(e:Entity)=when(e.str("snapPriority","normal")){"high"->0;"low"->2;else->1}
fun snap(point:Vec,d:Drawing,options:SnapOptions,previous:Vec?=null):SnapResult {
 var p=point; var reason=""
 if(previous!=null) { val delta=p-previous
  if(options.ortho) {p=if(abs(delta.x)>abs(delta.y)) Vec(p.x,previous.y) else Vec(previous.x,p.y);reason="Ortho"}
  else if(options.angleStep>0) { val a=round(Math.toDegrees(atan2(delta.y,delta.x))/options.angleStep)*options.angleStep; p=previous+Vec(cos(Math.toRadians(a)),sin(Math.toRadians(a)))*delta.length(); reason="Winkel" }
 }
 val candidates=mutableListOf<SnapCandidate>()
 val snapEdges=mutableListOf<Triple<Vec,Vec,Pair<String,Int>>>()
 if(options.geometry) {
  val segments=mutableListOf<Triple<Vec,Vec,String?>>()
  for(e in d.entities.filter { d.layers.find { l->l.id==it.layerId }?.visible != false && visibleIn(it,d) }) {
   val pr=snapPriority(e)
   val smart=isStair(e)||e.kind=="component"
   val grassSection=e.str("grassObject")=="true"&&d.viewMode()=="section"
   val pavingPlan=e.isParametricBuildUp()&&d.viewMode()!="section"
   val pavingCorners=if(pavingPlan){
    val origin=buildUpPlanOrigin(e);val angle=buildUpPlanAngle(e)
    contourOutline(e,d)
   }else emptyList()
   val pts=if(grassSection)grassSectionCorners(e) else if(pavingPlan)pavingCorners else if(smart)smartSnapReferencePoints(e,d)else resolvedPoints(e,d)
   val edgePts=if(smart)smartSnapOutline(e,d)else pts
   val endpointPts=when{e.smartFamily()=="curb"->curbWorldOutline(e,d);isStair(e)->smartSnapSegments(e,d).flatMap{listOf(it.first,it.second)}.distinct();else->edgePts}
   if(smart){
    val critical=if(e.smartFamily()=="curb")curbCriticalSnapPoints(e,d)else emptyList()
    endpointPts.filterNot{p0->critical.any{it.distance(p0)<1e-5}}.forEach{candidates.add(SnapCandidate(it,"Endpunkt",e.id,pr))}
    critical.forEach{candidates.add(SnapCandidate(it,"Endpunkt",e.id,0))}
    pts.getOrNull(4)?.let{candidates.add(SnapCandidate(it,"Zentrum",e.id,pr))};pts.drop(5).take(4).forEach{candidates.add(SnapCandidate(it,"Mitte",e.id,pr))}
   }
   else if(e.kind !in setOf("circle","tree"))pts.forEach {candidates.add(SnapCandidate(it,"Endpunkt",e.id,pr))} else pts.firstOrNull()?.let{candidates.add(SnapCandidate(it,"Zentrum",e.id,pr))}
   val closed=pavingPlan||e.kind in setOf("polygon","area","rect","building","property","paving","path")
   val seg=if(grassSection){grassSectionGeometry(e).segments} else if(e.kind in setOf("circle","tree"))emptyList() else if(smart)smartSnapSegments(e,d) else edgePts.zipWithNext()+(if(closed&&edgePts.size>2) listOf(edgePts.last() to edgePts.first()) else emptyList())
   for((index,edge) in seg.withIndex()) {val (a,b)=edge
    snapEdges.add(Triple(a,b,e.id to index));candidates.add(SnapCandidate((a+b)*0.5,"Mitte",e.id,pr));candidates.add(SnapCandidate(closestOnSegment(p,a,b),"Kante",e.id,pr));if(Bounds.of(listOf(a,b)).contains(p,options.toleranceMm))segments.add(Triple(a,b,e.id))}
   if(e.kind=="circle" || e.kind=="tree") { val c=pts.firstOrNull()?:continue; val r=if(e.kind=="tree") e.num("crownMm",2000.0)/2 else e.num("radiusMm",500.0);val v=p-c;if(v.length()>0)candidates.add(SnapCandidate(c+v*(r/v.length()),"Kreis",e.id,pr)) }
  }
  // Prioritize the closest segments instead of the first 250 in entity order.
  // Otherwise crowded drawings can miss intersections at the finger position.
  val nearby=segments.sortedBy { (a,b,_) -> closestOnSegment(p,a,b).distance(p) }.take(250)
  for(i in nearby.indices)for(j in i+1 until nearby.size) intersection(nearby[i].first,nearby[i].second,nearby[j].first,nearby[j].second)?.let { candidates.add(SnapCandidate(it,"Schnittpunkt",null,1)) }
 }
 candidates.removeAll { (if(it.reason=="Kreis")"Kante"else it.reason) !in options.modes }
 fun allowed(v:Vec):Boolean {
  if(previous==null||(!options.ortho&&options.angleStep<=0))return true
  val ray=p-previous;val target=v-previous
  return abs(cross(ray,target))<=1e-6*ray.length().coerceAtLeast(1.0)
 }
 candidates.removeAll{!allowed(it.point)}
 val inRange=candidates.filter{it.point.distance(p)<=options.toleranceMm}
 // Never let a distant corner or midpoint steal a nearby paving edge.
 // Prefer true endpoints only within a small fraction of the touch tolerance.
 val nearExact=inRange.filter{it.reason in setOf("Endpunkt","Schnittpunkt") && it.point.distance(p)<=options.toleranceMm}
 val pool=nearExact.ifEmpty{inRange}
 // At shared corners multiple entities may offer the same point. Give exact
 // intersections/endpoints precedence within a tiny physical tolerance, then
 // resolve by distance and the explicit snap priority.
 val nearest=pool.minWithOrNull(compareBy<SnapCandidate>{ if(it.reason=="Endpunkt" || it.reason=="Schnittpunkt") 0 else 1 }.thenBy{it.point.distance(p)}.thenBy{it.priority})
 if(nearest!=null && (!options.ortho || previous==null || abs(nearest.point.x-previous.x)<1e-6 || abs(nearest.point.y-previous.y)<1e-6)) {
  val entity=d.entities.find{it.id==nearest.entityId};val pr=entity?.str("snapPriority","normal")?:"normal"
  return SnapResult(nearest.point,nearest.reason,anchorAt(nearest.point,d) ?: snapEdges.minByOrNull { (a,b,_) -> closestOnSegment(nearest.point,a,b).distance(nearest.point) }?.takeIf { (a,b,_) -> closestOnSegment(nearest.point,a,b).distance(nearest.point)<1e-4 }?.let { (_,_,idIndex) -> Anchor(idIndex.first,idIndex.second,"edge",d.viewMode()) },pr)
 }
 if(options.grid && options.gridMm>0) {p=if(previous!=null && (options.ortho||options.angleStep>0)){val delta=p-previous;val len=delta.length();if(len>1e-9)previous+delta*(round(len/options.gridMm)*options.gridMm/len)else previous}else Vec(round((p.x-d.origin.x)/options.gridMm)*options.gridMm+d.origin.x,round((p.y-d.origin.y)/options.gridMm)*options.gridMm+d.origin.y);reason="Raster"}
 return SnapResult(p,reason)
}
/** Dedicated, model-space construction-edge snap for plan elevation markers.
 * No grid fallback: outside tolerance the actual finger point is preserved.
 * Interior paving joints are deliberately not used as construction edges.
 */
fun planHeightEdgeSnap(point:Vec,d:Drawing,toleranceMm:Double):SnapResult {
 if(d.viewMode()=="section")return SnapResult(point,"")
 data class Choice(val at:Vec,val distance:Double,val entityId:String,val segment:Int,val endpoint:Boolean)
 val candidates=mutableListOf<Choice>()
 for(e in d.entities.filter{visibleIn(it,d)&&d.layers.find{l->l.id==it.layerId}?.visible!=false}) {
  val segments:List<Pair<Vec,Vec>> = when {
   isStair(e)->smartSnapSegments(e,d)
   e.isParametricBuildUp()->{
    val origin=buildUpPlanOrigin(e);val angle=buildUpPlanAngle(e)
    val corners=rectangle(Vec(),Vec(e.num("planGraphicWidthMm",e.num("widthMm",1500.0)),e.num("topDepthMm",1000.0))).map{origin+it.rotate(angle)}
    corners.indices.map{i->corners[i] to corners[(i+1)%corners.size]}
   }
   e.kind=="component"->smartSnapSegments(e,d)
   e.str("grassObject")=="true"||e.kind in setOf("area","rect","polygon","path","paving")->{
    val vertices=resolvedPoints(e,d)
    vertices.zipWithNext()+(if(vertices.size>2)listOf(vertices.last() to vertices.first())else emptyList())
   }
   else->emptyList()
  }
  segments.forEachIndexed { index,(a,b)->
   val projection=closestOnSegment(point,a,b)
   val dist=projection.distance(point)
   if(dist<=toleranceMm)candidates.add(Choice(projection,dist,e.id,index,false))
   for(end in listOf(a,b))if(end.distance(point)<=toleranceMm*0.35)
    candidates.add(Choice(end,end.distance(point),e.id,index,true))
  }
 }
 val best=candidates.minWithOrNull(compareBy<Choice>{it.distance}.thenByDescending{it.endpoint})
  ?:return SnapResult(point,"")
 return SnapResult(best.at,if(best.endpoint)"Bauteilecke" else "Bauteilkante",
  Anchor(best.entityId,best.segment,"edge",d.viewMode()))
}
fun hitTest(p:Vec,e:Entity,tolerance:Double):Boolean {
 val pts=e.points
 return when(e.kind) {
 "arc" -> { val c=pts.firstOrNull()?:Vec();val v=p-c;val start=e.num("startAngle");val sweep=e.num("sweepAngle",90.0);val a=Math.toDegrees(atan2(v.y,v.x));val delta=if(sweep>=0)((a-start)%360+360)%360 else ((start-a)%360+360)%360;abs(v.length()-e.num("radiusMm",500.0))<=tolerance&&(abs(sweep)>=360||delta<=abs(sweep)+1e-6) }
 "circle","tree" -> p.distance(pts.firstOrNull()?:Vec()) <= (if(e.kind=="tree") e.num("crownMm",2000.0)/2 else e.num("radiusMm",500.0))+tolerance
 "area","polygon","rect","building","property","hedge" -> if(e.kind=="hedge" && e.str("hedgeRectangle")!="true") pts.zipWithNext().any{(a,b)->closestOnSegment(p,a,b).distance(p)<tolerance} else inside(p,pts)||pts.indices.any{i->closestOnSegment(p,pts[i],pts[(i+1)%pts.size]).distance(p)<tolerance}
 "assembly" -> entityBounds(e).contains(p,tolerance)
 "component","image","stack" -> entityBounds(e).contains(p.rotate(-e.rotation,pts.firstOrNull()?:Vec()),tolerance)
 "plan-height" -> {
  val at=pts.firstOrNull()?:Vec()
  val scale=e.num("annotationScalePct",35.0).coerceIn(1.0,100.0)/100.0
  val font=e.num("elevationFontPaperMm",3.0)*50.0*scale
  val value=e.str("elevationPrefix")+" ±00,00"
  val width=value.length*font*0.6
  Bounds(Vec(at.x-font,at.y-font*2.1),Vec(at.x+width+font,at.y+font)).contains(p,tolerance)
 }
 "text","elevation" -> (pts.firstOrNull()?:Vec()).distance(p)<tolerance*3
 "legend" -> { val a=pts.firstOrNull()?:Vec(); val w=e.num("legendHitWidthMm",3000.0); val h=e.num("legendHitHeightMm",5000.0); p.x>=a.x-tolerance&&p.x<=a.x+w+tolerance&&p.y>=a.y-h*.1-tolerance&&p.y<=a.y+h+tolerance }
 else -> pts.zipWithNext().any {(a,b)->closestOnSegment(p,a,b).distance(p)<tolerance} || pts.any {it.distance(p)<tolerance}
 }
}

/** The full printed label, not just its insertion point, is a touch target. */
fun labelTextBounds(e:Entity,d:Drawing):Bounds? {
 if(!labelActive(e,d))return null
 val value=if(e.str("labelMode","auto")=="manual"&&e.str("labelText").isNotBlank())e.str("labelText") else if(e.isParametricBuildUp())buildUpLabel(e) else if(isStair(e))"Blockstufenanlage" else e.name.ifBlank{e.kind}
 val lines=value.split("\n")
 val size=e.style.textPaperMm*50.0*(e.num("annotationScalePct",100.0).coerceIn(1.0,100.0)/100.0)
 val at=objectLabelPosition(e,d);val width=(lines.maxOfOrNull{it.length}?:0)*size*.57
 return Bounds(Vec(at.x-width/2.0,at.y-size),Vec(at.x+width/2.0,at.y+(lines.size-1)*size*1.4+size*.3))
}

fun hitTest(p:Vec,e:Entity,d:Drawing,tolerance:Double):Boolean {
 if(e.kind in setOf("elevation","plan-height")){
  val anchor=(if(d.viewMode()=="top")sectionElevationPlanPoint(e,d) else null)
   ?:resolvedPoints(e,d).firstOrNull()?:e.points.firstOrNull()?:Vec()
  val tip=if(e.kind=="plan-height")anchor else anchor+elevationLabelOffset(e,d.viewMode())
  val scale=e.num("annotationScalePct",35.0).coerceIn(1.0,100.0)/100.0
  val font=3.0*50.0*scale
  val r=2.5*50.0*scale
  val h=if(e.kind=="plan-height") (if(e.str("elevationRole")=="relative")planRelativeHeightMm(e,d)?:0.0 else e.num("heightMm")) else elevationValueMm(e,d)
  val label=if(kotlin.math.abs(h)<0.001)"±0,00" else (if(h>0)"+" else "")+String.format(java.util.Locale.GERMANY,"%.2f",h/1000)
  val value=e.str("elevationPrefix").trim().let{if(it.isEmpty())label else "$it $label"}
  val width=value.sumOf{ch->when(ch){'1','i','l','I','.',',',':',' '->.28;'+','-','−','±'->.55;else->.56}}*font
  val left=tip.x-r*.5
  val labelBounds=Bounds(Vec(left-r,tip.y-r-font*1.35),Vec(left+width+r,tip.y+2.0))
  // Select the whole marker, its label and the line back to the measurement point.
  return labelBounds.contains(p,tolerance) || anchor.distance(p)<=tolerance*2 ||
   closestOnSegment(p,anchor,tip).distance(p)<=tolerance
 }
 if(e.str("grassObject")=="true"&&d.viewMode()=="section")return grassSectionBounds(e).contains(p,tolerance)
 if(isFoundation(e)){val pts=foundationOutline(e,d);return inside(p,pts)||pts.zipWithNext().any{(a,b)->closestOnSegment(p,a,b).distance(p)<tolerance}}
 if(isFrozenTemplate(e))return frozenTemplateBounds(e,d).contains(p,tolerance)
 if(isKg2000(e))return viewBounds(e,d).contains(p,tolerance)
 if(labelTextBounds(e,d)?.contains(p,tolerance)==true)return true
 if(e.isParametricBuildUp()){
  val outline=if(d.viewMode()=="section")emptyList() else contourOutline(e,d)
  if(outline.size>=3)return inside(p,outline)||outline.indices.any{i->closestOnSegment(p,outline[i],outline[(i+1)%outline.size]).distance(p)<=tolerance}
  return viewBounds(e,d).contains(p,tolerance)
 }
 if(isStair(e))return Bounds.of(stairReferencePoints(e,d.viewMode())).contains(p,tolerance)
 if(isSteelEdge(e)){
  val outline=steelEdgeOutline(e,d)
  val fingerTol=tolerance.coerceAtLeast(75.0)
  return inside(p,outline) || outline.indices.any{i->closestOnSegment(p,outline[i],outline[(i+1)%outline.size]).distance(p)<=fingerTol}
 }
 if(e.kind=="component") {
  // Selection must follow the actually rendered, view-specific geometry.
  // Using entityBounds(viewEntity(...)) here loses the mirror transform and left
  // a stale hitbox at the former position after mirroring.  Rebuild the hit
  // polygon from the same world geometry used by snapping/rendering instead.
  val outline=if(e.smartFamily()=="curb")curbWorldOutline(e,d)else componentReferencePoints(e,d).take(4)
  if(outline.size>=3){
   if(inside(p,outline))return true
   if(outline.indices.any{i->closestOnSegment(p,outline[i],outline[(i+1)%outline.size]).distance(p)<tolerance})return true
   return false
  }
 }
 if(e.kind!="dimension") return hitTest(p,viewEntity(e,d),tolerance)
 val textSize=e.style.textPaperMm*d.sheet.scale
 val metric=e.str("metric")
 val source=if(metric.isNotEmpty())d.entities.find{it.id==e.str("sourceId")}else null
 val witnesses=if(metric.isNotEmpty())source?.let{metricWitnesses(it,metric,d)}else resolvedPoints(e,d)
 if(witnesses==null||witnesses.size<2)return false
 val label=dimensionLabel(e,d)
 // Primitive.Text is START-anchored, not centred. Use the same anchor and
 // approximate glyph rectangle as the renderer, including the unit suffix.
 fun textHit(at:Vec,margin:Double):Boolean {
  val width=label.length*textSize*.62
  return Bounds(Vec(at.x,at.y-textSize),Vec(at.x+width,at.y+textSize*.35)).contains(p,margin)
 }
 val anchor=e.points.firstOrNull()?:witnesses[0]
 val origin=Vec(e.num("metricOriginX",anchor.x),e.num("metricOriginY",anchor.y))
 val metricShift=if(metric.isNotEmpty())anchor-origin else Vec()
 val shift=Vec(e.num("dimDx"),e.num("dimDy"))+metricShift
 if(metric=="Stufengefälle") {
  val start=witnesses[0]+Vec(e.num("dimDx"),e.num("dimDy"))
  val end=witnesses[1]+Vec(e.num("dimDx"),e.num("dimDy"))
  val textAt=(start+end)*.5+Vec(0.0,-textSize*.65)
  // Slope labels have a deliberately tight hitbox; don't steal nearby risers.
  return textHit(textAt,tolerance.coerceAtMost(textSize*.28)) ||
   closestOnSegment(p,start,end).distance(p)<=tolerance.coerceAtMost(textSize*.30)
 }
 val actual=if(source!=null&&isStair(source)&&metric in setOf("Gesamthöhe","Stufenhöhe")) {
  // Match Scene.entity: vertical riser dimensions use the physical front/rear
  // edges, which differ from the generic metric witnesses on sloped steps.
  val right=e.num("dimDx")+witnesses[0].x-e.num("metricOriginX",witnesses[0].x) >
   (witnesses[0].x+witnesses[1].x)/2-witnesses[0].x
  stairHeightWitnesses(source,if(metric=="Gesamthöhe")stairCount(source)-1 else 0,metric=="Gesamthöhe",right)
 }else witnesses
 val a=actual[0];val b=actual[1];val raw=b-a;val dist=raw.length()
 val mode=e.str("mode","aligned");val off=e.num("offsetMm",d.sheet.scale*8)
 val base=when(mode){"horizontal"->Vec(0.0,off);"vertical"->Vec(off,0.0);else->if(dist>1e-9)Vec(-raw.y/dist,raw.x/dist)*off else Vec(0.0,off)}
 val aa=a+base+shift
 val bb=when(mode){"horizontal"->Vec(b.x+shift.x,aa.y);"vertical"->Vec(aa.x,b.y+shift.y);else->b+base+shift}
 val textAt=dimensionTextPosition(a,b,aa,bb,label,textSize,e.num("textDx"),e.num("textDy"))
 if(textHit(textAt,tolerance.coerceAtMost(textSize*.55)))return true
 return closestOnSegment(p,aa,bb).distance(p)<=tolerance ||
  closestOnSegment(p,a,aa).distance(p)<=tolerance ||
  closestOnSegment(p,b,bb).distance(p)<=tolerance

}

data class Quantity(val key:String,val label:String,val unit:String,val value:Double)
fun quantities(d:Drawing,entries:List<LibraryEntry> = emptyList()):List<Quantity> {
 val rows=d.entities.mapNotNull { e ->
  if(e.status=="Abbruch") return@mapNotNull null
  val unit=e.quantityUnit ?: if(closedContour(e))"m²"else when(e.kind){"area"->"m²";"hedge","tree","component"->"Stk";else->return@mapNotNull null}
  val value=when(unit){"m²"->surfaceArea(e.copy(points=resolvedPoints(e,d)))/1e6;"m"->length(e.points)/1000;"Stk"->if(e.kind=="hedge") hedgeCount(length(e.points),e.num("spacingMm",400.0)).toDouble() else e.num("count",1.0);"m³"->area(e.points)*e.num("depthMm",100.0)/1e9;else->e.num("count",1.0)}
  val key=e.materialId?:e.libraryId?:e.name.ifEmpty {e.kind}; val label=entries.find {it.id==key}?.name?:e.name.ifEmpty {e.kind}
  Quantity(key,label,unit,value)
 }
 return rows.groupBy {it.key to it.unit}.values.map {g->g.first().copy(value=g.sumOf {it.value})}
}
fun dimensionValue(e:Entity,d:Drawing):Double {
 if(e.str("metric").isNotEmpty())return d.entities.find{it.id==e.str("sourceId")}?.let{metricValue(it,e.str("metric"))}?:0.0
 val pts=resolvedPoints(e,d);if(pts.size<2)return 0.0
 val delta=pts[1]-pts[0]
 return when(e.str("mode","aligned")){"horizontal"->abs(delta.x);"vertical"->abs(delta.y);"radius"->delta.length();"diameter"->2*delta.length();"angle"->{if(pts.size<3)0.0 else {val a=pts[0]-pts[1];val b=pts[2]-pts[1];Math.toDegrees(acos(((a.x*b.x+a.y*b.y)/(a.length()*b.length())).coerceIn(-1.0,1.0)))}};else->delta.length()}
}
fun slopeLabel(e:Entity,d:Drawing):String {
 val pts=resolvedPoints(e,d); val dist=if(pts.size>1)pts[0].distance(pts[1]) else 0.0
 val percent=if(e.str("mode","manual")=="auto" && dist>0) slopePercent(dist,e.num("startHeightMm")-e.num("endHeightMm")) else e.num("percent",2.0)
 return when(e.str("unit","%")){"cm/m"->"${fmt(percent)} cm/m";"1:x"->if(percent==0.0)"eben" else "1:${fmt(100/abs(percent))}";else->"${fmt(percent)} %"}
}
fun calibrate(e:Entity,a:Vec,b:Vec,realMm:Double):Entity {require(realMm>0 && a.distance(b)>1e-9);return transform(e,factor=realMm/a.distance(b),center=e.points.firstOrNull()?:Vec())}

data class LegendItem(val key:String,val label:String,val style:Style)
fun legendItems(d:Drawing,entries:List<LibraryEntry>):List<LegendItem> {
 val result=linkedMapOf<String,LegendItem>()
 for(e in d.entities) {
  val explicitKg=if(isKg2000(e)){val dn=e.num("dnMm",160.0).toInt();LegendItem("kg2000:$dn","KG2000 DN $dn",e.style)}else null
  if(explicitKg!=null)result.putIfAbsent(explicitKg.key,explicitKg)
  val key=e.materialId?:e.libraryId?:if(e.kind in setOf("tree","hedge"))"${e.kind}:${e.name}"else null
  if(key!=null&&!isKg2000(e)) {val library=entries.find{it.id==key};result.putIfAbsent(key,LegendItem(key,library?.name?:e.name.ifBlank{if(e.kind=="tree")"Baum"else"Hecke"},library?.style?:e.style))}
  for(layer in e.strata){val k=layer.materialId.ifBlank{layer.name};val library=entries.find{it.id==k};result.putIfAbsent(k,LegendItem(k,library?.name?:layer.name,library?.style?:Style(fill=layer.color)))}
 }
 return result.values.toList()
}
