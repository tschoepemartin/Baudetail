# BauDetail 0.9.49 – gezielte Render-Optimierung

- Interaktiver CanvasRenderer: Pfade und Kreise außerhalb des sichtbaren Ausschnitts werden vor dem Zeichnen per Canvas.quickReject übersprungen.
- Sichtbarkeitsprüfung berücksichtigt Strichbreite und Antialiasing-Rand.
- Druck-/PDF-Pfad bleibt unverändert (Optimierung nur bei interactive=true).
- Keine Änderungen an Snapping, Objektgeometrie, Menüs oder Eingabeverhalten.

## Einschränkungen
Dies ist eine risikoarme erste allgemeine Render-Optimierung, keine nachgewiesene vollständige Behebung des Ruckelns. Die Ursachen für mögliche Compose-Recompositions sind noch nicht durch Android-Profiling belegt. Ein Android-Build und Gerätetest stehen aus.
