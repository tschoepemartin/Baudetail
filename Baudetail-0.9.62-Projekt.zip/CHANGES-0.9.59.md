# BauDetail 0.9.59 – Experimentelle Performance-Korrektur

- Auf Basis 0.9.58, ohne den RenderNode-Umbau aus 0.9.57.
- Interaktiven Path-Cache auf Identität der unveränderten Szenen-Punktlisten umgestellt.
- Teures strukturelles Hashing und Kopieren sämtlicher Polygonpunkte bei Cache-Misses entfällt.
- PDF-Renderer bleibt unverändert (nichtinteraktiver Pfad).
- Kamera-, Snap- und Geometriedaten nicht verändert.

**Hinweis:** Das ist eine begrenzte Optimierung eines belegbaren Hotpaths, keine nachgewiesene vollständige Entkopplung von UI- und Zeichen-Thread. Android-Build und Gerätemessung stehen aus.
