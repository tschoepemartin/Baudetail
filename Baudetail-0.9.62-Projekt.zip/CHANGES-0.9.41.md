# BauDetail 0.9.41 – Fortsetzung (nicht freigegeben)
- Parametrische Pflasteraufbauten speichern eine bearbeitete vierpunktige Kontur als buildUpContourLocal in den Objektparametern.
- Die Kontur wird für die Draufsicht, den Plan-Footprint und Objektgrenzen berücksichtigt.
- Pflasterverband und Oberflächenvisualisierung werden auf das Polygon geclippt.
- Schichtaufbau, Materialien und Schnittdarstellung bleiben erhalten.
- Weiter offen: vollständige Menüsynchronisierung, echte PDF-basierte Vorschau, alle Spezialobjekte, Android-Build und Gerätetest.
- Fix: Bearbeitungsgriffe für parametrische Pflasteraufbauten verwenden gespeicherte Kontur statt Schnitt-Geometriepunkte; Live-Vorschau ebenso.
