# BauDetail 0.9.52 – weitere interaktive Renderer-Optimierungen

- Identitätsbasierter LRU-Schnellcache für unveränderte Pfadpunktlisten: vermeidet wiederholtes lineares Hashing sämtlicher Punkte bei jedem Zeichenaufruf; der bestehende inhaltsbasierte Cache bleibt als Fallback erhalten.
- Bereits geladene Bitmap-/SVG-Ressourcen werden vor der Dateipfad-Auflösung geprüft. Keine erneuten Asset-Dateisystemabfragen pro Zeichenaufruf bei Cache-Treffern.
- Ausschließlich der interaktive Renderer nutzt den neuen Pfad-Schnellcache; PDF/Druck nutzt weiterhin den bisherigen Pfad.
- Snapping, Geometrie, Darstellung und Werkzeuge nicht absichtlich geändert.
- Noch kein Android-Build oder Laufzeittest; nach GitHub-Build bitte erneut CSV messen.
