# BauDetail 0.9.38
- Im Kontur-Bearbeiten-Modus bleibt der senkrechte Abstand der zuletzt ausgewählten Kante sichtbar.
- Auswahl einer anderen Kante, eines Eckpunkts, Tippen ins Leere oder Werkzeugwechsel hebt das Maß auf.
- Antippen der Maßzahl öffnet ein kleines Eingabefenster mit aktuellem Abstand, Schließen und OK.
- OK verschiebt ausschließlich die gewählte Kante senkrecht um die Differenz zum eingegebenen Abstand; gegenüberliegende Kante bleibt stehen.
- Grundlegende Prüfung gegen degenerierte oder selbstschneidende Polygone.
- Android-Build noch nicht verifiziert; GitHub Actions ist für den Build vorgesehen.
