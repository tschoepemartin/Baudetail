package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Assert.*
import org.junit.Test

class BuildUpSectionLength0830Test {
 @Test fun rightFixedRealSlopeAndShortSectionRemainIndependent() {
  val e=Entity(kind="stack",points=listOf(Vec())).withNum("topDepthMm",6500.0)
   .withNum("buildUpSectionLengthMm",1000.0).withNum("buildUpRealLengthMm",6500.0)
   .withStr("buildUpRealLengthEnabled","true").withNum("buildUpSlopePct",1.65)
   .withStr("buildUpSlopeFixedSide","right")
  assertEquals(1000.0,buildUpGraphicLengthMm(e),0.001)
  assertTrue(buildUpBroken(e))
  assertEquals(-107.25,buildUpRealDropMm(e,0.0),0.001)
  assertEquals(0.0,buildUpRealDropMm(e,1000.0),0.001)
  assertEquals(-16.5,buildUpSlopeDropMm(e,0.0),0.001)
  assertEquals(6500.0,metricValue(e,"Weglänge"),0.001)
  assertEquals(1000.0,buildUpSurfaceEdge(e).second.x-buildUpSurfaceEdge(e).first.x,0.001)
 }
}
