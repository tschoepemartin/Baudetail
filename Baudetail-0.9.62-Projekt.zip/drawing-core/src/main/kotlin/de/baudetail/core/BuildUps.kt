package de.baudetail.core

import kotlinx.serialization.json.*
import de.baudetail.geometry.Vec

/** Generic marker for editable multi-layer constructions coming from a library. */
fun LibraryEntry.isParametricBuildUp():Boolean {
 val explicit=(attributes["parametric_build_up"] as? JsonPrimitive)?.booleanOrNull
  ?: (extensions["parametricBuildUp"] as? JsonPrimitive)?.booleanOrNull
 if(explicit!=null)return explicit
 return (attributes["Schichten"] as? JsonPrimitive)?.contentOrNull?.isNotBlank()==true
}

fun LibraryEntry.buildUpEditorTitle():String =
 (attributes["build_up_editor_title"] as? JsonPrimitive)?.contentOrNull?.takeIf{it.isNotBlank()}
  ?: if(name.contains("Pflaster",true)||name.contains("Platten",true)) "Pflasteraufbau anpassen" else "Aufbau anpassen"

private fun layerThicknessMm(text:String):Double {
 val m=Regex("""([0-9]+(?:[.,][0-9]+)?)\\s*(mm|cm|m)\\b""",RegexOption.IGNORE_CASE).find(text)?:return 0.0
 val n=m.groupValues[1].replace(',','.').toDoubleOrNull()?:0.0
 return when(m.groupValues[2].lowercase()){ "m"->n*1000.0;"cm"->n*10.0;else->n }
}

fun LibraryEntry.defaultBuildUpStrata():List<Stratum> {
 val raw=(attributes["Schichten"] as? JsonPrimitive)?.contentOrNull.orEmpty()
 if(raw.isBlank())return emptyList()
 val colors=listOf("#B6BBB7","#E4DBC4","#CBC3B4","#C8C0AE","#D5D1C6")
 return raw.split('|').mapIndexedNotNull{i,part->
  val t=part.trim();if(t.isBlank())null else {
   val mm=layerThicknessMm(t)
   val name=t.replace(Regex("""\\s+[0-9]+(?:[.,][0-9]+)?\\s*(?:mm|cm|m)\\b.*$""",RegexOption.IGNORE_CASE),"").trim()
   val grading=Regex("""\\b[0-9]+(?:[.,][0-9]+)?/[0-9]+(?:[.,][0-9]+)?\\b""").find(t)?.value.orEmpty()
   run {
    val clean=name.ifBlank{"Schicht ${i+1}"}
    val lower=clean.lowercase()
    val material=when { i==0||lower.contains("pflaster")||lower.contains("platte")->"Betonpflaster"; lower.contains("bett")->"Splitt 2/5"; lower.contains("frost")||lower.contains("trag")->"FS-Kies 0/32"; else->clean }
    val defaultMm=when { lower.contains("bett")->40.0; lower.contains("frost")||lower.contains("trag")->300.0; i==0->if(mm>0)mm else 80.0; else->if(mm>0)mm else 40.0 }
    val g=when(material){"Splitt 2/5"->"2/5";"Splitt 1/3"->"1/3";"Bettungsmaterial 0/5"->"0/5";"FS-Kies 0/32","FS-Schotter 0/32","RC 0/32"->"0/32";else->grading}
    Stratum(material,clean,defaultMm,colors[i%colors.size],g)
   }
  }
 }
}

fun Entity.isParametricBuildUp(entry:LibraryEntry?=null):Boolean = if(str("mergedPaving")=="true")false else kind=="stack" || str("parametricBuildUp")=="true" || entry?.isParametricBuildUp()==true

/** Adds editable build-up data to old placed library components without changing their identity/anchor. */
fun Entity.withBuildUpDefaults(entry:LibraryEntry?):Entity {
 if(!isParametricBuildUp(entry))return this
 val layers=if(strata.isNotEmpty())strata else entry?.defaultBuildUpStrata().orEmpty()
 val defaultPattern=pattern?:Pattern(200.0,100.0,4.0,0.0,1.0/3.0)
 val width=num("widthMm",entry?.attribute("width_mm",1200.0)?:1200.0)
 return copy(strata=layers,pattern=defaultPattern,params=JsonObject(params.toMutableMap().apply{
  put("parametricBuildUp",JsonPrimitive(true));put("widthMm",JsonPrimitive(width));if(!containsKey("topDepthMm"))put("topDepthMm",JsonPrimitive(entry?.let{it.attribute("top_height_mm",it.attribute("width_mm",1200.0))}?:1200.0))
 }))
}

val pavingMaterialChoices=listOf("Betonpflaster","Feinsteinzeug","Feinsteinzeug Holzoptik","Jurakalk","Granit","Sandstein","Natursteinplatten","Dränpflaster","Großkopfsteinpflaster","Kleinsteinpflaster","Mosaikpflaster","Klinker","Sonstiges")
/** Consistent material identity, including legacy saved strata. */
fun pavingVisualColor(material:String):String = when {
 material.contains("Jura",true)->"#D7C4A2"
 material.contains("Sandstein",true)->"#CDB493"
 material.contains("Granit",true)->"#A8ADB0"
 material.contains("Holzoptik",true)->"#B6A089"
 material.contains("Feinstein",true)->"#C8C7C1"
 material.contains("Klinker",true)->"#A66D57"
 material.contains("Dränpflaster",true)->"#A7ACA6"
 material.contains("Großkopf",true)->"#999B95"
 material.contains("Kleinstein",true)->"#ADB0AA"
 material.contains("Mosaik",true)->"#B9B7AB"
 else->"#B6BBB7"
}
fun pavingStoneSize(material:String):Pair<Double,Double> = when {
 material.contains("Mosaik",true)->90.0 to 90.0
 material.contains("Kleinstein",true)->110.0 to 110.0
 material.contains("Großkopf",true)->170.0 to 170.0
 material.contains("Klinker",true)->240.0 to 115.0
 material.contains("Feinstein",true)||material.contains("Natursteinplatten",true)->600.0 to 600.0
 else->200.0 to 100.0
}
val beddingMaterialChoices=listOf("Splitt 2/5","Splitt 1/3","Bettungsmaterial 0/5","Dränbeton/Einkornbeton","Sonstiges")
val frostMaterialChoices=listOf("FS-Kies 0/32","FS-Schotter 0/32","RC 0/32","Sonstiges")
fun buildUpMaterialChoices(index:Int)=when(index){0->pavingMaterialChoices;1->beddingMaterialChoices;2->frostMaterialChoices;else->listOf("Sonstiges")}
fun buildUpGrading(material:String)=when(material){"Splitt 2/5"->"2/5";"Splitt 1/3"->"1/3";"Bettungsmaterial 0/5"->"0/5";"FS-Kies 0/32","FS-Schotter 0/32","RC 0/32"->"0/32";else->""}
fun buildUpLayerDisplay(s:Stratum):String { val mat=s.materialId.takeUnless{it.isBlank()||it.lowercase() in setOf("paving","grit","frost","layer")}?:s.name.ifBlank{"Schicht"};return "$mat ${fmt(s.thicknessMm/10)} cm" + if(s.grading.isNotBlank()&&!mat.contains(s.grading)) " · ${s.grading}" else "" }
fun buildUpLabel(e:Entity)=e.strata.joinToString("\n",transform=::buildUpLayerDisplay)

/** Slope is stored as a percentage; positive means falling to the right in section. */
fun buildUpSlopePercent(e:Entity):Double = e.num("buildUpSlopePct",0.0).coerceIn(-100.0,100.0)
/** A broken section keeps its drawn slope but uses the real length for construction levels. */
fun buildUpGraphicLengthMm(e:Entity)=e.num("buildUpSectionLengthMm",e.num("topDepthMm",e.num("widthMm",1500.0))).coerceAtLeast(1.0)
fun buildUpRealLengthMm(e:Entity)=if(e.str("buildUpRealLengthEnabled","false")=="true")e.num("buildUpRealLengthMm",buildUpGraphicLengthMm(e)).coerceAtLeast(1.0) else buildUpGraphicLengthMm(e)
fun buildUpBroken(e:Entity)=e.str("buildUpRealLengthEnabled","false")=="true" && kotlin.math.abs(buildUpRealLengthMm(e)-buildUpGraphicLengthMm(e))>0.01
fun buildUpRealDropMm(e:Entity,x:Double):Double {
 val width=buildUpGraphicLengthMm(e)
 val real=buildUpRealLengthMm(e)
 val fixedRight=e.str("buildUpSlopeFixedSide","left")=="right"
 return (x/width-(if(fixedRight)1.0 else 0.0))*real*buildUpSlopePercent(e)/100.0
}
fun buildUpSlopeDropMm(e:Entity,x:Double):Double {
 val width=buildUpGraphicLengthMm(e)
 val fixedRight=e.str("buildUpSlopeFixedSide","left")=="right"
 return (x-if(fixedRight)width else 0.0)*buildUpSlopePercent(e)/100.0
}
/** World position of the associated slope label, independent of the material labels. */
fun buildUpSlopeLabelCenter(e:Entity,scale:Double):Vec {
 val edge=buildUpSurfaceEdge(e)
 // The anchor is a MODEL-space position relative to the paving surface.
 // Never derive its position from the print scale: changing 1:50 to 1:20
 // must not move an existing slope annotation relative to the object.
 val width=(edge.second-edge.first).length()
 val clearance=(width*0.07).coerceIn(35.0,100.0)
 return (edge.first+edge.second)*.5+Vec(e.num("buildUpSlopeLabelDx"),-clearance+e.num("buildUpSlopeLabelDy"))
}
fun buildUpSlopeLabelHit(e:Entity,at:Vec,scale:Double,tolerance:Double):Boolean {
 if(kotlin.math.abs(buildUpSlopePercent(e))<1e-8)return false
 val center=buildUpSlopeLabelCenter(e,scale)
 val factor=e.num("buildUpSlopeLabelScalePct",100.0).coerceIn(1.0,250.0)/100.0
 val half=kotlin.math.min((buildUpSurfaceEdge(e).second-buildUpSurfaceEdge(e).first).length()*.22,22.0*scale)
 return kotlin.math.abs(at.x-center.x)<=half*factor+tolerance && kotlin.math.abs(at.y-center.y)<=scale*4*factor+tolerance
}
/** The physical paving top edge, including section rotation. */
fun buildUpSurfaceEdge(e:Entity):Pair<Vec,Vec> {
 val origin=e.points.firstOrNull()?:Vec()
 val length=buildUpGraphicLengthMm(e)
 return (origin+Vec(0.0,buildUpSlopeDropMm(e,0.0)).rotate(e.rotation)) to (origin+Vec(length,buildUpSlopeDropMm(e,length)).rotate(e.rotation))
}


/** Absolute OK Belag at a section endpoint, using the true construction length.
 * The drawing-space endpoint is visual only when a broken section is used. */
fun buildUpSurfaceLevelMm(e:Entity,endpoint:Int,datumMm:Double):Double {
 val edge=buildUpSurfaceEdge(e)
 val point=if(endpoint==0)edge.first else edge.second
 val x=if(endpoint==0)0.0 else buildUpGraphicLengthMm(e)
 return datumMm-point.y-(buildUpRealDropMm(e,x)-buildUpSlopeDropMm(e,x))+e.num("buildUpLevelOffsetMm")
}

/** Reconcile the moved construction's level datum with the stationary neighbour.
 * The existing drawn surface and slope remain untouched. */
fun buildUpAlignLevelAtJoin(moved:Entity,target:Entity,sourceEnd:Int,targetEnd:Int,datumMm:Double):Entity {
 val difference=buildUpSurfaceLevelMm(target,targetEnd,datumMm)-buildUpSurfaceLevelMm(moved,sourceEnd,datumMm)
 return moved.withNum("buildUpLevelOffsetMm",moved.num("buildUpLevelOffsetMm")+difference)
}

/** Shared real OK edge for vertical paving and grass sections. Never use plan polygon corners. */
fun constructionSurfaceEdge(e:Entity):Pair<Vec,Vec> =
 if(e.str("grassObject")=="true")grassSectionGeometry(e).vegetationTop else buildUpSurfaceEdge(e)

/** Continuous section edge guidance. Aligns the X coordinate of complete
 * vertical construction edges without constraining vertical dragging. */
fun constructionSectionEdgeGuide(moving:Entity,targets:List<Entity>,raw:Vec,toleranceMm:Double):BuildUpSurfaceJoin? {
 if(!moving.isParametricBuildUp() && moving.str("grassObject")!="true")return null
 fun verticalEdges(e:Entity):List<Pair<Vec,Vec>> {
  val outline=if(e.str("grassObject")=="true")grassSectionGeometry(e).outline else {
   val surface=constructionSurfaceEdge(e)
   val depth=e.strata.sumOf{it.thicknessMm}
   listOf(surface.first,surface.second,surface.second+Vec(0.0,depth),surface.first+Vec(0.0,depth))
  }
  return outline.indices.mapNotNull{i->
   val a=outline[i];val b=outline[(i+1)%outline.size]
   if(kotlin.math.abs(a.x-b.x)<0.01 && kotlin.math.abs(a.y-b.y)>0.01)a to b else null
  }
 }
 val sources=verticalEdges(moving)
 return targets.asSequence().filter{it.id!=moving.id && (it.isParametricBuildUp()||it.str("grassObject")=="true")}.flatMap{target->
  val edges=verticalEdges(target)
  sources.asSequence().flatMap{source->edges.asSequence().mapNotNull{edge->
   val dx=edge.first.x-(source.first.x+raw.x)
   val sy0=kotlin.math.min(source.first.y,source.second.y)+raw.y
   val sy1=kotlin.math.max(source.first.y,source.second.y)+raw.y
   val ty0=kotlin.math.min(edge.first.y,edge.second.y)
   val ty1=kotlin.math.max(edge.first.y,edge.second.y)
   if(kotlin.math.abs(dx)<=toleranceMm && sy1>=ty0-toleranceMm && ty1>=sy0-toleranceMm)
    kotlin.math.abs(dx) to BuildUpSurfaceJoin(Vec(raw.x+dx,raw.y),target.id,0,0)
   else null
  }}
 }.minByOrNull{it.first}?.second
}

/** Surface-only join for paving sections. Never snap a paving OK to a layer
 * underside or the generic rectangular bounding box. Coordinates are model mm.
 * This is deliberately a preview/translation calculation: no slope or fixed
 * reference height is silently rewritten by a drag. */
data class BuildUpSurfaceJoin(val delta:Vec,val targetId:String,val sourceEnd:Int,val targetEnd:Int)
fun buildUpSurfaceJoin(moving:Entity,targets:List<Entity>,raw:Vec,toleranceMm:Double):BuildUpSurfaceJoin? {
 if(!moving.isParametricBuildUp() && moving.str("grassObject")!="true")return null
 val source=constructionSurfaceEdge(moving)
 val endpoints=listOf(source.first,source.second)
 return targets.asSequence().filter{it.id!=moving.id&&(it.isParametricBuildUp()||it.str("grassObject")=="true")}.flatMap{target->
  val edge=constructionSurfaceEdge(target)
  val ends=listOf(edge.first,edge.second)
  endpoints.asSequence().flatMapIndexed{si,p->ends.asSequence().mapIndexedNotNull{ti,q->
   val proposed=p+raw
   val gap=proposed.distance(q)
   if(gap<=toleranceMm)Triple(gap,BuildUpSurfaceJoin(raw+q-proposed,target.id,si,ti),q)else null
  }}
 }.minByOrNull{it.first}?.second
}
