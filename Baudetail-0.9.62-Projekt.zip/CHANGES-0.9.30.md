# BauDetail 0.9.30 – Vegetationsbibliothek

- Neue Bibliotheksobjekte mit Kategorie Vegetation und Namen Großbaum, Grossbaum, Kleinbaum oder Strauch werden als editierbare Pflanzobjekte statt als starre Komponenten erzeugt.
- Großbaum: 5 m Standard-Kronendurchmesser; Strauch: 1,2 m. Bibliotheksangabe crown_mm hat Vorrang.
- Bei alten Bibliothekskomponenten Großbaum/Strauch/Kleinbaum erscheint die explizite Aktion 'In bearbeitbare Pflanzung umwandeln'. Keine automatische Umwandlung bestehender Zeichnungen.
- Nach der Umwandlung steht das Pflanzung-anpassen-Menü zur Verfügung. Position, Layer und Objekt-ID bleiben erhalten.
- Organische Vektorkrone und Bruns-Auswahl aus 0.9.27 bis 0.9.29 bleiben erhalten.

Offen: Pflasterflächen-Vereinigung erfordert eine echte polygonfähige Parametrik für Belagsaufbauten; nicht als implementiert ausgeben.
Prüfung: ZIP-Integrität, keine Android-Kompilierung/Geräteprüfung.
