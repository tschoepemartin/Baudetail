# BauDetail 0.9.29 – Entwicklungsstand

- Hecke beim Platzieren als 1000 x 1000 mm Rechteck statt Zweipunktlinie.
- Hecke anpassen im Inspektor direkt oben sichtbar.
- Heckenlänge und -breite bei neuen Rechteck-Hecken unabhängig, Mittelpunkt bleibt erhalten.
- Pflanzenarten-Mix und Kronenstruktur-Auswahl im Heckenmenü.
- Unterschiedliche deterministische Vektormuster für Feldhecke, Laubhecke, Taxus und Thuja anhand von Pflanzenart oder manueller Auswahl.
- Pflanzung anpassen für `tree` im Inspektor direkt oben sichtbar.

Einschränkungen:
- Bibliotheksbasierte Großbaum-/Strauch-Symbole mit anderen Objektarten werden noch nicht automatisch migriert.
- Bestehende alte Hecken als Linien bleiben aus Kompatibilitätsgründen erhalten.
- Zusammenführen von Pflasterflächen nicht implementiert.
- Android-Build und Gerätetest noch nicht durchgeführt.
