package de.baudetail.ui.dialogs

import androidx.compose.material3.*
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.runtime.*
import de.baudetail.core.*
import de.baudetail.ui.*

@Composable fun OverviewMenu(vm:BaudetailViewModel,id:String,name:String,drawing:Boolean,onDismiss:()->Unit,onOpen:()->Unit,onExport:()->Unit){
 var action by remember{mutableStateOf("")}
 var chosenType by remember(id){mutableStateOf(vm.project?.drawings?.find{it.id==id}?.type?:"Lageplan")}
 val choices=if(drawing)listOf("Öffnen","Dokumenttyp ändern","Umbenennen","Duplizieren","Exportieren / Teilen","In Projekt verschieben","Löschen")else listOf("Öffnen","Dokumenttyp ändern","Umbenennen","Duplizieren","Exportieren / Teilen","Projektinformationen","Löschen")
 if(action.isEmpty())AlertDialog(onDismissRequest=onDismiss,title={Text(name)},text={Column{choices.forEach{choice->TextButton(onClick={action=choice}){Text(choice)}}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})
 when(action){
  "Öffnen"->{LaunchedEffect(Unit){onOpen();onDismiss()}}
  "Exportieren / Teilen"->{LaunchedEffect(Unit){onExport();onDismiss()}}
  "Dokumenttyp ändern"->AlertDialog(onDismissRequest=onDismiss,title={Text("Dokumenttyp ändern")},text={
   Column {
    Text("Zeichnung: $name")
    val types=listOf("Lageplan","Hausgartenentwurf","Technische Draufsicht","Schnitt","Detailzeichnung","Freies Blatt")
    var expanded by remember{mutableStateOf(false)}
    androidx.compose.foundation.layout.Box {
     OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(chosenType+"  ▾")}
     DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
      types.forEach{t->DropdownMenuItem(text={Text(t)},onClick={chosenType=t;expanded=false})}
     }
    }
    if(chosenType=="Lageplan")Text("Lageplan: nur Draufsicht (2,5D). Schnittdaten bleiben gespeichert.")
   }
  },confirmButton={TextButton(onClick={vm.changeDrawingType(id,chosenType);onDismiss()}){Text("Speichern")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
  "Umbenennen"->FormDialog("Umbenennen",listOf(Field("name","Name",name)),onDismiss){if(drawing)vm.renameDrawing(id,it.getValue("name"))else vm.projectAction(id,"rename",it.getValue("name"))}
  "Duplizieren"->{LaunchedEffect(Unit){if(drawing)vm.duplicateDrawing(id)else vm.projectAction(id,"duplicate");onDismiss()}}
  "Löschen"->AlertDialog(onDismissRequest=onDismiss,title={Text("Wirklich löschen?")},text={Text("${if(drawing)"Zeichnung"else"Projekt"} „$name“ wirklich löschen?")},confirmButton={TextButton(onClick={if(drawing)vm.deleteDrawing(id)else vm.projectAction(id,"delete");onDismiss()}){Text("Löschen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
  "In Projekt verschieben"->{val targets=vm.records.filter{it.id!=vm.project?.id};ChoiceDialog("Zielprojekt",targets.map{it.name},onDismiss){vm.moveDrawing(id,targets[it].id)}}
  "Projektinformationen"->AlertDialog(onDismissRequest=onDismiss,title={Text(name)},text={Text("${vm.records.find{it.id==id}?.drawings?:0} Zeichnungen\nProjekt-ID: $id")},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})
 }
}
