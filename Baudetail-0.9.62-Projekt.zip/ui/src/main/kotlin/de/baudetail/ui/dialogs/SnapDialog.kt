package de.baudetail.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.parseNumber

@Composable fun SnapDialog(d:Drawing,grid:Boolean,onDismiss:()->Unit,onSave:(Drawing)->Unit) {
 var settings by remember{mutableStateOf(d.input())}
 var step by remember{mutableStateOf(fmt(if(grid)d.gridMm else settings.snapMm))}
 val value=parseNumber(step)
 var edgeStep by remember{mutableStateOf(fmt(settings.edgeStepMm))}
 val edgeValue=parseNumber(edgeStep)
 AlertDialog(onDismissRequest=onDismiss,title={Text(if(grid)"Raster"else"Fang")},text={
 Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Row{Switch(if(grid)settings.gridVisible else settings.snapEnabled,{settings=if(grid)settings.copy(gridVisible=it)else settings.copy(snapEnabled=it)});Text("Aktiv",Modifier.padding(12.dp))}
 OutlinedTextField(step,{step=it},label={Text("${if(grid)"Rasterweite"else"Fangschritt"} in mm")},isError=value==null||value<=0,singleLine=true)
 listOf(listOf(1,5,10),listOf(20,50,100),listOf(200,500,1000)).forEach{row->Row{row.forEach{mm->TextButton(onClick={step=mm.toString()},modifier=Modifier.weight(1f)){Text(if(mm>=1000)"1 m"else if(mm>=10)"${mm/10} cm"else"$mm mm")}}}}
 if(!grid){
  Text("Kantenführung: seitliche Schritte beim Verschieben an einer Objektkante")
  OutlinedTextField(edgeStep,{edgeStep=it},label={Text("Kantenschritt in mm (0 = frei)")},singleLine=true,isError=edgeValue==null||edgeValue<0)
  Row{listOf(10,50,100,200,500).forEach{mm->TextButton(onClick={edgeStep=mm.toString()}){Text("${mm/10} cm")}}}
 }
 Text("Raster und Fangschritt sind unabhängig. Bei weitem Herauszoomen wird das Raster zur besseren Lesbarkeit ausgedünnt.")
 if(!grid)listOf("Raster" to "Rasterpunkt","Endpunkt" to "Endpunkt","Mitte" to "Kantenmittelpunkt","Schnittpunkt" to "Schnittpunkt","Kante" to "Kante / Kreisrand","Zentrum" to "Kreiszentrum").forEach{(key,label)->Row{Checkbox(key in settings.modes,{enabled->settings=settings.copy(modes=if(enabled)settings.modes+key else settings.modes-key)});Text(label,Modifier.padding(top=12.dp))}}
 }},confirmButton={TextButton(enabled=value!=null&&value>0&&(grid||edgeValue!=null&&edgeValue>=0),onClick={onSave(if(grid)d.copy(gridMm=value!!).withInput(settings)else d.withInput(settings.copy(snapMm=value!!,edgeStepMm=edgeValue!!)));onDismiss()}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
