package de.baudetail.ui

import de.baudetail.core.*
import de.baudetail.geometry.*
import kotlin.math.*

/** Exact polygon boundary union in model coordinates; refuses holes and disjoint results.
 * No rounding or bounding-box reconstruction of the outer contour. */
internal fun unionAreaContours(items:List<Entity>):List<Vec>? {
 if(items.size<2 || items.any{it.points.size<3})return null
 val polygons=items.map{it.points.let{p->if(p.size>3&&p.first().distance(p.last())<1e-7)p.dropLast(1)else p}}
 val eps=1e-6
 fun onSegment(p:Vec,a:Vec,b:Vec):Boolean=abs((b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x))<eps*max(1.0,a.distance(b)) && (p-a).let{v->v.x*(p.x-b.x)+v.y*(p.y-b.y)}<=eps
 fun inside(p:Vec,poly:List<Vec>):Boolean {
  if(poly.indices.any{i->onSegment(p,poly[i],poly[(i+1)%poly.size])})return true
  var hit=false
  for(i in poly.indices){val a=poly[i];val b=poly[(i+1)%poly.size];if((a.y>p.y)!=(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)hit=!hit}
  return hit
 }
 data class Edge(val a:Vec,val b:Vec)
 val raw=polygons.flatMap{poly->poly.indices.map{i->Edge(poly[i],poly[(i+1)%poly.size])}}
 val boundary=mutableListOf<Edge>()
 raw.forEachIndexed{index,e->
  val delta=e.b-e.a;val length2=delta.x*delta.x+delta.y*delta.y
  if(length2<eps*eps)return@forEachIndexed
  val cuts=mutableListOf(0.0,1.0)
  raw.forEachIndexed{j,other->if(index!=j){
   intersection(e.a,e.b,other.a,other.b)?.let{p->val t=((p.x-e.a.x)*delta.x+(p.y-e.a.y)*delta.y)/length2;if(t>eps&&t<1-eps)cuts.add(t)}
   listOf(other.a,other.b).forEach{p->if(onSegment(p,e.a,e.b)){val t=((p.x-e.a.x)*delta.x+(p.y-e.a.y)*delta.y)/length2;if(t>eps&&t<1-eps)cuts.add(t)}}
  }}
  val sorted=cuts.sorted().distinctBy{round(it*1e9).toLong()}
  for(k in 0 until sorted.lastIndex){val a=e.a+delta*sorted[k];val b=e.a+delta*sorted[k+1];if(a.distance(b)<eps)continue
   val mid=(a+b)*.5;val normal=Vec(-(b.y-a.y),b.x-a.x)*(1e-5/a.distance(b))
   val left=polygons.any{inside(mid+normal,it)};val right=polygons.any{inside(mid-normal,it)}
   if(left!=right)boundary.add(if(left)Edge(a,b)else Edge(b,a))
  }
 }
 if(boundary.isEmpty())return null
 val edges=boundary.distinctBy{e->listOf(e.a.x,e.a.y,e.b.x,e.b.y).map{round(it*1e6).toLong()}}
 val used=BooleanArray(edges.size);val loop=mutableListOf<Vec>();var current=edges[0].a
 repeat(edges.size){
  val next=edges.indices.firstOrNull{!used[it]&&edges[it].a.distance(current)<eps}?:return null
  used[next]=true;loop.add(edges[next].a);current=edges[next].b
  if(current.distance(loop.first())<eps){if(used.any{!it})return null;return loop.filterIndexed{i,p->val a=loop[(i+loop.size-1)%loop.size];val b=loop[(i+1)%loop.size];abs((p.x-a.x)*(b.y-p.y)-(p.y-a.y)*(b.x-p.x))>eps}}
 }
 return null
}
