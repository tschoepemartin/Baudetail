# BauDetail 0.9.56

- Zeichnungs-Kontextmenü: „Dokumenttyp ändern“ mit Dropdown für alle sechs vorhandenen Typen.
- Umstellung speichert nur den Dokumenttyp; Zeichnungsobjekte, Maße, Ebenen und bisherige Ansichtsinformationen bleiben erhalten.
- Nur Lageplan: 2,5D-Draufsicht erzwungen, Schnitt-Umschalter und Schnitt-Ansichtsprofil ausgeblendet.
- Kombinierter Schnitt-/Draufsicht-PDF-Export bei Lageplan deaktiviert.
- Andere Dokumenttypen unverändert.
- Keine belegte messbare Performanceverbesserung: die Schnittberechnung war im bestehenden Code bereits überwiegend ansichtsabhängig.
