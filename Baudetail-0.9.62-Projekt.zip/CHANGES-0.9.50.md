# BauDetail 0.9.50 – optionale Performance-Diagnose

Unter Einstellungen → Diagnose kann eine Messung gestartet und nach dem Test gestoppt werden. Die Daten lassen sich als CSV exportieren.

Messgrößen: Zeit zwischen Canvas-Zeichenaufrufen, CPU-Dauer des Canvas-Zeichenblocks, Dauer der ACTION_MOVE-Verarbeitung auf der Zeichenfläche, Objektanzahl. Die Messung ist standardmäßig aus und wird auf maximal 12.000 Samples begrenzt. Es werden keine Objektkoordinaten oder Zeichnungsinhalte gespeichert.

Wichtig: Canvas-Aufrufintervalle sind **keine** systemweite FPS-/Jank-Messung. Die Werkzeugleiste besitzt keinen eigenen instrumentierten Touch-Handler. Bei Werkzeugleistenbewegungen kann deshalb insbesondere erkannt werden, ob und wie häufig die Zeichenfläche mitzeichnet. Für echte Frame-Jank-/Compose-Recomposition-Analyse wäre zusätzlich Android Studio Perfetto/Layout Inspector nötig.

Unverändert: Rendering, Snapping, Geometrie, PDF-Export und Bedienverhalten.
