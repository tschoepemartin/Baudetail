package de.baudetail.geometry

import org.junit.Assert.assertEquals
import org.junit.Test

class PlanViewportTest {
 @Test fun roundTripAtAnyAngleAndZoom() {
  for(angle in listOf(-170.0,-90.0,0.0,37.0,90.0,180.0))
   for(zoom in listOf(0.001,0.06,1.0,8.0)) {
    val camera=PlanViewport(zoom,Vec(270.0,-93.0),angle,Vec(350.0,700.0))
    val point=Vec(6500.0,-190.0)
    val result=camera.toWorld(camera.toScreen(point))
    assertEquals(point.x,result.x,1e-6)
    assertEquals(point.y,result.y,1e-6)
   }
 }
 @Test fun panningDoesNotChangeModelCoordinates() {
  val a=PlanViewport(0.12,Vec(40.0,80.0),35.0,Vec(400.0,700.0))
  val point=Vec(3500.0,1700.0)
  val delta=Vec(91.0,-34.0)
  val b=a.copy(offset=a.offset+a.panDelta(delta))
  val result=b.toWorld(a.toScreen(point)+delta)
  assertEquals(point.x,result.x,1e-6)
  assertEquals(point.y,result.y,1e-6)
 }
 @Test fun zoomPreservesFingerAnchor() {
  val a=PlanViewport(0.05,Vec(60.0,60.0),-28.0,Vec(400.0,700.0))
  val touch=Vec(220.0,510.0)
  val anchor=a.toWorld(touch)
  val b=a.copy(zoom=0.3,offset=a.offsetForAnchor(anchor,touch,0.3))
  assertEquals(touch.x,b.toScreen(anchor).x,1e-6)
  assertEquals(touch.y,b.toScreen(anchor).y,1e-6)
 }
}
