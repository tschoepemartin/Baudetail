# BauDetail 0.9.55

- Grundstück: exakte geometrische Konstruktion für 4 Ecken, fixierte a/b/d und rechte Winkel α/β; c/γ/δ werden aus der Kontur berechnet. Bestehender allgemeiner Solver bleibt für andere Fälle erhalten.
- Interaktives Canvas: konservative frühe Sichtbarkeitsprüfung für weit außerhalb des Bildschirms liegende Texte vor Glyphenmessung, Paint-Erzeugung und Rotation. Export/PDF bleibt unverändert.
- Snapping, Objektgeometrie außerhalb des genannten Spezialfalls und Werkzeuge unverändert.
- ZIP strukturell geprüft; Android-Kompilierung und Laufzeitperformance noch nicht verifiziert.
