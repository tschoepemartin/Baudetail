#!/usr/bin/env python3
"""Compare extracted 0.9.46 project to 0.9.47. No Android runtime needed."""
import hashlib
import pathlib
import sys

old, new = map(pathlib.Path, sys.argv[1:3])
def files(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}
a, b = files(old), files(new)
changed = {p for p in a.keys() & b.keys() if a[p] != b[p]}
removed = a.keys() - b.keys()
expected = {'app/build.gradle.kts', 'export/src/main/kotlin/de/baudetail/export/CanvasRenderer.kt'}
assert changed == expected, changed
assert not removed, removed
original = (old / 'export/src/main/kotlin/de/baudetail/export/CanvasRenderer.kt').read_text()
reference = (new / 'export/src/androidTest/kotlin/de/baudetail/export/ReferenceCanvasRenderer0946.kt').read_text()
assert reference == original.replace('class CanvasRenderer(', 'internal class ReferenceCanvasRenderer0946(').replace('sanitizeSvg(', 'sanitizeSvg0946(')
config = (new / 'app/build.gradle.kts').read_text()
assert config.replace('versionCode = 947', 'versionCode = 946').replace('versionName = "0.9.47"', 'versionName = "0.9.46"') == (old / 'app/build.gradle.kts').read_text()
print(f'PASS: {len(a)-len(changed)} existing files byte-identical; only renderer and version changed.')
print('PASS: frozen reference renderer equals 0.9.46 except symbol names.')
print('Added files:', *sorted(b.keys()-a.keys()), sep='\n  ')
