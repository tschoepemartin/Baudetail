# BauDetail 0.9.24 – weitere Korrekturen

- Pflasteraufbau: explizite Auswahl „Verband an Nachbarfläche ausrichten“. Es werden nur Flächen mit identischem Deckmaterial, Steinformat, Fuge und Verband angeboten.
- Persistente Referenz per `pavingPatternReferenceId`; die Phase und Drehung der Referenz werden beim Zeichnen neu aufgelöst. Beide Flächen bleiben eigenständige Objekte.
- Steinbilder und Fugenraster verwenden dieselbe berechnete Ausrichtung.
- Traufe: Maßfelder verwenden lokale gedrehte Kanten statt Bounding-Box-Abmessungen; der Mittelpunkt bleibt bei der Größenänderung erhalten.

## Weiterhin offen
- Systematische Maßänderungskorrekturen weiterer Objektfamilien und vollständige Snapping-Überarbeitung.
- Android-Build nicht durchgeführt: Gradle-Distribution konnte in dieser Umgebung nicht geladen werden.
- Kein Gerätetest.
