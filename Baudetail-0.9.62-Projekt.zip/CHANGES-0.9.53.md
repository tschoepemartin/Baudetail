# BauDetail 0.9.53
- Interaktiver Renderer: Text außerhalb des sichtbaren Bereichs wird vor dem eigentlichen Zeichnen ausgelassen. Export/Print unverändert.
- Performance-Diagnose: CPU-Zeiten für Path, Circle, Text, Asset und Group werden optional separat protokolliert. Gruppenzeit enthält Unterelemente und darf nicht zusätzlich zur Summe addiert werden.
- Performance-Diagnose: `zoom_factor` dokumentiert den aktuellen Zoomfaktor in der vorhandenen CSV-Spalte `duration_ms` (hier dimensionslos).
- Keine Änderungen an Snap-Logik, Geometrie, Maßhaltigkeit oder PDF-Export.
- GitHub/Android-Build und reale Geschwindigkeitsmessung stehen aus.
