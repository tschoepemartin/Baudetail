# BauDetail 0.9.36 – Konturbearbeitung (Testversion)

- Neues Werkzeug **Bearbeiten** unter Zusammenführen in der linken Werkzeugleiste.
- Auswahlrahmen von Polygonen, Flächen, Rechtecken (einschließlich vereinigter Pflaster- und Pflanzflächen) folgt der tatsächlichen Kontur statt der Bounding-Box.
- Eckpunktgriffe für Flächen, Polygone und Rechtecke im Bearbeiten-Modus.
- Eckpunkt einzeln oder komplette Kante durch Verschieben beider Endpunkte ziehen.
- Fangfunktion bleibt aktiv; Live-Vorschau und Live-Maße für Verschiebung und ungefähre Tiefe.
- Numerische Eingabe für Eckpunkt-/Kantennummer und Verschiebung in X/Y in mm.
- Bearbeitungen laufen über das vorhandene Undo-fähige vm.update.

Grenzen: Die Tiefe ist derzeit eine Näherung aus der Bounding-Box, bei schrägen und komplexen Polygonen noch keine exakte Gegenkantenmessung. Es gibt noch keinen Griff zum Einfügen neuer Polygonpunkte. Keine Android-Kompilierung oder Geräteprüfung durchgeführt.
