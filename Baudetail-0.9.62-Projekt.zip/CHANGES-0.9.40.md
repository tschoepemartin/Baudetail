# BauDetail 0.9.40

- Parametrische Pflasteraufbauten in der Draufsicht mit „Bearbeiten“: Kontur aus tatsächlicher Pflastergeometrie, Kantenverschiebung und numerischer Kantenabstand.
- Geometrieänderungen aktualisieren die parametrischen Breiten-/Tiefenwerte und den Plananker, ohne Schichten oder Verlegemuster zu verwerfen.
- Gemeinsame Farbpalette (HEX, Standardfarben, RAL) auch für Linien-/Beschriftungsfarben und Texthintergründe.
- Spezialobjekte mit nicht-rechteckiger Geometrie bleiben vorerst bei ihren bisherigen objektspezifischen Bearbeitungsfunktionen.
