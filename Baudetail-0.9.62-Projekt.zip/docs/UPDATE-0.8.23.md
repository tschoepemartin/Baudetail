# 0.8.23
- More paving surface material choices and distinct deterministic vector texture/colours in plan and section.
- Fixed paper-size slope symbol length independent of construction length.
- All four plan footprint edges of build-ups are now snap targets (corners, midpoint, nearest edge).
- Saved drawings automatically render with the new material styles and snapping.
