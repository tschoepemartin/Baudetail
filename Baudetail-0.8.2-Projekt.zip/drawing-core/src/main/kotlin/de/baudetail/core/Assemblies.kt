package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

fun Drawing.viewMode()=(extensions["viewMode"] as? JsonPrimitive)?.contentOrNull ?: if(type=="Schnitt")"section"else"top"
fun Drawing.withViewMode(mode:String)=copy(extensions=JsonObject(extensions+("viewMode" to JsonPrimitive(mode))+(if(mode=="top"&&profile()=="Schnitt")mapOf("viewProfile" to JsonPrimitive("Oberflächenplan"))else emptyMap())))
fun LibraryEntry.isStairStep():Boolean = (attributes["assembly_role"] as? JsonPrimitive)?.contentOrNull=="stair_step" || (type in setOf("component","step") && (category+"/"+name).lowercase().let{"stuf" in it||"step" in it})
fun isStair(e:Entity)=e.kind=="assembly"&&e.str("assemblyType")=="stair"
fun stairCount(e:Entity)=e.num("stepCount",5.0).toInt().coerceIn(1,100)
fun stairRise(e:Entity)=if(e.str("heightMode")=="total") {
 val count=stairCount(e); val drop=stairSlopeDrop(e)
 // Hgesamt = (Stufenhoehe + Auftritt * Gefaelle/100) * Anzahl
 // => Stufenhoehe = Hgesamt/Anzahl - Gefaelleanteil je Stufe
 e.num("totalHeightMm",750.0)/count-drop
} else e.num("riseMm",150.0)
fun stairGoing(e:Entity)=if(e.str("lengthMode")=="total")if(stairCount(e)>1)(e.num("totalLengthMm",1800.0)-stairDepth(e))/(stairCount(e)-1)else stairDepth(e)else e.num("goingMm",350.0)
fun stairSlopeDrop(e:Entity)=stairGoing(e)*e.num("slope")/100.0
fun stairEffectiveRise(e:Entity)=stairRise(e)+stairSlopeDrop(e)
fun stairTotalHeight(e:Entity):Double {
 val count=stairCount(e)
 // Reale Treppenhoehe: pro Stufe kommt zur Stufenhoehe der Hoehenanteil
 // aus dem Laengsgefaelle des Auftritts hinzu.
 return count*(stairRise(e)+stairSlopeDrop(e))
}
fun stairLocalPoints(e:Entity,view:String):List<Vec> {
 val count=stairCount(e);val rise=stairRise(e);val going=stairGoing(e);val width=e.num("widthMm",1200.0);val effectiveRise=stairEffectiveRise(e);val drop=stairSlopeDrop(e)
 return if(view=="section") (0 until count).flatMap{i->val baseY=-i*effectiveRise;listOf(Vec(i*going,baseY),Vec(i*going,baseY-rise),Vec((i+1)*going,baseY-rise-drop))}
 else ((0 until count).map{it*going}+stairLength(e)).flatMap{x->listOf(Vec(x,0.0),Vec(x,width))}
}
/** Actual visible section geometry of the sloped block steps.
 * Snap edges must follow these rotated rectangles, never the unsloped bounding box. */
fun stairVisibleSectionSegments(e:Entity):List<Pair<Vec,Vec>> {
 val count=stairCount(e);val going=stairGoing(e);val depth=stairDepth(e);val rise=stairRise(e);val effectiveRise=stairEffectiveRise(e)
 val angle=-atan(e.num("slope")/100.0)
 return (0 until count).flatMap{i->
  val origin=Vec(i*going,-(i+1)*effectiveRise+e.num("widthMm",1000.0)*e.num("crossSlope")/200)
  val c=rectangle(Vec(),Vec(depth,rise)).map{it.rotate(Math.toDegrees(angle))+origin}
  c.indices.map{j->c[j] to c[(j+1)%c.size]}
 }
}
fun stairVisibleSectionOutline(e:Entity):List<Vec> {
 val pts=stairVisibleSectionSegments(e).flatMap{listOf(it.first,it.second)}
 return if(pts.isEmpty())rectangle(Vec(),Vec(stairLength(e),stairTotalHeight(e))) else {val b=Bounds.of(pts);rectangle(b.min,b.max)}
}

fun assemblyPoint(e:Entity,point:Vec,view:String?=null):Vec {
 val local=Vec(point.x,if(e.num("mirrored")==1.0)-point.y else point.y)
 val rotation=if(view==null)e.rotation else smartViewRotation(e,view)
 val origin=if(view==null)(e.points.firstOrNull()?:Vec()) else smartViewOrigin(e,view)
 return local.rotate(rotation)+origin
}
fun stairReferencePoints(e:Entity,view:String)=stairLocalPoints(e,view).map{assemblyPoint(e,it,view)}

/** Actual corners of the rendered, slope-rotated block; never mix front and rear. */
fun stairHeightWitnesses(e:Entity,stepIndex:Int,overall:Boolean,atRear:Boolean=false):List<Vec> {
 val i=stepIndex.coerceIn(0,stairCount(e)-1)
 val angle=-atan(e.num("slope")/100.0)
 val going=stairGoing(e);val depth=stairDepth(e);val rise=stairRise(e)
 fun corners(index:Int):Pair<Vec,Vec> {
  // Use the same transformed block corners as the section snap geometry.
  // Deriving a second, approximate height box made witness lines miss the
  // real rear lower corner after rotation / longitudinal slope changes.
  val segments=stairVisibleSectionSegments(e)
  val block=segments.drop(index*4).take(4)
  if(block.size!=4) {
   val origin=Vec(index*going,-(index+1)*stairEffectiveRise(e)+e.num("widthMm",1000.0)*e.num("crossSlope")/200)
   val x=if(atRear)depth else 0.0
   return assemblyPoint(e,Vec(x,0.0).rotate(Math.toDegrees(angle))+origin,"section") to
    assemblyPoint(e,Vec(x,rise).rotate(Math.toDegrees(angle))+origin,"section")
  }
  val corner=if(atRear)1 else 0
  val top=block[corner].first
  val bottom=block[if(atRear)2 else 3].first
  return assemblyPoint(e,top,"section") to assemblyPoint(e,bottom,"section")
 }

 val (top,bottom)=corners(i)
 return if(overall) listOf(corners(0).second,top) else listOf(bottom,top)
}

fun stairSteps(e:Entity,d:Drawing,p:Project):List<Entity> {
 val base=e.children.firstOrNull()?:p.libraryEntries.find{it.id==e.libraryId}?.let{componentInstance(it,Vec())}?:return emptyList()
 val rise=stairRise(e);val effectiveRise=stairEffectiveRise(e);val going=stairGoing(e);val depth=stairDepth(e)
 require(going>0&&going<=depth){"Auftritt muss positiv und höchstens so groß wie die Stufentiefe sein"}
 return (0 until stairCount(e)).map{i->
  val local=if(d.viewMode()=="section")Vec(i*going,-(i+1)*effectiveRise+e.num("widthMm",1000.0)*e.num("crossSlope")/200)else Vec(i*going,0.0)
  base.copy(id="${e.id}-step-$i",points=listOf(assemblyPoint(e,local,d.viewMode())),layerId=e.layerId,placement=e.placement,rotation=smartViewRotation(e,d.viewMode()))
   .withNum("depthMm",depth).withNum("widthMm",depth).withNum("stairWidthMm",e.num("widthMm",1000.0))
   .withNum("topDx",0.0).withNum("topDy",0.0).withNum("sectionDx",0.0).withNum("sectionDy",0.0)
   .withNum("topRotationDelta",0.0).withNum("sectionRotationDelta",0.0)
   .withNum("mirrored",e.num("mirrored")).withNum("slope",e.num("slope")).withNum("crossSlope",e.num("crossSlope"))
 }
}

/** Associates an already snapped point with its source geometry. */
fun anchorAt(point:Vec,d:Drawing):Anchor? {
 for(e in d.entities.filter{visibleIn(it,d)}){
  if(isStair(e)||e.kind=="component"){val i=smartSnapReferencePoints(e,d).indexOfFirst{it.distance(point)<1e-5};if(i>=0)return Anchor(e.id,i,"smart",d.viewMode())}
  if(isStair(e)&&assemblyPoint(e,Vec(stairLength(e),0.0),d.viewMode()).distance(point)<1e-5)return Anchor(e.id,reference="stairEnd",view=d.viewMode())
  if(e.kind=="circle"){val v=point-(e.points.firstOrNull()?:Vec());if(abs(v.length()-e.num("radiusMm"))<1e-5)return Anchor(e.id,reference="circleEdge",fraction=atan2(v.y,v.x))}

  val pts=if(isStair(e))stairReferencePoints(e,d.viewMode())else resolvedPoints(e,d)
  val i=pts.indexOfFirst{it.distance(point)<1e-5}
  if(i>=0)return Anchor(e.id,i,if(isStair(e))"stair"else"",d.viewMode())
 }
 val edges=mutableListOf<Anchor>()
 for(e in d.entities.filter{visibleIn(it,d)}){
  val smart=isStair(e)||e.kind=="component"
  if(smart && e.smartFamily()=="curb") {
   // In section the chamfer is real snap geometry.  In plan it remains visually
   // rectangular; only the semantic side/height reference is carried across.
   smartSnapSegments(e,d).forEachIndexed { i,(a,b) ->
    val len=a.distance(b)
    if(len>1e-9 && closestOnSegment(point,a,b).distance(point)<1e-5)
     edges.add(Anchor(e.id,i,"edge",d.viewMode(),fraction=a.distance(point)/len))
   }
  } else {
   val all=if(smart)smartSnapOutline(e,d)else resolvedPoints(e,d)
   val pts=all
   val closed=smart||e.kind in setOf("polygon","rect","building","area")
   val count=if(closed)pts.size else (pts.size-1).coerceAtLeast(0)
   for(i in 0 until count){val a=pts[i];val b=pts[(i+1)%pts.size];val len=a.distance(b)
    if(len>1e-9 && closestOnSegment(point,a,b).distance(point)<1e-5)edges.add(Anchor(e.id,i,"edge",d.viewMode(),fraction=a.distance(point)/len))
   }
  }
 }
 val first=edges.firstOrNull()?:return null
 val second=edges.drop(1).firstOrNull{it.entityId!=first.entityId}
 return if(second!=null)first.copy(reference="intersection",otherEntityId=second.entityId,otherVertex=second.vertex)else first
}
