package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import org.junit.Assert.*
import org.junit.Test

class Regression073Test {
 @Test fun stairMinimalAndExecutionHaveCorrectMetricsPerView(){
  val e=Entity(kind="assembly",params=buildJsonObject{put("stairCount",JsonPrimitive(4));put("stepCount",JsonPrimitive(4));put("widthMm",JsonPrimitive(1000.0));put("slope",JsonPrimitive(2.0))})
  // The two view profiles must remain independent even if the source stores both.
  val source=e.withStr("autoMeasureSection","Ausführung").withStr("autoMeasureTop","Minimal")
  assertEquals("Ausführung",source.str("autoMeasureSection"))
  assertEquals("Minimal",source.str("autoMeasureTop"))
 }
 @Test fun buildUpWidthOffsetOnlyMovesPlanGeometry(){
  val e=Entity(kind="stack",points=listOf(Vec(50.0,80.0)),params=buildJsonObject{
   put("widthMm",JsonPrimitive(2000.0));put("topDepthMm",JsonPrimitive(1000.0));put("buildUpTopWidthOffsetMm",JsonPrimitive(100.0))
  },strata=listOf(Stratum(thicknessMm=80.0),Stratum(thicknessMm=40.0),Stratum(thicknessMm=300.0)))
  val top=viewBounds(e,Drawing().withViewMode("top"));val section=viewBounds(e,Drawing().withViewMode("section"))
  assertEquals(180.0,top.min.y,0.01)
  assertEquals(80.0,section.min.y,0.01)
  assertEquals(1000.0,top.height,0.01)
  assertEquals(420.0,section.height,0.01)
 }
 @Test fun noZeroDimensionsFromCoincidentWitnesses(){
  val e=Entity(kind="assembly",points=listOf(Vec(0.0,0.0)))
  val dimensions=automaticMeasures(e,Drawing().withViewMode("section"),"Ausführung")
  assertTrue(dimensions.all{it.str("metric").isNotEmpty()})
 }
}
