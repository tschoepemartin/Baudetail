package de.baudetail.core
import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import org.junit.Test
import org.junit.Assert.*
class CoreTest {
 @Test fun dimensionTracksVertices(){val line=Entity(id="line",points=listOf(Vec(),Vec(1000.0,0.0)));val measure=Entity(kind="dimension",anchors=listOf(Anchor("line",0),Anchor("line",1)));val d=Drawing(entities=listOf(line,measure));assertEquals(1000.0,dimensionValue(measure,d),0.0);assertEquals(1500.0,dimensionValue(measure,d.copy(entities=listOf(line.copy(points=listOf(Vec(),Vec(1500.0,0.0))),measure))),0.0)}
 @Test fun sectionLink(){val cut=Drawing(type="Schnitt");val mark=Entity(kind="section",targetDrawingId=cut.id,text="A–A");val plan=Drawing(entities=listOf(mark));val p=Project(drawings=listOf(plan,cut));assertEquals(cut,p.drawings.find{it.id==mark.targetDrawingId})}
 @Test fun groupedQuantities(){val first=Entity(kind="area",points=rectangle(Vec(),Vec(4000.0,3000.0)),materialId="grass");val second=first.copy(id=uid());val rows=quantities(Drawing(entities=listOf(first,second)));assertEquals(1,rows.size);assertEquals(24.0,rows.first().value,0.0)}
 @Test fun titleVariablesUpdate(){val p=Project(name="Garten");val d=Drawing(sheet=Sheet(scale=10.0));assertEquals("Garten · 10",interpolate("{projekt} · {maßstab}",variables(p,d)));assertEquals("20",interpolate("{maßstab}",variables(p,d.copy(sheet=Sheet(scale=20.0)))))}
 @Test fun backgroundCalibration(){val bg=Entity(kind="image",points=listOf(Vec()),params=buildJsonObject{put("widthMm",1000);put("heightMm",500)});val calibrated=calibrate(bg,Vec(),Vec(500.0,0.0),2500.0);assertEquals(5000.0,calibrated.num("widthMm"),0.0);assertEquals(2500.0,calibrated.num("heightMm"),0.0)}
 @Test fun pavingUsesRealUnits(){val p=Pattern(widthMm=200.0,heightMm=100.0,jointMm=4.0);val result=Scene.pattern(rectangle(Vec(),Vec(1000.0,1000.0)),p,Style(),10.0) as Primitive.Group;val cells=((result.nodes.single() as Primitive.Group).nodes);val r=cells.first() as Primitive.Path;assertEquals(200.0,Bounds.of(r.points).width,0.0);assertEquals(100.0,Bounds.of(r.points).height,0.0)}
 @Test fun fivePersistentUndoSteps(){val h=EditorHistory(DrawingHistory(Drawing()));repeat(8){h.commit(h.current.copy(name="Step $it"))};val restart=EditorHistory(h.persisted());repeat(5){assertTrue(restart.canUndo);restart.undo()};assertFalse(restart.canUndo);assertEquals("Step 2",restart.current.name)}
 @Test fun tenBackupsRestore(){val h=EditorHistory(DrawingHistory(Drawing()));repeat(15){h.commit(h.current.copy(name="Step $it"))};assertEquals(10,h.persisted().backups.size);val desired=h.persisted().backups[0];h.restore(0);assertEquals(desired,h.current)}
 @Test fun snapEndpointsAndIntersections(){val lines=listOf(Entity(points=listOf(Vec(),Vec(1000.0,1000.0))),Entity(points=listOf(Vec(0.0,1000.0),Vec(1000.0,0.0))));assertEquals(Vec(500.0,500.0),snap(Vec(503.0,502.0),Drawing(entities=lines),SnapOptions(grid=false,toleranceMm=10.0)).point)}
 @Test fun dimensionsInPaperSceneAreScaled(){val d=Drawing(entities=listOf(Entity(points=listOf(Vec(),Vec(1000.0,0.0)))),sheet=Sheet(scale=10.0));val outer=Scene.paper(d,Project()).first() as Primitive.Group;val drawing=outer.nodes.first() as Primitive.Group;assertEquals(.1,drawing.scale,0.0)}
 @Test fun radiusDimensionTracksParameter(){val circle=Entity(id="c",kind="circle",points=listOf(Vec(),Vec(500.0,0.0))).withNum("radiusMm",750.0);val dim=Entity(kind="dimension",anchors=listOf(Anchor("c",0),Anchor("c",1))).withStr("mode","radius");assertEquals(750.0,dimensionValue(dim,Drawing(entities=listOf(circle,dim))),0.0)}
 @Test fun dynamicTextUsesSourceParameters(){val source=Entity(id="source",name="Betonplatte").withNum("widthMm",600.0);val text=Entity(kind="text",text="{name} {widthMm}").withStr("sourceId","source");assertEquals("Betonplatte 600.0",interpolate(text.text,textVariables(text,Drawing(entities=listOf(source,text)),Project())))}
 @Test fun angleMeasuresRightAngle(){val dim=Entity(kind="dimension",points=listOf(Vec(100.0,0.0),Vec(),Vec(0.0,100.0))).withStr("mode","angle");assertEquals(90.0,dimensionValue(dim,Drawing()),1e-8)}
 @Test fun chainHasSeparateDimensions(){val dim=Entity(kind="dimension",points=listOf(Vec(),Vec(100.0,0.0),Vec(200.0,0.0))).withStr("mode","chain");val d=Drawing(entities=listOf(dim));assertEquals(2,Scene.entity(dim,d,Project()).filterIsInstance<Primitive.Text>().size)}
 @Test fun nonPrintableLayerExcluded(){val d=Drawing(layers=listOf(Layer(id="guide",name="Hilfslinien",printable=false)),entities=listOf(Entity(layerId="guide",points=listOf(Vec(),Vec(10.0,10.0)))));assertTrue(Scene.drawing(d,Project(),true).isEmpty());assertTrue(Scene.drawing(d,Project(),false).isNotEmpty())}
 @Test fun legendIncludesVegetationAndLayers(){val d=Drawing(entities=listOf(Entity(kind="tree",name="Birke"),Entity(kind="hedge",name="Hainbuche"),Entity(kind="stack",strata=listOf(Stratum(materialId="sand",name="Sand")))));assertEquals(listOf("Birke","Hainbuche","Sand"),legendItems(d,emptyList()).map{it.label})}

 @Test fun kg2000PipeConnectorsSitOnVisibleCenterline(){val e=Entity(kind="component",points=listOf(Vec())).withStr("componentFamily","pipe").withStr("pipeSystem","KG2000").withStr("fittingType","pipe").withNum("dnMm",160.0).withNum("pipeLengthMm",1000.0);val c=kg2000Connectors(e,Drawing());assertEquals(Vec(0.0,80.0),c[0].at);assertEquals(Vec(1000.0,80.0),c[1].at)}
 @Test fun kg2000ReducerKeepsLargeSpigotAndSmallSocket(){val e=Entity(kind="component",points=listOf(Vec())).withStr("componentFamily","pipe").withStr("pipeSystem","KG2000").withStr("fittingType","reducer").withNum("inletDnMm",160.0).withNum("outletDnMm",110.0);val c=kg2000Connectors(e,Drawing());assertEquals("spigot",c[0].kind);assertEquals(160.0,c[0].dnMm,0.0);assertEquals("socket",c[1].kind);assertEquals(110.0,c[1].dnMm,0.0)}
 @Test fun kg2000BendSectionDirectionControlsFreeEnd(){
  fun bendDir(value:String):Double {
   return kg2000BendGeometry(
    Entity(kind="component").withNum("dnMm",160.0).withNum("bendAngle",45.0).withStr("bendDirection",value),
    "section"
   ).spigotDirection
  }
  assertEquals(-90.0,bendDir("up"),1e-8)
  assertEquals(90.0,bendDir("down"),1e-8)
  assertEquals(0.0,bendDir("right"),1e-8)
  assertEquals(180.0,bendDir("left"),1e-8)
 }
}
