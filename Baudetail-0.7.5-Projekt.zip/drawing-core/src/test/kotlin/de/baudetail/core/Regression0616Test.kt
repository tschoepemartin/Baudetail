package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.*
import org.junit.Test

class Regression0616Test {
 @Test fun channelBoxHasNoOutletByDefaultAndSupportsBottom(){
  val entry=LibraryEntry(id="r",type="component",name="Kastenrinne",category="Entwässerung",attributes=buildJsonObject{put("component_family","channel_box")})
  val e=componentInstance(entry,Vec())
  assertEquals("none",e.str("pipeOutlet","none"))
  val d=Drawing(entities=listOf(e)).withViewMode("top")
  assertTrue(channelBoxPipeConnectors(e,d).isEmpty())
  val bottom=e.withStr("pipeOutlet","bottom")
  val c=channelBoxPipeConnectors(bottom,d).single()
  assertEquals(bottom.num("boxLengthMm",500.0)/2.0,c.at.x,1e-6)
  assertEquals(bottom.num("boxWidthMm",185.0),c.at.y,1e-6)
 }

 @Test fun elevationValueDoesNotChangeWhenSwitchingToPlan(){
  val stair=Entity(kind="assembly",points=listOf(Vec(1000.0,1000.0)),params=buildJsonObject{put("assemblyType","stair");put("stepCount",5);put("riseMm",150.0);put("goingMm",300.0);put("depthMm",400.0);put("widthMm",1200.0)})
  val section=Drawing(entities=listOf(stair)).withViewMode("section")
  val target=smartSnapReferencePoints(stair,section).minBy{it.y}
  val anchor=anchorAt(target,section)!!
  val ref=Entity(kind="elevation",points=listOf(Vec(0.0,1000.0)),params=buildJsonObject{put("elevationRole","leader");put("heightMm",0.0);put("elevationCreatedView","section")})
  val kote=Entity(kind="elevation",points=listOf(target),anchors=listOf(anchor),params=buildJsonObject{put("elevationRole","relative");put("heightOffsetMm",0.0);put("elevationCreatedView","section")})
  val ds=section.copy(entities=listOf(stair,ref,kote));val top=ds.withViewMode("top")
  assertEquals(elevationValueMm(kote,ds),elevationValueMm(kote,top),1e-6)
 }

 @Test fun elevationLabelOffsetIsIndependentFromMarkerOffset(){
  val e=Entity(kind="elevation",points=listOf(Vec(10.0,20.0)))
  val moved=moveAnnotationInView(e,"top",Vec(100.0,50.0))
  val label=moveElevationLabelInView(moved,"top",Vec(30.0,-20.0))
  assertEquals(Vec(100.0,50.0),annotationViewOffset(label,"top"))
  assertEquals(Vec(30.0,-20.0),elevationLabelOffset(label,"top"))
 }
}
