package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue

class Regression0612Test {
 private fun pipe(at:Vec=Vec())=Entity(kind="component",name="KG2000 DN 160",points=listOf(at),placement=Placement(level="Leitungen"),params=buildJsonObject{
  put("componentFamily","pipe");put("pipeSystem","KG2000");put("fittingType","pipe");put("dnMm",160.0);put("pipeLengthMm",1000.0);put("topRotationDelta",0.0)
 })
 private fun box(at:Vec=Vec())=Entity(kind="component",name="Sinkkasten",points=listOf(at),params=buildJsonObject{
  put("componentFamily","channel_box");put("boxLengthMm",500.0);put("boxWidthMm",185.0);put("boxHeightMm",610.0);put("pipeDnMm",160.0);put("pipeAxisFromTopMm",500.0);put("pipeOutlet","left");put("topRotationDelta",0.0)
 })

 @Test fun undergroundPipeIsHiddenInSurfacePlanButVisibleInUtilityPlan(){
  val e=pipe()
  val base=Drawing(entities=listOf(e)).withViewMode("top")
  assertFalse(visibleIn(e,base.withProfile("Oberflächenplan")))
  assertTrue(visibleIn(e,base.withProfile("Entwässerungs-/Leitungsplan")))
 }

 @Test fun channelBoxLeftOutletIsAtBoxCentreAndPointsLeft(){
  val e=box(Vec(1000.0,2000.0));val d=Drawing(entities=listOf(e)).withViewMode("top")
  val c=channelBoxPipeConnectors(e,d).single()
  assertEquals(Vec(1000.0,2092.5),c.at)
  assertEquals(180.0,c.direction,1e-6)
 }

 @Test fun straightPipeCanAlignFromSinkCentreToTheLeft(){
  val b=box(Vec(1000.0,2000.0));val p=pipe();val d=Drawing(entities=listOf(b,p)).withViewMode("top")
  val target=channelBoxPipeConnectors(b,d).single();val source=kg2000Connectors(p,d).first()
  var rot=(target.direction+180.0-source.direction+180.0)%360.0-180.0
  val aligned=rotateSmartInView(p,"top",rot)
  val sc=kg2000Connectors(aligned,d).first()
  val moved=moveSmartInView(aligned,"top",target.at-sc.at)
  val cons=kg2000Connectors(moved,d)
  assertEquals(target.at,cons.first().at)
  assertTrue(cons.last().at.x < target.at.x)
  assertEquals(target.at.y,cons.last().at.y,1e-6)
 }

 @Test fun grassAndPipeDoNotReceiveLegacyQuarterTurnByDefault(){
  fun entry(name:String,cat:String,family:String)=LibraryEntry(id=name,type="component",name=name,category=cat,attributes=buildJsonObject{put("component_family",family);put("width_mm",1000.0);put("height_mm",100.0)})
  assertEquals(0.0,componentInstance(entry("Rasen","Vegetation/Rasen","grass"),Vec()).num("topRotationDelta"),1e-6)
  assertEquals(0.0,componentInstance(entry("KG2000","Rohre/KG","pipe"),Vec()).num("topRotationDelta"),1e-6)
 }
}
