package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.*
import org.junit.Test

class Cad032Test {
 @Test fun printVariablesNeverLeakUnknownPlaceholders(){
  val p=Project(name="Test",metadata=mapOf("bearbeiter" to "Martin"))
  val d=Drawing(name="Schnitt A")
  val text=interpolate("{projekt}|{projektnummer}|{bearbeiter}|{unbekannt}",variables(p,d))
  assertEquals("Test||Martin|",text)
 }

 @Test fun metricDimensionCanBeHitOnVisibleDimensionLine(){
  val stair=Entity(kind="assembly",points=listOf(Vec(1000.0,1000.0)),params=buildJsonObject{
   put("assemblyType","stair");put("stepCount",5);put("depthMm",400);put("goingMm",350);put("riseMm",150);put("widthMm",1000)
  })
  val base=Drawing(type="Schnitt",entities=listOf(stair)).withViewMode("section")
  val dim=automaticMeasures(stair,base,"Vollständig").first{it.str("metric")=="Auftritt"}
  val d=base.copy(entities=listOf(stair,dim))
  val witnesses=metricWitnesses(stair,"Auftritt",d)!!
  val a=witnesses[0];val b=witnesses[1];val raw=b-a;val len=raw.length();val off=dim.num("offsetMm",d.sheet.scale*8)
  val normal=Vec(-raw.y/len,raw.x/len)*off
  val shift=Vec(dim.num("dimDx"),dim.num("dimDy"))
  val middle=(a+normal+shift+b+normal+shift)*.5
  assertTrue(hitTest(middle,dim,d,20.0))
 }

 @Test fun legacyGrassSectionGetsTopFallback(){
  val entry=LibraryEntry(id="grass",type="component",category="Vegetation/Rasen/Schnitt",name="Rasenkante Standard",attributes=buildJsonObject{
   put("Darstellung","Schnitt");put("width_mm",1000);put("height_mm",260);put("section_width_mm",1000);put("section_height_mm",260)
  },views=mapOf("top" to "same-section.svg","section" to "same-section.svg"),style=Style(fill="#D5E5B7"))
  val e=componentInstance(entry,Vec())
  assertEquals("true",e.str("grassTopFallback"))
  assertEquals(1000.0,e.num("topWidthMm"),.001)
  assertEquals(1000.0,e.num("topHeightMm"),.001)
 }
 @Test fun legacyPaperOriginDoesNotClipRemoteDrawing(){
  val e=Entity(kind="rect",points=listOf(Vec(6000.0,3000.0),Vec(7000.0,3000.0),Vec(7000.0,3500.0),Vec(6000.0,3500.0)))
  val d=Drawing(sheet=Sheet(scale=50.0,origin=Vec()),entities=listOf(e))
  val paper=Scene.paper(d,Project(drawings=listOf(d)))
  val outer=paper.first() as Primitive.Group
  val content=outer.nodes.single() as Primitive.Group
  // 0.6.11+: sheet.origin is deliberately the fixed lower-left world anchor.
  // Changing paper size must not recenter or rescale the drawing.
  assertEquals(10.0,content.translate.x,.001)
 }

 @Test fun stairSlopeIsIncludedInRealTotalHeight(){
  val stair=Entity(kind="assembly",params=buildJsonObject{
   put("assemblyType","stair");put("stepCount",8);put("riseMm",150);put("goingMm",350);put("depthMm",400);put("slope",2.0)
  })
  // 2 % of 350 mm = 7 mm fall along each tread.  The vertical step-to-step
  // displacement is therefore 150 + 7 = 157 mm and the visible outline ends
  // at the same total height reported by the metric.
  assertEquals(157.0,stairEffectiveRise(stair),.001)
  assertEquals(1256.0,metricValue(stair,"Gesamthöhe"),.001)
  val pts=stairLocalPoints(stair,"section")
  assertEquals(-1256.0,pts.last().y,.001)
 }

}
