package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.junit.Assert.*
import org.junit.Test

class Regression0618Test {
 private fun stack()=Entity(kind="stack",points=listOf(Vec(100.0,200.0)),name="Pflasteraufbau",params=JsonObject(mapOf("widthMm" to JsonPrimitive(1500.0),"topDepthMm" to JsonPrimitive(1000.0))),pattern=Pattern(200.0,100.0,4.0,0.0,1.0/3.0),strata=listOf(Stratum("paving","Pflaster",80.0,"#B6BBB7"),Stratum("grit","Bettung",40.0,"#E4DBC4","2/5"),Stratum("frost","Frostschutz",250.0,"#CBC3B4","0/32")))
 private fun flatten(nodes:List<Primitive>):List<Primitive> = nodes.flatMap{if(it is Primitive.Group) listOf(it)+flatten(it.nodes) else listOf(it)}

 @Test fun topViewRendersPavingPatternAndNeverLayerSection(){
  val nodes=flatten(Scene.entity(stack(),Drawing().withViewMode("top"),Project()))
  assertFalse(nodes.filterIsInstance<Primitive.Text>().any{it.value.contains("Bettung")||it.value.contains("Frostschutz")})
  assertTrue(nodes.filterIsInstance<Primitive.Path>().size>2)
 }

 @Test fun legacyNonSectionPlanTokenAlsoRendersTopPattern(){
  val d=Drawing(extensions=JsonObject(mapOf("viewMode" to JsonPrimitive("plan"))))
  val nodes=flatten(Scene.entity(stack(),d,Project()))
  assertFalse(nodes.filterIsInstance<Primitive.Text>().any{it.value.contains("Bettung")||it.value.contains("Frostschutz")})
  assertTrue(nodes.filterIsInstance<Primitive.Path>().size>2)
 }

 @Test fun sectionUsesNormalObjectLabelInsteadOfFixedLayerTexts(){
  val e=stack().withStr("labelEnabled","true")
  val nodes=flatten(Scene.entity(e,Drawing().withViewMode("section"),Project()))
  val labels=nodes.filterIsInstance<Primitive.Text>().map{it.value}
  assertEquals(3,labels.size)
  assertTrue(labels.any{it.contains("Pflaster")})
  assertTrue(labels.any{it.contains("Bettung")})
  assertTrue(labels.any{it.contains("Frostschutz")})
 }
}
