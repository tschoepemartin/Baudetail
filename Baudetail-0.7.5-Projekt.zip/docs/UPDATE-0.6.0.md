# Baudetail 0.6.0

Gezielter Korrekturstand auf Basis 0.5.10.

- Spiegeln bleibt positionsstabil wie in 0.5.10.
- Auswahl-/Hitbox intelligenter Bauteile wird nach Spiegelungen aus der tatsächlich gerenderten, ansichtsspezifischen Weltgeometrie neu bestimmt.
- Borde/Leistensteine verwenden dabei ihre echte Kontur inklusive Phase; Phasen- und OK-Snap bleiben unverändert.
- Keine Bibliotheksänderung erforderlich; Grundbibliothek v10 bleibt kompatibel.
- App-ID und Dateiformate unverändert.
- versionCode 24, versionName 0.6.0.
