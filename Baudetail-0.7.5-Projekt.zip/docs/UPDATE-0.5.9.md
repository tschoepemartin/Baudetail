# Baudetail 0.5.9

Gezielter Bord-/Leistenstein-Patch auf Basis 0.5.8.

- Borde/Leistensteine besitzen standardmäßig eine reale einseitige Phase 3 mm breit / 4 mm tief.
- Die Phase wird in Schnitt und PDF maßstäblich aus mm-Geometrie gerendert.
- OK-Kante, Phasenbeginn und Phasenende sind echte Snap-Geometrie.
- Objektmenü: `Ohne Phase` blendet die Phase geometrisch aus; Standard ist Phase aktiv.
- Variantenwechsel erhält die Phasen-Einstellung.
- Grundbibliothek v10 trägt die Phasenparameter an allen curb-Objekten.
- versionCode 22, versionName 0.5.9.
