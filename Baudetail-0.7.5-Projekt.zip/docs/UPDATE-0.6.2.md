# Baudetail 0.6.2

- Ansichtsübergreifende semantische Snap-Verknüpfung zwischen Schnitt und Draufsicht.
- Snap-Verbindungen speichern Quell- und Zielbedeutung statt nur Bildschirmkoordinaten.
- Intelligente Bauteile werden in der jeweils anderen Ansicht am korrespondierenden Snap ausgerichtet.
- Gruppen verschieben bei einer ansichtsübergreifenden Snap-Korrektur ihre übrigen Mitglieder gemeinsam.
- Bestehende Bord-Phase/OK-, Spiegel- und Gruppen-Snap-Funktionen bleiben erhalten.
- versionCode 26, versionName 0.6.2.
