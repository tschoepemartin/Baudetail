# Baudetail 0.6.10

Fokus: Draufsicht aus Schnittbeziehungen korrekt rekonstruieren.

- Schnitt-Verknüpfungen werden in der Draufsicht als zusammenhängende Einbaukette angeordnet statt aus alten Top-Koordinaten übernommen.
- Die Schnittposition entlang des Treppenlaufs bestimmt die Position im Grundriss.
- Bauteile werden automatisch so gedreht, dass die zur Schnittdicke passende Planabmessung in der Einbaukette liegt. Dadurch stehen Leisten-/Bordsteine quer zum Treppenlauf, während ihre Dicke in der Reihenfolge Bord -> Kasten -> Bord -> Treppe liegt.
- KG2000 startet im Grundriss am Mittelpunkt des Einlauf-/Sinkkastens und läuft vom Treppenanschluss weg; Folgeelemente bleiben über ihre echten Connectoren verbunden.
- Rohre werden in der Zeichenreihenfolge hinter Bord, Kasten und anderen sichtbaren Bauteilen gezeichnet.
- Bestehende 0.6.9-Korrekturen (Bord-Phasenpunkt/OK-Snap, Legendenbearbeitung, Höhenkoten, Rücksprung auf Auswahl) bleiben erhalten.
- versionCode 34, versionName 0.6.10.
