# Baudetail 0.5.4

Gezielter Korrekturstand auf Basis 0.5.3.

- Eigene Bauwerke/Frozen Templates verwenden für Auswahl und Darstellung jetzt die tatsächlichen äußeren Kind-Geometrien statt einer generischen Komponentenbox.
- Snap-Referenzen von Bauwerken werden aus den äußeren Referenzpunkten ihrer enthaltenen Bauteile abgeleitet. Damit können äußere Bauteile wie ein Sinkkasten wieder normal an angrenzende Geometrie/Treppen snappen.
- Treppenstufen erben keine pauschale 90°-Draufsichtrotation oder View-Offets mehr von Bibliothekskomponenten.
- Treppenschnitt und Stufenfüllungen liegen wieder auf derselben lokalen Geometrie.
- Draufsicht der Treppe wird vollständig grau gefüllt; Stufenlinien und Laufrichtung liegen darüber.
- versionCode 17, versionName 0.5.4.
