# Baudetail 0.7.0

- Generische parametrische Aufbauobjekte aus der Bibliothek: Bibliothekseinträge mit `Schichten` (oder explizitem `parametric_build_up`) werden automatisch als editierbare Aufbauten erkannt.
- Kein Namens-Sondercode: auch zukünftige `.bdlib`-Aufbauten erhalten automatisch die Aufbau-Bearbeitung.
- Bestehende bereits platzierte Bibliotheksobjekte werden anhand ihrer `libraryId` zur Laufzeit migriert; sie müssen nicht neu eingefügt werden.
- Objektmenü zeigt `Pflasteraufbau anpassen` bei Pflaster/Platten, sonst generisch `Aufbau anpassen`.
- Schnitt rendert Schichten; Draufsicht rendert die Oberfläche mit Verlegemuster und verwendet nicht mehr das alte Section-SVG als Top-Ansicht.
- Regressionstests prüfen echte Bibliotheks-Metadaten, Altobjekt-Migration, zukünftige Namen und Draufsicht ohne Section-Asset.
