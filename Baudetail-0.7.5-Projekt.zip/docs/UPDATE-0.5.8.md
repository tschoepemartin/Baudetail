# Baudetail 0.5.8

Gezielter Korrekturstand auf Basis 0.5.7.

- Parametrischer Einlaufkasten: sichtbare Geometrie, Hitbox, Bemaßung und PDF benutzen dieselben realen mm-Bounds. Dekorative Rahmen/Rostlinien bleiben innerhalb der Bauteilkontur; DN-Auslass wird mit realem Außendurchmesser gerendert.
- Maßverschiebung: nur horizontal/vertikal magnetisch. Kein 15°/30°/45°- oder allgemeiner Objekt-/Rastersnap beim Verschieben von Bemaßungen.
- Das Einrasten horizontal/vertikal ist bereits während des Drags sichtbar; außerhalb des Fangbereichs bleibt die Maßposition frei zweidimensional.
- versionCode 21, versionName 0.5.8.
