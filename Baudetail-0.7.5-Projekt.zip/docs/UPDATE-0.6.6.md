# Baudetail 0.6.6

- Schnitt -> Draufsicht verwendet jetzt semantische Anschlussflächen statt Rohkoordinaten.
- Die Reihenfolge/Anlage verbundener Bauteile wird in der Draufsicht über Flächenmittelpunkte aufgelöst.
- Automatische Objektbeschriftungen sind ansichtsspezifisch, quellenbezogen und in stabilen Lanes angeordnet.
- Beschriftungstext bleibt horizontal; Führung zeigt auf die nächstgelegene Objektkante.
- Manuelles Verschieben einer Beschriftung wird getrennt für Schnitt und Draufsicht gespeichert.
- Automatische Maße wurden nicht verändert.
