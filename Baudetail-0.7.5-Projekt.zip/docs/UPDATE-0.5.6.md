# Baudetail 0.5.6

Gezielter Patch auf Basis 0.5.5.

- Automatische Bemaßung gespeicherter Bauwerke verwendet im Schnitt wieder die äußeren fachlichen Bezugskanten: unten die Gesamtlänge des kompletten Bauwerks, rechts die Kastenhöhe.
- Einlaufkasten-Detailmaße bleiben in Ausführungs-/Vollständig-Profilen verfügbar.
- Manuell verschobene automatische Maße speichern ihren Darstellungs-Offset nun dauerhaft am Quellobjekt; Geometrieanker bleiben assoziativ. Profilwechsel, Neuberechnung und erneutes Öffnen setzen die Position nicht mehr auf die Standardspur zurück.
- versionCode 19, versionName 0.5.6.
