# Baudetail 0.6.3

## Regression-Fix Snap / Ansichten
- Die semantische Snap-Zuordnung aus 0.6.2 bleibt für Schnitt -> Draufsicht erhalten.
- Der neue View-Link wirkt nicht mehr als dauerhafte Zwangsbedingung im Schnitt.
- Beim manuellen Verschieben eines Smart-Objekts wird der semantische View-Link gelöst; ein neuer echter Snap kann ihn neu anlegen.
- Die in 0.6.2 ergänzte automatische Mehrfachauswahl-/Gruppen-Snap-Verknüpfung wurde entfernt.
- Die bestehende Edge-Follower-Logik aus 0.6.1 bleibt erhalten.
