# Baudetail 0.6.7 – Draufsicht/Snap/Bauwerke Hotfix

- Schnitt→Draufsicht-Verknüpfung korrigiert: eine Längsschnitt-Beziehung zur Treppe wird im Plan entlang der Treppenlaufrichtung projiziert; angeschlossene Querschnittsbauteile liegen quer zur Treppe an der gespeicherten Station.
- Abschnitts-Verknüpfungen zwischen Borden/Rinnen/Kästen verwenden eine deterministische gemeinsame Längsstation statt zufälliger alter Plan-Koordinaten.
- Verknüpfte Objekte werden bereits beim Öffnen des Projekts synchronisiert, damit bestehende falsche Draufsichten repariert werden.
- Bord-Snap ist beim Verschieben 1,9× magnetischer.
- Eigene Bauwerke werden zusätzlich als einzelne portable `.bdlib`-Dateien im Unterordner `Bauwerke` der gewählten externen Bibliothek gespeichert. Vorhandene eigene Bauwerksvorlagen werden beim Start/Ordnerwechsel dorthin synchronisiert.
- Einlaufkasten-Autobeschriftung: nur `Einlaufkasten`; interne Rostbezeichnung wird nicht als Zeichnungstext ausgegeben.
- Einstellungsanzeige zeigt Version 0.6.7.
