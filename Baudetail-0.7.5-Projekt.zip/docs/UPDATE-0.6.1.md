# Baudetail 0.6.1

- Bord-/Leistenstein-Snap ist bidirektional: reale OK-, Phasen- und Kantenpunkte sind auch beim bewegten Bord Quell-Snaps.
- Reale Phasenkontur liefert zusätzlich Kantenmittelpunkte als physische Fangpunkte.
- Gruppierte Objekte behalten beim Verschieben die echten Snap-Punkte ihrer Kindobjekte.
- Gruppen verwenden keine Bounding-Box als Snap-Geometrie; eine gemeinsame Fangkorrektur hält die interne Lage unverändert.
- Interne Maße werden beim Gruppen-Snap nicht als Quellpunkte verwendet.
- versionCode 25, versionName 0.6.1.
