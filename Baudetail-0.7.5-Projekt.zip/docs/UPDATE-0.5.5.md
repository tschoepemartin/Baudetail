# Baudetail 0.5.5

Gezielter Korrekturstand auf Basis 0.5.4.

- Eigene Bauwerke speichern Schnitt- und Draufsicht-Posen gemeinsam und setzen sie beim erneuten Platzieren relativ zum Bauwerksursprung wieder zusammen.
- Navigation: Zeichnung → Projektübersicht → Hauptmenü ohne Rücksprung in die vorige Zeichnung.
- Maßprofile markieren den aktiven Zustand zuverlässig; „Aus“ blendet automatische Maße sofort aus. Manuell verschobene Maß-Offsets bleiben beim Aus-/Einschalten erhalten.
- Maßtexte werden mittig zur Maßstrecke und außerhalb der Pfeil-/Maßlinie platziert.
- Automatische Maße von eigenen Bauwerken verwenden die fachlichen Maße des enthaltenen Hauptbauteils statt Gruppen-Bounds.
- Einlaufkasten: Minimal = Kastenbreite/-höhe; Ausführung ergänzt Rohr-DN und Rohrachse ab OK. DN-Hilfslinien greifen exakt die Außenkanten des Rohrauslasses.
- versionCode 18, versionName 0.5.5.
