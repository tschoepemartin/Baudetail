# Baudetail 0.6.13

Build-Fix für die 0.6.12-Regressionsprüfungen.

- Testquellen verwenden die bereits vorhandene JUnit-4-Abhängigkeit statt der nicht eingebundenen `kotlin.test`-API.
- Der KG2000-Bogen-Test wurde in eine parserrobuste mehrzeilige Form gebracht.
- Die in 0.6.12 eingeführten Geometrie-/Sichtbarkeitskorrekturen bleiben unverändert erhalten.
- `preBuild` bleibt an `:drawing-core:test` gekoppelt: eine APK wird nur erzeugt, wenn die Core-Regressionstests erfolgreich sind.
