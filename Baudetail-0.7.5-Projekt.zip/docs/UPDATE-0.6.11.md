# Baudetail 0.6.11

Fokus: maßstabstreue Druckpositionierung und reale Treppen-Snapgeometrie.

- Druck-/Exportbereich verwendet einen festen Weltanker unten links. Papierformatwechsel verschieben die Zeichnung nicht.
- Die Zeichnung kann in der Druckvorschau per Drag verschoben werden; dabei wird ausschließlich die Translation geändert, niemals der Maßstab.
- „Position zurücksetzen“ setzt die Zeichnung wieder an den unteren linken Standardanker.
- PDF wird wieder vektoriell ausgegeben. Plankopf, Fußzeilen und Beschriftungen werden als echte PDF-Texte statt als gerasterte Seitengrafik erzeugt.
- PNG und SVG verwenden dieselbe Drucktransformation wie Vorschau/PDF.
- Treppen mit Stufengefälle verwenden im Schnitt für Kanten-Snapping die tatsächlich geneigten sichtbaren Stufenrechtecke statt der ursprünglichen Bounding-Box.
- Bestehende spezielle Snap-Punkte (u. a. Bordsteinphase 3 × 4 mm) bleiben unverändert.
- versionCode 35, versionName 0.6.11.
