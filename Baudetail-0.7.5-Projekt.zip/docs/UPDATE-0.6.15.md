# Baudetail 0.6.15

Gezielte Korrektur der letzten beiden Snap-Regressionen aus dem 0.6.14-Testlauf.

- Die 3×4-mm-Fase bleibt ausschließlich sichtbare/reale Geometrie im Schnitt.
- Die Fase wird in der Draufsicht nicht künstlich dargestellt.
- Reale Fasen-Kanten im Schnitt liefern wieder einen gültigen Bauteil-Kantenanker.
- Semantische `cross:`-Referenzen werden beim Wechsel Schnitt → Draufsicht wieder aufgelöst. Dadurch kann die zugehörige Seiten-/Höhenkotenreferenz in der Draufsicht korrekt positioniert werden, ohne dort die Fase darzustellen.
- Bestehendes Test-Gate bleibt aktiv.
