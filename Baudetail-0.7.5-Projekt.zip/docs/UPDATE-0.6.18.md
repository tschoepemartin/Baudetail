# Baudetail 0.6.18

- Pflasteraufbau besitzt im Objektmenü einen zentralen Punkt **„Pflasteraufbau anpassen“**.
- Das Dialogfenster bearbeitet Schichtnamen, Dicken, Körnungen sowie Steinformat, Fuge, Verband, Versatz, Ausrichtung und Darstellungsbreite gemeinsam.
- Bestehende `stack`-Objekte erhalten dieselbe Bearbeitung; keine Neuerstellung erforderlich.
- Pflasteraufbau rendert in jeder Nicht-Schnitt-Ansicht als Draufsicht mit Verlegemuster. Nur die Schnittansicht zeigt den Schichtaufbau.
- Regressionstests sichern Draufsicht, Legacy-Planansicht und Schnittdarstellung getrennt ab.
