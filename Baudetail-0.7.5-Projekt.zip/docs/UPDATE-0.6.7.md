# Baudetail 0.6.7

- Echte GaLaBau-Grundbibliothek v11 als einzige mitgelieferte Standardbibliothek.
- Alte generische KG/KG2000-DN-Bibliothekseinträge entfernt; eigene parametrische Rohrlogik bleibt erhalten.
- Rinnen auf Fassadenrinne, Kastenrinne und Schlitzrinne konsolidiert, jeweils mit Belastungsklasse, Rost/Abdeckung und freien Abmessungen.
- Bord 8/25/100 in der Grundbibliothek vorhanden.
- Bord-Snap neu getrennt von der sichtbaren Phase: rechteckige Anlagekante, Snap auf OK Bord und unteren Phasen-Höhenpunkt; die schräge Phase ist nur Darstellung.
- Beim Snappen an Borde wird die sichtbare Quellkante gegenüber einem bloßen Eckpunkt bevorzugt, damit angrenzende Bauteile nicht in den Bord hinein springen.
- Schnitt -> Draufsicht: Flächenbezug wird als Seite plus Längsende übertragen, damit angrenzende Leistensteine/Borde in der Draufsicht neben dem Zielobjekt am passenden Ende landen.
- Treppenbeschriftung UNTEN/OBEN kleiner und auf der Treppe näher am Pfeil.
- Automatische Maße unverändert.
