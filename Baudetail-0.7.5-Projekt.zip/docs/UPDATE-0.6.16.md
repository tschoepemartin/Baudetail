# Baudetail 0.6.16

- Kastenrinnen haben standardmäßig keinen Rohranschluss. Anschluss optional: keiner, links, rechts, unten.
- Sichtbarkeit in Draufsicht und Schnitt ist pro Objekt direkt im Objektmenü schaltbar.
- Legenden erhalten eine echte Hit-Fläche, sind nach dem Einfügen auswähl- und verschiebbar und Legendentexte können direkt im Plan inline bearbeitet werden.
- Verschiebe-Snapping nutzt bei normalen Flächen/Objekten nicht nur den Einfügepunkt, sondern sichtbare Eck-/Randreferenzen; dadurch funktioniert Annäherung von links/rechts/oben/unten.
- Höhenkoten trennen Marker- und Textposition: Marker verschiebt die gesamte Kote; der Text kann separat verschoben werden.
- Relative Höhen werden in der ursprünglichen Mess-/Ankeransicht berechnet. Ein Wechsel in die Draufsicht oder eine reine 2D-Verschiebung verändert den Höhenwert nicht.
- Neue Regressionstests sichern Rohranschluss-Standard, unteren Anschluss, ansichtsunabhängige Höhenwerte und getrennte Höhenkoten-Textversätze.
