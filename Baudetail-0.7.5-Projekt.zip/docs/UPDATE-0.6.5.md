# Baudetail 0.6.5

## Snap-Regressionen
- Schnitt -> Draufsicht überträgt bei normalen Bauteilen nur noch die laterale Querschnittsbeziehung; die Längsstation in der Draufsicht bleibt unverändert.
- Bord-/Leistensteine verwenden beim Ziehen ausschließlich ihre echte Kontur inklusive Phase; der nicht vorhandene rechte obere Rechteckpunkt ist kein Drag-Snap mehr.
- Beim Ziehen werden echte Quellkanten berücksichtigt. Ein Phasen-Endpunkt kann dadurch auf einer Bauteilkante einrasten, ohne das Bauteil entlang der Kante zu verschieben.
- Sinkkasten und Bordstein funktionieren damit in beiden Snap-Richtungen als Quelle und Ziel.
