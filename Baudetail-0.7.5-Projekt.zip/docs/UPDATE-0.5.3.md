# Baudetail 0.5.3

Gezielter KG2000- und Navigationspatch auf Basis 0.5.2.

- KG2000-Snap nutzt die tatsächlichen sichtbaren Anschlussachsen von Rohr, Reduzierung, Zwischenstück und Bogen.
- Normales KG2000-Rohr: Connectoren liegen auf der gezeichneten Rohrachse (DN/2), nicht auf der oberen Kante.
- Belegte KG2000-Connectoren werden beim Anschluss-Snap ignoriert; der nächstgelegene freie kompatible Anschluss gewinnt.
- Reduzierung: große Seite Spitzende, kleine Seite Muffe; exzentrische Achslage bleibt erhalten.
- Bögen werden als gekrümmtes KG2000-Rohr mit Muffe und Spitzende gerendert.
- Schnitt-Bogen: Weiterführung oben, unten, rechts oder links auswählbar.
- Bogen-Hitbox umfasst die komplette gezeichnete Bogenkontur.
- Zurück-Pfeil in der Zeichnung speichert und springt direkt zur Projektübersicht. Android-System-Zurück macht dasselbe, sofern kein unvollständiger Zeichenbefehl offen ist.
- versionCode 16, versionName 0.5.3.
