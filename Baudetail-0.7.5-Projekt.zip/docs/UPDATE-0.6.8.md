# Baudetail 0.6.8

Gezielter Korrekturstand auf Basis 0.6.7.

- Draufsicht aus Schnittbeziehungen neu geordnet: Seitenkontakte bleiben Seitenkontakte, die Reihenfolge Bord → Kasten → Bord → Treppe bleibt erhalten.
- KG2000-Rohranschlüsse am Einlauf-/Sinkkasten werden in der Draufsicht über echte Connectoren ausgerichtet; Standardauslauf links führt rechtwinklig aus der Kastenmitte nach links.
- Bord-Snap deutlich magnetischer (2,8× Smart-Snap-Toleranz).
- Treppenbeschriftung UNTEN/OBEN kleiner und vollständig innerhalb des Treppenumrisses.
- Parametrische Treppe ist als portabler Bauwerks-Deskriptor Bestandteil des Ordners `Bauwerke` statt nur als hart codierter Menüpunkt.
- Eigene Bauwerke bleiben einzelne `.bdlib`-Dateien im Ordner `Bauwerke`.
- Eingefügte Bauwerke können mit „Bauwerk auflösen“ wieder in intelligente Einzelkomponenten zerlegt werden; deren echte Snappunkte und Verknüpfungen bleiben erhalten.
- Einlaufkasten-Beschriftung bleibt kurz; dekorative Gitterrost-Beschriftung bleibt entfernt.
- versionCode 32, versionName 0.6.8.
