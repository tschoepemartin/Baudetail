# Baudetail 0.5.7

Gezielter Korrekturstand auf Basis 0.5.6.

- Maßprofil neuer Bauteile: intern und im Dialog standardmäßig **Aus**; Häkchen zeigt immer den gespeicherten Zustand.
- Maßtextlayout: horizontale Maßzahlen werden wirklich mittig unter/über der Maßlinie gesetzt; vertikale Maßzahlen liegen näher an der Maßlinie.
- Automatische Maße lassen sich frei zweidimensional verschieben. Nahe horizontal/vertikal rastet der Drag weich ein; deutliche diagonale Bewegung bleibt möglich.
- Manuelle Maßposition wird direkt als `dimDx`/`dimDy` gespeichert und bleibt bei Rebuild, Profilwechsel und erneutem Öffnen erhalten.
- Einlauf-/Sinkkasten: optische Oberkante und geometrische Oberkante/Snap-Ebene sind identisch; 21-mm-Zarge liegt innerhalb der 610-mm-Gesamthöhe.
- KG2000-Visualisierung: Muffenkragen liegt innerhalb der semantischen Baulänge; Reduziermuffe überschreitet den Connector nicht mehr. Geometrie bleibt auf echte mm bezogen.
- Externe Grundbibliothek v9: 433 Einträge geprüft, 290 Komponenten/807 View-Ressourcen validiert. KG/KG2000 enthält ausschließlich die fünf parametrischen Rohrlogik-Objekte.
- versionCode 20, versionName 0.5.7.
