# Baudetail 0.6.17

- Pflasteraufbauten: Name, Dicke und Körnung jeder Schicht bearbeitbar.
- Schnitt: Pflasterfugen sowie körnungsabhängige technische Darstellung von Bettung und Tragschichten.
- Draufsicht: Pflaster statt Schichtquerschnitt; Steinformat, Fuge, Ausrichtung und Kreuzfuge/Reihenverband 1/2, 1/3, 1/4 bzw. freier Versatz einstellbar.
- Fassaden-/Kastenrinnen: Abdeckungen Stabgitter, Gitterrost, Längsstäbe, Stegrost und Schlitz werden in der Draufsicht optisch unterschiedlich dargestellt.
