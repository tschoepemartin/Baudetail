# Baudetail 0.6.4

## Snap-Korrekturen
- Schnitt -> Draufsicht verwendet für semantische Punkt-Snaps jetzt die Längsstation des Anschlusses statt die vertikale Schnittkoordinate als seitliche Plan-Koordinate zu missbrauchen.
- Die Gegenansicht wird dadurch auf der korrespondierenden Längsstation und Plan-Mittellinie ausgerichtet.
- Bordsteine liefern ihre reale Kontur inklusive Phase als Snap-Outline.
- Die historische Reihenfolge der Bord-Snapreferenzen (4 Ecken, Zentrum, 4 Kantenmitten) bleibt für Edge-Follower erhalten; Phasenpunkte und Phasen-Kantenmitten werden zusätzlich angehängt.
- Bord/Phase kann damit wieder sowohl Snap-Ziel als auch bewegte Snap-Quelle sein.
- Freies Verschieben im Schnitt und die 0.6.3-Entkopplung von automatischer Gruppenverschiebung bleiben unverändert.
- versionCode 28, versionName 0.6.4.
