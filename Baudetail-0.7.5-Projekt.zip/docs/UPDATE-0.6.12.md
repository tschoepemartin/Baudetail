# Baudetail 0.6.12

Regression-/Stabilitätsstand auf Basis 0.6.11.

- Unterirdische Rohrkomponenten werden beim Einfügen dem Level `Leitungen` zugeordnet und sind damit im Oberflächenplan standardmäßig ausgeblendet.
- In Draufsichten werden eingeblendete Rohrleitungen gestrichelt dargestellt.
- KG2000, Rasen und Sinkkästen erhalten keine pauschale 90°-Draufsichtsdrehung mehr; ihre parametrierte Geometrie bestimmt die Orientierung.
- Regressionstests sichern den linken Sinkkastenanschluss, die Leitungs-Sichtbarkeit und die Standardorientierung von Rasen/KG2000.
- APK-Builds sind an die drawing-core Regressionstests gekoppelt; ein fehlschlagender Geometrietest stoppt `assembleDebug` bereits vor dem APK-Build.
