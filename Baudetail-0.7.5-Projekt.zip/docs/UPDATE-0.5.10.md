# Baudetail 0.5.10

Gezielter Transformations-/Renderer-Patch auf Basis 0.5.9.

- Spiegeln hält Einzelobjekte in der aktiven Ansicht auf derselben sichtbaren Position.
- Nach Spiegelung werden sichtbare Bounds/Hitbox/Snap-Geometrie aus dem transformierten Objekt neu abgeleitet.
- Mehrfachauswahl spiegelt weiter um das gemeinsame Zentrum, mit anschließender Bounds-Korrektur.
- Bord-/Leistenstein-Renderer nutzt dieselbe reale mm-Außenkontur wie Hitbox und Snap.
- Phase 3 x 4 mm bleibt echte Geometrie; OK-Snap und Phasen-Snap bleiben getrennt erhalten.
- Optische Kontur wird innerhalb der physikalischen Bordkontur gezeichnet, sodass sichtbare OK und Snap-OK nicht auseinanderlaufen.
- versionCode 23, versionName 0.5.10.
