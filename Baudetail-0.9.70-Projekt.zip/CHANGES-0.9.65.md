# BauDetail 0.9.65

- Leistenstein-Inspector: Reihe aktivieren, Gesamtlänge in mm, Länge übernehmen.
- Ein einziges Bauteil mit Gesamtkontur, sichtbaren Steinstößen in Draufsicht und optionalem zugeschnittenem Endstein.
- Schnittdarstellung unverändert; alte Objekte ohne Reihenmodus bleiben unverändert.
- GitHub-Build und Gerätetest noch offen.
