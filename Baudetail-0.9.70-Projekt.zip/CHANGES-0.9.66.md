# BauDetail 0.9.66

- Build-Fix: Leistenstein-Reihensteuerung aus der zu großen Compose-Methode `Inspector` in `LeistensteinRowControls` ausgelagert.
- Funktionalität der Leistenstein-Reihe unverändert.
- Behebt die im GitHub-Build #240 gemeldete `MethodTooLargeException` in `InspectorKt.Inspector`.
- Build muss noch über GitHub Actions bestätigt werden.
