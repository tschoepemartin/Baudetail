# BauDetail 0.9.70

Fix: Fehlenden Import de.baudetail.geometry.parseNumber in CurbSettingsDialog.kt ergänzt. Fehler aus GitHub Actions #243. Keine weiteren Funktionsänderungen.
