package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.parseNumber
import de.baudetail.ui.*

/** Separate curb editor: does not add bytecode to the main Inspector method. */
@Composable
internal fun CurbSettingsDialog(e:Entity,onDismiss:()->Unit,onSave:(Entity)->Unit){
 val row=e.str("curbRowEnabled","false")=="true"
 var enabled by remember(e.id){mutableStateOf(row)}
 var kind by remember(e.id){mutableStateOf(e.str("curbType",e.name))}
 var material by remember(e.id){mutableStateOf(e.str("curbMaterial","Beton"))}
 var length by remember(e.id){mutableStateOf(fmt(e.num("curbSingleLengthMm",if(row)e.num("topWidthMm",1000.0).coerceAtMost(1000.0) else e.num("topWidthMm",1000.0))))}
 var width by remember(e.id){mutableStateOf(fmt(e.num("topHeightMm",e.num("heightMm",100.0))))}
 var thickness by remember(e.id){mutableStateOf(fmt(e.num("sectionHeightMm",e.num("heightMm",200.0))))}
 var sectionWidth by remember(e.id){mutableStateOf(fmt(e.num("sectionWidthMm",e.num("widthMm",100.0))))}
 var chamfer by remember(e.id){mutableStateOf(e.str("withoutChamfer","false")!="true")}
 var chamferW by remember(e.id){mutableStateOf(fmt(e.num("chamferWidthMm",3.0)))}
 var chamferD by remember(e.id){mutableStateOf(fmt(e.num("chamferDepthMm",4.0)))}
 var total by remember(e.id){mutableStateOf(fmt(e.num("curbRowLengthMm",e.num("topWidthMm",1000.0))))}
 var startCut by remember(e.id){mutableStateOf(fmt(e.num("curbStartCutMm",0.0)))}
 var endCut by remember(e.id){mutableStateOf(fmt(e.num("curbEndCutMm",0.0)))}
 fun positive(v:String)=parseNumber(v)?.takeIf{it.isFinite()&&it>0.0}
 val valid=positive(length)!=null&&positive(width)!=null&&positive(thickness)!=null&&positive(sectionWidth)!=null&&(!enabled||((positive(total)?:0.0)>=(positive(length)?:Double.MAX_VALUE)))
 AlertDialog(onDismissRequest=onDismiss,title={Text("Bordstein / Leistenstein anpassen")},text={
  Column(Modifier.fillMaxWidth().heightIn(max=580.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
   OutlinedTextField(kind,{kind=it},label={Text("Steinart / Sorte")},singleLine=true)
   OutlinedTextField(material,{material=it},label={Text("Material")},singleLine=true)
   OutlinedTextField(length,{length=it},label={Text("Steinlänge (mm)")},singleLine=true)
   OutlinedTextField(width,{width=it},label={Text("Breite Draufsicht (mm)")},singleLine=true)
   OutlinedTextField(sectionWidth,{sectionWidth=it},label={Text("Breite Schnitt (mm)")},singleLine=true)
   OutlinedTextField(thickness,{thickness=it},label={Text("Höhe / Dicke Schnitt (mm)")},singleLine=true)
   Row{Checkbox(chamfer,{chamfer=it});Text("Mit Phase",Modifier.padding(top=12.dp))}
   OutlinedTextField(chamferW,{chamferW=it},label={Text("Fasenbreite (mm)")},enabled=chamfer,singleLine=true)
   OutlinedTextField(chamferD,{chamferD=it},label={Text("Fasentiefe (mm)")},enabled=chamfer,singleLine=true)
   HorizontalDivider()
   Row{Checkbox(enabled,{enabled=it});Text("Reihe aktivieren",Modifier.padding(top=12.dp))}
   OutlinedTextField(total,{total=it},label={Text("Gesamtlänge Reihe (mm)")},enabled=enabled,singleLine=true)
   OutlinedTextField(startCut,{startCut=it},label={Text("Schrägschnitt Anfang (mm)")},enabled=enabled,singleLine=true)
   OutlinedTextField(endCut,{endCut=it},label={Text("Schrägschnitt Ende (mm)")},enabled=enabled,singleLine=true)
   Text("Schrägschnitte: Versatz der äußeren Ecke in Längsrichtung. Endkanten lassen sich auch mit Bearbeiten verschieben.")
  }
 },confirmButton={TextButton(onClick={
  val l=positive(length)?:return@TextButton
  val t=if(enabled)positive(total)?:return@TextButton else l
  var out=e.withStr("curbType",kind).withStr("curbMaterial",material).withStr("withoutChamfer",(!chamfer).toString())
   .withStr("curbRowEnabled",enabled.toString()).withNum("curbSingleLengthMm",l)
   .withNum("curbRowLengthMm",t).withNum("topWidthMm",t).withNum("topHeightMm",positive(width)?:100.0)
   .withNum("sectionWidthMm",positive(sectionWidth)?:100.0).withNum("sectionHeightMm",positive(thickness)?:200.0)
   .withNum("chamferWidthMm",(parseNumber(chamferW)?:3.0).coerceAtLeast(0.0))
   .withNum("chamferDepthMm",(parseNumber(chamferD)?:4.0).coerceAtLeast(0.0))
   .withNum("curbStartCutMm",if(enabled)parseNumber(startCut)?:0.0 else 0.0)
   .withNum("curbEndCutMm",if(enabled)parseNumber(endCut)?:0.0 else 0.0)
  onSave(out)
 },enabled=valid){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
