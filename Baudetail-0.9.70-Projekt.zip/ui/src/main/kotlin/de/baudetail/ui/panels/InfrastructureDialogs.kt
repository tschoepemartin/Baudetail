package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

@Composable
internal fun InfrastructureDialogs(dialog:String,e:Entity,vm:BaudetailViewModel,setDialog:(String)->Unit,onAddCut:(String)->Unit){
 val d=vm.drawing?:return
 when(dialog){
 "foundationSettings"->{val f=foundationFor(e,d);if(f!=null){val sb=viewBounds(e,d);val fields=mutableListOf(Field("type","Ausführung",if(f.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil",choices=listOf("Fundament mit Keil","Fundament ohne Keil")),Field("width","Breite cm",fmt(f.num("foundationWidthMm",sb.width+200.0)/10.0),true,true),Field("thickness",if(isStair(e))"Dicke unter VK Stufe cm" else "Dicke ab Unterkante cm",fmt(f.num("thicknessMm",200.0)/10.0),true,true),Field("embedMode","Einbindung",if(f.str("embedMode","auto")=="manual")"manuell" else "automatisch 1/3",choices=listOf("automatisch 1/3","manuell")),Field("embed","Einbindung cm (bei manuell)",fmt(f.num("embedMm",sb.height/3.0)/10.0),true),Field("side","Keilseite",when(f.str("wedgeSide","both")){"left"->"links";"right"->"rechts";else->"beidseitig"},choices=listOf("beidseitig","links","rechts")));if(isStair(e))fields.add(1,Field("stairExecution","Treppenfundament",if(f.str("stairFoundationExecution","separate")=="sloped")"schräg" else "getrennt",choices=listOf("schräg","getrennt")));FormDialog("Unterfundament",fields,{setDialog("")}){v->val type=if(v["type"].orEmpty().contains("mit Keil"))"with_wedge" else "without_wedge";val mode=if(v["embedMode"]=="manuell")"manual" else "auto";val side=when(v["side"]){"links"->"left";"rechts"->"right";else->"both"};val stairExecution=if(v["stairExecution"]=="getrennt")"separate" else "sloped";vm.updateFoundation(e,parseNumber(v["thickness"]!!)!!*10.0,parseNumber(v["width"]!!)!!*10.0,type,mode,parseNumber(v["embed"]!!)!!*10.0,side,stairExecution)}}}
 "foundationObjectSettings"->{val source=d.entities.find{it.id==e.str("sourceId")};val sb=source?.let{viewBounds(it,d)}?:viewBounds(e,d);val fields=mutableListOf(Field("type","Ausführung",if(e.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil",choices=listOf("Fundament mit Keil","Fundament ohne Keil")),Field("width","Breite cm",fmt(e.num("foundationWidthMm",sb.width+200.0)/10.0),true,true),Field("thickness",if(source?.let(::isStair)==true)"Dicke unter VK Stufe cm" else "Dicke ab Unterkante cm",fmt(e.num("thicknessMm",200.0)/10.0),true,true),Field("embedMode","Einbindung",if(e.str("embedMode","auto")=="manual")"manuell" else "automatisch 1/3",choices=listOf("automatisch 1/3","manuell")),Field("embed","Einbindung cm (bei manuell)",fmt(e.num("embedMm",sb.height/3.0)/10.0),true),Field("side","Keilseite",when(e.str("wedgeSide","both")){"left"->"links";"right"->"rechts";else->"beidseitig"},choices=listOf("beidseitig","links","rechts")));if(source?.let(::isStair)==true)fields.add(1,Field("stairExecution","Treppenfundament",if(e.str("stairFoundationExecution","separate")=="sloped")"schräg" else "getrennt",choices=listOf("schräg","getrennt")));FormDialog("Unterfundament",fields,{setDialog("")}){v->val type=if(v["type"].orEmpty().contains("mit Keil"))"with_wedge" else "without_wedge";val mode=if(v["embedMode"]=="manuell")"manual" else "auto";val side=when(v["side"]){"links"->"left";"rechts"->"right";else->"both"};val stairExecution=if(v["stairExecution"]=="getrennt")"separate" else "sloped";vm.update(e.withNum("thicknessMm",parseNumber(v["thickness"]!!)!!*10.0).withNum("foundationWidthMm",parseNumber(v["width"]!!)!!*10.0).withStr("foundationType",type).withStr("wedgeEnabled",(type=="with_wedge").toString()).withStr("embedMode",mode).withNum("embedMm",parseNumber(v["embed"]!!)!!*10.0).withStr("wedgeSide",side).withStr("stairFoundationExecution",stairExecution))}}
 "textEdit"->FormDialog("Text bearbeiten",listOf(Field("text","Text",e.text)),{setDialog("")}){v->vm.update(e.copy(text=v["text"].orEmpty()))}
 "fillMaterial"->{val materials=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material"}.distinctBy{it.id}.sortedBy{it.name};val labels=listOf("Keine Füllung")+materials.map{it.name};val selected=if(e.materialId==null)0 else materials.indexOfFirst{it.id==e.materialId}.let{if(it<0)null else it+1};ChoiceDialog("Füllung / Material",labels,{setDialog("")},selectedIndex=selected){i->if(i==0)vm.update(e.copy(materialId=null,materialSnapshot=null))else{val m=materials[i-1];vm.attachLibraryForPlacedVariant(m);vm.update(e.copy(materialId=m.id,materialSnapshot=null,quantityUnit=e.quantityUnit?:"m²"))}}}
 "fillSettings"->FormDialog("Füllungsdarstellung",listOf(Field("mode","Draufsicht",when(e.str("fillMode","auto")){"area"->"flächig";"vertical"->"senkrecht";else->"auto"},choices=listOf("auto","flächig","senkrecht")),Field("top","In Draufsicht sichtbar",if(e.placement.visibleTop)"ja"else"nein",checkbox=true),Field("section","Im Schnitt sichtbar",if(e.placement.visibleSection)"ja"else"nein",checkbox=true)),{setDialog("")}){v->val mode=when(v["mode"].orEmpty().lowercase()){"flächig","flaechig","area"->"area";"senkrecht","vertical"->"vertical";else->"auto"};vm.update(e.withStr("fillMode",mode).copy(placement=e.placement.copy(visibleTop=v["top"]!="nein",visibleSection=v["section"]!="nein")))}
 "pipe"->FormDialog("Rohr-/Leitungsorientierung",listOf(Field("orientation","Orientierung",if(e.str("orientation","horizontal")=="vertical")"vertikal"else"horizontal",choices=listOf("horizontal","vertikal")),Field("direction","Bei vertikal",if(e.str("verticalDirection","down")=="up")"oben"else"unten",choices=listOf("unten","oben")),Field("length","Vertikale dargestellte Länge mm",fmt(e.num("verticalLengthMm",1000.0)),true,true)),{setDialog("")}){v->vm.update(e.withStr("orientation",if(v["orientation"].orEmpty().startsWith("v",true))"vertical"else"horizontal").withStr("verticalDirection",if(v["direction"].orEmpty().startsWith("o",true))"up"else"down").withNum("verticalLengthMm",parseNumber(v["length"]!!)!!))}
 "planter"->{
  val manufacturerEntries=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material" && it.extensions.containsKey("baudetailManufacturer")}.distinctBy{it.id}
  fun manufacturerMeta(entry:de.baudetail.core.LibraryEntry):JsonObject?=entry.extensions["baudetailManufacturer"] as? JsonObject
  fun metaValue(entry:de.baudetail.core.LibraryEntry,key:String)=(manufacturerMeta(entry)?.get(key) as? JsonPrimitive)?.contentOrNull.orEmpty()
  val byManufacturer=manufacturerEntries.groupBy{metaValue(it,"manufacturer")}.filterKeys{it.isNotBlank()}
  val manufacturerNames=listOf("Ohne Hersteller")+byManufacturer.keys.sorted()
  val seriesByManufacturer=byManufacturer.mapValues{(_,items)->items.map{metaValue(it,"product")}.filter{it.isNotBlank()}.distinct().sorted()}
  val colorBySeries=manufacturerEntries.groupBy{metaValue(it,"manufacturer")+"|"+metaValue(it,"product")}.mapValues{(_,items)->items.map{listOf(metaValue(it,"color"),metaValue(it,"surface")).filter{v->v.isNotBlank()}.joinToString(" · ")}.distinct().sorted()}
  val chosenManufacturer=e.str("planterManufacturer","Ohne Hersteller").takeIf{it in manufacturerNames}?:"Ohne Hersteller"
  val chosenSeries=e.str("planterSeries").takeIf{it in seriesByManufacturer[chosenManufacturer].orEmpty()}?:seriesByManufacturer[chosenManufacturer].orEmpty().firstOrNull().orEmpty()
  val chosenVariant=e.str("planterVariant").takeIf{it in colorBySeries[chosenManufacturer+"|"+chosenSeries].orEmpty()}?:colorBySeries[chosenManufacturer+"|"+chosenSeries].orEmpty().firstOrNull().orEmpty()
  FormDialog("Pflanztrog einstellen",listOf(
  Field("shape","Form",e.str("planterShape","Rechteckig"),choices=listOf("Rechteckig","Quadratisch","Rund")),
  Field("width","Breite mm (rechteckig/quadratisch)",fmt(e.num("planterWidthMm",1200.0)),true,true),
  Field("depth","Tiefe mm (rechteckig)",fmt(e.num("planterDepthMm",500.0)),true,true),
  Field("diameter","Durchmesser mm (rund)",fmt(e.num("planterDiameterMm",500.0)),true,true),
  Field("height","Höhe mm",fmt(e.num("planterHeightMm",600.0)),true,true),
  Field("wall","Wandstärke mm",fmt(e.num("planterWallMm",5.0)),true,true),
  Field("material","Material",e.str("planterMaterial","Cortenstahl"),choices=listOf("Cortenstahl","Beton","Holz","Stahl","Aluminium","Mauersteine")),
  Field("stoneType","Mauerstein",e.str("planterStoneType","Betonmauerstein"),choices=listOf("Betonmauerstein","Naturmauerstein","Klinker"),visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("manufacturer","Hersteller",chosenManufacturer,choices=manufacturerNames,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("series","Steinart / Produktserie",chosenSeries,choices=seriesByManufacturer.values.flatten().distinct().ifEmpty{listOf("Keine Serien vorhanden")},visibleChoiceKey="material",visibleChoiceValue="Mauersteine",choiceDependsOn="manufacturer",choiceMap=seriesByManufacturer),
  Field("variant","Farbe / Oberfläche (Hersteller)",chosenVariant,choices=colorBySeries.values.flatten().distinct().ifEmpty{listOf("Keine Varianten vorhanden")},visibleChoiceKey="material",visibleChoiceValue="Mauersteine",choiceDependsOn="series",choiceMap=manufacturerEntries.groupBy{metaValue(it,"product")}.mapValues{(_,items)->items.map{listOf(metaValue(it,"color"),metaValue(it,"surface")).filter{v->v.isNotBlank()}.joinToString(" · ")}.distinct().sorted()}),
  Field("stoneLength","Steinlänge mm",fmt(e.num("planterStoneLengthMm",400.0)),true,true,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("stoneHeight","Steinhöhe mm",fmt(e.num("planterStoneHeightMm",200.0)),true,true,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("stoneDepth","Steintiefe mm",fmt(e.num("planterStoneDepthMm",200.0)),true,true,visibleChoiceKey="material",visibleChoiceValue="Mauersteine"),
  Field("finish","Farbe / Oberfläche",e.str("planterFinish","Naturrost"),choices=listOf("Naturrost","Dunkelrost","Betongrau","Hellgrau","Anthrazit","Weiß","Lärche natur","Douglasie","Eiche","Braun lasiert","Anthrazit lasiert","Verzinkt","Silber","Schwarz"),visibleChoiceKey="material",visibleChoiceValue="Cortenstahl"),
  Field("ok","Oberkante / Höhenkote m",fmt(e.num("planterTopElevationMm",0.0)/1000.0),true),
  Field("fill","Substrat anzeigen",if(e.str("planterFill","true")=="true")"ja"else"nein",checkbox=true),
  Field("planting","Substrat mit Pflanzung anzeigen",if(e.str("planterPlanting","true")=="true")"ja"else"nein",checkbox=true)
 ),{setDialog("")}){v->
  val shape=v["shape"].orEmpty();val width=parseNumber(v["width"]!!)!!;val depth=parseNumber(v["depth"]!!)!!;val dia=parseNumber(v["diameter"]!!)!!;val height=parseNumber(v["height"]!!)!!;val wall=parseNumber(v["wall"]!!)!!
  val minDim=if(shape=="Rund")dia else minOf(width,if(shape=="Quadratisch")width else depth)
  require(width>0&&depth>0&&dia>0&&height>0&&wall>0&&wall*2<minOf(minDim,height)){"Ungültige Maße / Wandstärke"}
  val matching=manufacturerEntries.firstOrNull{v["material"]=="Mauersteine" && metaValue(it,"manufacturer")==v["manufacturer"] && metaValue(it,"product")==v["series"] && listOf(metaValue(it,"color"),metaValue(it,"surface")).filter{it.isNotBlank()}.joinToString(" · ")==v["variant"]}
  if(matching!=null)vm.attachLibraryForPlacedVariant(matching)
  vm.update(e.copy(materialId=matching?.id,materialSnapshot=null).withStr("planterManufacturer",if(v["material"]=="Mauersteine")v["manufacturer"].orEmpty() else "Ohne Hersteller").withStr("planterSeries",if(matching!=null)v["series"].orEmpty() else "").withStr("planterVariant",if(matching!=null)v["variant"].orEmpty() else "").withStr("planterManufacturerMaterialId",matching?.id.orEmpty()).withStr("planterShape",shape).withNum("planterWidthMm",width).withNum("planterDepthMm",if(shape=="Quadratisch")width else depth).withNum("planterDiameterMm",dia).withNum("planterHeightMm",height).withNum("planterWallMm",wall).withStr("planterMaterial",v["material"].orEmpty()).withStr("planterStoneType",v["stoneType"].orEmpty()).withNum("planterStoneLengthMm",parseNumber(v["stoneLength"].orEmpty())?:400.0).withNum("planterStoneHeightMm",parseNumber(v["stoneHeight"].orEmpty())?:200.0).withNum("planterStoneDepthMm",parseNumber(v["stoneDepth"].orEmpty())?:200.0).withStr("planterFinish",v["finish"].orEmpty()).withNum("planterTopElevationMm",parseNumber(v["ok"]!!)!!*1000.0).withStr("planterFill",(v["fill"]!="nein").toString()).withStr("planterPlanting",(v["planting"]!="nein").toString()))
 }
 }
 "lightwell"->FormDialog("Lichtschacht einstellen",listOf(
  Field("width","Breite mm",fmt(e.num("lightwellWidthMm",1000.0)),true,true),
  Field("depth","Tiefe mm",fmt(e.num("lightwellDepthMm",500.0)),true,true),
  Field("height","Höhe mm",fmt(e.num("lightwellHeightMm",1000.0)),true,true),
  Field("wall","Wandstärke mm",fmt(e.num("lightwellWallMm",80.0)),true,true),
  Field("cover","Abdeckung",e.str("lightwellCover","Gitterrost"),choices=listOf("Gitterrost","Längsstabrost","Gitter mit Insektenschutz")),
  Field("color","Farbe",e.str("lightwellColor","Silber"),choices=listOf("Edelstahl silber","Silber","Cortenstahl","Anthrazit","Grau","Schwarz")),
  Field("ok","Oberkante / Höhenkote m",fmt(e.num("lightwellTopElevationMm",0.0)/1000.0),true)
 ),{setDialog("")}){v->
  val w=parseNumber(v["width"]!!)!!;val depth=parseNumber(v["depth"]!!)!!;val h=parseNumber(v["height"]!!)!!;val wall=parseNumber(v["wall"]!!)!!
  require(w>0&&depth>0&&h>0&&wall>0&&wall*2<minOf(w,depth)) {"Ungültige Abmessungen / Wandstärke"}
  vm.update(e.withNum("lightwellWidthMm",w).withNum("lightwellDepthMm",depth).withNum("lightwellHeightMm",h).withNum("lightwellWallMm",wall).withStr("lightwellCover",v["cover"].orEmpty()).withStr("lightwellColor",v["color"].orEmpty()).withNum("lightwellTopElevationMm",parseNumber(v["ok"]!!)!!*1000.0))
 }
 "channelBox"->FormDialog("Rinne / Einlaufkasten",listOf(
  Field("type","Rinnentyp",when(e.str("channelType","box")){"facade"->"Fassadenrinne";"slot"->"Schlitzrinne";else->"Kastenrinne"},choices=listOf("Kastenrinne","Fassadenrinne","Schlitzrinne")),
  Field("class","Belastungsklasse",e.str("loadClass","B 125"),choices=listOf("A 15","B 125","C 250","D 400","E 600","F 900")),
  Field("grateType","Rost / Abdeckung",e.str("grateType",when(e.str("channelType","box")){"slot"->"Schlitz";"facade"->"Längsstab";else->"Gitterrost"}),choices=listOf("Stabgitter","Gitterrost","Längsstäbe","Stegrost","Schlitz")),
  Field("width","Kastenbreite cm",fmt(e.num("boxWidthMm",185.0)/10.0),true,true),
  Field("height","Kastenhöhe cm",fmt(e.num("boxHeightMm",610.0)/10.0),true,true),
  Field("length","Kastenlänge cm",fmt(e.num("boxLengthMm",500.0)/10.0),true,true),
  Field("nw","Rinnen-Nennweite cm",fmt(e.num("channelNominalWidthMm",150.0)/10.0),true,true),
  Field("outlet","Rohranschluss",when(e.str("pipeOutlet","none")){"left"->"links";"right"->"rechts";"bottom"->"unten";else->"keiner"},choices=listOf("keiner","links","rechts","unten")),
  Field("dn","Rohranschluss DN",("DN "+e.num("pipeDnMm",160.0).toInt()),choices=listOf("DN 110","DN 125","DN 160","DN 200","DN 250","DN 315","DN 400","DN 500","DN 630")),
  Field("axis","Rohrachse ab OK cm",fmt(e.num("pipeAxisFromTopMm",500.0)/10.0),true,true),
  Field("basket","Laubfangkorb",if(e.str("leafBasket","true")=="true")"ja"else"nein",checkbox=true),
  Field("grate","Rost sichtbar",if(e.str("grateVisible","true")=="true")"ja"else"nein",checkbox=true)
 ),{setDialog("")}){v->vm.update(e.withStr("channelType",when(v["type"]){"Fassadenrinne"->"facade";"Schlitzrinne"->"slot";else->"box"}).withStr("loadClass",v["class"].orEmpty().ifBlank{"B 125"}).withStr("grateType",v["grateType"].orEmpty().ifBlank{"Gitterrost"}).withNum("boxWidthMm",parseNumber(v["width"]!!)!!*10).withNum("boxHeightMm",parseNumber(v["height"]!!)!!*10).withNum("boxLengthMm",parseNumber(v["length"]!!)!!*10).withNum("channelNominalWidthMm",parseNumber(v["nw"]!!)!!*10).withStr("pipeOutlet",when(v["outlet"]){"links"->"left";"rechts"->"right";"unten"->"bottom";else->"none"}).withNum("pipeDnMm",v["dn"].orEmpty().filter{it.isDigit()}.toDoubleOrNull()?:160.0).withNum("pipeAxisFromTopMm",parseNumber(v["axis"]!!)!!*10).withStr("leafBasket",(v["basket"]!="nein").toString()).withStr("grateVisible",(v["grate"]!="nein").toString()))}
 "kg2000"->{
  val dns=listOf("DN 110","DN 125","DN 160","DN 200","DN 250","DN 315","DN 400","DN 500","DN 630")
  val type=e.str("fittingType","pipe")
  val fields=mutableListOf<Field>()
  if(type !in setOf("reducer","y"))fields.add(Field("dn","DN","DN "+e.num("dnMm",160.0).toInt(),choices=dns))
  fields.add(Field("length","Länge cm",fmt(e.num("pipeLengthMm",if(type=="double_spigot")500.0 else 1000.0)/10.0),true,true))
  fields.add(Field("slope","Gefälle %",fmt(e.num("slope",0.0)),true))
  fields.add(Field("flowDirection","Fließrichtung",if(e.str("flowDirection","forward")=="reverse")"rückwärts" else "vorwärts",choices=listOf("vorwärts","rückwärts")))
  fields.add(Field("flow","Fließrichtung anzeigen",if(e.str("flowArrow","true")=="true")"ja"else"nein",checkbox=true))
  if(type=="bend"){fields.add(Field("angle","Bogenwinkel",fmt(e.num("bendAngle",45.0))+"°",choices=kg2000BendAngles(e.num("dnMm",160.0).toInt()).map{fmt(it,1)+"°"}));if(d.viewMode()=="section"){val current=when(e.str("bendDirection",e.str("verticalDirection","down"))){"up","oben"->"oben";"left","links"->"links";"right","rechts"->"rechts";else->"unten"};fields.add(Field("bendDirection","Weiterführung im Schnitt",current,choices=listOf("oben","unten","rechts","links")))}}
  if(type=="y"){
   val pairs=kg2000Y45Pairs().map{"DN ${it.first} / DN ${it.second}"}
   fields.add(Field("pair","Y-Stück 45° (Haupt / Abzweig)","DN ${e.num("dnMm",160.0).toInt()} / DN ${e.num("branchDnMm",110.0).toInt()}",choices=pairs))
  }
  if(type=="reducer"){
   val pairs=kg2000ReducerPairs().map{"DN ${it.first} / DN ${it.second}"}
   fields.add(Field("pair","Reduzierung (groß / klein)","DN ${e.num("inletDnMm",160.0).toInt()} / DN ${e.num("outletDnMm",110.0).toInt()}",choices=pairs))
  }
  FormDialog("KG 2000",fields,{setDialog("")}){v->
   fun selectedDn(key:String,def:Double):Double=v[key].orEmpty().filter{ch->ch.isDigit()}.toDoubleOrNull()?:def
   var r=e.withNum("dnMm",if(type in setOf("reducer","y"))e.num("dnMm",160.0)else selectedDn("dn",160.0)).withNum("pipeLengthMm",parseNumber(v["length"]!!)!!*10).withNum("slope",parseNumber(v["slope"]!!)!!).withStr("flowArrow",(v["flow"]!="nein").toString()).withStr("flowDirection",if(v["flowDirection"]=="rückwärts")"reverse"else"forward")
   if(type=="bend"){r=r.withNum("bendAngle",v["angle"].orEmpty().replace(",",".").filter{ch->ch.isDigit()||ch=='.'}.toDoubleOrNull()?:45.0);if(d.viewMode()=="section"){val dir=when(v["bendDirection"]){"oben"->"up";"links"->"left";"rechts"->"right";else->"down"};r=r.withStr("bendDirection",dir).withStr("verticalDirection",if(dir=="up")"up"else"down")}}
   if(type=="y"){val nums=Regex("""\d+""").findAll(v["pair"].orEmpty()).map{it.value.toDouble()}.toList();if(nums.size>=2)r=r.withNum("dnMm",nums[0]).withNum("branchDnMm",nums[1])}
   if(type=="reducer"){val nums=Regex("""\d+""").findAll(v["pair"].orEmpty()).map{it.value.toDouble()}.toList();if(nums.size>=2){val official=kg2000ReducerLengthMm(nums[0].toInt(),nums[1].toInt());r=r.withNum("inletDnMm",nums[0]).withNum("outletDnMm",nums[1]).withNum("dnMm",nums[0]);if(official!=null)r=r.withNum("pipeLengthMm",official)}}
   vm.update(r)
  }
 }

 }
}

