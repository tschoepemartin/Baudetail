package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

@Composable
internal fun VegetationAndWallDialogs(dialog:String,e:Entity,vm:BaudetailViewModel,setDialog:(String)->Unit,onAddCut:(String)->Unit){
 val d=vm.drawing?:return
 when(dialog){
 "propertySettings"->PropertySettingsDialog(e,vm){setDialog("")}
 "plantBrunsPicker"->BrunsPlantPicker(onDismiss={setDialog("plantSettings")},onSelect={plant->vm.update(e.withStr("plantName",plant).copy(name=plant));setDialog("plantSettings")})
 "plantSettings"->PlantSettingsDialog(e,vm){setDialog("")}
 "brunsPicker"->BrunsPlantPicker(onDismiss={setDialog("")},onSelect={plant->vm.update(e.withStr("hedgePlant",plant));setDialog("")})
 "hedgeSettings"->{
  val bounds=Bounds.of(e.points)
  val currentLength=if(e.str("hedgeRectangle")=="true")bounds.width else if(e.points.size>=2)e.points.first().distance(e.points.last()) else bounds.width
  FormDialog("Hecke anpassen",listOf(
   Field("length","Länge m",fmt(currentLength/1000.0),true,true),
   Field("width","Breite m",fmt(if(e.str("hedgeRectangle")=="true")bounds.height/1000.0 else e.num("widthMm",600.0)/1000.0),true,true),
   Field("plant","Pflanze (botanischer/deutscher Name)",e.str("hedgePlant","Carpinus betulus")),
   Field("plants","Mischhecke: weitere Arten (mit ; trennen)",e.str("hedgePlantMix","")),
   Field("texture","Kronenstruktur",e.str("hedgeTexture","Automatisch"),choices=listOf("Automatisch","Feldhecke","Laubhecke","Taxus","Thuja")),
   Field("density","Pflanzen je laufendem Meter",fmt(1000.0/e.num("spacingMm",400.0).coerceAtLeast(1.0)),true,true),
   Field("height","Pflanzenhöhe m",fmt(e.num("plantHeightMm",1500.0)/1000.0),true,true)
  ),{setDialog("")}){v->
   val newLength=(parseNumber(v["length"].orEmpty())?:currentLength/1000.0).coerceAtLeast(0.01)*1000.0
   val newWidth=(parseNumber(v["width"].orEmpty())?:0.6).coerceAtLeast(0.01)*1000.0
   val density=(parseNumber(v["density"].orEmpty())?:2.5).coerceAtLeast(0.01)
   val start=e.points.firstOrNull()?:Vec()
   val end=e.points.lastOrNull()?:start+Vec(1000.0,0.0)
   val dx=end.x-start.x;val dy=end.y-start.y
   val dist=kotlin.math.hypot(dx,dy).coerceAtLeast(0.0001)
   val finish=Vec(start.x+dx/dist*newLength,start.y+dy/dist*newLength)
   val newPoints=if(e.str("hedgeRectangle")=="true"){
    val cx=(bounds.min.x+bounds.max.x)/2;val cy=(bounds.min.y+bounds.max.y)/2
    rectangle(Vec(cx-newLength/2,cy-newWidth/2),Vec(cx+newLength/2,cy+newWidth/2))
   }else listOf(start,finish)
   vm.update(e.copy(points=newPoints).withNum("widthMm",newWidth).withNum("spacingMm",1000.0/density).withNum("plantHeightMm",(parseNumber(v["height"].orEmpty())?:1.5)*1000.0).withStr("hedgePlant",v["plant"].orEmpty()).withStr("hedgePlantMix",v["plants"].orEmpty()).withStr("hedgeTexture",v["texture"].orEmpty()))
  }
 }
 "cutSettings"->{
  val owner=d.entities.find{it.id==e.str("pavingCutOwner")}
  val inherited=(owner?.pattern?.jointMm?:4.0).coerceAtLeast(0.1)
  val mode=e.str("cutJointMode","auto")
  FormDialog("Schnittkante anpassen",listOf(
   Field("mode","Fugenbreite",if(mode=="manual")"Manuell einstellen" else "Vom Pflasteraufbau übernehmen",choices=listOf("Vom Pflasteraufbau übernehmen","Manuell einstellen")),
   Field("width","Manuelle Fugenbreite (mm)",fmt(e.num("cutJointWidthMm",inherited)),true,true,visibleChoiceKey="mode",visibleChoiceValue="Manuell einstellen"),
   Field("colorMode","Fugenfarbe",if(e.str("cutColorMode","auto")=="manual")"Manuell einstellen" else "Wie bestehende Pflasterfugen",choices=listOf("Wie bestehende Pflasterfugen","Manuell einstellen")),
   Field("color","Manuelle Fugenfarbe (#RRGGBB)",e.str("cutColor",owner?.style?.stroke?:e.style.stroke),visibleChoiceKey="colorMode",visibleChoiceValue="Manuell einstellen")
  ),{setDialog("")}){v->
   val manual=v["mode"]=="Manuell einstellen"
   val custom=if(manual)(parseNumber(v["width"].orEmpty())?:inherited) else inherited
   require(custom>0.0 && custom<=100.0){"Fugenbreite muss zwischen 0 und 100 mm liegen"}
   val customColor=v["colorMode"]=="Manuell einstellen"
   val chosen=v["color"].orEmpty()
   require(!customColor||Regex("#[0-9a-fA-F]{6}").matches(chosen)){"Fugenfarbe als #RRGGBB eingeben"}
   vm.update(e.withStr("cutJointMode",if(manual)"manual" else "auto")
    .withNum("cutJointWidthMm",custom)
    .withStr("cutColorMode",if(customColor)"manual" else "auto")
    .withStr("cutColor",if(customColor)chosen else (owner?.style?.stroke?:e.style.stroke)))
  }
 }
 "level"->LevelDialog(e,{setDialog("")},vm::update)
 "measureFormat"->MeasureDialog(e,{setDialog("")},vm::update)
 "autoMeasures","autoMeasuresSection","autoMeasuresTop"->{val section=dialog!="autoMeasuresTop";val key=if(section)"autoMeasureSection" else "autoMeasureTop";val current=e.str(key,e.str("autoMeasureProfile").ifBlank{"Aus"});ChoiceDialog(if(section)"Automatische Maße – Schnitt" else "Automatische Maße – Draufsicht",measureProfiles,{setDialog("")},selectedIndex=measureProfiles.indexOf(current).takeIf{it>=0}){vm.setAutoMeasures(e,measureProfiles[it],if(section)"section" else "top")}}
 "saveAssembly","updateAssembly"->FormDialog("Bauwerksvorlage",listOf(Field("name","Name",e.name.ifBlank{"Eigenes Bauwerk"}),Field("category","Kategorie","Eigene Bauwerke")),{setDialog("")}){v->vm.saveAssembly(v.getValue("name"),v.getValue("category"),if(dialog=="updateAssembly")(d.extensions["editingTemplateId"] as? JsonPrimitive)?.contentOrNull else null)}

 "masonryWallSettings"->{
  // Same hierarchical manufacturer selection as the established Pflanztrog editor.
  val manufacturerEntries=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material" && it.extensions.containsKey("baudetailManufacturer")}.distinctBy{it.id}
  fun meta(entry:LibraryEntry,key:String)=((entry.extensions["baudetailManufacturer"] as? JsonObject)?.get(key) as? JsonPrimitive)?.contentOrNull.orEmpty()
  fun variantLabel(entry:LibraryEntry)=listOf(meta(entry,"color"),meta(entry,"surface")).filter{it.isNotBlank()}.joinToString(" · ")
  val byManufacturer=manufacturerEntries.groupBy{meta(it,"manufacturer")}.filterKeys{it.isNotBlank()}
  val manufacturers=listOf("Ohne Hersteller")+byManufacturer.keys.sorted()
  val seriesByManufacturer=byManufacturer.mapValues{(_,items)->items.map{meta(it,"product")}.filter{it.isNotBlank()}.distinct().sorted()}
  val variantBySeries=manufacturerEntries.groupBy{meta(it,"product")}.mapValues{(_,items)->items.map(::variantLabel).distinct().sorted()}
  val chosenManufacturer=e.str("wallManufacturer","Ohne Hersteller").let{if(it=="Standard")"Ohne Hersteller" else it}.takeIf{it in manufacturers}?:"Ohne Hersteller"
  val chosenSeries=e.str("wallSeries").takeIf{it in seriesByManufacturer[chosenManufacturer].orEmpty()}?:seriesByManufacturer[chosenManufacturer].orEmpty().firstOrNull().orEmpty()
  val chosenVariant=e.str("wallManufacturerVariantLabel").takeIf{it in variantBySeries[chosenSeries].orEmpty()}?:variantBySeries[chosenSeries].orEmpty().firstOrNull().orEmpty()
  FormDialog("Mauer anpassen",listOf(
   Field("type","Mauerstein",e.str("wallStoneType","Betonmauerstein"),choices=listOf("Betonmauerstein","Naturstein","Klinker","Kalksandstein","Granit","Jurakalk")),
   Field("manufacturer","Hersteller",chosenManufacturer,choices=manufacturers),
   Field("series","Steinart / Produktserie",chosenSeries,choices=seriesByManufacturer.values.flatten().distinct().ifEmpty{listOf("Keine Serien vorhanden")},choiceDependsOn="manufacturer",choiceMap=seriesByManufacturer),
   Field("variant","Farbe / Oberfläche (Hersteller)",chosenVariant,choices=variantBySeries.values.flatten().distinct().ifEmpty{listOf("Keine Varianten vorhanden")},choiceDependsOn="series",choiceMap=variantBySeries),
   Field("bond","Verband",e.str("wallBond","Halbverband"),choices=listOf("Halbverband","Drittelverband","Kreuzfuge")),
   Field("color","Standardfarbe",e.str("wallColor","Grau"),choices=listOf("Grau","Anthrazit","Beige","Weiß","Rotbraun","Sandstein","Eigene HEX-Farbe"),visibleChoiceKey="manufacturer",visibleChoiceValue="Ohne Hersteller"),
   Field("hex","HEX-Farbe",e.str("wallCustomHex","#B6B6B2"),visibleChoiceKey="color",visibleChoiceValue="Eigene HEX-Farbe"),
   Field("length","Mauerlänge mm",fmt(e.num("wallLengthMm",3000.0)),true,true),
   Field("height","Mauerhöhe mm",fmt(e.num("wallHeightMm",1200.0)),true,true),
   Field("thickness","Mauerdicke mm",fmt(e.num("wallThicknessMm",240.0)),true,true),
   Field("stoneLength","Steinlänge mm",fmt(e.num("wallStoneLengthMm",400.0)),true,true),
   Field("stoneHeight","Steinhöhe mm",fmt(e.num("wallStoneHeightMm",200.0)),true,true),
   Field("stoneDepth","Steintiefe mm",fmt(e.num("wallStoneDepthMm",240.0)),true,true),
   Field("joint","Fugenbreite mm",fmt(e.num("wallJointMm",10.0)),true,true)
  ),{setDialog("")}){v->
  fun positive(key:String)= (parseNumber(v[key].orEmpty())?:error("Ungültiges Maß: $key")).also{require(it>0){"Maß muss größer als null sein"}}
  val len=positive("length");val h=positive("height");val thick=positive("thickness")
  val sl=positive("stoneLength");val sh=positive("stoneHeight");val sd=positive("stoneDepth")
  val joint=(parseNumber(v["joint"].orEmpty())?:0.0).also{require(it in 0.0..50.0){"Fugenbreite 0–50 mm"}}
  val color=when(v["color"]){"Anthrazit"->"#555759";"Beige"->"#C3B49A";"Weiß"->"#E4E2DA";"Rotbraun"->"#A06B54";"Sandstein"->"#CEB58F";"Eigene HEX-Farbe"->v["hex"].orEmpty();else->"#B6B6B2"}
  if(v["manufacturer"]=="Ohne Hersteller")require(color.matches(Regex("#[0-9a-fA-F]{6}"))){"HEX-Farbe muss #RRGGBB sein"}
  val selectedEntry=if(v["manufacturer"]!="Ohne Hersteller")manufacturerEntries.firstOrNull{meta(it,"manufacturer")==v["manufacturer"] && meta(it,"product")==v["series"] && variantLabel(it)==v["variant"]}else null
  if(v["manufacturer"]!="Ohne Hersteller")require(selectedEntry!=null){"Bitte eine passende Produktserie und Farbe/Oberfläche auswählen."}
  if(selectedEntry!=null)vm.attachLibraryForPlacedVariant(selectedEntry)
  val texture=(selectedEntry?.extensions?.get("baudetailTextureTop") as? JsonPrimitive)?.contentOrNull.orEmpty()
  vm.update(e.copy(materialId=selectedEntry?.id,materialSnapshot=null)
   .withStr("wallManufacturer",v["manufacturer"].orEmpty()).withStr("wallSeries",if(selectedEntry!=null)v["series"].orEmpty() else "")
   .withStr("wallManufacturerVariant",v["variant"].orEmpty()).withStr("wallManufacturerVariantLabel",v["variant"].orEmpty()).withStr("wallManufacturerVariantId",selectedEntry?.id.orEmpty())
   .withStr("wallManufacturerTexture",texture)
   .withStr("wallStoneType",v["type"].orEmpty()).withStr("wallBond",v["bond"].orEmpty())
   .withStr("wallColor",v["color"].orEmpty()).withStr("wallCustomHex",if(selectedEntry!=null)e.str("wallCustomHex","#B6B6B2") else color)
   .withNum("wallLengthMm",len).withNum("wallHeightMm",h).withNum("wallThicknessMm",thick)
   .withNum("wallStoneLengthMm",sl).withNum("wallStoneHeightMm",sh).withNum("wallStoneDepthMm",sd)
   .withNum("wallJointMm",joint).withNum("topWidthMm",len).withNum("topHeightMm",thick)
   .withNum("sectionWidthMm",len).withNum("sectionHeightMm",h).withNum("widthMm",len).withNum("heightMm",h)
   .copy(style=e.style.copy(fill=if(selectedEntry!=null)e.style.fill else color),name="Mauer"))
  }
 }
 "steelEdgeSettings"->FormDialog("Stahlkante anpassen",listOf(
  Field("type","Art",e.str("steelType","Verzinkter Stahl"),choices=listOf("Stahl roh","Verzinkter Stahl","Edelstahl","Cortenstahl","Pulverbeschichtet")),
  Field("color","Farbe",e.str("steelColor","Silbergrau"),choices=listOf("Silbergrau","Anthrazit","Schwarz","Rostbraun","Weiß","Farbpalette")),
  Field("customHex","HEX-Farbe",e.str("steelCustomHex",e.style.fill?:"#92979A")),
  Field("length","Länge mm",fmt(e.num("edgeLengthMm",1000.0)),true,true),
  Field("thickness","Dicke mm",fmt(e.num("edgeThicknessMm",8.0)),true,true),
  Field("height","Höhe mm",fmt(e.num("edgeHeightMm",150.0)),true,true),
  Field("foundation","Unterfundament C20/25",e.str("steelFoundation","false"),checkbox=true),
  Field("foundationWidth","Fundamentbreite mm",fmt(e.num("steelFoundationWidthMm",200.0)),true,true),
  Field("foundationHeight","Fundamenthöhe mm",fmt(e.num("steelFoundationHeightMm",200.0)),true,true),
  Field("backing","Rückenstütze",e.str("steelBacking","false"),checkbox=true),
  Field("backingWidth","Rückenstützenbreite mm",fmt(e.num("steelBackingWidthMm",100.0)),true,true),
  Field("backingHeight","Rückenstützenhöhe mm",fmt(e.num("steelBackingHeightMm",100.0)),true,true)
 ),{setDialog("")}){v->
  val len=parseNumber(v["length"].orEmpty())?:1000.0
  val thick=parseNumber(v["thickness"].orEmpty())?:8.0
  val h=parseNumber(v["height"].orEmpty())?:150.0
  require(len>0&&thick>0&&h>0){"Länge, Dicke und Höhe müssen größer als null sein"}
  val col=when(v["color"]){"Anthrazit"->"#474A4E";"Schwarz"->"#25272A";"Rostbraun"->"#985D48";"Weiß"->"#E1E1DF";"Farbpalette"->v["customHex"].orEmpty();else->"#92979A"}
  vm.update(e.withStr("steelEdge","true").withStr("steelCustomHex",v["customHex"].orEmpty()).withStr("steelType",v["type"].orEmpty()).withStr("steelColor",v["color"].orEmpty())
   .withStr("steelFoundation",(v["foundation"].orEmpty().lowercase() in setOf("ja","true")).toString()).withStr("steelBacking",(v["backing"].orEmpty().lowercase() in setOf("ja","true")).toString())
   .withNum("edgeLengthMm",len).withNum("edgeThicknessMm",thick).withNum("edgeHeightMm",h)
   .withNum("steelFoundationWidthMm",(parseNumber(v["foundationWidth"].orEmpty())?:200.0).coerceAtLeast(1.0))
   .withNum("steelFoundationHeightMm",(parseNumber(v["foundationHeight"].orEmpty())?:200.0).coerceAtLeast(1.0))
   .withNum("steelBackingWidthMm",(parseNumber(v["backingWidth"].orEmpty())?:100.0).coerceAtLeast(1.0))
   .withNum("steelBackingHeightMm",(parseNumber(v["backingHeight"].orEmpty())?:100.0).coerceAtLeast(1.0))
   .copy(style=e.style.copy(fill=col,stroke=col),name="Stahlkante",libraryId="cmp-einfassungen-kanten-stahlkante"))
 }

 }
}

