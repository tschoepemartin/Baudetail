# BauDetail 0.9.68

Fix: `buildUp` is now passed explicitly from Inspector to GeometryAndPavingDialogs, preserving the existing normalized build-up object when editing stacks. Fixes unresolved reference in GitHub Actions #241.
