# BauDetail 0.9.63 – Renderoptimierung (Quellcode, Build ausstehend)

- Scene.materialStoneTextures: redundante Einzelstein-Clipping-Gruppen entfernt; jedes Asset zeichnet bereits in sein Rechteck. Die äußere Flächenbegrenzung bleibt erhalten.
- CanvasRenderer: frühzeitiger Clip-Bounds-Test für interaktive Gruppen; vollständig unsichtbare Unterbäume werden übersprungen.
- Keine Änderungen an Geometrie, Snapping, Objektformaten oder PDF-Exportalgorithmus.
- Lokaler Gradle-Build nicht möglich: Gradle Wrapper versucht services.gradle.org zu erreichen, Netzwerkzugriff nicht verfügbar.
- Performancegewinn und optische Gleichheit noch auf Gerät und in CI zu verifizieren.
