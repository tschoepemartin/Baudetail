package de.baudetail.core

import de.baudetail.geometry.*
import kotlin.math.*

/** The editable plan outline is derived from the actual parametric paving dimensions. */
fun contourOutline(e:Entity,d:Drawing):List<Vec> = if(e.isParametricBuildUp() && d.viewMode()!="section") {
 val o=buildUpPlanOrigin(e); val a=buildUpPlanAngle(e)
 rectangle(Vec(),Vec(e.num("planGraphicWidthMm",e.num("widthMm",1500.0)),e.num("topDepthMm",1000.0))).map{o+it.rotate(a)}
} else resolvedPoints(e,d)

/** Keep the paving build-up parametric, including materials and bond; never replace its section points. */
fun updateContour(e:Entity,d:Drawing,changed:List<Vec>):Entity {
 if(!e.isParametricBuildUp() || d.viewMode()=="section")return e.copy(points=changed).let{if(it.kind=="hedge" && it.str("hedgeRectangle")=="true")it.withNum("widthMm",Bounds.of(changed).height)else it}
 if(changed.size!=4)return e
 val a=buildUpPlanAngle(e)
 val origin=buildUpPlanOrigin(e)
 val local=changed.map{(it-origin).rotate(-a)}
 val minX=local.minOf{it.x};val maxX=local.maxOf{it.x}
 val minY=local.minOf{it.y};val maxY=local.maxOf{it.y}
 val w=maxX-minX;val h=maxY-minY
 if(w<=1.0||h<=1.0)return e
 // Updating dimensions can shift the derived anchor. Compensate with the existing plan offsets.
 val resized=e.withNum("planGraphicWidthMm",w).withNum("widthMm",w).withNum("topDepthMm",h).withStr("buildUpAnchorV2","true")
 val desired=origin+Vec(minX,minY).rotate(a)
 val actual=buildUpPlanOrigin(resized)
 val shift=desired-actual
 return resized.withNum("buildUpTopDxMm",resized.num("buildUpTopDxMm")+shift.x).withNum("buildUpTopDyMm",resized.num("buildUpTopDyMm")+shift.y)
}
