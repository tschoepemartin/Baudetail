package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.*
import org.junit.Test

class Snap064Test {
 private fun curb(at:Vec=Vec())=Entity(
  id="curb",kind="component",points=listOf(at),params=buildJsonObject{
   put("componentFamily","curb");put("libraryViews",true)
   put("widthMm",100.0);put("heightMm",200.0)
   put("sectionWidthMm",100.0);put("sectionHeightMm",200.0)
   put("topWidthMm",1000.0);put("topHeightMm",100.0)
   put("chamferWidthMm",3.0);put("chamferDepthMm",4.0)
  })

 @Test fun curbChamferVerticesAreRealBidirectionalSnapPoints(){
  val e=curb()
  val d=Drawing(type="Schnitt",entities=listOf(e)).withViewMode("section")
  val refs=smartSnapReferencePoints(e,d)
  assertTrue(refs.any{it.distance(Vec(97.0,0.0))<1e-6})
  assertTrue(refs.any{it.distance(Vec(100.0,4.0))<1e-6})
  // Historic edge-follow slots stay intact.
  assertEquals(Vec(0.0,0.0),refs[0]);assertEquals(Vec(100.0,0.0),refs[1])
  assertEquals(Vec(100.0,200.0),refs[2]);assertEquals(Vec(0.0,200.0),refs[3])
  assertEquals(Vec(50.0,100.0),refs[4])

  val end=snap(Vec(97.0,0.0),d,SnapOptions(grid=false,toleranceMm=1.0,modes=setOf("Endpunkt")))
  assertEquals("Endpunkt",end.reason)
  assertEquals(e.id,end.anchor?.entityId)

  val phaseMid=Vec(98.5,2.0)
  val edge=snap(phaseMid,d,SnapOptions(grid=false,toleranceMm=1.0,modes=setOf("Kante")))
  assertEquals("Kante",edge.reason)
  assertEquals(e.id,edge.anchor?.entityId)
  assertEquals("edge",edge.anchor?.reference)
 }

 @Test fun sectionSemanticSnapMapsRunStationToPlanCenterline(){
  val e=curb()
  val section=Drawing(type="Schnitt",entities=listOf(e)).withViewMode("section")
  val key=smartSemanticSnapKey(e,section,Vec(100.0,4.0))
  assertEquals("run:1000000",key)
  val top=section.withViewMode("top")
  val p=smartSemanticSnapPoint(e,top,key!!)
  assertNotNull(p)
  assertEquals(1000.0,p!!.x,1e-6)
  assertEquals(50.0,p.y,1e-6)
 }
}
