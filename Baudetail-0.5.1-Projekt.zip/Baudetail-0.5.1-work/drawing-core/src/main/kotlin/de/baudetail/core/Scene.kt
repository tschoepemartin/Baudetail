package de.baudetail.core
import kotlinx.serialization.json.*

import de.baudetail.geometry.*
import kotlin.math.*

sealed interface Primitive {
 data class Path(val points:List<Vec>,val closed:Boolean=false,val style:Style=Style()):Primitive
 data class Circle(val center:Vec,val radius:Double,val style:Style=Style()):Primitive
 data class Text(val at:Vec,val value:String,val size:Double,val style:Style=Style(),val angle:Double=0.0):Primitive
 data class Asset(val at:Vec,val width:Double,val height:Double,val path:String,val opacity:Double=1.0,val angle:Double=0.0):Primitive
 data class Group(val nodes:List<Primitive>,val translate:Vec=Vec(),val scale:Double=1.0,val angle:Double=0.0,val clip:List<Vec>?=null,val mirrorY:Boolean=false):Primitive
}
object Scene {
 fun drawing(d:Drawing,p:Project,printing:Boolean=false):List<Primitive> = d.entities.filter {e->val l=d.layers.find {it.id==e.layerId};l?.visible!=false&&visibleIn(e,d)&&(!printing||l?.printable!=false)}.sortedBy{if(isFoundation(it))0 else if(it.kind in setOf("dimension","text","leader","elevation"))2 else 1}.flatMap {entity(it,d,p)}
 fun entity(input:Entity,d:Drawing,p:Project):List<Primitive> {
  val entry=p.libraryEntries.find{it.id==input.libraryId}
  val sourceMaterial=input.materialSnapshot?.let{LibraryEntry(id="snapshot",type="material",name="",category="",appearance=it)}?:p.libraryEntries.find{it.id==input.materialId}
  val material=if(d.viewMode()=="top"&&input.str("fillMode","auto")=="vertical")null else sourceMaterial
  var e=viewEntity(if(material!=null&&closedContour(input))input.copy(style=materialStyle(material,d.viewMode()=="section"))else input,d)
  if(e.kind=="component"&&e.str("frozenTemplate")!="true"){
   val rawAsset=e.str("asset_"+d.viewMode()).ifBlank{entry?.views?.get(d.viewMode()).orEmpty()}
   val asset=if(d.viewMode()=="top"&&e.str("grassTopFallback")=="true")"" else rawAsset
   e=e.copy(asset=asset.ifBlank{if(e.view==d.viewMode()&&(d.viewMode()!="top"||e.str("libraryViews")!="true"))e.asset else null})
  }
  val pts=resolvedPoints(e,d);val a=pts.firstOrNull()?:Vec();val b=pts.getOrNull(1)?:a;val s=e.style.copy(widthMm=e.style.widthMm*d.sheet.scale,dashed=e.style.dashed||e.status=="Abbruch"||e.placement.hidden)
  val textSize=e.style.textPaperMm*d.sheet.scale
  fun text(at:Vec,value:String,size:Double=textSize)=Primitive.Text(at,value,size,s,e.rotation)
  fun arrow(start:Vec,end:Vec):List<Primitive> {
   val delta=end-start;val dist=delta.length();if(dist<1e-6)return emptyList();val u=delta*(1/dist);val v=Vec(-u.y,u.x);val head=min(2.5*d.sheet.scale,dist/3)
   return listOf(Primitive.Path(listOf(start,end),style=s),Primitive.Path(listOf(end-u*head+v*(head/2),end,end-u*head-v*(head/2)),style=s))
  }
  val rendered=when(e.kind) {
   "assembly" -> {
    if(!isStair(e))return emptyList()
    // The assembly always renders the same real library-step instances that are
    // used when a step is inserted individually. The plan view only adds the
    // conventional flight annotation on top.
    val nodes=stairSteps(e,d,p).flatMap{entity(it,d,p)}.toMutableList()
    val refs=stairReferencePoints(e,d.viewMode())
    if(d.viewMode()!="section") {
     val width=e.num("widthMm",1200.0);val total=stairLength(e)
     // Overlay the conventional, perfectly aligned tread/front edges so the
     // stair remains readable even if a manufacturer top asset is very subtle.
     refs.chunked(2).filter{it.size==2}.forEach{nodes.add(Primitive.Path(it,style=s))}
     for(y in listOf(0.0,width))nodes.add(Primitive.Path(listOf(assemblyPoint(e,Vec(0.0,y),d.viewMode()),assemblyPoint(e,Vec(total,y),d.viewMode())),style=s))
     val start=assemblyPoint(e,Vec(0.0,width/2),d.viewMode());val end=assemblyPoint(e,Vec(total,width/2),d.viewMode())
     nodes.addAll(arrow(start,end))
     val labelOffset=d.sheet.scale*3.0
     nodes.add(text(assemblyPoint(e,Vec(-labelOffset,width/2),d.viewMode()),"UNTEN"))
     nodes.add(text(assemblyPoint(e,Vec(total+labelOffset,width/2),d.viewMode()),"OBEN"))
    }
    nodes
   }
   "circle" -> listOf(Primitive.Circle(a,e.num("radiusMm",a.distance(b)),s))+materialHatch(e,material,d)
   "arc" -> {val r=e.num("radiusMm",500.0);val from=e.num("startAngle",0.0);val sweep=e.num("sweepAngle",90.0);listOf(Primitive.Path((0..96).map {val t=Math.toRadians(from+sweep*it/96);a+Vec(cos(t),sin(t))*r},style=s))}
   "polyline","area","rect","polygon","building" -> {
    if(!closedContour(e))return listOf(Primitive.Path(pts,style=s))
    val out=mutableListOf<Primitive>(Primitive.Path(pts,true,s));e.pattern?.let {out.add(pattern(pts,it,s,d.sheet.scale))};out.addAll(materialHatch(e.copy(points=pts),material,d));out
   }
   "arrow","leader" -> arrow(a,b)+(if(e.text.isNotEmpty())listOf(text(a,interpolate(e.text,textVariables(e,d,p))))else emptyList())
   "text" -> listOf(text(a,interpolate(e.text,textVariables(e,d,p))))
   "elevation" -> {
    val h=elevationValueMm(input,d);val label=if(abs(h)<0.001)"±0,00" else (if(h>0)"+" else "")+String.format(java.util.Locale.GERMANY,"%.2f",h/1000)
    val role=input.str("elevationRole","manual");val prefix=if(role=="leader")"REF "else input.str("elevationPrefix")
    val r=2*d.sheet.scale;listOf(Primitive.Path(listOf(a+Vec(-r,-r),a,a+Vec(r,-r)),true,s),text(a+Vec(r*1.5,-r),prefix+label))
   }
   "foundation" -> {
    val outline=foundationOutline(input,d);val fill=s.fill?:"#C8C8C3"
    val b=if(outline.size>=3)Bounds.of(outline)else Bounds(Vec(),Vec())
    val overlaps=d.entities.any{it.id!=input.id&&isFoundation(it)&&visibleIn(it,d)&&runCatching{val ob=Bounds.of(foundationOutline(it,d));!(ob.max.x<b.min.x||ob.min.x>b.max.x||ob.max.y<b.min.y||ob.min.y>b.max.y)}.getOrDefault(false)}
    // When foundations overlap they remain separate model objects but visually merge.
    val concrete=s.copy(fill=fill,stroke=if(overlaps)fill else s.stroke)
    val nodes=mutableListOf<Primitive>();if(outline.size>=3){nodes.add(Primitive.Path(outline,true,concrete));nodes.addAll(materialHatch(input.copy(kind="polygon",points=outline),material,d))};nodes
   }
   "slope" -> arrow(a,b)+text((a+b)*0.5+Vec(0.0,-textSize),slopeLabel(e,d))
   "dimension" -> {
    if(e.str("metric").isNotEmpty()){
     val source=d.entities.find{it.id==e.str("sourceId")};val witnesses=source?.let{metricWitnesses(it,e.str("metric"),d)}
     if(witnesses==null)return listOf(text(a+Vec(e.num("textDx"),e.num("textDy")),dimensionLabel(e,d)))
     val annotation=e.copy(points=witnesses,anchors=emptyList(),bindings=emptyList(),params=JsonObject(e.params-setOf("metric","sourceId"))).withStr("renderLabel",dimensionLabel(e,d)).withNum("dimDx",e.num("dimDx")+a.x-e.num("metricOriginX",a.x)).withNum("dimDy",e.num("dimDy")+a.y-e.num("metricOriginY",a.y))
     return entity(annotation,d,p)
    }
    val mode=e.str("mode","aligned")
    if(mode=="chain") return pts.zipWithNext().flatMap { (start,end) -> entity(e.copy(points=listOf(start,end),anchors=emptyList()).withStr("mode","aligned"),d,p) }
    if(mode=="angle" && pts.size>=3) {
     val center=pts[1];val first=pts[0]-center;val last=pts[2]-center;val from=atan2(first.y,first.x);var sweep=atan2(last.y,last.x)-from
     while(sweep>PI)sweep-=2*PI;while(sweep< -PI)sweep+=2*PI
     val r=abs(e.num("offsetMm",8*d.sheet.scale)).coerceAtLeast(textSize*2)
     val arc=(0..64).map { val t=from+sweep*it/64;center+Vec(cos(t),sin(t))*r }
     return listOf(Primitive.Path(listOf(pts[0],center,pts[2]),style=s),Primitive.Path(arc,style=s),text(center+Vec(cos(from+sweep/2),sin(from+sweep/2))*(r+textSize),"${fmt(dimensionValue(e,d))}°"))
    }
    val rawDelta=b-a;val dist=rawDelta.length();val off=e.num("offsetMm",d.sheet.scale*8)
    val base=when(mode){"horizontal"->Vec(0.0,off);"vertical"->Vec(off,0.0);else->if(dist>0)Vec(-rawDelta.y/dist,rawDelta.x/dist)*off else Vec(0.0,off)}
    val shift=Vec(e.num("dimDx"),e.num("dimDy"));val aa=a+base+shift;val bb=when(mode){"horizontal"->Vec(b.x+shift.x,aa.y);"vertical"->Vec(aa.x,b.y+shift.y);else->b+base+shift}
    val label=e.str("renderLabel",dimensionLabel(e,d))
    listOf(Primitive.Path(listOf(a,aa),style=s),Primitive.Path(listOf(b,bb),style=s))+arrow(aa,bb)+arrow(bb,aa)+text((aa+bb)*0.5+Vec(e.num("textDx"),-textSize*0.35+e.num("textDy")),label)
   }
   "section" -> {
    val delta=b-a;val u=if(delta.length()>0)delta*(1/delta.length())else Vec(1.0,0.0);val v=Vec(-u.y,u.x)*(e.num("direction",1.0)*d.sheet.scale*7)
    listOf(Primitive.Path(listOf(a,b),style=s.copy(dashed=true)))+arrow(a,a+v)+arrow(b,b+v)+text(a+v*1.4,e.text.ifBlank {"A–A"})+text(b+v*1.4,e.text.ifBlank {"A–A"})
   }
   "tree" -> {
    val r=e.num("crownMm",2000.0)/2;val out=mutableListOf<Primitive>(Primitive.Circle(a,r,s),Primitive.Circle(a,e.num("trunkMm",120.0)/2,s.copy(fill=s.stroke)),Primitive.Path(listOf(a-Vec(r,0.0),a+Vec(r,0.0)),style=s),Primitive.Path(listOf(a-Vec(0.0,r),a+Vec(0.0,r)),style=s))
    if(e.num("rootMm")>0)out.add(Primitive.Circle(a,e.num("rootMm")/2,s.copy(fill=null,dashed=true)))
    if(e.num("pitMm")>0)out.add(Primitive.Path(rectangle(a-Vec(e.num("pitMm")/2,e.num("pitMm")/2),a+Vec(e.num("pitMm")/2,e.num("pitMm")/2)),true,s.copy(fill=null,dashed=true)))
    if(e.name.isNotEmpty())out.add(text(a+Vec(r*0.6,-r),e.name));out
   }
   "hedge" -> {
    val spacing=e.num("spacingMm",400.0).coerceAtLeast(1.0);val len=length(pts);val n=hedgeCount(len,spacing);val r=e.num("widthMm",600.0)/2
    val nodes=mutableListOf<Primitive>(Primitive.Path(pts,style=s.copy(widthMm=r*2,opacity=0.25)))
    if(n<=1500)for(i in 0 until n)nodes.add(Primitive.Circle(pointAt(pts,if(n<=1)0.0 else len*i/(n-1)),r,s))
    nodes.add(text(a+Vec(0.0,-r-textSize),"${e.name.ifBlank {"Hecke"}} · $n Stk"));nodes
   }
   "stack" -> {
    var y=0.0;val nodes=mutableListOf<Primitive>();val w=e.num("widthMm",1500.0)
    for(layer in e.strata){nodes.add(Primitive.Path(rectangle(Vec(0.0,y),Vec(w,y+layer.thicknessMm)),true,s.copy(fill=layer.color)));nodes.add(Primitive.Text(Vec(if(e.str("labels","inside")=="right")w+textSize else textSize,y+layer.thicknessMm/2+textSize*0.3),"${fmt(layer.thicknessMm/10)} cm ${layer.name}",textSize,s));y+=layer.thicknessMm}
    listOf(Primitive.Group(nodes,a,angle=e.rotation))
   }
   "legend" -> {
    val items=legendItems(d,p.libraryEntries);val nodes=mutableListOf<Primitive>();var y=0.0
    items.forEach {item->nodes.add(Primitive.Path(rectangle(Vec(0.0,y-textSize),Vec(textSize*1.6,y)),true,s.copy(fill=item.style.fill)));nodes.add(Primitive.Text(Vec(textSize*2,y),item.label,textSize,s));y+=textSize*1.7}
    if(e.text.isNotBlank())nodes.add(Primitive.Text(Vec(0.0,y),e.text,textSize,s));listOf(Primitive.Group(nodes,a))
   }
   "component" -> {
    when {
     isChannelBox(e) -> {
      val bw=e.num("boxWidthMm",185.0);val bh=e.num("boxHeightMm",610.0);val bl=e.num("boxLengthMm",500.0);val nw=e.num("channelNominalWidthMm",150.0);val dn=e.num("pipeDnMm",160.0);val axis=e.num("pipeAxisFromTopMm",500.0);val side=e.str("pipeOutlet","left");val body=s.copy(fill=s.fill?:"#D9C27C");val dark=s.copy(stroke="#42484A",fill="#596164");val metal=s.copy(stroke="#50575A",fill="#AAB0B2")
      val nodes=mutableListOf<Primitive>()
      if(d.viewMode()=="top"){
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(bl,bw)),true,body));val grateW=nw.coerceAtMost(bw);val y0=(bw-grateW)/2;nodes.add(Primitive.Path(rectangle(Vec(),Vec(bl,bw)),true,body));nodes.add(Primitive.Path(rectangle(Vec(0.0,y0),Vec(bl,y0+grateW)),true,metal));for(i in 1..16){val x=bl*i/17;nodes.add(Primitive.Path(listOf(Vec(x,y0),Vec(x,y0+grateW)),style=dark.copy(widthMm=0.35*d.sheet.scale)))}
       if(e.str("leafBasket","true")=="true")nodes.add(Primitive.Path(rectangle(Vec(bl*.25,y0+grateW*.15),Vec(bl*.75,y0+grateW*.85)),true,dark.copy(fill=null,dashed=true)))
      } else {
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(bw,bh)),true,body));val cx=bw/2;val cutW=nw.coerceAtMost(bw);val cutD=minOf(150.0,bh*.26);nodes.add(Primitive.Path(listOf(Vec(cx-cutW/2,0.0),Vec(cx-cutW/2,cutD*.45),Vec(cx,cutD),Vec(cx+cutW/2,cutD*.45),Vec(cx+cutW/2,0.0)),style=dark.copy(fill=null,widthMm=0.65*d.sheet.scale)));if(e.str("grateVisible","true")=="true")nodes.add(Primitive.Path(listOf(Vec(cx-cutW/2,0.0),Vec(cx+cutW/2,0.0)),style=dark.copy(widthMm=1.4*d.sheet.scale)));if(e.str("leafBasket","true")=="true")nodes.add(Primitive.Path(rectangle(Vec(cx-cutW*.32,cutD+20),Vec(cx+cutW*.32,cutD+170)),true,metal.copy(fill=null,dashed=true)));if(side!="none"){val y=axis.coerceIn(dn/2,bh-dn/2);val x=if(side=="left")0.0 else bw;nodes.add(Primitive.Circle(Vec(x,y),dn/2,dark.copy(fill="#5B6D78")))}
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isRetainingWall(e) -> {
      if(d.viewMode()=="section") listOf(Primitive.Group(listOf(Primitive.Path(retainingWallSection(e),true,s.copy(fill=s.fill?:"#D0CEC6"))),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      else {val (wall,foot)=retainingWallTop(e);listOf(Primitive.Group(listOf(Primitive.Path(foot,true,s.copy(fill=null,dashed=true)),Primitive.Path(wall,true,s.copy(fill=s.fill?:"#D0CEC6"))),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))}
     }
     isPipe(e) -> {
      val dn=e.num("dnMm",e.num("sectionHeightMm",160.0)).coerceAtLeast(1.0);val vertical=e.str("orientation","horizontal")=="vertical";val dir=if(e.str("verticalDirection","down")=="up")-1.0 else 1.0;val len=e.num("pipeLengthMm",e.num("verticalLengthMm",1000.0)).coerceAtLeast(dn)
      if(isKg2000(e)&&!vertical){
       val green=s.copy(stroke="#0B5F34",fill="#149447",widthMm=0.5*d.sheet.scale);val dark=s.copy(stroke="#063E23",fill="#0C6E3B",widthMm=0.45*d.sheet.scale);val type=e.str("fittingType","pipe");val nodes=mutableListOf<Primitive>()
       when(type){
        "bend"->{val ang=Math.toRadians(e.num("bendAngle",45.0));val end=Vec(len*cos(ang),len*sin(ang));nodes.add(Primitive.Path(listOf(Vec(),Vec(len*.45,0.0),end),style=green.copy(fill=null,widthMm=dn)));nodes.add(Primitive.Circle(Vec(),dn*.62,dark));nodes.add(Primitive.Circle(end,dn*.5,green.copy(fill=null)))}
        "y"->{val branch=e.num("branchDnMm",dn);nodes.add(Primitive.Path(listOf(Vec(),Vec(len,0.0)),style=green.copy(fill=null,widthMm=dn)));nodes.add(Primitive.Path(listOf(Vec(len*.52,0.0),Vec(len*.88,len*.36)),style=green.copy(fill=null,widthMm=branch)));nodes.add(Primitive.Circle(Vec(),dn*.62,dark))}
        "reducer"->{val big=e.num("inletDnMm",dn);val small=e.num("outletDnMm",dn);val actualLen=kg2000ReducerLengthMm(big.toInt(),small.toInt())?:len;val sy=(big-small)/2.0;nodes.add(Primitive.Path(listOf(Vec(0.0,-big/2),Vec(actualLen,sy-small/2),Vec(actualLen,sy+small/2),Vec(0.0,big/2)),true,green));nodes.add(Primitive.Path(rectangle(Vec(actualLen-small*.14,sy-small*.62),Vec(actualLen+small*.14,sy+small*.62)),true,dark))}
        "double_spigot"->{nodes.add(Primitive.Path(rectangle(Vec(),Vec(len,dn)),true,green))}
        else->{nodes.add(Primitive.Path(rectangle(Vec(),Vec(len,dn)),true,green));nodes.add(Primitive.Path(rectangle(Vec(-dn*.12,-dn*.12),Vec(dn*.12,dn*1.12)),true,dark))}
       }
       if(e.str("flowArrow","true")=="true"){val from=if(e.str("flowDirection","forward")=="reverse")Vec(len*.65,dn*.5)else Vec(len*.35,dn*.5);val to=if(e.str("flowDirection","forward")=="reverse")Vec(len*.35,dn*.5)else Vec(len*.65,dn*.5);nodes.addAll(arrow(from,to))}
       listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      } else {
       val node=if(d.viewMode()=="section") {if(vertical)Primitive.Path(rectangle(Vec(-dn/2,0.0),Vec(dn/2,dir*len)),true,s.copy(fill=s.fill)) else Primitive.Circle(Vec(),dn/2,s.copy(fill=s.fill))} else {if(vertical)Primitive.Circle(Vec(),dn/2,s.copy(fill=s.fill)) else Primitive.Path(rectangle(Vec(),Vec(e.num("topWidthMm",len),dn)),true,s.copy(fill=s.fill))}
       listOf(Primitive.Group(listOf(node),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      }
     }
     e.smartFamily()=="grass" && d.viewMode()=="section" && e.asset==null -> {
      val w=e.num("sectionWidthMm",1000.0);val h=e.num("sectionHeightMm",150.0);val grassStyle=s.copy(fill=s.fill?:"#B79B72");val blades=(0..(w/35).toInt().coerceAtMost(200)).map{i->val x=i*35.0;Primitive.Path(listOf(Vec(x,0.0),Vec(x+7,-20.0),Vec(x+13,0.0)),style=s.copy(stroke="#6F9B55"))};listOf(Primitive.Group(listOf(Primitive.Path(rectangle(Vec(),Vec(w,h)),true,grassStyle))+blades,a,angle=e.rotation))
     }
     e.children.isNotEmpty()&&(e.str("frozenTemplate")=="true"||(e.asset==null&&e.view==d.viewMode()&&(e.str("libraryViews")!="true"||d.viewMode()=="section"))) -> {
      val bounds=Bounds.of(e.children.flatMap {it.points});val base=e.num("baseWidthMm",bounds.width.coerceAtLeast(1.0));val scale=if(e.str("frozenTemplate")=="true")e.num("templateScale",1.0)else e.num("widthMm",base)/base
      listOf(Primitive.Group(e.children.flatMap {entity(it,d,p)},a,scale,e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     e.asset!=null -> listOf(Primitive.Group(listOf(Primitive.Asset(Vec(),e.num("widthMm",500.0),e.num("heightMm",500.0),e.asset,s.opacity)),a,angle=e.rotation+(if(d.viewMode()=="section")-Math.toDegrees(atan(e.num("slope")/100))else 0.0),mirrorY=e.num("mirrored")==1.0))
     else -> listOf(Primitive.Group(listOf(Primitive.Path(rectangle(Vec(),Vec(e.num("widthMm",500.0),e.num("heightMm",500.0))),true,s)),a,angle=e.rotation+(if(d.viewMode()=="section")-Math.toDegrees(atan(e.num("slope")/100))else 0.0),mirrorY=e.num("mirrored")==1.0))
    }
   }
   "image" -> if(e.asset!=null)listOf(Primitive.Asset(a,e.num("widthMm",1000.0),e.num("heightMm",1000.0),e.asset,s.opacity,e.rotation))else listOf(text(a,"Ressource fehlt"))
   else -> listOf(Primitive.Path(pts,style=s))
  }
  if(e.str("labelEnabled")=="true") {
   val bounds=if(isStair(e))Bounds.of(stairReferencePoints(e,d.viewMode()))else viewBounds(e,d)
   val target=Vec(bounds.center.x,bounds.min.y)
   val atLabel=objectLabelPosition(e,d)
   val value=if(e.str("labelMode","auto")=="manual"&&e.str("labelText").isNotBlank())e.str("labelText") else e.name.ifBlank{e.kind}
   return rendered+arrow(atLabel,target)+text(atLabel,value)
  }
  return rendered
 }
 fun materialHatch(e:Entity,entry:LibraryEntry?,d:Drawing):List<Primitive>{
  if(entry==null||d.viewMode()!="section")return emptyList()
  val asset=entry.appearance?.sectionPattern?:entry.views["section"]?:return emptyList()
  val polygon=contour(e);if(polygon.size<3)return emptyList();val b=Bounds.of(polygon)
  val w=(entry.appearance?.tileWidthMm?:entry.attribute("pattern_width_mm",200.0)).coerceAtLeast(1.0);val h=(entry.appearance?.tileHeightMm?:entry.attribute("pattern_height_mm",200.0)).coerceAtLeast(1.0)
  val cols=ceil(b.width/w).toInt().coerceAtLeast(1);val rows=ceil(b.height/h).toInt().coerceAtLeast(1)
  if(cols.toLong()*rows>10000)return listOf(Primitive.Text(b.min,"Schraffur: Fläche teilen (mehr als 10.000 Kacheln)",3*d.sheet.scale))
  return listOf(Primitive.Group((0 until rows).flatMap{y->(0 until cols).map{x->Primitive.Asset(b.min+Vec(x*w,y*h),w,h,asset)}},clip=polygon))
 }
 fun pattern(poly:List<Vec>,p:Pattern,style:Style,scale:Double):Primitive {
  val dx=(p.widthMm+p.jointMm).coerceAtLeast(1.0);val dy=(p.heightMm+p.jointMm).coerceAtLeast(1.0)
  val bounds=Bounds.of(poly.map {(it-p.origin).rotate(-p.angle)})
  val minX=floor(bounds.min.x/dx).toInt()-2;val maxX=ceil(bounds.max.x/dx).toInt()+2;val minY=floor(bounds.min.y/dy).toInt()-2;val maxY=ceil(bounds.max.y/dy).toInt()+2
  val nodes=mutableListOf<Primitive>();val count=(maxX.toLong()-minX+1)*(maxY.toLong()-minY+1)
  if(count<=40000)for(row in minY..maxY)for(col in minX..maxX){val offset=if(row%2==0)0.0 else p.offset*dx;val a=Vec(col*dx+offset,row*dy);nodes.add(Primitive.Path(rectangle(a,a+Vec(p.widthMm,p.heightMm)),true,style.copy(fill=null,widthMm=0.12*scale)))}
  return Primitive.Group(listOf(Primitive.Group(nodes,p.origin,angle=p.angle)),clip=poly)
 }
 fun paper(d:Drawing,p:Project):List<Primitive> {
  val sh=d.sheet;val margin=10.0;val bottom=sh.heightMm-32.0
  val printableW=(sh.widthMm-2*margin).coerceAtLeast(1.0)*sh.scale
  val printableH=(bottom-margin).coerceAtLeast(1.0)*sh.scale
  val visible=d.entities.filter { e ->
   val l=d.layers.find{it.id==e.layerId};l?.visible!=false&&l?.printable!=false&&visibleIn(e,d)
  }
  val actual=visible.flatMap { listOf(viewBounds(it,d).min,viewBounds(it,d).max) }.takeIf{it.isNotEmpty()}?.let(Bounds::of)
  val configured=Bounds(sh.origin,sh.origin+Vec(printableW,printableH))
  // Keep the explicitly positioned paper when the drawing centre is actually on it.
  // Old/legacy drawings sometimes have a zero sheet origin although all geometry
  // lives elsewhere; exporting those used to clip the complete drawing away.
  val exportOrigin=if(actual==null||configured.contains(actual.center))sh.origin else actual.center-Vec(printableW,printableH)*0.5
  val content=Primitive.Group(drawing(d,p,true),Vec(margin-exportOrigin.x/sh.scale,margin-exportOrigin.y/sh.scale),1/sh.scale)
  val style=Style(widthMm=0.2)
  val titleLines=interpolate(sh.titleTemplate,variables(p,d)).lines().map{it.trimEnd()}.filter{it.isNotBlank()}
  val titleSize=2.6
  val frameTop=bottom+2
  val head=mutableListOf<Primitive>(
   Primitive.Group(listOf(content),clip=rectangle(Vec(margin,margin),Vec(sh.widthMm-margin,bottom))),
   Primitive.Path(rectangle(Vec(margin,frameTop),Vec(sh.widthMm-margin,sh.heightMm-margin)),true,style)
  )
  titleLines.take(4).forEachIndexed{i,line->head.add(Primitive.Text(Vec(margin+3,frameTop+5+i*3.8),line,titleSize,style))}
  head.add(Primitive.Path(listOf(Vec(sh.widthMm-115,sh.heightMm-15),Vec(sh.widthMm-15,sh.heightMm-15)),style=style))
  head.add(Primitive.Text(Vec(sh.widthMm-115,sh.heightMm-17),"Kontrollmaß 100 mm · Druck 100 %",2.2,style))
  return head
 }
}
