# BauDetail 0.9.125
- Frontansicht: Stufenoberkanten, Außenkanten und versetzte Fugen werden über gemeinsame Zeichnungs-/Fanggeometrie erfasst.
- Blockstufen und Treppen: Materialdarstellung im Schnitt verwendet die externe Stufenbibliothek (Schnitttextur, ersatzweise Oberflächentextur) und deren Materialfarbe.
- Vorhandene Treppenparameter, Draufsicht und Stufenberechnung bleiben unverändert.
- Noch nicht auf Android bzw. im PDF visuell getestet.
