# Baudetail 0.5.0

- Automatische Maße: kantenbezogene Witnesses, dünne Maßhilfslinien, keine störenden Präfixe; Maße bleiben assoziativ und über Maßtext verschiebbar.
- Unterfundamente: Bearbeitungsgriffe nur im expliziten Bearbeiten-Modus; Duplizieren nimmt gekoppelte Fundamente mit.
- Einlauf-/Sinkkasten: Standard 18,5 × 61 × 50 cm, NW 150, DN 160; Kastenlänge statt -tiefe; parametrischer Rost, Korb, Auslass; Draufsicht neu.
- KG 2000: eigene parametrische Rohr-/Formstückfamilie mit DN 110/125/160/200/250/315/400/500/630, Bögen 15/30/45/67/87,5°, Y 45°, Reduzierungen, Muffe/Spitzende-Anschlusslogik, Gefälle und Fließrichtung.
- Alte KG-Bibliothekseinträge entfallen in Grundbibliothek v5.
