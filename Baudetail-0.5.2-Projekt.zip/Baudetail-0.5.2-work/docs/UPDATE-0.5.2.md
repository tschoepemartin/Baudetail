# Baudetail 0.5.2

Gezielter Korrekturstand auf Basis 0.5.1.

- Schnellbutton **Spiegeln** verwendet jetzt dieselbe echte Spiegeltransformation wie das funktionierende Spiegeln im Objektmenü; keine 180°-Drehung mehr.
- KG-2000-Bögen neu modelliert: gekrümmte Mittelliniengeometrie statt Knick/Blob, Muffe und Spitzende als echte Anschlüsse.
- Im Schnitt besitzt der Bogen ausschließlich die Abgangsrichtung **oben / unten**; der Bogenwinkel bleibt DN-abhängig auswählbar.
- KG-2000-Snap richtet Anschlussachsen beim Andocken automatisch gegeneinander aus und übernimmt die nötige Rotation.
- Connectoren folgen Spiegelung, Bogenrichtung und real gezeichneter Bogenendposition.
- Fließpfeil folgt beim Bogen der gekrümmten Geometrie. Standard bleibt: **vorwärts = von Muffe zum Spitzende**.
- versionCode 15, versionName 0.5.2.
