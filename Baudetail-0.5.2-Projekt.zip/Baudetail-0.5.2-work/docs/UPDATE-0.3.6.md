# Baudetail 0.3.6

- Unterfundamente sind geschlossene Polygonflächen statt Rechteck + Einzelkeile.
- Fundament mit Keil / Fundament ohne Keil als klare Auswahl.
- Keileinbindung standardmäßig automatisch 1/3 der Bauteilhöhe; alternativ manuell in cm.
- Fundamentbreite und Dicke werden in cm bearbeitet; Breite bleibt unter dem Bauteil zentriert.
- Treppenfundamente folgen im Schnitt als gestufte Polygonfläche der Unterseite der Blockstufen.
- Beton-Unterfundament nutzt im Schnitt die C20/25-Materialschraffur/Körnung, sofern in der Bibliothek vorhanden.
- Direkte Griffe für Breite, Dicke und Einbindung; beim Ziehen Live-Maß in cm.
- Standard: normale Bauteile Fundament mit Keil, Treppen Fundament ohne Keil.
