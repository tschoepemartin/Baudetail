# Baudetail 0.3.5

Gezielter Bedien- und Konstruktionsausbau auf Basis von 0.3.4.

- Intelligentes Unterfundament als eigenes, mit dem Bauteil verknüpftes Objekt. Standardmaterial C20/25; Standarddicke 200 mm; Überstand 100 mm. Rückenstütze/Keil bei normalen Bauteilen standardmäßig aktiv, bei Treppen deaktiviert. Maße bleiben editierbar.
- Höhenkoten mit Erstellmenü, Leader/Bezugshöhe, manueller oder relativer Berechnung. Relative Koten verwenden die geometrische Höhendifferenz zum Leader. Darstellungspositionen in Schnitt und Draufsicht sind getrennt verschiebbar.
- Bemaßung per Ziehen, Winkelsnap oder frei drehbar. Live-Winkelanzeige während des Drehens.
- Pfeile und Hinweise werden per Ziehen erzeugt. Hinweistext ist jederzeit editierbar.
- Sichtbarer Text von Text-/Hinweisobjekten öffnet beim Antippen direkt die Textbearbeitung.
- Vorgegebene Auswahlen verwenden Dropdowns/Checkboxen statt Freitext, aktive Optionen sind mit Häkchen markiert.
- Ausgewählte intelligente Bauteile zeigen ihre Fang-/Referenzpunkte und vorhandene Verknüpfungen an.
- Stufentyp 15/40/100 bleibt bevorzugter Standard und wird in der Auswahl sichtbar markiert.

App-ID und Dateiformate bleiben unverändert. versionCode=9, versionName=0.3.5.
