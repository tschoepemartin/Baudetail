# Baudetail 0.5.1

Gezielter Korrektur-/Ausbau-Patch auf Basis von 0.5.0.

## Maße
- Auto-Maße sind ansichtsbezogen: Bord im Schnitt nur Breite + Höhe; keine Bauteillänge.
- Fundament im Schnitt: Breite + Dicke; Dicke ab Unterkante des Hauptbauteils.
- Maßtexte ohne Präfixe wie „Breite“/„Dicke“.
- dünnere Maß-/Hilfslinien.
- automatische Maße erhalten eigene Spuren; Bordbreite oberhalb, Fundamentbreite unterhalb, vertikale Fundamentmaße weiter außen.
- Zahl/Dimension ist per Hit-Test auswählbar; Verschieben verändert nur den Darstellungs-Offset, Referenzpunkte bleiben an der Geometrie.
- horizontale Auto-Maße nur hoch/runter, vertikale nur links/rechts verschiebbar.
- alte 0.5.0-Auto-Maße werden beim Projektöffnen auf Maßmodell v2 migriert; nicht mehr gültige bzw. verwaiste Auto-Maße werden entfernt.
- Löschen eines Bauteils löscht abhängige Auto-Maße und gekoppelte Fundamente; Undo arbeitet weiter über die Zeichnungshistorie.

## Auswahl, Snap, Drehen
- Auswahl-Hitbox und Snap-Geometrie sind getrennt.
- Treppen-Snap basiert auf realen Stufenkanten/-punkten, nicht auf der großen Auswahl-Boundingbox.
- intelligente Komponenten starten in Draufsicht standardmäßig um 90° gedreht.
- freie Objektrotation rastet in 15°-Schritten; Winkelanzeige wird sichtbar vom Finger/Stift versetzt angezeigt.
- KG2000-Auswahl-Hitbox umfasst das vollständige Bauteil mit Touch-Toleranz; Snap bleibt an echten Anschlüssen.
- Schnellaktionen bei Auswahl: Objektmenü, Duplizieren, Spiegeln/180°-Flip.
- Duplizieren nimmt gekoppelte Fundamente/Auto-Maße mit und remappt IDs/Quellbezüge.

## Einlauf-/Sinkkasten
- Standard: 18,5 cm Breite, 61 cm Höhe, 50 cm Länge, NW150, DN160.
- Rohr-Achse ab OK standardmäßig 50 cm.
- Anschluss-Connector wird aus derselben Rohr-Achsenhöhe berechnet; Änderung des Auslasses verschiebt damit auch den Snap-Anschluss.
- KG2000-kompatibler Muffen-Connector.
- Draufsicht: Rost folgt Kastenlänge und Rinnen-Nennweite.

## KG 2000
- altes „KG“ wird bei Import der neuen Bibliothek aus dem Katalog bereinigt.
- DN/OD: 110, 125, 160, 200, 250, 315, 400, 500, 630.
- Bögen mit DN-abhängigem Herstellerprogramm.
- Y-Stück 45° nur mit hinterlegten Herstellerkombinationen.
- exzentrische Reduzierungen: große Seite Spitzende, kleine Seite Muffe.
- hinterlegte Reduzierungen: 125/110, 160/110, 160/125, 200/160, 250/200, 315/250, 400/315, 500/400, 630/500.
- hinterlegte Baulängen aus Herstellerzeichnungen soweit verfügbar: 176,5 / 210,5 / 211 / 254 / 303 / 349 / 425 / 691 / 660 mm.
- KG2000-Passstück „beidseitig Spitzende“: Standard DN110, 50 cm; DN und Länge veränderbar.
- Fließrichtung vorwärts/rückwärts und Pfeilanzeige veränderbar.
- Connector-Snap prüft DN sowie Muffe ↔ Spitzende; Einlaufkasten-Auslass ist eingebunden.

## Hinweis zur Prüfung
Die Struktur, JSON-Dateien, Bibliotheks-Hashes und ZIP-Integrität werden vor Ausgabe geprüft. Der verbindliche Android-Compile erfolgt wie bei den vorherigen Versionen über den GitHub-Actions-Workflow.
