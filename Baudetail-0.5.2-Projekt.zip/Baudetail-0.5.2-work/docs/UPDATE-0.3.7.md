# Baudetail 0.3.7

- Treppen-Unterfundamente erhalten die Auswahl **getrennt** oder **schräg**.
- Beide Varianten werden als zusammenhängende geschlossene Polygonfläche erzeugt, nicht als Sammlung einzelner Rechtecke.
- Getrennt/stufig folgt Ober- und Unterkante den einzelnen Stufenfeldern.
- Schräg/durchgehend folgt die Oberkante der Treppenunterseite; die Unterkante läuft als gerade geneigte Linie durch.
- Betonmaterial und vorhandene C20/25-Schnittschraffur bleiben erhalten.
- Vorhandene Fundamentparameter (Breite, Dicke, Einbindung in cm) bleiben Bestandteil des Fundamentobjekts.
- versionCode=11, versionName=0.3.7.
