# Baudetail 0.4.0

- Automatische Maße kantenbezogen und nach Maßketten gruppierbar.
- Unterfundamente standardmäßig hinter Hauptbauteilen; in Draufsicht standardmäßig unsichtbar.
- Treppenfundament standardmäßig schräg, mit konstanter Dicke unter VK Stufe und Abschluss bis Hinterkante.
- Überlagernde Unterfundamente verschmelzen optisch.
- Parametrische Einlauf-/Sinkkästen passend zu Rinnen mit Rohranschluss, Rost und Laubfangkorb.
- Neue GaLaBau-Grundbibliothek v4 mit passenden Rinnen-/Einlaufkasten-Bauteilen.
- versionCode=12, versionName=0.4.0.
