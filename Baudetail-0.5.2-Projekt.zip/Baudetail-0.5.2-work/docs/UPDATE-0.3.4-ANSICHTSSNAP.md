# Baudetail 0.3.4 – Ansichtssnap-Korrektur

- Intelligente Bauteile besitzen nun getrennte Darstellungs-Offsets und Drehungen für Schnitt und Draufsicht. Manuelles Ausrichten in einer Ansicht verschiebt die andere Ansicht nicht mehr.
- Prioritäts-Snap koppelt Außenkanten semantisch; verknüpfte Folger werden in Schnitt und Draufsicht an denselben Anschlusskanten gehalten.
- In der Draufsicht darf die Anschlusskante eines folgenden Bauteils die Länge der führenden Kante übernehmen (z. B. 1000 mm Treppenbreite). Schnittdicken werden dabei nicht gestreckt.
- Prioritätslogik: Führend > Normal > Folgend. Auch Normal kann damit ein Folgend-Objekt führen.
- Treppendialog wählt bei neuen Treppen bevorzugt 15/40/100 als Standardstufe und übernimmt deren 1000-mm-Länge als Standardbreite.
- Im Prioritätsdialog ist die aktuell gewählte Priorität rechts mit einem Häkchen markiert.
