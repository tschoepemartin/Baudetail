package de.baudetail.core
import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

val cadLevels=listOf("Oberfläche","Unterbau","Fundament","Leitungen","Untergrund")
val viewProfiles=listOf("Oberflächenplan","Fundamentplan","Entwässerungs-/Leitungsplan","Pflanzplan","Schnitt")
fun Drawing.profile()=(extensions["viewProfile"] as? JsonPrimitive)?.contentOrNull?:if(viewMode()=="section")"Schnitt"else"Oberflächenplan"
fun Drawing.withProfile(value:String)=withViewMode(if(value=="Schnitt")"section"else"top").let{it.copy(extensions=JsonObject(it.extensions+("viewProfile" to JsonPrimitive(value))))}
fun visibleIn(e:Entity,d:Drawing):Boolean {
 if(e.num("hidden")==1.0)return false
 if(d.viewMode()=="section")return e.placement.visibleSection
 if(isFoundation(e)&&e.str("showInTop","false")!="true")return false
 if(!e.placement.visibleTop)return false
 val level=if(e.placement.level=="Oberfläche"&&e.kind=="component"&&e.name.contains("fundament",true))"Fundament"else e.placement.level
 return when(d.profile()){"Oberflächenplan","Pflanzplan"->level=="Oberfläche";"Fundamentplan"->level in setOf("Fundament","Unterbau");"Entwässerungs-/Leitungsplan"->level in setOf("Leitungen","Oberfläche");else->true}
}
fun closedContour(e:Entity)=e.kind in setOf("rect","circle","polygon","area","building")||(e.kind=="polyline"&&e.points.size>=4&&e.points.first().distance(e.points.last())<0.001)
fun asArea(e:Entity):Entity {require(closedContour(e)){"Nur geschlossene Konturen sind Flächen"};return if(e.kind=="circle")e.copy(quantityUnit="m²")else e.copy(kind="area",points=if(e.points.size>3&&e.points.first()==e.points.last())e.points.dropLast(1)else e.points,quantityUnit="m²")}
fun surfaceArea(e:Entity)=if(e.kind=="circle")PI*e.num("radiusMm").pow(2)else if(closedContour(e))area(e.points)else 0.0
fun perimeter(e:Entity)=if(e.kind=="circle")2*PI*e.num("radiusMm")else length(e.points,closedContour(e))
fun contour(e:Entity):List<Vec> = if(e.kind=="circle")(0 until 128).map{val t=it*2*PI/128;(e.points.firstOrNull()?:Vec())+Vec(cos(t),sin(t))*e.num("radiusMm")}else e.points
fun LibraryEntry.attribute(key:String,default:Double)=(attributes[key] as? JsonPrimitive)?.doubleOrNull?.takeIf{it.isFinite()&&it>0}?:default
fun materialStyle(entry:LibraryEntry,section:Boolean)=if(section)entry.appearance?.section?:entry.style else entry.appearance?.top?:entry.style
fun LibraryEntry.isGrassSectionComponent():Boolean = type=="component" && (category.contains("Vegetation/Rasen",true)||name.contains("Rasen",true)) && ((attributes["Darstellung"] as? JsonPrimitive)?.contentOrNull?.contains("Schnitt",true)==true || views["top"]==views["section"])
fun componentInstance(entry:LibraryEntry,at:Vec):Entity {
 val depth=entry.attribute("depth_mm",entry.attribute("section_width_mm",entry.attribute("width_mm",400.0)))
 val height=entry.attribute("section_height_mm",entry.attribute("height_mm",150.0))
 val width=entry.attribute("length_mm",entry.attribute("top_height_mm",entry.attribute("width_mm",1000.0)))
 val grass=entry.isGrassSectionComponent()
 val topWidth=entry.attribute("top_width_mm",entry.attribute("width_mm",1000.0))
 val topHeight=entry.attribute("top_height_mm",if(grass)entry.attribute("width_mm",1000.0)else entry.attribute("height_mm",500.0))
 val family=entry.smartFamily()
 return Entity(kind="component",name=entry.name,libraryId=entry.id,view=if(entry.views.containsKey("top")&&entry.geometry.all{it.view=="top"})"top"else"section",points=listOf(at),style=entry.style,children=entry.geometry,params=buildJsonObject{
  put("widthMm",depth);put("heightMm",height);put("depthMm",depth);put("stepHeightMm",height);put("stairWidthMm",width);put("isStep",entry.isStairStep());put("topWidthMm",topWidth);put("topHeightMm",topHeight);put("sectionWidthMm",depth);put("sectionHeightMm",height);put("grassTopFallback",grass);entry.views.forEach{(k,v)->put("asset_"+k,v)};put("libraryViews",true);put("mirrored",0)
  put("componentFamily",family);put("variantGroup",entry.variantGroup());put("libraryCategory",entry.category);put("labelEnabled",false);put("labelMode","auto");put("fillMode","auto");put("snapPriority","normal");put("topRotationDelta",90.0)
  if(family=="pipe"){
   val system=(entry.attributes["pipe_system"] as? JsonPrimitive)?.contentOrNull ?: (entry.attributes["Material"] as? JsonPrimitive)?.contentOrNull.orEmpty()
   val fitting=(entry.attributes["fitting_type"] as? JsonPrimitive)?.contentOrNull ?: "pipe"
   put("dnMm",entry.attrNumber("DN","DN_mm","dn_mm",default=height));put("pipeSystem",system);put("fittingType",fitting);put("pipeLengthMm",entry.attrNumber("length_mm","width_mm",default=1000.0));put("bendAngle",entry.attrNumber("angle_deg",default=45.0));put("branchDnMm",entry.attrNumber("branch_dn_mm","DN","DN_mm",default=height));put("inletDnMm",entry.attrNumber("inlet_dn_mm","DN","DN_mm",default=height));put("outletDnMm",entry.attrNumber("outlet_dn_mm","DN","DN_mm",default=height));put("slope",0.0);put("flowArrow","true");put("flowDirection","forward");put("orientation","horizontal");put("verticalDirection","down");put("verticalLengthMm",1000.0);put("doubleSpigot",fitting=="double_spigot")
  }

  if(family=="channel_box"){
   put("boxWidthMm",entry.attrNumber("box_width_mm","width_mm",default=185.0));put("boxHeightMm",entry.attrNumber("box_height_mm","section_height_mm",default=610.0));put("boxLengthMm",entry.attrNumber("box_length_mm","box_depth_mm",default=500.0));put("channelNominalWidthMm",entry.attrNumber("channel_nominal_width_mm","NW","NW_mm",default=150.0));put("pipeDnMm",entry.attrNumber("pipe_dn_mm","DN","DN_mm",default=160.0));put("pipeAxisFromTopMm",entry.attrNumber("pipe_axis_from_top_mm",default=500.0));put("pipeOutlet","left");put("leafBasket","true");put("grateVisible","true")
  }
  if(family=="retaining_wall"){put("wallHeightMm",entry.attrNumber("wall_height_mm","Höhe_mm","height_mm",default=height));put("footDepthMm",entry.attrNumber("foot_depth_mm","Fußtiefe_mm","Breite_mm","section_width_mm",default=depth));put("wallThicknessMm",entry.attrNumber("wall_thickness_mm","Wandstärke_mm",default=70.0));put("footThicknessMm",entry.attrNumber("foot_thickness_mm","Fußstärke_mm",default=100.0));put("elementLengthMm",entry.attrNumber("element_length_mm","Länge_mm","length_mm","width_mm",default=topWidth));put("footSide","right")}
 })
}
fun stairDepth(e:Entity)=e.num("depthMm",e.children.firstOrNull()?.num("depthMm",400.0)?:400.0)
fun stairLength(e:Entity)=(stairCount(e)-1)*stairGoing(e)+stairDepth(e)
fun templateEntry(name:String,category:String,entities:List<Entity>,origin:Vec,previous:LibraryEntry?=null):LibraryEntry {
 require(entities.isNotEmpty())
 return LibraryEntry(id=previous?.id?:uid(),type="assembly-template",name=name,category=category,version=(previous?.version?:0)+1,geometry=entities.map{transform(it,translation=Vec()-origin).copy(bindings=emptyList(),anchors=emptyList())},attributes=buildJsonObject{put("origin_x_mm",0);put("origin_y_mm",0)},extensions=buildJsonObject{put("previewKind","geometry")})
}
fun instantiateTemplate(entry:LibraryEntry,at:Vec):Entity {
 val copies=entry.geometry.map{it.copy(id=uid(),bindings=emptyList(),anchors=emptyList())}
 return Entity(kind="component",name=entry.name,points=listOf(at),children=copies,params=buildJsonObject{put("frozenTemplate",true);put("templateScale",1.0);put("templateId",entry.id);put("templateVersion",entry.version);put("mirrored",0)})
}
val measureProfiles=listOf("Aus","Minimal","Ausführung","Vollständig","Benutzerdefiniert")
fun metrics(e:Entity,d:Drawing):List<String> = when {
 isFoundation(e)-> if(d.viewMode()=="section") listOf("Breite","Dicke") else emptyList()
 e.smartFamily()=="curb" -> if(d.viewMode()=="section") listOf("Breite","Höhe") else listOf("Länge","Breite")
 isChannelBox(e)-> if(d.viewMode()=="section") listOf("Breite","Höhe","Rohr DN","Rohrachse ab OK") else listOf("Länge","Breite","Rinnenbreite")
 isStair(e)-> if(d.viewMode()=="section") listOf("Gesamthöhe","Stufenhöhe","Stufentiefe","Auftritt","Überdeckung","Stufengefälle","Anzahl") else listOf("Gesamtlänge","Breite","Stufentiefe","Auftritt","Überdeckung","Anzahl")
 isKg2000(e)-> listOf("DN","Länge","Gefälle")
 closedContour(e)->listOf("Fläche","Umfang","Länge","Breite","Gefälle")
 else->listOf("Länge","Breite","Höhe","DN","Gefälle")
}
fun metricValue(e:Entity,key:String):Double = when(key){"Fläche"->surfaceArea(e);"Umfang"->perimeter(e);"Gesamtlänge"->stairLength(e);"Gesamthöhe"->stairTotalHeight(e);"Stufenhöhe"->stairRise(e);"Stufentiefe"->stairDepth(e);"Auftritt"->stairGoing(e);"Überdeckung"->stairDepth(e)-stairGoing(e);"Anzahl"->stairCount(e).toDouble();"Stufengefälle","Gefälle"->e.num("slope",e.num("percent"));"Dicke"->e.num("thicknessMm",e.num("heightMm",entityBounds(e).height));"Einbindung"->e.num("embedMm");"Länge"->if(isKg2000(e))e.num("pipeLengthMm",1000.0)else e.num("boxLengthMm",e.num("topWidthMm",entityBounds(e).width));"Tiefe"->e.num("boxLengthMm",e.num("topHeightMm",entityBounds(e).height));"Rinnenbreite"->e.num("channelNominalWidthMm");"Rohr DN"->e.num("pipeDnMm",e.num("dnMm"));"Rohrachse ab OK"->e.num("pipeAxisFromTopMm");"Breite"->if(isFoundation(e))e.num("foundationWidthMm",entityBounds(e).width) else e.num("boxWidthMm",e.num("widthMm",entityBounds(e).width));"Höhe"->e.num("boxHeightMm",e.num("heightMm",entityBounds(e).height));"DN"->e.num("dnMm",e.num("DN"));else->if(closedContour(e))entityBounds(e).height else if(e.points.size>1)length(e.points)else e.num("widthMm")}
fun automaticMeasures(e:Entity,d:Drawing,profile:String):List<Entity>{
 val available=metrics(e,d)
 val keys=when(profile){"Aus"->emptyList();"Minimal"->available.take(2);"Ausführung"->available.take(6);else->available}
 val gap=d.sheet.scale*8.0;var hLane=0;var vLane=0
 return keys.mapNotNull{key->
  val witnesses=metricWitnesses(e,key,d)?:return@mapNotNull null
  val vertical=kotlin.math.abs(witnesses[1].y-witnesses[0].y)>kotlin.math.abs(witnesses[1].x-witnesses[0].x)
  val lane=if(vertical)++vLane else ++hLane;val shift=gap*lane
  val origin=viewBounds(e,d).center
  val defaultDx=if(vertical){if(isFoundation(e))gap*2.0 else shift}else 0.0
  val defaultDy=if(!vertical && e.smartFamily()=="curb" && key=="Breite")-shift else if(!vertical)shift else 0.0
  Entity(kind="dimension",points=listOf(origin),layerId=e.layerId,placement=e.placement,style=Style(stroke="#354B48",widthMm=0.08,textPaperMm=2.6),params=buildJsonObject{put("sourceId",e.id);put("metric",key);put("prefix","");put("unit",when(key){"Fläche"->"m²";"Gefälle","Stufengefälle"->"%";"Anzahl"->"Stk";"Rohr DN","DN"->"mm";else->"cm"});put("decimals",if(key in setOf("Rohr DN","DN"))0 else 1);put("auto",1);put("measureVersion",2);put("mode",if(vertical)"vertical"else"horizontal");put("offsetMm",0.0);put("dimDx",defaultDx);put("dimDy",defaultDy);put("metricOriginX",origin.x);put("metricOriginY",origin.y);put("measureChainKey",(e.groupId?:e.id)+":"+(if(vertical)"V"else"H"));put("chainLane",lane)})
 }
}

fun dimensionLabel(e:Entity,d:Drawing):String {
 val source=d.entities.find{it.id==e.str("sourceId")};val value=if(source!=null&&e.str("metric").isNotEmpty())metricValue(source.copy(points=resolvedPoints(source,d)),e.str("metric"))else dimensionValue(e,d)
 val unit=e.str("unit","mm");val factor=when(unit){"cm"->10.0;"m"->1000.0;"m²"->1e6;else->1.0}
 return e.str("prefix",e.text)+fmt(value/factor,e.num("decimals",2.0).toInt().coerceIn(0,6))+e.str("suffix",if(unit.isEmpty())""else" $unit")
}
fun viewEntity(e:Entity,d:Drawing):Entity {
 var result=e.copy(points=resolvedPoints(e,d))
 if(e.kind=="component"){val off=smartViewOffset(e,d.viewMode());result=result.copy(points=result.points.map{it+off},rotation=smartViewRotation(e,d.viewMode()))}
 if(e.kind=="elevation"){val off=annotationViewOffset(e,d.viewMode());result=result.copy(points=result.points.map{it+off})}
 if(e.str("libraryViews")=="true")result=if(e.str("isStep")=="true")result.withNum("widthMm",stairDepth(e)).withNum("heightMm",e.num(if(d.viewMode()=="section")"stepHeightMm"else"stairWidthMm",1000.0))else result.withNum("widthMm",e.num(if(d.viewMode()=="section")"sectionWidthMm"else"topWidthMm",1000.0)).withNum("heightMm",e.num(if(d.viewMode()=="section")"sectionHeightMm"else"topHeightMm",500.0))
 if(isRetainingWall(e))result=if(d.viewMode()=="section")result.withNum("widthMm",e.num("footDepthMm",400.0)).withNum("heightMm",e.num("wallHeightMm",800.0))else result.withNum("widthMm",e.num("elementLengthMm",1000.0)).withNum("heightMm",e.num("footDepthMm",400.0))
 if(isChannelBox(e))result=if(d.viewMode()=="section")result.withNum("widthMm",e.num("boxWidthMm",185.0)).withNum("heightMm",e.num("boxHeightMm",610.0))else result.withNum("widthMm",e.num("boxLengthMm",500.0)).withNum("heightMm",e.num("boxWidthMm",185.0))
 if(isPipe(e)){val dn=e.num("dnMm",100.0);val vertical=e.str("orientation","horizontal")=="vertical";val len=e.num("pipeLengthMm",e.num("topWidthMm",1000.0));result=if(vertical)result.withNum("widthMm",dn).withNum("heightMm",e.num("verticalLengthMm",1000.0))else result.withNum("widthMm",len).withNum("heightMm",dn)}
 return result
}
fun viewBounds(e:Entity,d:Drawing)=when{isFoundation(e)->Bounds.of(foundationOutline(e,d));isStair(e)->Bounds.of(stairReferencePoints(e,d.viewMode()));isKg2000(e)->kg2000Bounds(e,d);e.kind=="component"->Bounds.of(componentReferencePoints(e,d));else->entityBounds(viewEntity(e,d))}
fun objectLabelPosition(e:Entity,d:Drawing):Vec {
 val b=viewBounds(e,d);val center=b.center
 return if("labelDx" in e.params||"labelDy" in e.params)center+Vec(e.num("labelDx"),e.num("labelDy")) else Vec(center.x,b.min.y-d.sheet.scale*8.0)
}
fun componentReferencePoints(e:Entity,d:Drawing):List<Vec>{val v=viewEntity(e,d);val origin=v.points.firstOrNull()?:Vec();val b=entityBounds(v);return (rectangle(b.min,b.max)+b.center).map{val q=it-origin;origin+Vec(q.x,if(v.num("mirrored")==1.0)-q.y else q.y).rotate(v.rotation)}}
fun metricWitnesses(e:Entity,key:String,d:Drawing):List<Vec>? {
 if(isFoundation(e)){
  val o=foundationOutline(e,d);if(o.size<3)return null;val b=Bounds.of(o);val src=d.entities.find{it.id==e.str("sourceId")}
  return when(key){"Breite"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y));"Dicke"->src?.let{val sb=viewBounds(it,d);val top=sb.max.y;listOf(Vec(b.max.x,top),Vec(b.max.x,top+foundationThicknessMm(e)))}?:listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y));"Einbindung"->src?.let{val sb=viewBounds(it,d);listOf(Vec(b.max.x,sb.max.y-foundationEmbedMm(e,it,d)),Vec(b.max.x,sb.max.y))};else->null}
 }
 if(isChannelBox(e)){
  val b=viewBounds(e,d);return when(key){"Breite"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y));"Höhe"->listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y));"Länge"->if(d.viewMode()=="top")listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y))else null;"Tiefe"->if(d.viewMode()=="top")listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y))else null;"Rinnenbreite"->if(d.viewMode()=="top"){val w=e.num("channelNominalWidthMm",100.0);listOf(Vec(b.center.x-w/2,b.min.y),Vec(b.center.x+w/2,b.min.y))}else null;"Rohr DN"->if(d.viewMode()=="section"){val dn=e.num("pipeDnMm",100.0);val y=b.min.y+e.num("pipeAxisFromTopMm",500.0);listOf(Vec(b.max.x-dn,y),Vec(b.max.x,y))}else null;"Rohrachse ab OK"->if(d.viewMode()=="section"){val y=b.min.y+e.num("pipeAxisFromTopMm",500.0);listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,y))}else null;else->null}
 }
 if(isStair(e)){
  val pair=when(key){"Gesamtlänge"->Vec() to Vec(stairLength(e),0.0);"Gesamthöhe"->if(d.viewMode()=="section")Vec() to Vec(0.0,-stairTotalHeight(e))else return null;"Breite"->if(d.viewMode()=="top")Vec() to Vec(0.0,e.num("widthMm",1200.0))else return null;"Stufenhöhe"->if(d.viewMode()=="section")Vec() to Vec(0.0,-stairRise(e))else return null;"Stufentiefe"->Vec() to Vec(stairDepth(e),0.0);"Auftritt"->Vec() to Vec(stairGoing(e),0.0);"Überdeckung"->Vec(stairGoing(e),0.0) to Vec(stairDepth(e),0.0);else->return null}
  return listOf(assemblyPoint(e,pair.first,d.viewMode()),assemblyPoint(e,pair.second,d.viewMode()))
 }
 val pts=resolvedPoints(e,d);if(key=="Länge"&&!closedContour(e)&&pts.size==2)return pts
 val b=viewBounds(e,d);return when(key){
  "Breite"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y))
  "Höhe"->listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y))
  "Länge"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y))
  else->null
 }
}
