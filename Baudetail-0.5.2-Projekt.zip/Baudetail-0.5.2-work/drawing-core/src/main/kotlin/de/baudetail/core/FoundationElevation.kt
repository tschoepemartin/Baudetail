package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*

fun isFoundation(e:Entity)=e.kind=="foundation"
fun supportsFoundation(e:Entity)=isStair(e)||(e.kind=="component"&&e.smartFamily() !in setOf("grass","pipe"))
fun foundationFor(source:Entity,d:Drawing)=d.entities.find{isFoundation(it)&&it.str("sourceId")==source.id}

/** Smart underfoundation geometry. The foundation is ONE closed polygon. It
 * follows the linked construction object and remains centred below it. UI values
 * are shown in cm; the model deliberately stays in mm. */
fun foundationWidthMm(e:Entity,source:Entity,d:Drawing):Double {
 val b=viewBounds(source,d)
 val fallback=if(d.viewMode()=="section")b.width+200.0 else minOf(b.width,b.height)+200.0
 return e.num("foundationWidthMm",fallback).coerceAtLeast(if(d.viewMode()=="section")b.width else minOf(b.width,b.height))
}
fun foundationThicknessMm(e:Entity)=e.num("thicknessMm",200.0).coerceAtLeast(1.0)
fun foundationEmbedMm(e:Entity,source:Entity,d:Drawing):Double {
 val automatic=e.str("embedMode","auto")!="manual"
 val sourceHeight=viewBounds(source,d).height.coerceAtLeast(0.0)
 return (if(automatic)sourceHeight/3.0 else e.num("embedMm",sourceHeight/3.0)).coerceIn(0.0,sourceHeight)
}

private fun stairFoundationTopProfile(source:Entity):List<Vec> {
 val count=stairCount(source);val going=stairGoing(source);val depth=stairDepth(source)
 val rise=stairRise(source);val eff=stairEffectiveRise(source)
 // Real underside envelope of the overlapping block steps (local stair coordinates).
 val intervals=(0 until count).map{i->
  val x0=i*going; val x1=x0+depth; val y=-(i+1)*eff+rise
  Triple(x0,x1,y)
 }
 val xs=intervals.flatMap{listOf(it.first,it.second)}.distinct().sorted()
 if(xs.size<2)return emptyList()
 val profile=mutableListOf<Vec>()
 for(i in 0 until xs.lastIndex){
  val x0=xs[i];val x1=xs[i+1];val mid=(x0+x1)/2
  val y=intervals.filter{mid>=it.first-1e-6&&mid<=it.second+1e-6}.maxOfOrNull{it.third}?:continue
  if(profile.isEmpty()||profile.last().x!=x0)profile.add(Vec(x0,y))
  else if(profile.last().y!=y)profile.add(Vec(x0,y))
  profile.add(Vec(x1,y))
 }
 return profile.fold(mutableListOf()){acc,v->if(acc.isEmpty()||acc.last().distance(v)>1e-6)acc.add(v);acc}
}

private fun stairFoundationSection(e:Entity,source:Entity):List<Vec> {
 val top=stairFoundationTopProfile(source)
 if(top.size<2)return emptyList()
 val thick=foundationThicknessMm(e)
 val execution=e.str("stairFoundationExecution","sloped")
 val lower=if(execution=="sloped") {
  // Constant vertical thickness below every tread front edge (VK Stufe).
  // The lower line is derived from the collinear front edges and extended to the
  // rear edge of the last block, so the footing remains fully closed at the back.
  val count=stairCount(source);val going=stairGoing(source);val rise=stairRise(source);val eff=stairEffectiveRise(source)
  val fronts=(0 until count).map{i->Vec(i*going,-(i+1)*eff+rise)}
  val a=fronts.first();val z=fronts.last();val slope=if(kotlin.math.abs(z.x-a.x)<1e-9)0.0 else (z.y-a.y)/(z.x-a.x)
  fun lowerY(x:Double)=a.y+slope*(x-a.x)+thick
  listOf(Vec(top.last().x,lowerY(top.last().x)),Vec(top.first().x,lowerY(top.first().x)))
 } else {
  // "Getrennt / stufig": one editable polygon whose lower edge follows every stair bay.
  // It is deliberately NOT assembled from separate rectangles.
  top.asReversed().map{Vec(it.x,it.y+thick)}
 }
 return (top+lower).map{assemblyPoint(source,it,"section")}
}

fun foundationOutline(e:Entity,d:Drawing):List<Vec> {
 val source=d.entities.find{it.id==e.str("sourceId")} ?: return e.points
 if(d.viewMode()=="section"&&isStair(source))return stairFoundationSection(e,source)
 val b=viewBounds(source,d);val thick=foundationThicknessMm(e);val width=foundationWidthMm(e,source,d)
 if(d.viewMode()!="section") {
  // In plan the foundation follows the object's long direction and is centred
  // in the short direction. This avoids the old blanket expansion on all sides.
  return if(b.width>=b.height){val half=width/2;rectangle(Vec(b.min.x,b.center.y-half),Vec(b.max.x,b.center.y+half))}
  else {val half=width/2;rectangle(Vec(b.center.x-half,b.min.y),Vec(b.center.x+half,b.max.y))}
 }
 val top=b.max.y;val bottom=top+thick;val half=width/2;val left=b.center.x-half;val right=b.center.x+half
 val withWedge=e.str("foundationType",if(e.str("wedgeEnabled","false")=="true")"with_wedge" else "without_wedge")=="with_wedge"
 if(!withWedge)return rectangle(Vec(left,top),Vec(right,bottom))
 val embed=foundationEmbedMm(e,source,d);val side=e.str("wedgeSide","both")
 val pts=when(side){
  "left"->listOf(Vec(left,top),Vec(b.min.x,top-embed),Vec(b.max.x,top),Vec(right,top),Vec(right,bottom),Vec(left,bottom))
  "right"->listOf(Vec(left,top),Vec(b.min.x,top),Vec(b.max.x,top-embed),Vec(right,top),Vec(right,bottom),Vec(left,bottom))
  else->listOf(Vec(left,top),Vec(b.min.x,top-embed),Vec(b.max.x,top-embed),Vec(right,top),Vec(right,bottom),Vec(left,bottom))
 }
 return pts
}

/** Deprecated compatibility helper: wedge is now integrated into foundationOutline. */
fun foundationWedges(e:Entity,d:Drawing):List<List<Vec>> = emptyList()

fun foundationEditHandles(e:Entity,d:Drawing):Map<String,Vec> {
 val source=d.entities.find{it.id==e.str("sourceId")}?:return emptyMap();if(d.viewMode()!="section"||isStair(source))return emptyMap()
 val b=viewBounds(source,d);val out=Bounds.of(foundationOutline(e,d))
 return mapOf("foundationWidthLeft" to Vec(out.min.x,out.max.y),"foundationWidthRight" to Vec(out.max.x,out.max.y),"foundationThickness" to Vec(out.center.x,out.max.y),"foundationEmbed" to Vec(b.center.x,b.max.y-foundationEmbedMm(e,source,d)))
}

fun annotationViewOffset(e:Entity,view:String)=Vec(e.num("${view}Dx"),e.num("${view}Dy"))
fun moveAnnotationInView(e:Entity,view:String,delta:Vec)=e.withNum("${view}Dx",e.num("${view}Dx")+delta.x).withNum("${view}Dy",e.num("${view}Dy")+delta.y)

fun elevationLeader(d:Drawing):Entity?=d.entities.lastOrNull{it.kind=="elevation"&&it.str("elevationRole")=="leader"}
fun elevationValueMm(e:Entity,d:Drawing):Double {
 val role=e.str("elevationRole",e.str("mode","manual"))
 if(role=="leader"||role=="manual"||role=="absolute")return e.num("heightMm")
 val leader=elevationLeader(d)?:return e.num("heightMm")
 val leaderAt=resolvedPoints(leader,d).firstOrNull()?:leader.points.firstOrNull()?:Vec()
 val here=resolvedPoints(e,d).firstOrNull()?:e.points.firstOrNull()?:Vec()
 // CAD section Y grows downwards: points above the reference have a higher elevation.
 return leader.num("heightMm")+(leaderAt.y-here.y)+e.num("heightOffsetMm")
}
