package de.baudetail.ui.dialogs
import androidx.compose.runtime.*
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
@Composable fun LevelDialog(e:Entity,onDismiss:()->Unit,onSave:(Entity)->Unit){val p=e.placement
 FormDialog("Ebene und Sichtbarkeit",listOf(Field("level","Ebene",p.level,choices=cadLevels),Field("z","Z-Höhe mm (optional)",p.zMm?.let{fmt(it)}.orEmpty()),Field("top","Oberkante mm",p.topMm?.let{fmt(it)}.orEmpty()),Field("bottom","Unterkante mm",p.bottomMm?.let{fmt(it)}.orEmpty()),Field("vt","Draufsicht sichtbar",if(p.visibleTop)"ja"else"nein",checkbox=true),Field("vs","Schnitt sichtbar",if(p.visibleSection)"ja"else"nein",checkbox=true),Field("hidden","Verdeckt / gestrichelt",if(p.hidden)"ja"else"nein",checkbox=true)),onDismiss){v->
  fun optional(k:String):Double? {val s=v[k].orEmpty();return if(s.isBlank())null else requireNotNull(parseNumber(s)){"Ungültige Höhe"}}
  val top=optional("top");val bottom=optional("bottom");require(top==null||bottom==null||top>=bottom){"Oberkante liegt unter Unterkante"};onSave(e.copy(placement=Placement(v.getValue("level"),optional("z"),top,bottom,v["vt"]=="ja",v["vs"]=="ja",v["hidden"]=="ja")))
 }
}
@Composable fun MeasureDialog(e:Entity,onDismiss:()->Unit,onSave:(Entity)->Unit){
 val fields=listOf(Field("prefix","Präfix / Name",e.str("prefix",e.text)),Field("suffix","Suffix",e.str("suffix"," "+e.str("unit","cm"))),Field("unit","Einheit",e.str("unit","cm"),choices=listOf("mm","cm","m","m²","%","Stk")),Field("decimals","Nachkommastellen 0–6",fmt(e.num("decimals",2.0)),true),Field("textDx","Textversatz X mm",fmt(e.num("textDx")),true),Field("textDy","Textversatz Y mm",fmt(e.num("textDy")),true),Field("dimDx","Maßlinie X-Versatz mm",fmt(e.num("dimDx")),true),Field("dimDy","Maßlinie Y-Versatz mm",fmt(e.num("dimDy")),true),Field("offsetMm","Maßlinienabstand mm",fmt(e.num("offsetMm",400.0)),true),Field("hidden","Ausblenden 0/1",fmt(e.num("hidden")),true))
 FormDialog("Assoziatives Maß",fields,onDismiss){v->var next=e.copy(text="");for(f in fields)next=if(f.numeric)next.withNum(f.key,parseNumber(v.getValue(f.key))!!)else next.withStr(f.key,v.getValue(f.key));onSave(next)}
}
