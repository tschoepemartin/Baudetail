package de.baudetail.ui.dialogs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import de.baudetail.geometry.parseNumber

data class Field(val key:String,val label:String,val initial:String="",val numeric:Boolean=false,val positive:Boolean=false,val choices:List<String> = emptyList(),val checkbox:Boolean=false)
@Composable fun FormDialog(title:String,fields:List<Field>,onDismiss:()->Unit,onSubmit:(Map<String,String>)->Unit){
 val values=remember(fields){mutableStateMapOf<String,String>().apply{fields.forEach{put(it.key,it.initial)}}}
 var error by remember{mutableStateOf<String?>(null)};var openChoice by remember{mutableStateOf<String?>(null)}
 AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  fields.forEach{f->when{
   f.checkbox->{Row(Modifier.fillMaxWidth()){Checkbox(values[f.key].orEmpty().lowercase() in setOf("ja","true","1","an"),{values[f.key]=if(it)"ja"else"nein"});Text(f.label,Modifier.padding(top=12.dp))}}
   f.choices.isNotEmpty()->{Box{OutlinedButton(onClick={openChoice=f.key},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text("${f.label}: ${values[f.key].orEmpty()}");Spacer(Modifier.weight(1f));Text("▾")}};DropdownMenu(expanded=openChoice==f.key,onDismissRequest={openChoice=null}){f.choices.forEach{choice->DropdownMenuItem(text={Row(Modifier.fillMaxWidth()){Text(choice);Spacer(Modifier.weight(1f));if(values[f.key]==choice)Text("✓")}},onClick={values[f.key]=choice;openChoice=null})}}}}
   else->OutlinedTextField(values[f.key].orEmpty(),{values[f.key]=it},label={Text(f.label)},keyboardOptions=KeyboardOptions(keyboardType=if(f.numeric)KeyboardType.Decimal else KeyboardType.Text),modifier=Modifier.fillMaxWidth(),minLines=if(f.key=="notes"||f.key=="text"||f.key=="template")3 else 1)
  }}
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 }},confirmButton={TextButton(onClick={val bad=fields.firstOrNull{it.numeric&&(parseNumber(values[it.key].orEmpty())==null||(it.positive&&(parseNumber(values[it.key].orEmpty())?:0.0)<=0))};if(bad!=null)error="${bad.label}: gültige ${if(bad.positive)"positive "else""}Zahl eingeben"else try{onSubmit(values.toMap());onDismiss()}catch(e:Exception){error=e.message}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
@Composable fun ChoiceDialog(title:String,choices:List<String>,onDismiss:()->Unit,selectedIndex:Int?=null,onChoose:(Int)->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())){choices.forEachIndexed{i,s->TextButton(onClick={onDismiss();onChoose(i)},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text(s);Spacer(Modifier.weight(1f));if(selectedIndex==i)Text("✓")}}}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})}

@Composable fun ElevationDialog(title:String,initialRole:String="manual",initialHeight:String="0",initialPrefix:String="",onDismiss:()->Unit,onSubmit:(String,Double,String)->Unit){
 var role by remember{mutableStateOf(initialRole)};var height by remember{mutableStateOf(initialHeight)};var prefix by remember{mutableStateOf(initialPrefix)};var error by remember{mutableStateOf<String?>(null)}
 val roles=listOf("relative" to "Relativ automatisch","leader" to "Leader / Bezugshöhe","manual" to "Manuell")
 AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("Art");roles.forEach{(key,label)->Row(Modifier.fillMaxWidth()){RadioButton(selected=role==key,onClick={role=key});Text(label,Modifier.padding(top=12.dp));Spacer(Modifier.weight(1f));if(role==key)Text("✓",Modifier.padding(top=12.dp))}}
  OutlinedTextField(height,{height=it},label={Text(if(role=="relative")"Zusatz/Offset mm" else "Höhe mm")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
  OutlinedTextField(prefix,{prefix=it},label={Text("Bezeichnung optional, z. B. OK / UK / Sohle")},modifier=Modifier.fillMaxWidth())
  if(role=="relative")Text("Die Höhe wird aus dem Leader und der geometrischen Höhendifferenz des gefangenen Bauteilpunkts berechnet.",style=MaterialTheme.typography.bodySmall)
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 }},confirmButton={TextButton(onClick={val n=parseNumber(height);if(n==null)error="Gültige Zahl eingeben" else {onSubmit(role,n,prefix);onDismiss()}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
