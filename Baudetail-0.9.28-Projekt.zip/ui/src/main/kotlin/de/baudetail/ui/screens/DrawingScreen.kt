package de.baudetail.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import de.baudetail.ui.drawing.*
import de.baudetail.ui.panels.*
import de.baudetail.ui.toolbars.*
import kotlinx.serialization.json.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DrawingScreen(vm:BaudetailViewModel,onBack:()->Unit,onLibrary:()->Unit,onExport:()->Unit,onBackground:()->Unit){
 val d=vm.drawing;val project=vm.project
 if(d==null||project==null){Page("Zeichnung",onBack){Text("Keine Zeichnung geöffnet.")};return}
 var points by remember(d.id){mutableStateOf<List<Vec>>(emptyList())}
 var cutOwnerId by remember(d.id){mutableStateOf<String?>(null)}
 var pendingPlanPoint by remember(d.id){mutableStateOf<Vec?>(null)}
 var editingPlanId by remember(d.id){mutableStateOf<String?>(null)}
 val input=d.input();val grid=input.gridVisible;val snapOn=input.snapEnabled;val ortho=input.ortho;val angleStep=input.angleStep
 var penMode by remember{mutableStateOf(false)}
 var rotationSnap by remember{mutableStateOf(true)}
 var rotationInput by remember{mutableStateOf("")}
 var topMenu by remember{mutableStateOf(false)}
 var rotatingSlider by remember{mutableStateOf(false)}
 var sliderResizing by remember{mutableStateOf(false)};var toolPanel by remember{mutableStateOf(true)};var propertyPanel by remember{mutableStateOf(false)};var dialog by remember{mutableStateOf("")};var coordinate by remember{mutableStateOf(Vec())};var zoom by remember{mutableDoubleStateOf(.06)};var fit by remember{mutableIntStateOf(0)};var measurePoints by remember{mutableStateOf<List<Vec>>(emptyList())};var calibrating by remember{mutableStateOf<String?>(null)};var multi by remember{mutableStateOf(false)}
 val shapeTools=setOf("polygon","area","building","polyline","dimension-chain","measure-area")
 fun complete(ps:List<Vec> = points){
  val tool=vm.tool
  if(ps.isEmpty())return
  fun params(vararg pairs:Pair<String,Double>)=buildJsonObject{pairs.forEach{put(it.first,it.second)}}
  val a=ps.first();val b=ps.getOrElse(1){a+Vec(1000.0,500.0)}
  val e=when(tool){
   "rect"->Entity(kind="rect",points=rectangle(a,b))
   "grass"->Entity(kind="area",name="Rasen",points=rectangle(a,b),quantityUnit="m²",style=Style(stroke="#47774A",fill="#A7CF8A"),params=buildJsonObject{put("grassObject",true);put("grassType","Gebrauchsrasen");put("grassMethod","Saatrasen");put("grassRsm","RSM 2.3");put("grassHeights",JsonArray(emptyList()));put("grassBladeMm",40.0);put("grassLayer1Name","Oberboden");put("grassLayer1Grading","0/15");put("grassLayer1Mm",50.0);put("grassLayer2Name","Oberboden");put("grassLayer2Grading","0/25");put("grassLayer2Mm",150.0)})
   "circle"->Entity(kind="circle",points=listOf(a,b),params=params("radiusMm" to a.distance(b)))
   "arc"->Entity(kind="arc",points=listOf(a,b),params=params("radiusMm" to a.distance(b),"startAngle" to Math.toDegrees(atan2(b.y-a.y,b.x-a.x)),"sweepAngle" to 90.0))
   "planting-area"->Entity(kind="area",points=rectangle(a,b),placement=Placement(visibleTop=true,visibleSection=true),style=Style(stroke="#557047",fill="#C6D6AD"),name="Pflanzfläche",quantityUnit="m²",params=buildJsonObject{put("plantingArea",true);put("plantingType","Staudenfläche")},strata=listOf(
    Stratum("Auffüllkies","Tragschicht",200.0,"#C7BDAA","0/32"),
    Stratum("Oberboden 0/35","Oberboden grob",200.0,"#947B5B","0/35"),
    Stratum("Oberboden 0/20","Oberboden fein",150.0,"#A18A68","0/20"),
    Stratum("Rindenmulch","Deckschicht",50.0,"#785438","")
   ))
   "eaves-strip"->Entity(kind="area",points=rectangle(a,b),placement=Placement(visibleTop=true,visibleSection=true),style=Style(stroke="#686A66",fill="#B9B7AE"),name="Traufe",quantityUnit="m²",params=buildJsonObject{put("eavesStrip",true)},strata=listOf(
    Stratum("Schotter 0/32","Tragschicht",150.0,"#9F9F99","0/32"),
    Stratum("Kies 16/32 Grau","Deckschicht",100.0,"#B6B5AD","16/32")
   ))
   "building"->Entity(kind="building",points=ps,style=Style(fill="#DFE1DD",widthMm=.5),name="Gebäudeumriss")
   "slope"->Entity(kind="slope",points=ps,params=buildJsonObject{put("mode","manual");put("percent",2.0);put("startHeightMm",0);put("endHeightMm",-100);put("unit","%")})
   "dimension","dimension-chain","dimension-angle"->{val anchors=ps.mapNotNull{point->anchorAt(point,d)};Entity(kind="dimension",points=ps,anchors=if(anchors.size==ps.size)anchors else emptyList(),params=buildJsonObject{put("mode",when(tool){"dimension-chain"->"chain";"dimension-angle"->"angle";else->"aligned"});put("unit","cm");put("offsetMm",8*d.sheet.scale)})}
   "hedge"->Entity(kind="hedge",points=ps,name="Hecke",quantityUnit="Stk",params=params("spacingMm" to 400.0,"widthMm" to 600.0,"plantHeightMm" to 1500.0),style=Style(stroke="#47774A",fill="#BBD2AD"))
   "guide"->Entity(kind="guide",points=ps,layerId=d.layers.find{it.name=="Hilfslinien"}?.id?:"planning",style=Style(stroke="#A9B6C0",dashed=true))
   "leader"->Entity(kind="leader",points=ps,text="Hinweis")
   else->Entity(kind=tool,points=ps)
  }
  if(tool=="section")vm.addSection(ps,('A'.code+d.entities.count{it.kind=="section"}).toChar().let{"$it–$it"})
  else if(tool=="measure"||tool=="measure-area"){measurePoints=ps;dialog="measure"}
  else vm.add(e)
  points=emptyList()
 }
 fun tap(raw:Vec,long:Boolean=false,exact:Boolean=false){
  coordinate=raw
  if(calibrating!=null){points=points+raw;if(points.size==2)dialog="calibrate";return}
  if(vm.tool=="paving-cut"){
   val owner=d.entities.find{it.id==cutOwnerId}
   if(owner==null){vm.tool="select";points=emptyList();return}
   val point=if(exact)raw else snap(raw,d,input.options(18/zoom),points.lastOrNull()).point
   val boundary=planFootprint(owner,d)
   if(boundary.size<3)return
   if(points.isEmpty()){points=listOf(point);return}
   val segment=clipCutSegment(points.first(),point,boundary)
   if(segment!=null){
    vm.add(Entity(kind="line",name="Schnittkante",points=segment,layerId=owner.layerId,
     style=Style(stroke=owner.style.stroke,widthMm=(owner.pattern?.jointMm?:4.0).coerceAtLeast(0.1)/d.sheet.scale,align="cut-butt"),
     params=buildJsonObject{put("pavingCutOwner",owner.id);put("cutJointMode","auto")}))
   }
   cutOwnerId=null;points=emptyList();vm.tool="select";return
  }
  if(vm.tool=="rotate-object"){
   val hit=d.entities.asReversed().firstOrNull { e ->
    d.layers.find{it.id==e.layerId}?.visible!=false && visibleIn(e,d) &&
    hitTest(raw,e,d,18/zoom)
   }
   vm.selected=if(hit==null)emptySet() else setOf(hit.id)
   return
  }
  if(vm.tool=="select"){
   val eligible=d.entities.filter{e->d.layers.find{it.id==e.layerId}?.visible!=false&&visibleIn(e,d)}
   val hit=eligible.lastOrNull{it.isParametricBuildUp()&&d.viewMode()=="section"&&buildUpSlopeLabelHit(it,raw,d.sheet.scale,24/zoom)}
    ?:eligible.lastOrNull{it.kind=="dimension"&&hitTest(raw,it,d,10/zoom)}
    ?:eligible.lastOrNull{labelTextBounds(it,d)?.contains(raw,24/zoom)==true}
    ?:eligible.lastOrNull{hitTest(raw,it,d,18/zoom)}
   if(hit!=null){// Selecting or dragging a slope label never opens the inspector; only the top toolbar button does.
   val target=hit.targetDrawingId;if(hit.kind=="section"&&target!=null&&!long&&!multi){vm.openDrawing(target);return};val ids=if(hit.groupId!=null)d.entities.filter{it.groupId==hit.groupId}.map{it.id}.toSet()else setOf(hit.id);vm.selected=if(long||multi){if(hit.id in vm.selected)vm.selected-ids else vm.selected+ids}else ids;
   if(!long&&!multi&&hit.kind!="elevation"&&(hit.kind in setOf("text","leader")||hit.text.isNotBlank()))dialog="quickText";}
   else if(!multi)vm.selected=emptySet()
   return
  }
  val point=if(vm.tool=="assign-height" && d.viewMode()=="top") raw else if(exact)raw else snap(raw,d,input.options(18/zoom),points.lastOrNull()).point
  when(vm.tool){
   "library"->{vm.placeEntry(point);vm.tool="select"}
   "grass"->{complete(listOf(point,point+Vec(1000.0,1000.0)));vm.tool="select"}
   "planting-area","eaves-strip"->{complete(listOf(point,point+Vec(1000.0,1000.0)));vm.tool="select"}
   "origin"->vm.edit(d.copy(origin=point))
   "text"->{points=listOf(point);dialog="text"}
   "elevation"->{if(d.viewMode()!="section")return;val surface=elevationSurfaceSnap(point,d,120.0);val anchor=surface?.anchor;val marker=surface?.point?:point;vm.add(Entity(kind="elevation",points=listOf(marker),anchors=anchor?.let{listOf(it)}?:emptyList(),params=buildJsonObject{put("elevationRole","relative");put("heightOffsetMm",0.0);put("elevationCreatedView",d.viewMode())}));propertyPanel=false}
   "assign-height"->{if(d.viewMode()!="top")return;pendingPlanPoint=point;editingPlanId=null;dialog="planHeightEditor";propertyPanel=false}

   "tree"->vm.add(Entity(kind="tree",points=listOf(point),name="Baum",quantityUnit="Stk",style=Style(stroke="#476A48",fill="#D0DFBB"),params=buildJsonObject{put("crownMm",2500);put("trunkMm",120);put("rootMm",0);put("pitMm",0);put("plantHeightMm",4000);put("trunkCircumferenceMm",180);put("rootBallMm",600);put("plantName","")}))
   "stack"->vm.add(Entity(kind="stack",points=listOf(point),name="Belagsaufbau",params=buildJsonObject{put("widthMm",1500);put("topDepthMm",1000)},pattern=Pattern(200.0,100.0,4.0,0.0,1.0/3.0),strata=listOf(Stratum("Betonpflaster","Pflaster",80.0,"#B6BBB7",""),Stratum("Splitt 2/5","Bettung",40.0,"#E4DBC4","2/5"),Stratum("FS-Kies 0/32","Frostschutz",300.0,"#CBC3B4","0/32"))))
   "legend"->vm.add(Entity(kind="legend",points=listOf(point)))
   "hedge"->{
    if(points.isEmpty())points=listOf(point)
    else if(points.first().distance(point)>1e-6){
     complete(listOf(points.first(),point))
     vm.tool="select"
    }
   }
   "dimension"->{
    // Identical two-tap completion principle as the paving-plan cut edge:
    // both witness points are snapped, and the second tap finishes immediately.
    if(points.isEmpty())points=listOf(point)
    else {
     val first=points.first()
     if(first.distance(point)>1e-6){
      val witnesses=listOf(first,point)
      val bindings=witnesses.mapIndexedNotNull { index, witness ->
       anchorAt(witness,d)?.let { PointBinding(index,it) }
      }
      vm.add(Entity(kind="dimension",points=witnesses,bindings=bindings,
       params=buildJsonObject { put("mode","aligned");put("unit","cm");put("offsetMm",8*d.sheet.scale) }))
      points=emptyList();vm.tool="select"
     }
    }
   }
   "arrow","leader"->Unit
   else->{if(vm.tool=="polyline"&&points.size>=3&&point.distance(points.first())<=18/zoom){complete(points+points.first());return};points=points+point;if(vm.tool !in shapeTools && points.size>=if(vm.tool=="dimension-angle")3 else 2)complete(points)}
  }
 }
 BackHandler(points.isNotEmpty()||calibrating!=null){points=emptyList();calibrating=null}
 BackHandler(enabled=points.isEmpty()&&calibrating==null){onBack()}
 Scaffold(topBar={if(rotatingSlider){}else TopAppBar(title={Column{Text(vm.selected.firstNotNullOfOrNull { id -> d.entities.find { it.id==id } }?.let { selected -> selected.name.ifBlank { when(selected.kind) { "elevation" -> "Höhe Schnitt"; "plan-height" -> "Höhe Draufsicht"; "dimension" -> "Bemaßung"; "area" -> if(selected.str("plantingArea")=="true") "Pflanzfläche" else if(selected.str("grassObject")=="true") "Rasenaufbau" else "Fläche"; "component" -> "Bauteil"; else -> selected.kind.replaceFirstChar { it.uppercase() } } } } ?: d.name,maxLines=1,style=MaterialTheme.typography.titleMedium);Text("${project.name} · ${if(vm.saving)"Speichert …"else"Lokal"}",maxLines=1,style=MaterialTheme.typography.labelSmall)}},navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Projektakte")}},actions={IconButton(onClick=vm::undo,enabled=vm.canUndo){Icon(Icons.Default.Undo,"Rückgängig")};IconButton(onClick=vm::redo,enabled=vm.canRedo){Icon(Icons.Default.Redo,"Wiederholen")};if(vm.selected.isNotEmpty()){IconButton(onClick={val marker=vm.selected.firstNotNullOfOrNull{id->d.entities.find{it.id==id&&it.kind=="plan-height"}};if(marker!=null){editingPlanId=marker.id;dialog="planHeightEditor"}else propertyPanel=!propertyPanel}){Icon(Icons.Default.Tune,"Objektmenü")};IconButton(onClick=vm::duplicateSelected){Icon(Icons.Default.ContentCopy,"Duplizieren")};IconButton(onClick=vm::mirrorSelected){Icon(Icons.Default.Flip,"Spiegeln")}}else IconButton(onClick={propertyPanel=!propertyPanel}){Icon(Icons.Default.Tune,"Eigenschaften")};Box{IconButton(onClick={topMenu=true}){Icon(Icons.Default.MoreVert,"Zeichnungsmenü")};DropdownMenu(expanded=topMenu,onDismissRequest={topMenu=false}){DropdownMenuItem(text={Text("Zentrieren")},leadingIcon={Icon(Icons.Default.CenterFocusStrong,null)},onClick={topMenu=false;fit++});DropdownMenuItem(text={Text("Speichern")},leadingIcon={Icon(Icons.Default.Save,null)},onClick={topMenu=false;vm.persist()});DropdownMenuItem(text={Text("Exportieren / Teilen")},leadingIcon={Icon(Icons.Default.IosShare,null)},onClick={topMenu=false;onExport()})}}})},bottomBar={if(rotatingSlider){}else Surface(tonalElevation=3.dp){Column {
  if(vm.tool=="rotate-object" && vm.selected.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=3.dp),horizontalArrangement=Arrangement.Center,verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
   Text("Objekt drehen",style=MaterialTheme.typography.labelMedium)
   Spacer(Modifier.width(12.dp))
   IconButton(onClick={vm.rotateSelectedQuarter(false)}){Icon(Icons.Default.RotateLeft,"90° gegen Uhrzeigersinn")}
   Text("90°")
   IconButton(onClick={vm.rotateSelectedQuarter(true)}){Icon(Icons.Default.RotateRight,"90° im Uhrzeigersinn")}
  }
  Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(2.dp)){
  TextButton(onClick={dialog="sheet"}){Text("1:${fmt(d.sheet.scale)}")};FilterChip(grid,{dialog="grid"},label={Text("Raster ${if(grid)fmt(d.gridMm)+" mm"else"aus"}")});FilterChip(snapOn,{dialog="snap"},label={Text("Fang ${if(snapOn)fmt(input.snapMm)+" mm"else"aus"}")});FilterChip(ortho,{vm.edit(d.withInput(input.copy(ortho=!ortho)))},label={Text("Ortho")});TextButton(onClick={dialog="angle"}){Text("${fmt(angleStep)}°")};Text("mm · X ${fmt(coordinate.x-d.origin.x)} / Y ${fmt(coordinate.y-d.origin.y)}",Modifier.padding(12.dp));TextButton(onClick={fit++}){Text("Einpassen")}
 }}}}){padding->BoxWithConstraints(Modifier.padding(padding).fillMaxSize()){
  val wide=maxWidth>=1000.dp
  Column {
   if(!rotatingSlider)Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){
    IconButton(onClick={toolPanel=!toolPanel}){Icon(Icons.Default.Menu,"Werkzeuge")}
    TextButton(onClick=onLibrary){Text("Bibliothek")};TextButton(onClick={dialog="assemblies"}){Text("Bauwerke")};FilterChip(d.viewMode()=="section",{if(vm.tool=="assign-height"||vm.tool=="elevation")vm.tool="select";vm.edit(d.withViewMode(if(d.viewMode()=="section")"top"else"section"))},label={Text(if(d.viewMode()=="section")"Schnitt"else"Draufsicht")});TextButton(onClick={dialog="profile"}){Text(d.profile())};TextButton(onClick={dialog="layers"}){Text("Layer")};TextButton(onClick=onBackground){Text("Hintergrund")};TextButton(onClick={dialog="quantity"}){Text("Mengen")};TextButton(onClick={dialog="backups"}){Text("Sicherungen")};TextButton(onClick={dialog="objects"}){Text("Objekte")};TextButton(onClick={dialog="variant"}){Text("Variante")};TextButton(onClick={dialog="variables"}){Text("Variablen")};TextButton(onClick={dialog=if(vm.tool in dragShapeTools)"shapeNumeric"else"numeric"}){Text("Maße eingeben")};FilterChip(penMode,{penMode=!penMode},label={Text("Finger navigiert")});FilterChip(multi,{multi=!multi},label={Text("Mehrfachauswahl")});TextButton(onClick={vm.linkedSnap=!vm.linkedSnap}){Text(if(vm.linkedSnap)"Verknüpft fangen ✓"else"Verknüpft fangen")}
   }
   d.sourceDrawingId?.let{source->TextButton(onClick={vm.openDrawing(source)}){Text("← Zum Ausgangsplan")}}
   if(vm.tool=="paving-cut" && points.isEmpty())Text("Schnittkante: Anfangspunkt setzen · Zoom und Verschieben möglich",Modifier.padding(8.dp))
   if(points.isNotEmpty()||calibrating!=null)Row(Modifier.padding(horizontal=8.dp)){
    Text(if(calibrating!=null)"Kalibrieren: zwei Punkte wählen"else"${points.size} Punkte · ${drawTools.find{it.id==vm.tool}?.label.orEmpty()}",Modifier.weight(1f).padding(top=12.dp))
    if(vm.tool in shapeTools)TextButton(onClick={complete()},enabled=points.size>=if(vm.tool in setOf("area","polygon","building","measure-area"))3 else 2){Text("Abschließen")};TextButton(onClick={points=emptyList();calibrating=null;cutOwnerId=null;if(vm.tool=="paving-cut")vm.tool="select"}){Text("Abbrechen")}
   }
   Row(Modifier.weight(1f)){
    if(toolPanel&&!rotatingSlider)Surface(Modifier.width(if(wide)112.dp else 80.dp),tonalElevation=1.dp){LazyColumn{items(drawTools.size){i->val t=drawTools[i];FilledTonalButton(onClick={points=emptyList();calibrating=null;if(t.id=="rotate-view")dialog="rotateView" else if(t.id=="merge")vm.mergeSelectedAreas() else vm.tool=t.id},enabled=(if(t.id=="merge")vm.canMergeAreas() else if(t.id=="assign-height")d.viewMode()=="top" else if(t.id=="elevation")d.viewMode()=="section" else true),modifier=Modifier.fillMaxWidth().padding(2.dp),contentPadding=PaddingValues(4.dp),colors=if(vm.tool==t.id)ButtonDefaults.filledTonalButtonColors(containerColor=MaterialTheme.colorScheme.primaryContainer)else ButtonDefaults.filledTonalButtonColors(containerColor=MaterialTheme.colorScheme.surface)){Column(horizontalAlignment=androidx.compose.ui.Alignment.CenterHorizontally){Icon(t.icon,t.label);Text(t.label,style=MaterialTheme.typography.labelSmall,maxLines=1)}}}}}
    DrawingCanvas(d,project,vm.store::assetFile,vm.tool,vm.selected,points,grid,penMode,fit,Modifier.weight(1f).fillMaxHeight(),onTap={v,long->tap(v,long)},onFreehand={vm.add(Entity(kind="polyline",points=it))},onMove={delta,snap,offset,rot,id->if(id!=null)vm.selected=setOf(id);vm.moveSelected(delta,snap,offset,rot)},onDeleteRequested={dialog="confirmDelete"},onCoordinates={point,z->coordinate=point;zoom=z},onCreate={created->val enriched=if(created.kind=="dimension"){val anchors=created.points.mapNotNull{pt->anchorAt(pt,d)};if(anchors.size==created.points.size)created.copy(anchors=anchors)else created}else created;vm.add(enriched);points=emptyList()},onChange=vm::update)
    if(wide&&propertyPanel)Surface(Modifier.width(310.dp).fillMaxHeight(),tonalElevation=2.dp){Inspector(vm,onCalibrate={calibrating=vm.selected.firstOrNull();points=emptyList();propertyPanel=false},onAddCut={id->cutOwnerId=id;points=emptyList();vm.tool="paving-cut";propertyPanel=false})}
   }
  }
  if(!wide&&propertyPanel)ModalBottomSheet(onDismissRequest={propertyPanel=false;sliderResizing=false},containerColor=Color.Transparent,scrimColor=if(sliderResizing)Color.Transparent else Color.Black.copy(alpha=.32f),dragHandle=null){Inspector(vm,onCalibrate={calibrating=vm.selected.firstOrNull();points=emptyList();propertyPanel=false},onResizeChange={sliderResizing=it},onAddCut={id->cutOwnerId=id;points=emptyList();vm.tool="paving-cut";propertyPanel=false})}
 }}
 when(dialog){
  "planHeightEditor"->{
   val existing=editingPlanId?.let { id -> d.entities.find { it.id==id && it.kind=="plan-height" } }
   val role=existing?.str("elevationRole","manual")?:"relative"
   val initial=if(role=="relative")existing?.num("heightOffsetMm",0.0)?:0.0 else existing?.num("heightMm",d.elevationDatumMm)?:d.elevationDatumMm
   var selectedLeaderId by remember(existing?.id,dialog){mutableStateOf(existing?.str("planLeaderId","")?:"")}
   val leaders=d.entities.filter{it.kind=="plan-height"&&it.str("elevationRole")=="leader"}.sortedBy{it.num("planLeaderNumber",999999.0)}
    ElevationDialogWithLeaders(if(existing==null)"Höhe Draufsicht setzen" else "Höhe Draufsicht bearbeiten",role,fmt(initial/1000.0),existing?.str("elevationPrefix")?:"",existing?.num("elevationFontPaperMm",3.0)?:3.0,existing?.num("elevationArrowPaperMm",2.5)?:2.5,planLeaders=leaders.map{it.id to "Leader ${it.num("planLeaderNumber",0.0).toInt()} · ${fmt(it.num("heightMm")/1000.0)} m"},selectedPlanLeaderId=selectedLeaderId,onPlanLeaderSelected={selectedLeaderId=it},surfaceLabel=existing?.points?.firstOrNull()?.let{planSurfaceDescription(it,d)}?:pendingPlanPoint?.let{planSurfaceDescription(it,d)}?:"Keine Oberfläche erkannt",initialDecimals=existing?.num("heightDecimals",2.0)?.toInt()?:2,onDismiss= {dialog="";pendingPlanPoint=null;editingPlanId=null}){newRole,value,prefix,fontMm,arrowMm,decimals->
     val point=existing?.points?.firstOrNull()?:pendingPlanPoint
     if(point!=null){
      val anchor=if(newRole=="relative")planElevationAnchor(point,d) else null
      val number=if(newRole=="leader")existing?.num("planLeaderNumber",0.0)?.toInt()?.takeIf{it>0}?:((leaders.maxOfOrNull{it.num("planLeaderNumber",0.0).toInt()}?:0)+1) else 0
      val params=buildJsonObject{existing?.params?.forEach{(key,v)->put(key,v)};put("elevationRole",newRole);put("elevationPrefix",prefix);put("elevationFontPaperMm",fontMm);put("elevationArrowPaperMm",arrowMm);put("heightSystem","plan-v4");put("heightDecimals",decimals);if(newRole=="relative"){put("heightOffsetMm",value*1000.0);put("planLeaderId",selectedLeaderId)}else{put("heightMm",value*1000.0);if(newRole=="leader")put("planLeaderNumber",number)}}
      if(existing!=null)vm.update(existing.copy(anchors=anchor?.let{listOf(it)}?:emptyList(),params=params))
      else vm.add(Entity(kind="plan-height",name="Höhe Draufsicht",points=listOf(point),anchors=anchor?.let{listOf(it)}?:emptyList(),params=params))
     }
     dialog="";pendingPlanPoint=null;editingPlanId=null
    }
  }

  "rotateView"->{
   val current=d.topViewAngle()
   AlertDialog(onDismissRequest={dialog="";rotatingSlider=false},title={if(rotatingSlider)Text("Drehwinkel: ${fmt(current,1)}°") else Text("Seite drehen · Draufsicht")},text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
    if(!rotatingSlider)Text("Nur die Ansicht wird gedreht. Geometrie, Bezugspunkte und Papierformat bleiben unverändert.")
    if(!rotatingSlider)Text("Drehwinkel: ${fmt(current,1)}°")
    Slider(value=current.toFloat(),onValueChangeFinished={rotatingSlider=false},onValueChange={v->rotatingSlider=true;vm.edit(d.withTopViewAngle(if(rotationSnap)(kotlin.math.round(v/15f)*15f).toDouble() else v.toDouble()))},valueRange=0f..359f)
    if(!rotatingSlider)Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(0,90,180,270).forEach{v->TextButton(onClick={vm.edit(d.withTopViewAngle(v.toDouble()))}){Text("${v}°")}}}
    if(!rotatingSlider)Row{TextButton(onClick={vm.edit(d.withTopViewAngle(current-90))}){Text("−90°")};TextButton(onClick={vm.edit(d.withTopViewAngle(current+90))}){Text("+90°")}}
    if(!rotatingSlider)Row{Checkbox(checked=rotationSnap,onCheckedChange={rotationSnap=it});Text("Rastpunkte 15°")}
    if(!rotatingSlider)OutlinedTextField(value=rotationInput,onValueChange={rotationInput=it},label={Text("Winkel frei eingeben (°)")},singleLine=true)
    if(!rotatingSlider)TextButton(onClick={rotationInput.replace(',','.').toDoubleOrNull()?.let{vm.edit(d.withTopViewAngle(it))}}){Text("Winkel übernehmen")}
   }},confirmButton={if(!rotatingSlider)TextButton(onClick={dialog=""}){Text("Fertig")}},dismissButton={if(!rotatingSlider)TextButton(onClick={vm.edit(d.withTopViewAngle(0.0));dialog=""}){Text("Zurücksetzen")}})
  }
  "confirmDelete"->AlertDialog(onDismissRequest={dialog=""},title={Text("Löschen?")},text={Text(if(vm.selected.size==1)"Ausgewähltes Objekt löschen?"else"${vm.selected.size} ausgewählte Objekte löschen?")},confirmButton={TextButton(onClick={vm.removeSelected();dialog=""}){Text("Löschen")}},dismissButton={TextButton(onClick={dialog=""}){Text("Abbrechen")}})
  "assemblies"->{
   val entries=vm.catalog.entries().filter{it.type=="stair-template"||it.type=="assembly-template"}.sortedWith(compareBy<LibraryEntry>{if(it.type=="stair-template")0 else 1}.thenBy{it.name})
   ChoiceDialog("Bauwerke",entries.map{it.name},{dialog=""}){i->val entry=entries[i];if(entry.type=="stair-template")dialog="stair" else {vm.attachEntry(entry);dialog=""}}
  }
  "profile"->ChoiceDialog("Ansichtsprofil",viewProfiles,{dialog=""},selectedIndex=viewProfiles.indexOf(d.profile()).takeIf{it>=0}){vm.edit(d.withProfile(viewProfiles[it]))}
  "stair"->StairDialog(vm.catalog.entries()+project.libraryEntries,Entity(kind="assembly",points=listOf(coordinate)),{dialog=""},vm::saveStair)
 "text"->FormDialog("Text platzieren",listOf(Field("text","Text / Variablen z. B. {projekt}")),{dialog="";points=emptyList()}){vm.add(Entity(kind="text",points=listOf(points.firstOrNull()?:coordinate),text=it["text"].orEmpty()))}
 "quickText"->{val obj=d.entities.find{it.id in vm.selected};if(obj!=null)FormDialog("Text bearbeiten",listOf(Field("text","Text",obj.text)),{dialog=""}){v->vm.update(obj.copy(text=v["text"].orEmpty()))}else dialog=""}
 "elevationCreate"->ElevationDialog("Höhenkote hinzufügen","relative","0","",3.0,2.5,{dialog=""}){role,value,prefix,fontMm,arrowMm->val at=coordinate;val surface=if(d.viewMode()=="section")elevationSurfaceSnap(at,d,120.0) else null;val anchor=if(d.viewMode()=="top")planElevationAnchor(at,d) else surface?.anchor;val snappedAt=surface?.point?:at;var e=Entity(kind="elevation",points=listOf(snappedAt),anchors=if(role in setOf("relative","leader")&&anchor!=null)listOf(anchor)else emptyList(),params=buildJsonObject{put("elevationRole",role);put("elevationPrefix",prefix);put("elevationFontPaperMm",fontMm);put("elevationArrowPaperMm",arrowMm);put("elevationCreatedView",d.viewMode());if(role=="relative")put("heightOffsetMm",value*1000.0)else put("heightMm",value*1000.0)});vm.add(e);propertyPanel=true}
 "shapeNumeric"->{val circle=vm.tool in setOf("circle","arc");val line=vm.tool=="line"
 val fields=listOf(Field("x","Start X mm",fmt(points.firstOrNull()?.x?:coordinate.x),true),Field("y","Start Y mm",fmt(points.firstOrNull()?.y?:coordinate.y),true),Field("width",if(circle)"Radius mm"else if(line)"Länge mm"else"Breite mm","1000",true,true))+if(circle)emptyList()else if(line)listOf(Field("angle","Winkel Grad","0",true))else listOf(Field("height","Höhe / Tiefe mm","1000",true,true))
 FormDialog("${drawTools.find{it.id==vm.tool}?.label.orEmpty()} · genaue Maße",fields,{dialog=""}){v->val a=Vec(parseNumber(v.getValue("x"))!!,parseNumber(v.getValue("y"))!!);val w=parseNumber(v.getValue("width"))!!;val delta=if(circle)Vec(w,0.0)else if(line)Vec(w,0.0).rotate(parseNumber(v.getValue("angle"))!!)else Vec(w,parseNumber(v.getValue("height"))!!);vm.add(shapeFromDrag(vm.tool,a,a+delta));points=emptyList()}}
 "numeric"->FormDialog("Numerisch zeichnen",listOf(Field("x","X mm (relativ zum Nullpunkt)",fmt(coordinate.x-d.origin.x),true),Field("y","Y mm (relativ zum Nullpunkt)",fmt(coordinate.y-d.origin.y),true),Field("length","Länge ab letztem Punkt (0 = X/Y)","0",true),Field("angle","Winkel ab letztem Punkt in Grad","0",true)),{dialog=""}){v->val len=parseNumber(v["length"]!!)!!;val a=Math.toRadians(parseNumber(v["angle"]!!)!!);val point=if(len!=0.0&&points.isNotEmpty())points.last()+Vec(cos(a),sin(a))*len else Vec(parseNumber(v["x"]!!)!!,parseNumber(v["y"]!!)!!)+d.origin;tap(point,exact=true)}
 "sheet"->FormDialog("Papier und Maßstab",listOf(Field("scale","Maßstab 1:x",fmt(d.sheet.scale),true,true),Field("width","Papierbreite mm (A4 210/297, A3 297/420, A2 420/594)",fmt(d.sheet.widthMm),true,true),Field("height","Papierhöhe mm",fmt(d.sheet.heightMm),true,true),Field("x","Papierausschnitt Ursprung X mm",fmt(d.sheet.origin.x),true),Field("y","Papierausschnitt Ursprung Y mm",fmt(d.sheet.origin.y),true),Field("paper","Papierbereich anzeigen",if(d.sheet.showPaper)"ja"else"nein",checkbox=true),Field("grid","Rasterweite mm",fmt(d.gridMm),true,true),Field("datum","Bezugshöhe mm",fmt(d.elevationDatumMm),true),Field("template","Plankopfvorlage",d.sheet.titleTemplate)),{dialog=""}){v->fun n(k:String):Double { return parseNumber(v.getValue(k))!! }
vm.edit(d.copy(sheet=d.sheet.copy(scale=n("scale"),widthMm=n("width"),heightMm=n("height"),origin=Vec(n("x"),n("y")),showPaper=v["paper"]=="ja",titleTemplate=v["template"].orEmpty()),gridMm=n("grid"),elevationDatumMm=n("datum")))}
 "grid","snap"->SnapDialog(d,dialog=="grid",{dialog=""},vm::edit)
 "angle"->FormDialog("Winkelfang",listOf(Field("step","Schritt in Grad (0 = aus; z. B. 15, 30, 45)",fmt(angleStep),true)),{dialog=""}){val step=parseNumber(it.getValue("step"))!!;require(step in 0.0..180.0);vm.edit(d.withInput(input.copy(angleStep=step)))}
 "layers"->LayerDialog(vm){dialog=""}
 "objects"->ChoiceDialog("Objekt auswählen",d.entities.map{"${it.name.ifBlank{it.kind}} · ${it.id.take(6)}"},{dialog=""}){vm.selected=setOf(d.entities[it].id);propertyPanel=true}
 "quantity"->AlertDialog(onDismissRequest={dialog=""},title={Text("Mengen der Zeichnung")},text={Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState())){val rows=quantities(d,project.libraryEntries);if(rows.isEmpty())Text("Flächen, Hecken, Bäume und Bauteile platzieren oder Objekten eine Mengeneinheit zuweisen.");rows.forEach{Text("${it.label}: ${fmt(it.value)} ${it.unit}")}}},confirmButton={TextButton(onClick={dialog=""}){Text("Schließen")}})
 "backups"->ChoiceDialog("Automatische Sicherungen (${vm.backups().size}/10)",vm.backups().mapIndexed{i,b->"Sicherung ${i+1} · ${b.entities.size} Objekte"},{dialog=""}){vm.restoreBackup(it)}
 "variant"->FormDialog("Variante der Zeichnung",listOf(Field("name","Name",d.name+" · Variante B")),{dialog=""}){vm.addDrawing(it.getValue("name"),d.type,true)}
 "variables"->FormDialog("Freie Textvariable",listOf(Field("key","Variablenname ohne Klammern"),Field("value","Wert")),{dialog=""}){require(it["key"].orEmpty().isNotBlank());vm.edit(d.copy(variables=d.variables+(it.getValue("key") to it.getValue("value"))))}
 "calibrate"->FormDialog("Hintergrund kalibrieren",listOf(Field("distance","Reale Strecke mm","1000",true,true)),{dialog="";points=emptyList();calibrating=null}){v->val e=d.entities.find{it.id==calibrating}?:error("Hintergrund fehlt");vm.update(calibrate(e,points[0],points[1],parseNumber(v["distance"]!!)!!));fit++}
 "heightOnlyTop"->AlertDialog(onDismissRequest={dialog=""},title={Text("Höhe zuweisen")},text={Text("Dieses Werkzeug ist für die Draufsicht vorgesehen.")},confirmButton={TextButton(onClick={dialog=""}){Text("OK")}})
  "heightNoGrass"->AlertDialog(onDismissRequest={dialog=""},title={Text("Höhe zuweisen")},text={Text("Tippe auf eine höhenfähige Fläche (Rasen oder Pflasteraufbau).")},confirmButton={TextButton(onClick={dialog=""}){Text("OK")}})
  "assignPlanHeight"->{val source=d.entities.find{it.id in vm.selected};if(source!=null)FormDialog("Fixhöhe der Oberfläche",listOf(Field("height","Höhe am Fixpunkt in m",fmt(source.num("planHeightMm",d.elevationDatumMm)/1000.0),true)),{dialog=""}){v->val h=parseNumber(v["height"].orEmpty())?:return@FormDialog;val local=planLocalPoint(source,coordinate);val width=source.num("widthMm",1500.0).coerceAtLeast(1.0)
 val updated=source.withNum("planHeightMm",h*1000.0).withNum("planFixedFraction",(local.x/width).coerceIn(0.0,1.0))
 vm.update(updated)
 val anchor=planElevationAnchor(coordinate,d.copy(entities=d.entities.map{if(it.id==source.id)updated else it}))
 vm.add(Entity(kind="elevation",name="Fixhöhe",points=listOf(coordinate),anchors=anchor?.let{listOf(it)}?:emptyList(),params=buildJsonObject{put("elevationRole","relative");put("elevationPrefix","FIX");put("heightOffsetMm",0.0);put("elevationCreatedView","top")}))
 dialog=""}}
  "assignGrassHeight"->{val grass=d.entities.find{it.id in vm.selected};if(grass!=null)FormDialog("OK Rasen am Höhenpunkt",listOf(Field("height","Höhe in m","0,00",true)),{dialog=""}){v->val h=parseNumber(v["height"].orEmpty())?:0.0;val old=grass.params["grassHeights"] as? JsonArray ?: JsonArray(emptyList());val pointData=buildJsonObject{put("x",coordinate.x);put("y",coordinate.y);put("z",h*1000.0)};val nearby=old.indexOfFirst{val o=it as? JsonObject;val x=(o?.get("x") as? JsonPrimitive)?.doubleOrNull;val y=(o?.get("y") as? JsonPrimitive)?.doubleOrNull;x!=null&&y!=null&&Vec(x,y).distance(coordinate)<100.0};val next=old.toMutableList();if(nearby>=0)next[nearby]=pointData else next.add(pointData);vm.update(grass.copy(params=JsonObject(grass.params.toMutableMap().apply{put("grassHeights",JsonArray(next))})));dialog=""}}
 "measure"->AlertDialog(onDismissRequest={dialog=""},title={Text("Temporäre Messung")},text={val a=measurePoints.firstOrNull()?:Vec();val b=measurePoints.lastOrNull()?:a;Text("Fläche: ${fmt(area(measurePoints)/1e6)} m²\nLänge: ${fmt(length(measurePoints))} mm\nHorizontal: ${fmt(abs(b.x-a.x))} mm\nVertikal: ${fmt(abs(b.y-a.y))} mm\nWinkel: ${fmt(Math.toDegrees(atan2(b.y-a.y,b.x-a.x)))}°")},confirmButton={TextButton(onClick={vm.add(Entity(kind="dimension",points=measurePoints));dialog=""}){Text("Als Bemaßung")}},dismissButton={TextButton(onClick={dialog=""}){Text("Schließen")}})
 }
}
@Composable fun LayerDialog(vm:BaudetailViewModel,onDismiss:()->Unit){val d=vm.drawing?:return;var new by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Layer")},text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())){d.layers.forEach{layer->Column{Text(layer.name);Row{Checkbox(layer.visible,{v->vm.edit(d.copy(layers=d.layers.map{if(it.id==layer.id)it.copy(visible=v)else it}))});Text("Sichtbar");Checkbox(layer.locked,{v->vm.edit(d.copy(layers=d.layers.map{if(it.id==layer.id)it.copy(locked=v)else it}))});Text("Gesperrt")};Row{Checkbox(layer.printable,{v->vm.edit(d.copy(layers=d.layers.map{if(it.id==layer.id)it.copy(printable=v)else it}))});Text("Drucken")};HorizontalDivider()}};OutlinedTextField(new,{new=it},label={Text("Neuer Layer")});TextButton(onClick={if(new.isNotBlank()){vm.edit(d.copy(layers=d.layers+Layer(name=new)));new=""}}){Text("Hinzufügen")}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})}

/** Clip a diagonal construction joint to the paving polygon. */
private fun clipCutSegment(a:Vec,b:Vec,polygon:List<Vec>):List<Vec>? {
 val dx=b.x-a.x;val dy=b.y-a.y
 if(dx*dx+dy*dy<1e-9)return null
 val ts=mutableListOf(0.0,1.0)
 for(i in polygon.indices){
  val c=polygon[i];val d=polygon[(i+1)%polygon.size]
  val ex=d.x-c.x;val ey=d.y-c.y
  val denom=dx*ey-dy*ex
  if(kotlin.math.abs(denom)<1e-10)continue
  val t=((c.x-a.x)*ey-(c.y-a.y)*ex)/denom
  val u=((c.x-a.x)*dy-(c.y-a.y)*dx)/denom
  if(t in 0.0..1.0 && u in 0.0..1.0)ts.add(t)
 }
 val sorted=ts.distinct().sorted()
 fun inside(p:Vec):Boolean{
  var flag=false
  for(i in polygon.indices){val x=polygon[i];val y=polygon[(i+1)%polygon.size]
   if((x.y>p.y)!=(y.y>p.y) && p.x<(y.x-x.x)*(p.y-x.y)/(y.y-x.y)+x.x)flag=!flag
  };return flag
 }
 val intervals=sorted.zipWithNext().filter{(l,r)->inside(Vec(a.x+dx*(l+r)/2,a.y+dy*(l+r)/2))}
 val best=intervals.maxByOrNull{it.second-it.first}?:return null
 return listOf(Vec(a.x+dx*best.first,a.y+dy*best.first),Vec(a.x+dx*best.second,a.y+dy*best.second))
}
