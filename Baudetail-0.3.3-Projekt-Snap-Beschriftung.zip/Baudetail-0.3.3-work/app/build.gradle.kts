plugins { alias(libs.plugins.android.application); alias(libs.plugins.kotlin.android); alias(libs.plugins.compose.compiler) }
android {
 namespace = "de.baudetail"
 compileSdk = 35
 buildToolsVersion = "35.0.0"
 defaultConfig { minSdk = 26; applicationId = "de.baudetail"; targetSdk = 35; versionCode = 7; versionName = "0.3.3"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
 buildFeatures { compose = true }
 testOptions { unitTests.isIncludeAndroidResources = true }
 signingConfigs { getByName("debug") { storeFile=rootProject.file("debug-signing/baudetail-debug.keystore"); storePassword="android"; keyAlias="androiddebugkey"; keyPassword="android" } }
 buildTypes { release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}
dependencies {
 testImplementation("org.robolectric:robolectric:4.14.1")
 testImplementation(platform(libs.compose.bom))
 testImplementation(libs.compose.foundation)
 testImplementation(libs.compose.material3)
 testImplementation(libs.compose.ui.test)
 implementation(project(":ui"))
 androidTestImplementation(libs.android.test)
 androidTestImplementation(libs.android.runner)
 androidTestImplementation(platform(libs.compose.bom))
 androidTestImplementation(libs.compose.ui.test)
 constraints { androidTestImplementation(libs.annotation) }
 implementation(platform(libs.compose.bom))
 implementation(libs.compose.runtime)
 implementation(libs.activity)
 implementation(libs.viewmodel.core)
}
