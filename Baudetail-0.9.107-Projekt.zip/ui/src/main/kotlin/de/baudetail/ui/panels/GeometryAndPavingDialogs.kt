package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

@Composable
internal fun GeometryAndPavingDialogs(dialog:String,e:Entity,buildUp:Entity?,vm:BaudetailViewModel,setDialog:(String)->Unit,onAddCut:(String)->Unit){
 val d=vm.drawing?:return
 when(dialog){
 "retaining"->FormDialog("Mauerscheibe / Winkelstützelement",listOf(Field("height","Höhe mm",fmt(e.num("wallHeightMm",800.0)),true,true),Field("foot","Fußtiefe mm",fmt(e.num("footDepthMm",400.0)),true,true),Field("wall","Wandstärke mm",fmt(e.num("wallThicknessMm",70.0)),true,true),Field("slab","Fußstärke mm",fmt(e.num("footThicknessMm",100.0)),true,true),Field("length","Elementlänge mm",fmt(e.num("elementLengthMm",1000.0)),true,true),Field("side","Fußseite",if(e.str("footSide","right")=="left")"links"else"rechts",choices=listOf("rechts","links"))),{setDialog("")}){v->val h=parseNumber(v["height"]!!)!!;val f=parseNumber(v["foot"]!!)!!;val w=parseNumber(v["wall"]!!)!!;val slab=parseNumber(v["slab"]!!)!!;val len=parseNumber(v["length"]!!)!!;require(w<=f&&slab<=h){"Wand-/Fußstärke darf Gesamtmaß nicht überschreiten"};vm.update(e.withNum("wallHeightMm",h).withNum("sectionHeightMm",h).withNum("footDepthMm",f).withNum("sectionWidthMm",f).withNum("wallThicknessMm",w).withNum("footThicknessMm",slab).withNum("elementLengthMm",len).withNum("topWidthMm",len).withNum("topHeightMm",f).withStr("footSide",if(v["side"].orEmpty().startsWith("l",true))"left"else"right"))}
 "geometry"->{val origin=e.points.firstOrNull()?:Vec();val circle=e.kind=="circle";val line=e.kind=="line"
 val fields=listOf(Field("x",if(circle)"Mittelpunkt X mm"else"Position X mm",fmt(origin.x),true),Field("y",if(circle)"Mittelpunkt Y mm"else"Position Y mm",fmt(origin.y),true))+if(circle)listOf(Field("radius","Radius mm",fmt(e.num("radiusMm")),true,true))else listOf(Field("width",if(line)"Länge mm"else"Breite mm",fmt(e.points.getOrElse(1){origin}.distance(origin)),true,true),Field("angle","Drehwinkel Grad",fmt(rectangleAngle(e)),true))+(if(line)emptyList()else listOf(Field("height","Höhe / Tiefe mm",fmt(e.points.getOrElse(3){origin}.distance(origin)),true,true)))
 FormDialog("Geometrie bearbeiten",fields,{setDialog("")}){v->fun n(k:String)=parseNumber(v.getValue(k))!!
 val at=Vec(n("x"),n("y"))
 val sameOrigin=at.distance(e.points.first())<0.000001
 val sameAngle=kotlin.math.abs(n("angle")-rectangleAngle(e))<0.000001
 vm.update(if(circle)resizeCircle(e,n("radius"),at)else if(line)resizeLine(e,n("width"),n("angle"),at)else if(sameOrigin && sameAngle)resizeParametricRectangle(e,n("width"),n("height"))else resizeRectangle(e,n("width"),n("height"),at,n("angle")))}}
 "properties"->{val fields=mutableListOf(Field("name","Bezeichnung",e.name),Field("x","X in mm",fmt(e.points.firstOrNull()?.x?:0.0),true),Field("y","Y in mm",fmt(e.points.firstOrNull()?.y?:0.0),true),Field("status","Status",e.status,choices=listOf("Bestand","Planung","Abbruch")),Field("quantity","Mengeneinheit",e.quantityUnit.orEmpty(),choices=listOf("","m²","m","Stk","m³")))
 e.params.forEach{(k,v)->fields.add(Field(k,paramLabel(k),(v as? JsonPrimitive)?.content?:v.toString(),v is JsonPrimitive&&v.doubleOrNull!=null))}
 if(e.kind=="text"||e.kind=="leader"||e.kind=="dimension"||e.kind=="section"||e.kind=="legend")fields.add(Field("text","Text / manuelle Überschreibung",e.text))
 FormDialog("Objekteigenschaften",fields,{setDialog("")}){v->var result=transform(e,translation=Vec(parseNumber(v.getValue("x"))!!,parseNumber(v.getValue("y"))!!)-(e.points.firstOrNull()?:Vec())).copy(name=v["name"].orEmpty(),status=v["status"].orEmpty(),quantityUnit=v["quantity"]?.takeIf{it.isNotBlank()},text=v["text"]?:e.text)
 e.params.forEach{(k,value)->result=if(value is JsonPrimitive&&value.doubleOrNull!=null)result.withNum(k,parseNumber(v.getValue(k))!!)else result.withStr(k,v[k].orEmpty())}
 require(listOf("widthMm","heightMm","radiusMm","spacingMm","crownMm").all{!result.params.containsKey(it)||(it=="heightMm"&&result.kind=="elevation")||result.num(it)>0}){"Maße und Pflanzabstände müssen positiv sein"};vm.update(result)
 }}
 "points"->FormDialog("Eckpunkte (mm)",e.points.flatMapIndexed{i,p->listOf(Field("x$i","Punkt ${i+1}: X",fmt(p.x),true),Field("y$i","Punkt ${i+1}: Y",fmt(p.y),true))},{setDialog("")}){v->vm.update(e.copy(points=e.points.indices.map{i->Vec(parseNumber(v.getValue("x$i"))!!,parseNumber(v.getValue("y$i"))!!)}))}
 "style"->FormDialog("Linien und Texte",listOf(Field("stroke","Linienfarbe (#RRGGBB)",e.style.stroke),Field("fill","Füllfarbe (#RRGGBB, leer = keine)",e.style.fill.orEmpty()),Field("width","Linienstärke Papier in mm",fmt(e.style.widthMm),true,true),Field("opacity","Deckkraft 0–1",fmt(e.style.opacity),true),Field("textSize","Texthöhe Papier in mm",fmt(e.style.textPaperMm),true,true),Field("rotation","Drehung in Grad",fmt(e.rotation),true),Field("align","Textausrichtung",e.style.align,choices=listOf("left","center","right")),Field("font","Schrift",if(e.style.bold&&e.style.italic)"bolditalic"else if(e.style.bold)"bold"else if(e.style.italic)"italic"else"normal",choices=listOf("normal","bold","italic","bolditalic")),Field("frame","Rahmen",if(e.style.frame)"ja"else"nein",checkbox=true),Field("background","Texthintergrund (#RRGGBB, optional)",e.style.background.orEmpty())),{setDialog("")}){v->listOf("stroke","fill","background").forEach{require(v[it].isNullOrBlank()||Regex("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?").matches(v[it]!!)){"Ungültige Farbe"}};require(parseNumber(v["opacity"]!!)!! in 0.0..1.0);vm.update(transform(e,angle=parseNumber(v.getValue("rotation"))!!-e.rotation,center=e.points.firstOrNull()?:Vec()).copy(style=e.style.copy(stroke=v.getValue("stroke"),fill=v["fill"]?.takeIf{it.isNotBlank()},widthMm=parseNumber(v.getValue("width"))!!,opacity=parseNumber(v.getValue("opacity"))!!,textPaperMm=parseNumber(v.getValue("textSize"))!!,align=v.getValue("align"),bold=v["font"].orEmpty().contains("bold"),italic=v["font"].orEmpty().contains("italic"),frame=v["frame"]=="ja",background=v["background"]?.takeIf{it.isNotBlank()})))}
 "textLink"->ChoiceDialog("Textquelle ({name}, {widthMm}, {flaeche_m2}, {dicke_mm})",d.entities.filter{it.id!=e.id}.map{it.name.ifBlank{it.kind}},{setDialog("")}){i->vm.update(e.withStr("sourceId",d.entities.filter{it.id!=e.id}[i].id))}
 "layer"->ChoiceDialog("Layer",d.layers.map{it.name},{setDialog("")},selectedIndex=d.layers.indexOfFirst{it.id==e.layerId}.takeIf{it>=0}){i->vm.modifySelected{it.copy(layerId=d.layers[i].id)}}
 "transform"->FormDialog("Auswahl transformieren",listOf(Field("dx","Verschieben X (mm)","0",true),Field("dy","Verschieben Y (mm)","0",true),Field("angle","Drehen (Grad)","0",true),Field("scale","Skalierungsfaktor","1",true,true),Field("mirror","Spiegeln an vertikaler Achse","nein",checkbox=true)),{setDialog("")}){v->val chosen=d.entities.filter{it.id in vm.selected};val groupCenter=Bounds.of(chosen.flatMap{it.points}).center;vm.modifySelected{obj->val center=if(chosen.size==1)smartPivot(obj)else groupCenter;transform(obj,Vec(parseNumber(v["dx"]!!)!!,parseNumber(v["dy"]!!)!!),parseNumber(v["angle"]!!)!!,parseNumber(v["scale"]!!)!!,v["mirror"]=="ja",center)}}
 "symbol"->FormDialog("Als Bauteil speichern",listOf(Field("name","Bauteilname",e.name.ifBlank{"Eigenes Bauteil"})),{setDialog("")}){vm.saveSymbol(it.getValue("name"))}
 "pattern"->{val pattern=e.pattern?:Pattern();FormDialog("Verlegemuster",listOf(Field("width","Plattenlänge mm",fmt(pattern.widthMm),true,true),Field("height","Plattenbreite mm",fmt(pattern.heightMm),true,true),Field("joint","Fuge mm",fmt(pattern.jointMm),true),Field("angle","Winkel: 45 = diagonal",fmt(pattern.angle),true),Field("offset","Versatz: 0 = Kreuzfuge, 0,5 = Läufer",fmt(pattern.offset),true),Field("x","Ursprung X mm",fmt(pattern.origin.x),true),Field("y","Ursprung Y mm",fmt(pattern.origin.y),true),Field("cutX","Zuschnitt Breite",when(pattern.cutX){"left"->"Links";"both"->"Beidseitig";else->"Rechts"},choices=listOf("Links","Rechts","Beidseitig")),Field("cutY","Zuschnitt Länge",when(pattern.cutY){"top"->"Oben";"both"->"Beidseitig";else->"Unten"},choices=listOf("Oben","Unten","Beidseitig"))),{setDialog("")}){v->fun n(k:String):Double { return parseNumber(v.getValue(k))!! }
require(n("joint")>=0);vm.update(e.copy(pattern=Pattern(n("width"),n("height"),n("joint"),n("angle"),n("offset"),Vec(n("x"),n("y")),when(v["cutX"]){"Links"->"left";"Beidseitig"->"both";else->"right"},when(v["cutY"]){"Oben"->"top";"Beidseitig"->"both";else->"bottom"})))}}
 "stackEdit"->{
  val target=buildUp?:e;val p=target.pattern?:Pattern();val fields=mutableListOf<Field>()
  val libraryMaterials=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material"}.distinctBy{it.id}.sortedBy{it.name}
  // Only surface materials belong in the top paving layer. Keep the full catalog intact
  // for walls, planting and sub-base editors, and retain legacy IDs on placed objects.
  val excludedPavingTerms=listOf("wall","block","mauer","palisad","stütz","stuetz","rasen","wiese","saat","kies","splitt","schotter","sand 0/","brechsand","frost","trag","bettung","mulch","substrat","erde","pflanztrog","all an block","deca wall","garda wall","klassik wall","gran block","mix & match")
  val pavingLibrary=libraryMaterials.filter{entry->
   val label=(entry.name+" "+entry.category).lowercase(java.util.Locale.ROOT)
   val surface=entry.category.startsWith("Beläge/") || entry.category.startsWith("Belaege/") ||
    listOf("pflaster","platte","steinzeug","klinker","granit","jura","basalt","sandstein","quarzit").any{it in label}
   surface && excludedPavingTerms.none{it in label}
  }.distinctBy{it.name.trim().lowercase(java.util.Locale.ROOT)}
  val referenceCandidates=d.entities.filter{candidate->candidate.id!=target.id && candidate.kind=="stack" && adjacentPavingFootprints(target,candidate) && candidate.str("pavingPatternReferenceId")!=target.id && candidate.str("buildUpVariant")!="waterbound" && candidate.strata.firstOrNull()?.materialId==target.strata.firstOrNull()?.materialId && candidate.pattern?.let{cp->kotlin.math.abs(cp.widthMm-p.widthMm)<0.01 && kotlin.math.abs(cp.heightMm-p.heightMm)<0.01 && kotlin.math.abs(cp.jointMm-p.jointMm)<0.01 && kotlin.math.abs(cp.offset-p.offset)<0.0001}==true}
  val referenceChoices=listOf("Eigenständiger Verband")+referenceCandidates.map{candidate->"${candidate.name.ifBlank{"Pflasterfläche"}} · ${candidate.id.take(8)}"}
  val currentReference=referenceCandidates.indexOfFirst{it.id==target.str("pavingPatternReferenceId")}
  fields.add(Field("pavingReference","Verband an Nachbarfläche ausrichten",if(currentReference>=0)referenceChoices[currentReference+1] else referenceChoices.first(),choices=referenceChoices))
  fields.add(Field("buildUpVariant","Aufbauart",if(target.str("buildUpVariant") == "waterbound")"Wassergebundene Wegedecke" else "Pflaster / Platten",choices=listOf("Pflaster / Platten","Wassergebundene Wegedecke")))
  target.strata.forEachIndexed{i,layer->
   val water=target.str("buildUpVariant")=="waterbound"
   val choices=if(water)when(i){0->listOf("Brechsand 0/3","Kies gewaschen 4/8","Edelsplitt gewaschen 2/5","Sand","Sonstiges");1->listOf("Sand-Splitt-Gemisch 0/16","Sonstiges");else->frostMaterialChoices}else if(i==0)(buildUpMaterialChoices(i).filterNot{it=="Sonstiges"}+pavingLibrary.map{it.name}+"Sonstiges").distinct() else buildUpMaterialChoices(i)
   val saved=layer.materialId.ifBlank{layer.name}
   val libraryName=libraryMaterials.find{it.id==saved}?.name
   val current=(libraryName?:saved).takeIf{it in choices}?:"Sonstiges"
   fields.add(Field("material$i","Material Schicht ${i+1}",current,choices=choices))
   if(current=="Sonstiges")fields.add(Field("custom$i","Eigene Bezeichnung",layer.materialId.ifBlank{layer.name}))
   fields.add(Field("thickness$i","Dicke mm",fmt(layer.thicknessMm),true,true))
  }
  fields.addAll(listOf(
   Field("pathWidth","Grafische Breite Draufsicht mm",fmt(target.num("widthMm",1500.0)),true,true),
   Field("pathLength","Grafische Länge Draufsicht mm",fmt(target.num("topDepthMm",1000.0)),true,true),
   *buildUpMeasureFields(target).toTypedArray(),
   Field("pavingModeRaster","Rastermaß (einschließlich Fuge)",if(target.str("pavingDimensionMode","stone")=="raster")"ja" else "nein",checkbox=true),
   Field("pavingModeStone","Steinmaß (ohne Fuge)",if(target.str("pavingDimensionMode","stone")!="raster")"ja" else "nein",checkbox=true),
   Field("rasterWidth","Rasterlänge mm",fmt(p.widthMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("rasterHeight","Rasterbreite mm",fmt(p.heightMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("width","Steinlänge mm",fmt(p.widthMm),true,true,enabledWhen="pavingModeStone"),Field("height","Steinbreite mm",fmt(p.heightMm),true,true,enabledWhen="pavingModeStone"),Field("joint","Fugenbreite mm",fmt(p.jointMm),true),
   Field("musterEnabled","Musterverband aktivieren",if(p.musterEnabled)"ja" else "nein",checkbox=true),
   Field("bond","Verband",when{p.bond.isNotBlank()->p.bond;kotlin.math.abs(p.offset-1.0/3.0)<0.01->"Reihenverband 1/3";kotlin.math.abs(p.offset-.5)<0.01->"Reihenverband 1/2";kotlin.math.abs(p.offset-.25)<0.01->"Reihenverband 1/4";kotlin.math.abs(p.offset)<0.01->"Kreuzfuge";else->"freier Versatz"},choices=listOf("Kreuzfuge","Reihenverband 1/2","Reihenverband 1/3","Reihenverband 1/4","freier Versatz","Fischgrät 90°","Fischgrät 45°","Römischer Verband","Wilder Verband","Bahnenverband","Flechtverband","Ellbogenverband")),
   Field("externalPattern","Externes Originalmuster",vm.externalPatternChoices.firstOrNull{it.id==p.externalPatternId}?.label?:"Keines",choices=listOf("Keines")+vm.externalPatternChoices.map{it.label}),Field("formatCount","Steinformate im Muster (2–6)",p.formatCount.toString(),true),Field("formatSizes","Steinformate LxB mm (mit ; trennen)",p.formatSizes.ifBlank{"608x404;404x404;404x200;200x200"}),Field("offset","Freier Versatz 0–1",fmt(p.offset),true),Field("angle","Ausrichtung °",fmt(p.angle),true),
   Field("cutX","Zuschnitt Breite",when(p.cutX){"left"->"Links";"both"->"Beidseitig";else->"Rechts"},choices=listOf("Links","Rechts","Beidseitig")),
   Field("cutY","Zuschnitt Länge",when(p.cutY){"top"->"Oben";"both"->"Beidseitig";else->"Unten"},choices=listOf("Oben","Unten","Beidseitig"))))
  FormDialog(if(target.str("buildUpVariant")=="waterbound")"Wegeaufbau anpassen" else "Pflasteraufbau anpassen",fields,{setDialog("")},onAddCut=if(d.viewMode()=="top")({setDialog("");onAddCut(target.id)})else null){v->
   val off=when(v["bond"]){"Kreuzfuge"->0.0;"Reihenverband 1/2"->.5;"Reihenverband 1/3"->1.0/3.0;"Reihenverband 1/4"->.25;else->parseNumber(v["offset"].orEmpty())?:p.offset};require(off in 0.0..1.0)
   val jointMm=parseNumber(v["joint"]!!)!!
   require(jointMm>=0){"Fugenbreite darf nicht negativ sein"}
   val rasterMode=v["pavingModeRaster"]=="ja"
   val stoneWidth=if(rasterMode)(parseNumber(v["rasterWidth"]!!)!!-jointMm)else parseNumber(v["width"]!!)!!
   val stoneHeight=if(rasterMode)(parseNumber(v["rasterHeight"]!!)!!-jointMm)else parseNumber(v["height"]!!)!!
   require(stoneWidth>0 && stoneHeight>0){"Rastermaß muss größer als die Fugenbreite sein"}
   val waterbound=v["buildUpVariant"]=="Wassergebundene Wegedecke"
   val strata=target.strata.mapIndexed{i,layer->val chosen=v["material$i"].orEmpty();val material=if(chosen=="Sonstiges")v["custom$i"].orEmpty().ifBlank{layer.materialId.ifBlank{layer.name}}else pavingLibrary.find{it.name==chosen}?.id?:chosen;layer.copy(materialId=material,name=if(waterbound)when(i){0->"Deckschicht";1->"Tragschicht";2->"Frostschutz";else->layer.name}else when(i){0->"Pflaster";1->"Bettung";2->"Frostschutz";else->layer.name},thicknessMm=parseNumber(v.getValue("thickness$i"))!!,grading=buildUpGrading(chosen))}
   var result=target.copy(strata=strata,pattern=Pattern(stoneWidth,stoneHeight,jointMm,parseNumber(v["angle"]!!)!!,off,p.origin,when(v["cutX"]){"Links"->"left";"Beidseitig"->"both";else->"right"},when(v["cutY"]){"Oben"->"top";"Beidseitig"->"both";else->"bottom"},v["bond"].orEmpty().takeIf{it in listOf("Fischgrät 90°","Fischgrät 45°","Römischer Verband","Wilder Verband","Bahnenverband","Flechtverband","Ellbogenverband")}?:"",(v["formatCount"]?.toIntOrNull()?:p.formatCount).coerceIn(2,6),v["musterEnabled"]=="ja",v["formatSizes"].orEmpty(),if(v["musterEnabled"]=="ja")vm.externalPatternChoices.firstOrNull{it.label==v["externalPattern"]}?.id.orEmpty() else "",if(v["bond"]!="Römischer Verband" && v["musterEnabled"]=="ja" && v["externalPattern"] !in listOf(null,"Keines",""))requireNotNull(vm.loadExternalPattern(vm.externalPatternChoices.firstOrNull{it.label==v["externalPattern"]}?.id.orEmpty())){"Das externe Muster ist nicht wiederholbar oder enthält nicht unterstützte Geometrie"} else ""))
   val newWidth=parseNumber(v["pathWidth"]!!)!!
   val oldWidth=target.num("widthMm",1500.0)
   val sectionWidth=parseNumber(v["sectionWidth"]!!)!!
   val actualWidth=parseNumber(v["realWidth"]!!)!!
   require(newWidth>0 && sectionWidth>0 && actualWidth>0){"Breiten müssen größer als null sein"}
   // Keep the centerline fixed when resizing; the local near end stays at x=0.
   // Presentation offset belongs only to plan view, never to the section elevation.
   result=result.withNum("buildUpTopLengthOffsetMm",target.num("buildUpTopLengthOffsetMm")+(oldWidth-newWidth)/2.0)
   val graphicLength=parseNumber(v["pathLength"]!!)!!
   val sectionLength=parseNumber(v["sectionLength"]!!)!!
   val actualLength=parseNumber(v["realLength"]!!)!!
   require(graphicLength>0 && sectionLength>0 && actualLength>0){"Längen müssen größer als null sein"}
   result=result.withNum("widthMm",newWidth).withNum("buildUpSectionWidthMm",sectionWidth).withNum("buildUpRealWidthMm",actualWidth).withNum("topDepthMm",graphicLength).withNum("buildUpSectionLengthMm",sectionLength).withStr("labelEnabled","true")
    .withStr("buildUpRealLengthEnabled",if(v["realLengthEnabled"]=="ja" || kotlin.math.abs(actualLength-sectionLength)>0.01)"true" else "false")
    .withNum("buildUpRealLengthMm",actualLength)
   val slope=kotlin.math.abs(parseNumber(v["slopePct"].orEmpty())?:0.0)
   require(slope<=100.0){"Gefälle muss zwischen 0 und 100 % liegen"}
   result=result.withStr("buildUpSlopeFixedSide",if(v["slopeFixedSide"]=="Rechts")"right" else "left")
   result=result.withNum("buildUpSlopePct",if(v["slopeDirection"]=="Nach links fallend")-slope else slope)
    .withNum("buildUpSlopeLabelDx",parseNumber(v["slopeLabelDx"].orEmpty())?:0.0)
    .withNum("buildUpSlopeLabelDy",parseNumber(v["slopeLabelDy"].orEmpty())?:0.0)
   // Store the selected material definitions in the project so existing drawings
   // retain their appearance even when the external library is disconnected.
   strata.forEach{layer->libraryMaterials.find{it.id==layer.materialId}?.let{vm.attachLibraryForPlacedVariant(it)}}
   val selectedReference=referenceChoices.indexOf(v["pavingReference"].orEmpty())-1
   val referenceId=if(!waterbound && selectedReference in referenceCandidates.indices)referenceCandidates[selectedReference].id else ""
   vm.update(result.withStr("pavingPatternReferenceId",referenceId).withStr("pavingDimensionMode",if(rasterMode)"raster" else "stone").withStr("buildUpVariant",if(waterbound)"waterbound" else "paving"))
  }
 }
  "strata"->FormDialog("Pflasteraufbau",e.strata.flatMapIndexed{i,s->listOf(Field("name$i","Schicht ${i+1}: Name",s.name),Field("thickness$i","Dicke mm",fmt(s.thicknessMm),true,true),Field("grading$i","Körnung (z. B. 2/5 oder 0/32)",s.grading))},{setDialog("")}){v->vm.update(e.copy(strata=e.strata.mapIndexed{i,s->s.copy(name=v.getValue("name$i"),thicknessMm=parseNumber(v.getValue("thickness$i"))!!,grading=v["grading$i"].orEmpty())}))}
 "stackPattern"->{val p=e.pattern?:Pattern();FormDialog("Pflaster · Draufsicht",listOf(Field("pavingModeRaster","Rastermaß (einschließlich Fuge)",if(e.str("pavingDimensionMode","stone")=="raster")"ja" else "nein",checkbox=true),
   Field("pavingModeStone","Steinmaß (ohne Fuge)",if(e.str("pavingDimensionMode","stone")!="raster")"ja" else "nein",checkbox=true),
   Field("rasterWidth","Rasterlänge mm",fmt(p.widthMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("rasterHeight","Rasterbreite mm",fmt(p.heightMm+p.jointMm),true,true,enabledWhen="pavingModeRaster"),
   Field("width","Steinlänge mm",fmt(p.widthMm),true,true,enabledWhen="pavingModeStone"),Field("height","Steinbreite mm",fmt(p.heightMm),true,true,enabledWhen="pavingModeStone"),Field("joint","Fugenbreite mm",fmt(p.jointMm),true),Field("musterEnabled","Musterverband aktivieren",if(p.musterEnabled)"ja" else "nein",checkbox=true),
   Field("bond","Verband",when{p.bond.isNotBlank()->p.bond; kotlin.math.abs(p.offset-1.0/3.0)<0.01->"Reihenverband 1/3";kotlin.math.abs(p.offset-.5)<0.01->"Reihenverband 1/2";kotlin.math.abs(p.offset-.25)<0.01->"Reihenverband 1/4";kotlin.math.abs(p.offset)<0.01->"Kreuzfuge";else->"freier Versatz"},choices=listOf("Kreuzfuge","Reihenverband 1/2","Reihenverband 1/3","Reihenverband 1/4","freier Versatz","Fischgrät 90°","Fischgrät 45°","Römischer Verband","Wilder Verband","Bahnenverband","Flechtverband","Ellbogenverband")),Field("externalPattern","Externes Originalmuster",vm.externalPatternChoices.firstOrNull{it.id==p.externalPatternId}?.label?:"Keines",choices=listOf("Keines")+vm.externalPatternChoices.map{it.label}),Field("formatCount","Steinformate im Muster (2–6)",p.formatCount.toString(),true),Field("formatSizes","Steinformate LxB mm (mit ; trennen)",p.formatSizes.ifBlank{"608x404;404x404;404x200;200x200"}),Field("offset","Freier Versatz 0–1",fmt(p.offset),true),Field("angle","Ausrichtung °",fmt(p.angle),true),Field("depth","Darstellungsbreite Draufsicht mm",fmt(e.num("topDepthMm",1000.0)),true,true),Field("cutX","Zuschnitt Breite",when(p.cutX){"left"->"Links";"both"->"Beidseitig";else->"Rechts"},choices=listOf("Links","Rechts","Beidseitig")),Field("cutY","Zuschnitt Länge",when(p.cutY){"top"->"Oben";"both"->"Beidseitig";else->"Unten"},choices=listOf("Oben","Unten","Beidseitig"))),{setDialog("")}){v->val off=when(v["bond"]){"Kreuzfuge"->0.0;"Reihenverband 1/2"->.5;"Reihenverband 1/3"->1.0/3.0;"Reihenverband 1/4"->.25;else->parseNumber(v["offset"].orEmpty())?:p.offset};require(off in 0.0..1.0);val jointMm=parseNumber(v["joint"]!!)!!
   require(jointMm>=0){"Fugenbreite darf nicht negativ sein"}
   val rasterMode=v["pavingModeRaster"]=="ja"
   val stoneWidth=if(rasterMode)(parseNumber(v["rasterWidth"]!!)!!-jointMm)else parseNumber(v["width"]!!)!!
   val stoneHeight=if(rasterMode)(parseNumber(v["rasterHeight"]!!)!!-jointMm)else parseNumber(v["height"]!!)!!
   require(stoneWidth>0 && stoneHeight>0){"Rastermaß muss größer als die Fugenbreite sein"}
   vm.update(e.copy(pattern=Pattern(stoneWidth,stoneHeight,jointMm,parseNumber(v["angle"]!!)!!,off,p.origin,when(v["cutX"]){"Links"->"left";"Beidseitig"->"both";else->"right"},when(v["cutY"]){"Oben"->"top";"Beidseitig"->"both";else->"bottom"},v["bond"].orEmpty().takeIf{it in listOf("Fischgrät 90°","Fischgrät 45°","Römischer Verband","Wilder Verband","Bahnenverband","Flechtverband","Ellbogenverband")}?:"",(v["formatCount"]?.toIntOrNull()?:p.formatCount).coerceIn(2,6),v["musterEnabled"]=="ja",v["formatSizes"].orEmpty(),if(v["musterEnabled"]=="ja")vm.externalPatternChoices.firstOrNull{it.label==v["externalPattern"]}?.id.orEmpty() else "",if(v["bond"]!="Römischer Verband" && v["musterEnabled"]=="ja" && v["externalPattern"] !in listOf(null,"Keines",""))requireNotNull(vm.loadExternalPattern(vm.externalPatternChoices.firstOrNull{it.label==v["externalPattern"]}?.id.orEmpty())){"Das externe Muster ist nicht wiederholbar oder enthält nicht unterstützte Geometrie"} else "")).withNum("topDepthMm",parseNumber(v["depth"]!!)!!).withStr("pavingDimensionMode",if(rasterMode)"raster" else "stone"))}}
 }
}


