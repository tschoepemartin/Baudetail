package de.baudetail.ui.dialogs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import de.baudetail.geometry.parseNumber

data class Field(val key:String,val label:String,val initial:String="",val numeric:Boolean=false,val positive:Boolean=false,val choices:List<String> = emptyList(),val checkbox:Boolean=false,val enabledWhen:String?=null,val visibleChoiceKey:String?=null,val visibleChoiceValue:String?=null,val choiceDependsOn:String?=null,val choiceMap:Map<String,List<String>> = emptyMap())
@Composable fun FormDialog(title:String,fields:List<Field>,onDismiss:()->Unit,onAddCut:(()->Unit)?=null,onSubmit:(Map<String,String>)->Unit){
 val values=remember(fields){mutableStateMapOf<String,String>().apply{fields.forEach{put(it.key,it.initial)}}}
 var error by remember{mutableStateOf<String?>(null)};var openChoice by remember{mutableStateOf<String?>(null)}
 var paletteOpen by remember{mutableStateOf(false)}
 var paletteTarget by remember{mutableStateOf("customHex")}
 var paletteMode by remember{mutableStateOf("HEX")}
 var paletteHex by remember{mutableStateOf("#92979A")}
 var ralQuery by remember{mutableStateOf("")}
 val ralColors=listOf(
  Triple("RAL 1000 Grünbeige","#BEBD7F","1000"),Triple("RAL 1013 Perlweiß","#EAE6CA","1013"),Triple("RAL 1023 Verkehrsgelb","#F0CA00","1023"),
  Triple("RAL 2004 Reinorange","#E75B12","2004"),Triple("RAL 3000 Feuerrot","#AF2B1E","3000"),Triple("RAL 3011 Braunrot","#781F19","3011"),
  Triple("RAL 5002 Ultramarinblau","#20214F","5002"),Triple("RAL 5010 Enzianblau","#004F7C","5010"),Triple("RAL 5015 Himmelblau","#007CB0","5015"),
  Triple("RAL 6005 Moosgrün","#114232","6005"),Triple("RAL 6011 Resedagrün","#6C7C59","6011"),Triple("RAL 6029 Minzgrün","#007243","6029"),
  Triple("RAL 7016 Anthrazitgrau","#383E42","7016"),Triple("RAL 7021 Schwarzgrau","#23282B","7021"),Triple("RAL 7035 Lichtgrau","#CBD0CC","7035"),
  Triple("RAL 8004 Kupferbraun","#8D4931","8004"),Triple("RAL 8017 Schokoladenbraun","#45322E","8017"),Triple("RAL 9005 Tiefschwarz","#0E0E10","9005"),
  Triple("RAL 9010 Reinweiß","#F1ECE1","9010"),Triple("RAL 9016 Verkehrsweiß","#F6F6F6","9016")
 )
 val waterboundEditor="buildUpVariant" in values
 val waterbound=values["buildUpVariant"]=="Wassergebundene Wegedecke"
 val effectiveTitle=if(waterboundEditor)if(waterbound)"Wegeaufbau anpassen" else "Pflasteraufbau anpassen" else title
 val waterChoices=listOf(
  listOf("Brechsand 0/3","Kies gewaschen 4/8","Edelsplitt gewaschen 2/5","Sand","Sonstiges"),
  listOf("Sand-Splitt-Gemisch 0/16","Sonstiges"),
  listOf("FS-Kies 0/32","Frostschutz 0/45","Frostschutz 0/56","Sonstiges"))
 val pavingKeys=setOf("pavingModeRaster","pavingModeStone","rasterWidth","rasterHeight","width","height","joint","bond","offset","angle","cutX","cutY","musterEnabled","formatCount","formatSizes","externalPattern")
 val rememberedVariants=remember{mutableStateMapOf<String,Map<String,String>>()}
 AlertDialog(onDismissRequest=onDismiss,title={Text(effectiveTitle)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  fields.forEach{f->
   if(waterboundEditor && waterbound && f.key in pavingKeys)return@forEach
   if(f.visibleChoiceKey!=null && values[f.visibleChoiceKey]!=f.visibleChoiceValue)return@forEach
   if(f.key=="formatCount" && values["bond"]=="Römischer Verband")return@forEach
   if(f.key=="romanPreset" && (values["bond"]!="Römischer Verband" || values["musterEnabled"]!="ja"))return@forEach
   if(f.key in setOf("bond","formatSizes","externalPattern","offset") && values["musterEnabled"]!="ja")return@forEach
   if(f.key=="offset" && values["bond"]!="freier Versatz")return@forEach
   if(f.key=="externalPattern" && values["bond"]=="Römischer Verband")return@forEach
   if(f.key=="formatSizes" && values["bond"] !in setOf("Römischer Verband","Wilder Verband","Bahnenverband","Flechtverband","Ellbogenverband"))return@forEach
   if(f.key=="externalPattern" && values["musterEnabled"]!="ja")return@forEach
   val enabled=f.enabledWhen?.let{values[it].orEmpty().lowercase() in setOf("ja","true","1","an")}?:true
   when{
   f.checkbox->{Row(Modifier.fillMaxWidth()){Checkbox(values[f.key].orEmpty().lowercase() in setOf("ja","true","1","an"),{checked->
     if(f.key=="pavingModeRaster" || f.key=="pavingModeStone"){
      if(checked){values["pavingModeRaster"]=if(f.key=="pavingModeRaster")"ja" else "nein";values["pavingModeStone"]=if(f.key=="pavingModeStone")"ja" else "nein"}
     } else values[f.key]=if(checked)"ja"else"nein"
    });Text(f.label,Modifier.padding(top=12.dp))}}
   f.choices.isNotEmpty()->{val choices=if(f.choiceDependsOn!=null)f.choiceMap[values[f.choiceDependsOn]].orEmpty() else if(waterboundEditor && waterbound && f.key.matches(Regex("material[0-2]")))waterChoices[f.key.last().digitToInt()] else f.choices
    Box{OutlinedButton(onClick={openChoice=f.key},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text("${f.label}: ${values[f.key].orEmpty()}");Spacer(Modifier.weight(1f));Text("▾")}};DropdownMenu(expanded=openChoice==f.key,onDismissRequest={openChoice=null}){choices.forEach{choice->DropdownMenuItem(text={Row(Modifier.fillMaxWidth()){Text(choice);Spacer(Modifier.weight(1f));if(values[f.key]==choice)Text("✓")}},onClick={
     if(f.key=="buildUpVariant" && choice!=values[f.key]){
      val old=values[f.key].orEmpty()
      rememberedVariants[old]=values.toMap()
      val previous=rememberedVariants[choice]
      if(previous!=null)previous.filterKeys{it!="buildUpVariant"}.forEach{(key,value)->values[key]=value}
      else if(choice=="Wassergebundene Wegedecke"){
       listOf("Brechsand 0/3","Sand-Splitt-Gemisch 0/16","FS-Kies 0/32").forEachIndexed{index,material->values["material$index"]=material}
       listOf("10","100","300").forEachIndexed{index,mm->values["thickness$index"]=mm}
      }else{
       listOf("Betonpflaster","Splitt 2/5","FS-Kies 0/32").forEachIndexed{index,material->values["material$index"]=material}
       listOf("80","40","300").forEachIndexed{index,mm->values["thickness$index"]=mm}
      }
     }
     values[f.key]=choice
     if(f.key=="romanPreset"){
      val j=values["joint"].orEmpty().replace(',','.').toDoubleOrNull()?.coerceAtLeast(0.0)?:4.0
      val u=values["width"].orEmpty().replace(',','.').toDoubleOrNull()?.takeIf{it>j}?:200.0
      fun size(a:Int,b:Int)="${a*u+(a-1)*j}x${b*u+(b-1)*j}"
      values["formatSizes"]=if(choice=="3 Formate")listOf(size(2,2),size(2,1),size(1,1)).joinToString(";") else listOf(size(3,2),size(2,2),size(2,1),size(1,1)).joinToString(";")
     }
     if(f.key=="color" && choice=="Farbpalette"){
      paletteTarget="customHex";paletteHex=values["customHex"].orEmpty().ifBlank{"#92979A"}
      paletteOpen=true
     }
     // Cascade resets through all dependent selectors (manufacturer -> series -> variant).
     val pending=ArrayDeque<String>();pending.add(f.key)
     while(pending.isNotEmpty()){
      val parent=pending.removeFirst()
      fields.filter{it.choiceDependsOn==parent}.forEach{dependent->
       val allowed=dependent.choiceMap[values[parent]].orEmpty()
       if(values[dependent.key] !in allowed){values[dependent.key]=allowed.firstOrNull().orEmpty();pending.add(dependent.key)}
      }
     }
     openChoice=null
    })}}}}
   else->{
    if(f.key in setOf("stroke","fill","background") || (f.key.startsWith("color") && f.label.contains("Farbe"))){
     OutlinedButton(onClick={paletteTarget=f.key;paletteHex=values[f.key].orEmpty().ifBlank{"#000000"};paletteMode="HEX";paletteOpen=true},modifier=Modifier.fillMaxWidth()){
      Text("${f.label} · Farbpalette öffnen")
     }
    }
    OutlinedTextField(values[f.key].orEmpty(),{values[f.key]=it},enabled=enabled,label={Text(f.label)},keyboardOptions=KeyboardOptions(keyboardType=if(f.numeric && !f.positive)KeyboardType.Text else if(f.numeric)KeyboardType.Decimal else KeyboardType.Text),modifier=Modifier.fillMaxWidth(),minLines=if(f.key=="notes"||f.key=="text"||f.key=="template")3 else 1)
   }
  }}
  if(waterboundEditor && !waterbound && onAddCut!=null){
   HorizontalDivider()
   OutlinedButton(onClick=onAddCut,modifier=Modifier.fillMaxWidth()){
    Text("Schnittkante hinzufügen")
   }
  }
  if(values["color"]=="Farbpalette"){
   OutlinedButton(onClick={paletteOpen=true},modifier=Modifier.fillMaxWidth()){Text("Farbpalette öffnen · ${values["customHex"].orEmpty()}")}
  }
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
  if(paletteOpen){
   AlertDialog(onDismissRequest={paletteOpen=false},title={Text("Farbpalette")},text={Column(Modifier.fillMaxWidth().heightIn(max=460.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     listOf("HEX","RAL").forEach{mode->FilterChip(selected=paletteMode==mode,onClick={paletteMode=mode},label={Text(mode)})}
    }
    if(paletteMode=="HEX"){
     val swatches=listOf("#FFFFFF","#C0C0C0","#808080","#404040","#000000","#FF0000","#FF8800","#FFFF00","#008000","#00FFFF","#0000FF","#8000FF","#FF00FF","#8B4513","#985D48","#92979A")
     swatches.chunked(8).forEach{line->Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){line.forEach{hex->Box(Modifier.size(29.dp).background(Color(android.graphics.Color.parseColor(hex)),RoundedCornerShape(4.dp)).clickable{paletteHex=hex})}}}
     OutlinedTextField(paletteHex,{paletteHex=it},label={Text("HEX · #RRGGBB")},singleLine=true)
     val parsed=runCatching{android.graphics.Color.parseColor(paletteHex)}.getOrNull()
     if(parsed!=null){
      Box(Modifier.fillMaxWidth().height(42.dp).background(Color(parsed),RoundedCornerShape(6.dp)))
      Text("R: ${android.graphics.Color.red(parsed)}   G: ${android.graphics.Color.green(parsed)}   B: ${android.graphics.Color.blue(parsed)}")
     }else Text("Ungültiger HEX-Wert",color=MaterialTheme.colorScheme.error)
    }else{
     OutlinedTextField(ralQuery,{ralQuery=it},label={Text("RAL-Nummer oder Farbname suchen")},singleLine=true)
     ralColors.filter{it.first.contains(ralQuery,true)}.forEach{(label,hex,_)->Row(Modifier.fillMaxWidth().clickable{paletteHex=hex}.padding(vertical=3.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
      Box(Modifier.size(28.dp).background(Color(android.graphics.Color.parseColor(hex)),RoundedCornerShape(4.dp)))
      Text(label)
      if(paletteHex.equals(hex,true))Text("✓")
     }}
     Text("RAL-Farben sind Bildschirm-Näherungen, keine verbindlichen Farbmuster.",style=MaterialTheme.typography.bodySmall)
    }
   }},confirmButton={TextButton(onClick={if(runCatching{android.graphics.Color.parseColor(paletteHex)}.isSuccess){values[paletteTarget]=paletteHex;paletteOpen=false}}){Text("Farbe übernehmen")}},dismissButton={TextButton(onClick={paletteOpen=false}){Text("Abbrechen")}})
  }
 }},confirmButton={TextButton(onClick={val bad=fields.firstOrNull{it.numeric&&(it.visibleChoiceKey==null||values[it.visibleChoiceKey]==it.visibleChoiceValue)&&(it.enabledWhen==null||values[it.enabledWhen]=="ja")&&(parseNumber(values[it.key].orEmpty())==null||(it.positive&&(parseNumber(values[it.key].orEmpty())?:0.0)<=0))};if(bad!=null)error="${bad.label}: gültige ${if(bad.positive)"positive "else""}Zahl eingeben"else try{onSubmit(values.toMap());onDismiss()}catch(e:Exception){error=e.message}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
@Composable fun ChoiceDialog(title:String,choices:List<String>,onDismiss:()->Unit,selectedIndex:Int?=null,onChoose:(Int)->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())){choices.forEachIndexed{i,s->TextButton(onClick={onDismiss();onChoose(i)},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text(s);Spacer(Modifier.weight(1f));if(selectedIndex==i)Text("✓")}}}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})}

@Composable fun ElevationDialog(title:String,initialRole:String,initialHeight:String,initialPrefix:String,initialFontMm:Double,initialArrowMm:Double,onDismiss:()->Unit,onSubmit:(String,Double,String,Double,Double)->Unit){
 ElevationDialogWithLeaders(title,initialRole,initialHeight,initialPrefix,initialFontMm,initialArrowMm,emptyList(),"",{},"Keine Oberfläche erkannt",2,onDismiss,{role,value,prefix,font,arrow,_->onSubmit(role,value,prefix,font,arrow)})
}
@Composable
fun ElevationDialogWithLeaders(
 title: String,
 initialRole: String,
 initialHeight: String,
 initialPrefix: String,
 initialFontMm: Double,
 initialArrowMm: Double,
 planLeaders: List<Pair<String, String>>,
 selectedPlanLeaderId: String,
 onPlanLeaderSelected: (String) -> Unit,
 surfaceLabel: String,
 initialDecimals: Int,
 onDismiss: () -> Unit,
 onSubmit: (String, Double, String, Double, Double, Int) -> Unit
){
 var decimals by remember{mutableIntStateOf(initialDecimals.coerceIn(2,4))};var decimalExpanded by remember{mutableStateOf(false)};var role by remember{mutableStateOf(initialRole)};var height by remember{mutableStateOf(initialHeight)};var prefix by remember{mutableStateOf(initialPrefix)};var fontMm by remember{mutableStateOf(initialFontMm.toString())};var arrowMm by remember{mutableStateOf(initialArrowMm.toString())};var error by remember{mutableStateOf<String?>(null)}
 val roles=listOf("relative" to "Relativ automatisch","leader" to "Leader / Bezugshöhe","manual" to "Manuell")
 AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("Gemessene Oberfläche: $surfaceLabel",style=MaterialTheme.typography.bodySmall)
  Box { OutlinedButton(onClick={decimalExpanded=true}){Text("Nachkommastellen: $decimals ▾")};DropdownMenu(expanded=decimalExpanded,onDismissRequest={decimalExpanded=false}){(2..4).forEach{n->DropdownMenuItem(text={Text("$n Nachkommastellen")},onClick={decimals=n;decimalExpanded=false})}}}
  Text("Art");roles.forEach{(key,label)->Row(Modifier.fillMaxWidth()){RadioButton(selected=role==key,onClick={role=key});Text(label,Modifier.padding(top=12.dp));Spacer(Modifier.weight(1f));if(role==key)Text("✓",Modifier.padding(top=12.dp))}}
  if(role=="relative" && planLeaders.isNotEmpty()){
   var leaderExpanded by remember{mutableStateOf(false)}
   Box { OutlinedButton(onClick={leaderExpanded=true}){Text(planLeaders.firstOrNull{it.first==selectedPlanLeaderId}?.second?:"Leader auswählen ▾")}
    DropdownMenu(expanded=leaderExpanded,onDismissRequest={leaderExpanded=false}){planLeaders.forEach{(id,label)->DropdownMenuItem(text={Text(label)},onClick={onPlanLeaderSelected(id);leaderExpanded=false})}}
   }
  }
  OutlinedTextField(height,{height=it},label={Text(if(role=="relative")"Zusatz/Offset (m)" else "Höhe (m)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Text),modifier=Modifier.fillMaxWidth())
  OutlinedTextField(prefix,{prefix=it},label={Text("Bezeichnung optional, z. B. OK / UK / Sohle")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(fontMm,{fontMm=it},label={Text("Schriftgröße auf Papier (mm)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
  OutlinedTextField(arrowMm,{arrowMm=it},label={Text("Pfeilgröße auf Papier (mm)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
  if(role=="relative")Text("Die Höhe wird aus dem Leader und der geometrischen Höhendifferenz des gefangenen Bauteilpunkts berechnet.",style=MaterialTheme.typography.bodySmall)
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 }},confirmButton={TextButton(onClick={val n=parseNumber(height);if(n==null||parseNumber(fontMm)==null||parseNumber(arrowMm)==null||(parseNumber(fontMm)?:0.0)<=0||(parseNumber(arrowMm)?:0.0)<=0)error="Gültige Zahlen eingeben" else {onSubmit(role,n,prefix,parseNumber(fontMm)!!,parseNumber(arrowMm)!!,decimals);onDismiss()}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
