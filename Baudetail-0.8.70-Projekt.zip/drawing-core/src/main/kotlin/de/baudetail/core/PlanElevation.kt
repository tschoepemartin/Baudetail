package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

/** 2.5D surface attached to the actual plan footprint, never to the section Y axis. */
data class PlanSurface(val source:Entity,val polygon:List<Vec>)

fun planFootprint(e:Entity,d:Drawing):List<Vec> = when {
 isStair(e) -> smartSnapOutline(e,d.withViewMode("top"))
 e.isParametricBuildUp() -> rectangle(Vec(),Vec(e.num("planGraphicWidthMm",e.num("widthMm",1500.0)),e.num("topDepthMm",1000.0))).map{buildUpPlanOrigin(e)+it.rotate(buildUpPlanAngle(e))}
 e.str("grassObject")=="true" -> resolvedPoints(e,d.withViewMode("top"))
 e.kind in setOf("area","polygon","rect","paving","path") -> resolvedPoints(e,d.withViewMode("top"))
 else -> emptyList()
}

private fun insidePolygon(p:Vec,polygon:List<Vec>):Boolean {
 if(polygon.size<3)return false
 var inside=false
 for(i in polygon.indices){val a=polygon[i];val b=polygon[(i+1)%polygon.size]
  if(closestOnSegment(p,a,b).distance(p)<0.01)return true
  if((a.y>p.y)!=(b.y>p.y) && p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside
 }
 return inside
}

fun planSurfaceAt(point:Vec,d:Drawing):PlanSurface?=d.entities.asReversed().firstNotNullOfOrNull{e->
 if(!visibleIn(e,d)||e.locked||e.kind=="elevation")null else planFootprint(e,d).takeIf{insidePolygon(point,it)}?.let{PlanSurface(e,it)}
}

/** Local coordinates travel with the construction when moved or rotated. */
fun planLocalPoint(source:Entity,world:Vec):Vec {
 val origin=if(source.isParametricBuildUp())buildUpPlanOrigin(source) else source.points.firstOrNull()?:Vec()
 val angle=if(source.isParametricBuildUp())buildUpPlanAngle(source) else source.rotation
 return (world-origin).rotate(-angle)
}
fun planWorldPoint(source:Entity,local:Vec):Vec {
 val origin=if(source.isParametricBuildUp())buildUpPlanOrigin(source) else source.points.firstOrNull()?:Vec()
 val angle=if(source.isParametricBuildUp())buildUpPlanAngle(source) else source.rotation
 return origin+local.rotate(angle)
}

/** Plan Z in mm. A defined datum and longitudinal slope describe a plane.
 * Optional measured grass points override that plane using exact matches and
 * inverse-distance interpolation, pending a future triangulated terrain model. */
fun planSurfaceHeightMm(source:Entity,world:Vec,d:Drawing):Double? {
 if(isStair(source))return source.params["planHeightMm"]?.let{(it as? JsonPrimitive)?.doubleOrNull}?.plus(stairPlanRelativeZMm(source,world))
 val local=planLocalPoint(source,world)
 val slope=buildUpSlopePercent(source)
 val fixedRight=source.str("buildUpSlopeFixedSide","left")=="right"
 val length=if(source.str("grassObject")=="true")source.num("grassRealLengthMm",source.num("grassSectionLengthMm",1000.0)) else buildUpRealLengthMm(source)
 val footprintLength=if(source.isParametricBuildUp())source.num("planGraphicWidthMm",source.num("widthMm",1500.0)).coerceAtLeast(1.0) else Bounds.of(planFootprint(source,d.withViewMode("top"))).width.coerceAtLeast(1.0)
 val longitudinalDepth=if(source.isParametricBuildUp())source.num("topDepthMm",1000.0).coerceAtLeast(1.0) else footprintLength
 val normalized=(if(source.isParametricBuildUp())local.y/longitudinalDepth else local.x/footprintLength).coerceIn(0.0,1.0)
 val fixedFraction=source.num("planFixedFraction",if(fixedRight)1.0 else 0.0).coerceIn(0.0,1.0)
 // Independent local axes: longitudinal slope follows local X, crossfall local Y.
 // Zero crossfall guarantees an equal elevation across each transverse edge.
 val depth=source.num("topDepthMm",source.num("planGraphicDepthMm",1000.0)).coerceAtLeast(1.0)
 val crossSlope=source.num("planCrossSlopePct",0.0).coerceIn(-100.0,100.0)
 val crossFixed=source.num("planCrossFixedFraction",0.0).coerceIn(0.0,1.0)
 val drop=(normalized-fixedFraction)*length*slope/100.0 +
   ((if(source.isParametricBuildUp())local.x/footprintLength else local.y/depth).coerceIn(0.0,1.0)-crossFixed)*(if(source.isParametricBuildUp())footprintLength else depth)*crossSlope/100.0
 val base=source.params["planHeightMm"]?.let { (it as? JsonPrimitive)?.doubleOrNull }
 val points=(source.params["grassHeights"] as? JsonArray)?.mapNotNull{v->
  val o=v as? JsonObject?:return@mapNotNull null
  val x=(o["x"] as? JsonPrimitive)?.doubleOrNull?:return@mapNotNull null
  val y=(o["y"] as? JsonPrimitive)?.doubleOrNull?:return@mapNotNull null
  val z=(o["z"] as? JsonPrimitive)?.doubleOrNull?:return@mapNotNull null
  Vec(x,y) to z
 }.orEmpty()
 if(points.isEmpty())return base?.minus(drop)
 val exact=points.firstOrNull{it.first.distance(world)<0.01}
 if(exact!=null)return exact.second
 var weight=0.0;var sum=0.0
 for((p,z) in points){val w=1.0/(p.distance(world).coerceAtLeast(1.0).let{it*it});weight+=w;sum+=w*z}
 return if(weight>0.0)sum/weight else base?.minus(drop)
}

fun planElevationAnchor(point:Vec,d:Drawing):Anchor? {
 val surface=planSurfaceAt(point,d)?:return null
 val local=if(isStair(surface.source)) (point-smartViewOrigin(surface.source,"top")).rotate(-smartViewRotation(surface.source,"top")) else planLocalPoint(surface.source,point)
 return Anchor(surface.source.id,reference="planSurface",view="top",offset=local)
}
fun planElevationPoint(e:Entity,d:Drawing):Vec? {
 val a=e.anchors.firstOrNull{it.reference=="planSurface"}?:return null
 val source=d.entities.find{it.id==a.entityId}?:return null
 return if(isStair(source))assemblyPoint(source,a.offset,"top") else planWorldPoint(source,a.offset)
}
fun planElevationHeight(e:Entity,d:Drawing):Double? {
 val a=e.anchors.firstOrNull{it.reference=="planSurface"}?:return null
 val source=d.entities.find{it.id==a.entityId}?:return null
 return planSurfaceHeightMm(source,planElevationPoint(e,d)?:return null,d)
}

/** Project a section surface marker to the corresponding plan construction edge.
 * Only geometrically anchored markers can be projected; free section coordinates
 * are deliberately not guessed. Section distances use normalized real station. */
fun sectionElevationPlanPoint(e:Entity,d:Drawing):Vec? {
 if(e.kind!="elevation" || e.str("elevationCreatedView", "section")!="section")return null
 val a=e.anchors.firstOrNull{it.reference=="elevationSurface" && it.view=="section"}?:return null
 val source=d.entities.find{it.id==a.entityId}?:return null
 val fraction=a.fraction.coerceIn(0.0,1.0)
 if(source.isParametricBuildUp()) {
  val x=source.num("planGraphicWidthMm",source.num("widthMm",1500.0))*fraction
  val y=source.num("topDepthMm",1000.0)
  return planWorldPoint(source,Vec(x,y))
 }
 if(source.str("grassObject")=="true") {
  val footprint=planFootprint(source,d.withViewMode("top"))
  if(footprint.size<3)return null
  val edges=footprint.indices.map{i->footprint[i] to footprint[(i+1)%footprint.size]}
  val edge=edges.maxByOrNull{(u,v)->(u.x+v.x)/2.0}?:return null
  return edge.first+(edge.second-edge.first)*fraction
 }
 return null
}

/** Relative level on the same physical paving surface, independent of viewport. */
fun planSlopeDifferenceMm(source:Entity,from:Vec,to:Vec,d:Drawing):Double {
 if(isStair(source))return stairPlanRelativeZMm(source,to)-stairPlanRelativeZMm(source,from)
 val a=planLocalPoint(source,from);val b=planLocalPoint(source,to)
 val graphic=if(source.isParametricBuildUp())source.num("planGraphicWidthMm",source.num("widthMm",1500.0)).coerceAtLeast(1.0) else Bounds.of(planFootprint(source,d.withViewMode("top"))).width.coerceAtLeast(1.0)
 val real=if(source.str("grassObject")=="true")source.num("grassRealLengthMm",source.num("grassSectionLengthMm",1000.0)) else buildUpRealLengthMm(source)
 return if(source.isParametricBuildUp()) {
  val depth=source.num("topDepthMm",1000.0).coerceAtLeast(1.0)
  -(b.y-a.y)*real/depth*buildUpSlopePercent(source)/100.0-(b.x-a.x)*source.num("planCrossSlopePct",0.0)/100.0
 } else -(b.x-a.x)*real/graphic*buildUpSlopePercent(source)/100.0-(b.y-a.y)*source.num("planCrossSlopePct",0.0)/100.0
}
/** A leader can sit on a neighbouring drain, but only within 150 mm of the surface edge. */
private fun leaderReferenceOnSurface(point:Vec,surface:PlanSurface):Vec? {
 if(insidePolygon(point,surface.polygon))return point
 val nearest=surface.polygon.indices.map{i->closestOnSegment(point,surface.polygon[i],surface.polygon[(i+1)%surface.polygon.size])}.minByOrNull{it.distance(point)}?:return null
 return nearest.takeIf{it.distance(point)<=150.0}
}
fun planRelativeHeightMm(marker:Entity,d:Drawing):Double? {
 val target=marker.points.firstOrNull()?:return null
 val surface=planSurfaceAt(target,d)?:return null
 val requested=marker.str("planLeaderId")
 val leaders=d.entities.filter{it.kind=="plan-height"&&it.str("elevationRole")=="leader"&&(requested.isBlank()||it.id==requested)}
 val match=leaders.mapNotNull{leader->
  val lp=leader.points.firstOrNull()?:return@mapNotNull null
  val reference=leaderReferenceOnSurface(lp,surface)?:return@mapNotNull null
  Triple(leader,reference,lp.distance(reference))
 }.minByOrNull{it.third}?:return null
 return match.first.num("heightMm")+planSlopeDifferenceMm(surface.source,match.second,target,d)+marker.num("heightOffsetMm")
}
