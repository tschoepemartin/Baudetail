package de.baudetail.core
import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

val cadLevels=listOf("Oberfläche","Unterbau","Fundament","Leitungen","Untergrund")
val viewProfiles=listOf("Oberflächenplan","Fundamentplan","Entwässerungs-/Leitungsplan","Pflanzplan","Schnitt")
fun Drawing.profile()=(extensions["viewProfile"] as? JsonPrimitive)?.contentOrNull?:if(viewMode()=="section")"Schnitt"else"Oberflächenplan"
fun Drawing.withProfile(value:String)=withViewMode(if(value=="Schnitt")"section"else"top").let{it.copy(extensions=JsonObject(it.extensions+("viewProfile" to JsonPrimitive(value))))}
fun visibleIn(e:Entity,d:Drawing):Boolean {
 if(e.num("hidden")==1.0)return false
 // Elevation markers belong exclusively to the view in which they were created.
 if(e.kind=="elevation" && e.str("elevationCreatedView", "section")!=d.viewMode())return false
 if(e.kind=="dimension"&&e.num("auto")==1.0){val src=d.entities.find{it.id==e.str("sourceId")};if(src!=null&&src.str(if(d.viewMode()=="section")"autoMeasureSection" else "autoMeasureTop",src.str("autoMeasureProfile").ifBlank{"Aus"})=="Aus")return false}
 if(d.viewMode()=="section")return e.placement.visibleSection
 if(isFoundation(e)&&e.str("showInTop","false")!="true")return false
 if(!e.placement.visibleTop)return false
 val level=if(e.placement.level=="Oberfläche"&&e.kind=="component"&&e.name.contains("fundament",true))"Fundament"else e.placement.level
 return when(d.profile()){"Oberflächenplan","Pflanzplan"->level=="Oberfläche";"Fundamentplan"->level in setOf("Fundament","Unterbau");"Entwässerungs-/Leitungsplan"->level in setOf("Leitungen","Oberfläche");else->true}
}
fun closedContour(e:Entity)=e.kind in setOf("rect","circle","polygon","area","building")||(e.kind=="polyline"&&e.points.size>=4&&e.points.first().distance(e.points.last())<0.001)
fun asArea(e:Entity):Entity {require(closedContour(e)){"Nur geschlossene Konturen sind Flächen"};return if(e.kind=="circle")e.copy(quantityUnit="m²")else e.copy(kind="area",points=if(e.points.size>3&&e.points.first()==e.points.last())e.points.dropLast(1)else e.points,quantityUnit="m²")}
fun surfaceArea(e:Entity)=if(e.kind=="circle")PI*e.num("radiusMm").pow(2)else if(closedContour(e))area(e.points)else 0.0
fun perimeter(e:Entity)=if(e.kind=="circle")2*PI*e.num("radiusMm")else length(e.points,closedContour(e))
fun contour(e:Entity):List<Vec> = if(e.kind=="circle")(0 until 128).map{val t=it*2*PI/128;(e.points.firstOrNull()?:Vec())+Vec(cos(t),sin(t))*e.num("radiusMm")}else e.points
fun LibraryEntry.attribute(key:String,default:Double)=(attributes[key] as? JsonPrimitive)?.doubleOrNull?.takeIf{it.isFinite()&&it>0}?:default
fun materialStyle(entry:LibraryEntry,section:Boolean)=if(section)entry.appearance?.section?:entry.style else entry.appearance?.top?:entry.style
fun LibraryEntry.isGrassSectionComponent():Boolean = type=="component" && (category.contains("Vegetation/Rasen",true)||name.contains("Rasen",true)) && ((attributes["Darstellung"] as? JsonPrimitive)?.contentOrNull?.contains("Schnitt",true)==true || views["top"]==views["section"])
fun componentInstance(entry:LibraryEntry,at:Vec):Entity {
 val depth=entry.attribute("depth_mm",entry.attribute("section_width_mm",entry.attribute("width_mm",400.0)))
 val height=entry.attribute("section_height_mm",entry.attribute("height_mm",150.0))
 val width=entry.attribute("length_mm",entry.attribute("top_height_mm",entry.attribute("width_mm",1000.0)))
 val grass=entry.isGrassSectionComponent()
 val topWidth=entry.attribute("top_width_mm",entry.attribute("width_mm",1000.0))
 val topHeight=entry.attribute("top_height_mm",if(grass)entry.attribute("width_mm",1000.0)else entry.attribute("height_mm",500.0))
 val family=entry.smartFamily()
 if(entry.isParametricBuildUp()){
  val layers=entry.defaultBuildUpStrata()
  return Entity(kind="stack",name=entry.name,libraryId=entry.id,points=listOf(at),style=entry.style,strata=layers,pattern=Pattern(200.0,100.0,4.0,0.0,1.0/3.0),params=buildJsonObject{put("parametricBuildUp",true);put("buildUpEditorTitle",entry.buildUpEditorTitle());put("widthMm",entry.attribute("width_mm",1200.0));put("topDepthMm",entry.attribute("top_height_mm",entry.attribute("width_mm",1200.0)));put("buildUpTopRotationDelta",90.0);put("buildUpTopWidthOffsetMm",-entry.attribute("top_height_mm",entry.attribute("width_mm",1200.0))/2.0);put("autoMeasureProfile","Aus");put("labelEnabled","true");put("labelMode","auto")})
 }
 return Entity(kind="component",name=entry.name,libraryId=entry.id,placement=if(family=="pipe") Placement(level="Leitungen") else Placement(),view=if(entry.views.containsKey("top")&&entry.geometry.all{it.view=="top"})"top"else"section",points=listOf(at),style=entry.style,children=entry.geometry,params=buildJsonObject{
  put("widthMm",depth);put("heightMm",height);put("depthMm",depth);put("stepHeightMm",height);put("stairWidthMm",width);put("isStep",entry.isStairStep());put("topWidthMm",topWidth);put("topHeightMm",topHeight);put("sectionWidthMm",depth);put("sectionHeightMm",height);put("grassTopFallback",grass);entry.views.forEach{(k,v)->put("asset_"+k,v)};put("libraryViews",true);put("mirrored",0)
  put("componentFamily",family);put("variantGroup",entry.variantGroup());put("libraryCategory",entry.category);put("labelEnabled",family=="stair" || entry.isStairStep());put("labelVisibleSection",true);put("labelVisibleTop",false);put("labelMode","auto");put("fillMode","auto");put("snapPriority","normal");put("topRotationDelta",if(family in setOf("pipe","grass","channel_box"))0.0 else 90.0);put("autoMeasureProfile","Aus")
  if(family=="curb"){put("withoutChamfer",false);put("chamferWidthMm",entry.attrNumber("chamfer_width_mm",default=3.0));put("chamferDepthMm",entry.attrNumber("chamfer_depth_mm",default=4.0))}
  if(family=="pipe"){
   val system=(entry.attributes["pipe_system"] as? JsonPrimitive)?.contentOrNull ?: (entry.attributes["Material"] as? JsonPrimitive)?.contentOrNull.orEmpty()
   val fitting=(entry.attributes["fitting_type"] as? JsonPrimitive)?.contentOrNull ?: "pipe"
   put("dnMm",entry.attrNumber("DN","DN_mm","dn_mm",default=height));put("pipeSystem",system);put("fittingType",fitting);put("pipeLengthMm",entry.attrNumber("length_mm","width_mm",default=1000.0));put("bendAngle",entry.attrNumber("angle_deg",default=45.0));put("branchDnMm",entry.attrNumber("branch_dn_mm","DN","DN_mm",default=height));put("inletDnMm",entry.attrNumber("inlet_dn_mm","DN","DN_mm",default=height));put("outletDnMm",entry.attrNumber("outlet_dn_mm","DN","DN_mm",default=height));put("slope",0.0);put("flowArrow","true");put("flowDirection","forward");put("orientation","horizontal");put("verticalDirection","down");put("bendDirection",(entry.attributes["section_direction_default"] as? JsonPrimitive)?.contentOrNull?:"down");put("verticalLengthMm",1000.0);put("doubleSpigot",fitting=="double_spigot")
  }

  if(family=="channel_box"){
   val defaultType=(entry.attributes["channel_type"] as? JsonPrimitive)?.contentOrNull ?: "box"
   val defaultLoad=(entry.attributes["load_class"] as? JsonPrimitive)?.contentOrNull ?: "B 125"
   val defaultGrate=(entry.attributes["grate_type"] as? JsonPrimitive)?.contentOrNull ?: when(defaultType){"slot"->"Schlitz";"facade"->"Längsstab";else->"Gitterrost"}
   put("boxWidthMm",entry.attrNumber("box_width_mm","width_mm",default=185.0));put("boxHeightMm",entry.attrNumber("box_height_mm","section_height_mm",default=610.0));put("boxLengthMm",entry.attrNumber("box_length_mm","box_depth_mm",default=500.0));put("channelNominalWidthMm",entry.attrNumber("channel_nominal_width_mm","NW","NW_mm",default=150.0));put("pipeDnMm",entry.attrNumber("pipe_dn_mm","DN","DN_mm",default=160.0));put("pipeAxisFromTopMm",entry.attrNumber("pipe_axis_from_top_mm",default=500.0));put("pipeOutlet","none");put("leafBasket","true");put("grateVisible","true");put("channelType",defaultType);put("loadClass",defaultLoad);put("grateType",defaultGrate)
  }
  if(entry.id=="cmp-ausstattung-pflanztrog" || entry.name.equals("Pflanztrog",true)){
   put("planterShape","Rechteckig");put("planterWidthMm",entry.attribute("Breite_mm",1200.0));put("planterDepthMm",entry.attribute("Tiefe_mm",500.0));put("planterDiameterMm",entry.attribute("Durchmesser_mm",500.0));put("planterHeightMm",entry.attribute("Bauteilhöhe_mm",600.0));put("planterWallMm",entry.attribute("Wandstärke_mm",5.0));put("planterMaterial","Cortenstahl");put("planterFinish","Naturrost");put("planterTopElevationMm",0.0);put("planterFill","true")
  }
  if(family=="retaining_wall"){put("wallHeightMm",entry.attrNumber("wall_height_mm","Höhe_mm","height_mm",default=height));put("footDepthMm",entry.attrNumber("foot_depth_mm","Fußtiefe_mm","Breite_mm","section_width_mm",default=depth));put("wallThicknessMm",entry.attrNumber("wall_thickness_mm","Wandstärke_mm",default=70.0));put("footThicknessMm",entry.attrNumber("foot_thickness_mm","Fußstärke_mm",default=100.0));put("elementLengthMm",entry.attrNumber("element_length_mm","Länge_mm","length_mm","width_mm",default=topWidth));put("footSide","right")}
 })
}
fun stairDepth(e:Entity)=e.num("depthMm",e.children.firstOrNull()?.num("depthMm",400.0)?:400.0)
fun stairLength(e:Entity)=(stairCount(e)-1)*stairGoing(e)+stairDepth(e)
fun templateEntry(name:String,category:String,entities:List<Entity>,origin:Vec,previous:LibraryEntry?=null):LibraryEntry {
 require(entities.isNotEmpty())
 return LibraryEntry(id=previous?.id?:uid(),type="assembly-template",name=name,category=category,version=(previous?.version?:0)+1,geometry=entities.map{transform(it,translation=Vec()-origin).copy(bindings=emptyList(),anchors=emptyList())},attributes=buildJsonObject{put("origin_x_mm",0);put("origin_y_mm",0)},extensions=buildJsonObject{put("previewKind","geometry")})
}
fun instantiateTemplate(entry:LibraryEntry,at:Vec):Entity {
 val copies=entry.geometry.map{it.copy(id=uid(),bindings=emptyList(),anchors=emptyList())}
 return Entity(kind="component",name=entry.name,points=listOf(at),children=copies,params=buildJsonObject{put("frozenTemplate",true);put("templateScale",1.0);put("templateId",entry.id);put("templateVersion",entry.version);put("mirrored",0)})
}
val measureProfiles=listOf("Aus","Minimal","Ausführung","Vollständig","Benutzerdefiniert")
fun measureTarget(e:Entity):Entity = if(isFrozenTemplate(e)) e.children.firstOrNull{isChannelBox(it)} ?: e.children.firstOrNull{it.smartFamily()!="component"} ?: e else e
fun isChannelBoxMeasureSource(e:Entity)=isChannelBox(measureTarget(e))
fun metrics(e:Entity,d:Drawing):List<String> {
 if(isFrozenTemplate(e)){
  val box=e.children.firstOrNull{isChannelBox(it)}
  return if(d.viewMode()=="section") {
   if(box!=null) listOf("Gesamtlänge","Höhe","Rohr DN","Rohrachse ab OK") else listOf("Gesamtlänge","Höhe")
  } else {
   if(box!=null) listOf("Gesamtlänge","Breite","Rinnenbreite") else listOf("Gesamtlänge","Breite")
  }
 }
 val m=measureTarget(e)
 return when {
  m.isParametricBuildUp()-> if(d.viewMode()=="section")listOf("Weglänge","Aufbauhöhe") else listOf("Wegbreite","Weglänge")
  isFoundation(m)-> if(d.viewMode()=="section") listOf("Breite","Dicke") else emptyList()
  m.smartFamily()=="curb" -> if(d.viewMode()=="section") listOf("Breite","Höhe") else listOf("Länge","Breite")
  isChannelBox(m)-> if(d.viewMode()=="section") listOf("Breite","Höhe","Rohr DN","Rohrachse ab OK") else listOf("Länge","Breite","Rinnenbreite")
  isStair(m)-> if(d.viewMode()=="section") listOf("Gesamthöhe","Gesamtlänge","Stufenhöhe","Stufentiefe","Auftritt","Überdeckung","Stufengefälle","Anzahl") else listOf("Gesamtlänge","Breite","Stufentiefe","Auftritt","Überdeckung","Stufengefälle","Anzahl")
  isKg2000(m)-> listOf("DN","Länge","Gefälle")
  closedContour(m)->listOf("Fläche","Umfang","Länge","Breite","Gefälle")
  else->listOf("Länge","Breite","Höhe","DN","Gefälle")
 }
}
fun metricValue(e:Entity,key:String):Double {
 if(isFrozenTemplate(e)){
  val box=e.children.firstOrNull{isChannelBox(it)}
  return when(key){
   "Gesamtlänge" -> e.num("measureOverallLengthMm",Double.NaN).takeIf{it.isFinite()&&it>0} ?: 0.0
   "Höhe" -> box?.let{metricValue(it,"Höhe")} ?: e.num("measureOverallHeightMm",0.0)
   "Breite" -> e.num("measureOverallHeightMm",0.0)
   "Rinnenbreite" -> box?.let{metricValue(it,"Rinnenbreite")} ?: 0.0
   "Rohr DN" -> box?.let{metricValue(it,"Rohr DN")} ?: 0.0
   "Rohrachse ab OK" -> box?.let{metricValue(it,"Rohrachse ab OK")} ?: 0.0
   else -> 0.0
  }
 }
 if(e.isParametricBuildUp())return when(key){
  "Weglänge"->buildUpRealLengthMm(e)
  "Wegbreite"->e.num("widthMm",1500.0)
  "Aufbauhöhe"->e.strata.sumOf{it.thicknessMm}
  else->0.0
 }
 val m=measureTarget(e); if(m!==e)return metricValue(m,key)
 return when(key){"Fläche"->surfaceArea(e);"Umfang"->perimeter(e);"Gesamtlänge"->stairLength(e);"Gesamthöhe"->stairTotalHeight(e);"Stufenhöhe"->stairRise(e);"Stufentiefe"->stairDepth(e);"Auftritt"->stairGoing(e);"Überdeckung"->stairDepth(e)-stairGoing(e);"Anzahl"->stairCount(e).toDouble();"Stufengefälle","Gefälle"->e.num("slope",e.num("percent"));"Dicke"->e.num("thicknessMm",e.num("heightMm",entityBounds(e).height));"Einbindung"->e.num("embedMm");"Länge"->if(isKg2000(e))e.num("pipeLengthMm",1000.0)else e.num("boxLengthMm",e.num("topWidthMm",entityBounds(e).width));"Tiefe"->e.num("boxLengthMm",e.num("topHeightMm",entityBounds(e).height));"Rinnenbreite"->e.num("channelNominalWidthMm");"Rohr DN"->e.num("pipeDnMm",e.num("dnMm"));"Rohrachse ab OK"->e.num("pipeAxisFromTopMm");"Breite"->if(isFoundation(e))e.num("foundationWidthMm",entityBounds(e).width) else e.num("boxWidthMm",e.num("widthMm",entityBounds(e).width));"Höhe"->e.num("boxHeightMm",e.num("heightMm",entityBounds(e).height));"DN"->e.num("dnMm",e.num("DN"));else->if(closedContour(e))entityBounds(e).height else if(e.points.size>1)length(e.points)else e.num("widthMm")}
}

fun automaticMeasures(e:Entity,d:Drawing,profile:String):List<Entity>{
 val available=metrics(e,d)
 val keys=if(e.isParametricBuildUp() && profile in setOf("Minimal","Ausführung")) { if(d.viewMode()=="section") {if(profile=="Minimal")listOf("Weglänge") else listOf("Weglänge","Aufbauhöhe")}else listOf("Wegbreite","Weglänge") } else if(isStair(e)) {val minimal=if(d.viewMode()=="section")listOf("Gesamthöhe","Gesamtlänge")else listOf("Gesamtlänge","Breite");when(profile){"Aus"->emptyList();"Minimal"->minimal;"Ausführung"->minimal+if(d.viewMode()=="section")listOf("Auftritt","Stufenhöhe","Stufengefälle")else listOf("Auftritt","Stufengefälle");else->available}} else when(profile){"Aus"->emptyList();"Minimal"->available.take(2);"Ausführung"->available.take(6);else->available}
 val gap=d.sheet.scale*8.0;var hLane=0;var vLane=0
 return keys.mapNotNull{key->
  val witnesses=metricWitnesses(e,key,d)?:return@mapNotNull null
  if(witnesses[0].distance(witnesses[1])<0.01)return@mapNotNull null
  val vertical=if(isStair(e)&&key in setOf("Gesamthöhe","Stufenhöhe"))true else kotlin.math.abs(witnesses[1].y-witnesses[0].y)>kotlin.math.abs(witnesses[1].x-witnesses[0].x)
  val lane=if(vertical)++vLane else ++hLane
  val origin=viewBounds(e,d).center
  val channelBox=isChannelBoxMeasureSource(e)
  val defaultDx=when{
   isStair(e)&&key=="Gesamthöhe" -> viewBounds(e,d).max.x-witnesses[0].x+gap*1.5
   isStair(e)&&key=="Stufenhöhe" -> viewBounds(e,d).min.x-witnesses[0].x-gap*.45
   vertical&&channelBox&&key=="Höhe" -> gap
   vertical&&channelBox&&key=="Rohr DN" -> -gap*1.5
   vertical&&channelBox&&key=="Rohrachse ab OK" -> -gap*3.0
   vertical&&e.isParametricBuildUp() -> gap*1.5
   vertical&&isFoundation(e) -> gap*2.0
   vertical -> gap*lane
   else -> 0.0
  }
  val defaultDy=when{
   isStair(e)&&key=="Stufengefälle" -> -gap*1.5
   isStair(e)&&key=="Gesamtlänge" -> viewBounds(e,d).max.y-witnesses[0].y+gap*1.5
   isStair(e)&&key=="Auftritt" -> viewBounds(e,d).max.y-witnesses[0].y+gap*.35
   !vertical&&e.smartFamily()=="curb"&&key=="Breite" -> -gap
   !vertical&&channelBox&&key=="Rinnenbreite" -> -gap*1.5
   !vertical -> gap*lane
   else -> 0.0
  }
  Entity(kind="dimension",points=listOf(origin),layerId=e.layerId,placement=e.placement,style=Style(stroke="#354B48",widthMm=0.08,textPaperMm=2.6),params=buildJsonObject{put("sourceId",e.id);put("metric",key);put("prefix","");put("unit",when(key){"Fläche"->"m²";"Gefälle","Stufengefälle"->"%";"Anzahl"->"Stk";"Rohr DN","DN"->"mm";else->"cm"});put("decimals",if(key in setOf("Rohr DN","DN"))0 else 1);put("auto",1);put("measureVersion",5);put("mode",if(vertical)"vertical"else"horizontal");put("offsetMm",0.0);put("dimDx",defaultDx);put("dimDy",defaultDy);put("metricOriginX",origin.x);put("metricOriginY",origin.y);if(isFrozenTemplate(e)&&key in setOf("Gesamtlänge","Höhe","Breite"))put("metricOverrideMm",witnesses[0].distance(witnesses[1]));put("measureChainKey",(e.groupId?:e.id)+":"+(if(vertical)"V"else"H"));put("chainLane",lane)})
 }
}

fun dimensionLabel(e:Entity,d:Drawing):String {
 val source=d.entities.find{it.id==e.str("sourceId")};val override=e.num("metricOverrideMm",Double.NaN);val value=if(override.isFinite())override else if(source!=null&&e.str("metric").isNotEmpty())metricValue(source.copy(points=resolvedPoints(source,d)),e.str("metric"))else dimensionValue(e,d)
 val unit=e.str("unit","mm");val factor=when(unit){"cm"->10.0;"m"->1000.0;"m²"->1e6;else->1.0}
 return e.str("prefix",e.text)+fmt(value/factor,e.num("decimals",2.0).toInt().coerceIn(0,6))+e.str("suffix",if(unit.isEmpty())""else" $unit")
}
fun viewEntity(e:Entity,d:Drawing):Entity {
 var result=e.copy(points=resolvedPoints(e,d))
 if(e.kind=="component"){val off=smartViewOffset(e,d.viewMode());result=result.copy(points=result.points.map{it+off},rotation=smartViewRotation(e,d.viewMode()))}
 if(e.kind=="elevation"){val off=annotationViewOffset(e,d.viewMode());result=result.copy(points=result.points.map{it+off})}
 if(e.str("libraryViews")=="true")result=if(e.str("isStep")=="true")result.withNum("widthMm",stairDepth(e)).withNum("heightMm",e.num(if(d.viewMode()=="section")"stepHeightMm"else"stairWidthMm",1000.0))else result.withNum("widthMm",e.num(if(d.viewMode()=="section")"sectionWidthMm"else"topWidthMm",1000.0)).withNum("heightMm",e.num(if(d.viewMode()=="section")"sectionHeightMm"else"topHeightMm",500.0))
 if(isRetainingWall(e))result=if(d.viewMode()=="section")result.withNum("widthMm",e.num("footDepthMm",400.0)).withNum("heightMm",e.num("wallHeightMm",800.0))else result.withNum("widthMm",e.num("elementLengthMm",1000.0)).withNum("heightMm",e.num("footDepthMm",400.0))
 if(isPlanter(e))result=if(d.viewMode()=="section")result.withNum("widthMm",if(e.str("planterShape","Rechteckig")=="Rund")e.num("planterDiameterMm",500.0) else e.num("planterDepthMm",500.0)).withNum("heightMm",e.num("planterHeightMm",600.0))else result.withNum("widthMm",if(e.str("planterShape","Rechteckig")=="Rund")e.num("planterDiameterMm",500.0) else e.num("planterWidthMm",1200.0)).withNum("heightMm",if(e.str("planterShape","Rechteckig")=="Rund")e.num("planterDiameterMm",500.0) else e.num("planterDepthMm",500.0))
 if(isLightwell(e))result=if(d.viewMode()=="section")result.withNum("widthMm",e.num("lightwellDepthMm",500.0)).withNum("heightMm",e.num("lightwellHeightMm",1000.0))else result.withNum("widthMm",e.num("lightwellWidthMm",1000.0)).withNum("heightMm",e.num("lightwellDepthMm",500.0))
 if(isChannelBox(e))result=if(d.viewMode()=="section")result.withNum("widthMm",e.num("boxWidthMm",185.0)).withNum("heightMm",e.num("boxHeightMm",610.0))else result.withNum("widthMm",e.num("boxLengthMm",500.0)).withNum("heightMm",e.num("boxWidthMm",185.0))
 if(isPipe(e)){val dn=e.num("dnMm",100.0);val vertical=e.str("orientation","horizontal")=="vertical";val len=e.num("pipeLengthMm",e.num("topWidthMm",1000.0));result=if(vertical)result.withNum("widthMm",dn).withNum("heightMm",e.num("verticalLengthMm",1000.0))else result.withNum("widthMm",len).withNum("heightMm",dn)}
 return result
}
/** The plan footprint has its own horizontal pose; section elevation is never a plan drag target. */
fun buildUpPlanAngle(e:Entity):Double=e.rotation+e.num("buildUpTopRotationDelta")
fun buildUpPlanOrigin(e:Entity):Vec {
 val origin=e.points.firstOrNull()?:Vec()
 val angle=buildUpPlanAngle(e)
 val w=e.num("widthMm",1500.0)
 val depth=e.num("topDepthMm",1000.0)
 val footprint=Bounds.of(rectangle(Vec(),Vec(w,depth)).map{it.rotate(angle)})
 val section=Bounds.of(rectangle(Vec(),Vec(depth,e.strata.sumOf{it.thicknessMm})).map{origin+it.rotate(e.rotation)})
 // The plan footprint terminates at the SAME construction edge as the section.
 // Old top-only presentation offsets must not move the edge onto the staircase.
 return Vec(section.max.x-footprint.max.x,origin.y-footprint.min.y+e.num("buildUpTopLengthOffsetMm"))+
  Vec(if(e.str("buildUpAnchorV2")=="true")e.num("buildUpTopDxMm")else 0.0,if(e.str("buildUpAnchorV2")=="true")e.num("buildUpTopDyMm")else 0.0)
}
fun viewBounds(e:Entity,d:Drawing)=when{e.isParametricBuildUp() -> {val base=e.points.firstOrNull()?:Vec();val a=if(d.viewMode()=="section")base else buildUpPlanOrigin(e);val angle=if(d.viewMode()=="section")e.rotation else buildUpPlanAngle(e);val w=if(d.viewMode()=="section")e.num("topDepthMm",e.num("widthMm",1500.0))else e.num("widthMm",1500.0);val h=if(d.viewMode()=="section")e.strata.sumOf{it.thicknessMm}else e.num("topDepthMm",1000.0);Bounds.of((if(d.viewMode()=="section")listOf(Vec(0.0,0.0),Vec(w,buildUpSlopeDropMm(e,w)),Vec(w,h+buildUpSlopeDropMm(e,w)),Vec(0.0,h))else rectangle(Vec(),Vec(w,h))).map{a+it.rotate(angle)})};isFoundation(e)->Bounds.of(foundationOutline(e,d));isStair(e)->Bounds.of(stairReferencePoints(e,d.viewMode()));isFrozenTemplate(e)->frozenTemplateBounds(e,d);isKg2000(e)->kg2000Bounds(e,d);e.kind=="component"->Bounds.of(componentReferencePoints(e,d));else->entityBounds(viewEntity(e,d))}
fun objectLabelPosition(e:Entity,d:Drawing):Vec {
 val b=viewBounds(e,d);val center=b.center;val view=d.viewMode();val gap=d.sheet.scale*5.0
 val dxKey=if(view=="section")"labelSectionDx"else"labelTopDx";val dyKey=if(view=="section")"labelSectionDy"else"labelTopDy"
 if(dxKey in e.params||dyKey in e.params)return center+Vec(e.num(dxKey),e.num(dyKey))
 // Automatic labels use stable source-relative lanes, similar to auto-dimensions.
 // Prefer the first lane with the least overlap against nearby object bounds.
 val others=d.entities.filter{it.id!=e.id&&visibleIn(it,d)}.map{viewBounds(it,d)}
 data class Candidate(val at:Vec,val score:Double)
 val lanes=mutableListOf<Candidate>()
 for(side in listOf(-1.0,1.0))for(lane in 0..3){
  val at=Vec(center.x+side*gap*(1.4+lane*.75),b.min.y-gap*(1.0+lane*.65))
  val labelBox=Bounds(at-Vec(gap*1.8,gap*1.0),at+Vec(gap*1.8,gap*0.8))
  val overlap=others.sumOf{ob->
   val hit=!(labelBox.max.x<ob.min.x||labelBox.min.x>ob.max.x||labelBox.max.y<ob.min.y||labelBox.min.y>ob.max.y)
   if(hit)1.0 else 0.0
  }
  val lengthPenalty=at.distance(center)/(gap*10.0)
  val sideBias=if(side<0)0.0 else 0.1
  lanes+=Candidate(at,overlap+lengthPenalty+sideBias)
 }
 return lanes.minByOrNull{it.score}?.at ?: Vec(center.x-gap*1.4,b.min.y-gap)
}
fun objectLabelTarget(e:Entity,d:Drawing,label:Vec=objectLabelPosition(e,d)):Vec {
 val b=viewBounds(e,d)
 val x=label.x.coerceIn(b.min.x,b.max.x);val y=label.y.coerceIn(b.min.y,b.max.y)
 val candidates=listOf(Vec(x,b.min.y),Vec(x,b.max.y),Vec(b.min.x,y),Vec(b.max.x,y))
 return candidates.minByOrNull{it.distance(label)}?:b.center
}
fun componentReferencePoints(e:Entity,d:Drawing):List<Vec>{val v=viewEntity(e,d);val origin=v.points.firstOrNull()?:Vec();val b=entityBounds(v);return (rectangle(b.min,b.max)+b.center).map{val q=it-origin;origin+Vec(q.x,if(v.num("mirrored")==1.0)-q.y else q.y).rotate(v.rotation)}}
fun metricWitnesses(e:Entity,key:String,d:Drawing):List<Vec>? {
 if(isFrozenTemplate(e)){
  val b=frozenTemplateBounds(e,d)
  val box=e.children.firstOrNull{isChannelBox(it)}
  return when(key){
   "Gesamtlänge" -> listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y))
   "Höhe" -> if(box!=null) metricWitnesses(box,"Höhe",d)?.map{frozenTemplatePoint(e,it,d)} else listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y))
   "Breite" -> listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y))
   "Rinnenbreite","Rohr DN","Rohrachse ab OK" -> box?.let{metricWitnesses(it,key,d)?.map{p->frozenTemplatePoint(e,p,d)}}
   else -> null
  }
 }
 if(e.isParametricBuildUp()){
  val origin=e.points.firstOrNull()?:Vec()
  val w=e.num("topDepthMm",1000.0)
  val h=e.strata.sumOf{it.thicknessMm}
  if(d.viewMode()=="section"){
   fun point(x:Double,y:Double)=origin+Vec(x,y).rotate(e.rotation)
   return when(key){
    "Weglänge"->listOf(point(0.0,h+maxOf(buildUpSlopeDropMm(e,0.0),buildUpSlopeDropMm(e,w))),point(w,h+maxOf(buildUpSlopeDropMm(e,0.0),buildUpSlopeDropMm(e,w))))
    "Aufbauhöhe"->listOf(point(w,buildUpSlopeDropMm(e,w)),point(w,h+buildUpSlopeDropMm(e,w)))
    else->null
   }
  }
  val b=viewBounds(e,d)
  return when(key){"Weglänge"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y));"Wegbreite"->listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y));else->null}
 }
 if(isFoundation(e)){
  val o=foundationOutline(e,d);if(o.size<3)return null;val b=Bounds.of(o);val src=d.entities.find{it.id==e.str("sourceId")}
  return when(key){"Breite"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y));"Dicke"->src?.let{val sb=viewBounds(it,d);val top=sb.max.y;listOf(Vec(b.max.x,top),Vec(b.max.x,top+foundationThicknessMm(e)))}?:listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y));"Einbindung"->src?.let{val sb=viewBounds(it,d);listOf(Vec(b.max.x,sb.max.y-foundationEmbedMm(e,it,d)),Vec(b.max.x,sb.max.y))};else->null}
 }
 if(isChannelBox(e)){
  val v=viewEntity(e,d);val o=v.points.firstOrNull()?:Vec();val mirrored=v.num("mirrored")==1.0
  fun world(local:Vec):Vec {val q=Vec(local.x,if(mirrored)-local.y else local.y);return o+q.rotate(v.rotation)}
  val bw=e.num("boxWidthMm",185.0);val bh=e.num("boxHeightMm",610.0);val bl=e.num("boxLengthMm",500.0);val nw=e.num("channelNominalWidthMm",150.0);val dn=e.num("pipeDnMm",160.0);val axis=e.num("pipeAxisFromTopMm",500.0);val side=e.str("pipeOutlet","left")
  return when(key){
   "Breite"->if(d.viewMode()=="section")listOf(world(Vec(0.0,bh)),world(Vec(bw,bh)))else listOf(world(Vec(0.0,bw)),world(Vec(bl,bw)))
   "Höhe"->if(d.viewMode()=="section")listOf(world(Vec(bw,0.0)),world(Vec(bw,bh)))else null
   "Länge"->if(d.viewMode()=="top")listOf(world(Vec(0.0,bw)),world(Vec(bl,bw)))else null
   "Tiefe"->if(d.viewMode()=="top")listOf(world(Vec(bl,0.0)),world(Vec(bl,bw)))else null
   "Rinnenbreite"->if(d.viewMode()=="top")listOf(world(Vec(0.0,(bw-nw)/2)),world(Vec(0.0,(bw+nw)/2)))else null
   "Rohr DN"->if(d.viewMode()=="section"&&side!="none"){val x=if(side=="left")0.0 else bw;listOf(world(Vec(x,axis-dn/2)),world(Vec(x,axis+dn/2)))}else null
   "Rohrachse ab OK"->if(d.viewMode()=="section"&&side!="none"){val x=if(side=="left")0.0 else bw;listOf(world(Vec(x,0.0)),world(Vec(x,axis)))}else null
   else->null
  }
 }
 if(isStair(e)){
  val pair=when(key){"Gesamtlänge"->Vec() to Vec(stairLength(e),0.0);"Gesamthöhe"->if(d.viewMode()=="section")return stairHeightWitnesses(e,stairCount(e)-1,true) else return null;"Breite"->if(d.viewMode()=="top")Vec() to Vec(0.0,e.num("widthMm",1200.0))else return null;"Stufenhöhe"->if(d.viewMode()=="section")return stairHeightWitnesses(e,0,false) else return null;"Stufentiefe"->Vec() to Vec(stairDepth(e),0.0);"Auftritt"->Vec() to Vec(stairGoing(e),0.0);"Stufengefälle"->Vec(stairGoing(e)*.20,-stairRise(e)) to Vec(stairGoing(e)*.80,-stairRise(e)) ;"Überdeckung"->Vec(stairGoing(e),0.0) to Vec(stairDepth(e),0.0);else->return null}
  return listOf(assemblyPoint(e,pair.first,d.viewMode()),assemblyPoint(e,pair.second,d.viewMode()))
 }
 val pts=resolvedPoints(e,d);if(key=="Länge"&&!closedContour(e)&&pts.size==2)return pts
 val b=viewBounds(e,d);return when(key){
  "Breite"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y))
  "Höhe"->listOf(Vec(b.max.x,b.min.y),Vec(b.max.x,b.max.y))
  "Länge"->listOf(Vec(b.min.x,b.max.y),Vec(b.max.x,b.max.y))
  else->null
 }
}

/** Legacy stairs had labelEnabled=false by default; distinguish that from an explicit user toggle. */
fun labelActive(e:Entity,d:Drawing):Boolean {
 val enabled=if(e.str("labelEnabled")=="false")false else if(isStair(e)&&e.str("labelExplicit")!="true")true else e.str("labelEnabled")=="true"
 val viewKey=if(d.viewMode()=="section")"labelVisibleSection" else "labelVisibleTop"
 val visible=e.str(viewKey,if(d.viewMode()=="top"&&(e.isParametricBuildUp()||isStair(e)))"false" else "true")=="true"
 return enabled&&visible
}
