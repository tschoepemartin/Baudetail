#!/usr/bin/env python3
"""Create a Baudetail v1 library package from a local directory. Python 3.9+."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

def create(source: Path, destination: Path):
    source = source.resolve()
    library = json.loads((source / 'library.json').read_text(encoding='utf-8'))
    if library.get('formatVersion') != 1 or not isinstance(library.get('entries'), list):
        raise ValueError('library.json benötigt formatVersion: 1 und entries: []')
    ids = set()
    for entry in library['entries']:
        for field in ('id', 'type', 'category', 'name'):
            if not isinstance(entry.get(field), str) or not entry[field].strip():
                raise ValueError(f'Bibliothekseintrag: {field} fehlt')
        if entry['id'] in ids:
            raise ValueError('Doppelte ID: ' + entry['id'])
        ids.add(entry['id'])
        for path in list(entry.get('views', {}).values()) + ([entry['preview']] if entry.get('preview') else []):
            candidate = (source / path).resolve()
            if not candidate.is_relative_to(source) or not candidate.is_file():
                raise ValueError('Ressource fehlt oder Pfad unzulässig: ' + path)
    resources = {}
    for file in sorted(source.rglob('*')):
        if file.is_symlink():
            raise ValueError('Symbolische Links sind nicht zulässig')
        if not file.is_file() or file.name in ('manifest.json', 'library.json') or file.resolve() == destination.resolve():
            continue
        name = file.relative_to(source).as_posix()
        if ':' in name or '\\' in name:
            raise ValueError('Ungültiger Ressourcenpfad')
        resources[name] = file.read_bytes()
    if sum(map(len, resources.values())) > 128 * 1024 * 1024:
        raise ValueError('Paket zu groß')
    manifest = dict(formatVersion=1, kind='library', name=library.get('name', 'Bibliothek'), embedded=True,
                    resources={name: hashlib.sha256(data).hexdigest() for name, data in resources.items()})
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        archive.writestr('library.json', json.dumps(library, ensure_ascii=False, indent=2))
        for name, data in resources.items():
            archive.writestr(name, data)
    print(destination)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    create(args.source, args.destination)
