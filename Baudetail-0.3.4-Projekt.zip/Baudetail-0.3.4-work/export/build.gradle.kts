plugins { alias(libs.plugins.android.library); alias(libs.plugins.kotlin.android) }
android {
 namespace = "de.baudetail.export"
 compileSdk = 35
 buildToolsVersion = "35.0.0"
 defaultConfig { minSdk = 26; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 api(project(":drawing-core"))
 androidTestImplementation(libs.android.test)
 androidTestImplementation(libs.android.runner)
 implementation(libs.androidsvg)
 constraints {
  androidTestImplementation(libs.annotation) {
   because("Use a stable annotation version instead of the test runner's transitive beta.")
  }
 }
}
