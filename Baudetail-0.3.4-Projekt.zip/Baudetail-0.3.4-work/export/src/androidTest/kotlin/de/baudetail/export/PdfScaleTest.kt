package de.baudetail.export
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import de.baudetail.core.*
import de.baudetail.geometry.*
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
@RunWith(AndroidJUnit4::class)
class PdfScaleTest {
 @Test fun exported1000mmAt1To10Measures100mm(){
  val ctx=InstrumentationRegistry.getInstrumentation().targetContext
  val drawing=Drawing(sheet=Sheet(scale=10.0),entities=listOf(Entity(points=listOf(Vec(0.0,100.0),Vec(1000.0,100.0)),style=Style(stroke="#000000",widthMm=.2))))
  val file=File(ctx.cacheDir,"scale-test.pdf")
  file.outputStream().use{ExportService{File(ctx.filesDir,it)}.pdf(it,drawing,Project(drawings=listOf(drawing)))}
  ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY).use{fd->PdfRenderer(fd).use{pdf->pdf.openPage(0).use{page->
   val factor=4;val bitmap=Bitmap.createBitmap(page.width*factor,page.height*factor,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.WHITE);page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
   val y=(pdfPoints(20.0)*factor).toInt();val black=(0 until bitmap.width).filter{x->val c=bitmap.getPixel(x,y);Color.red(c)<80&&Color.green(c)<80&&Color.blue(c)<80}
   assertTrue(black.isNotEmpty());val mm=(black.last()-black.first()).toDouble()/factor*25.4/72
   assertEquals(100.0,mm,.5);bitmap.recycle()
  }}}
 }
}
