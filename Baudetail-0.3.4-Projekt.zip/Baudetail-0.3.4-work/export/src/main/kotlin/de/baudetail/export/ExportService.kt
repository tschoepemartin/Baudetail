package de.baudetail.export

import android.graphics.*
import android.graphics.pdf.PdfDocument
import de.baudetail.core.*
import de.baudetail.geometry.*
import java.io.*
import java.util.Base64
import kotlin.math.*

class ExportService(private val asset:(String)->File) {
 private val renderer=CanvasRenderer(asset)
 fun pdf(output:OutputStream,d:Drawing,p:Project) {
  val nodes=Scene.paper(d,p);validateAssets(nodes)
  // WYSIWYG: render exactly the same paper scene as the on-screen print preview.
  // A bounded raster intermediate avoids PdfDocument's device-dependent scaled-text
  // metrics and therefore keeps positions, labels and clipping identical to preview.
  val targetDpi=200.0;val maxPixels=12_000_000.0
  val rawW=d.sheet.widthMm*targetDpi/25.4;val rawH=d.sheet.heightMm*targetDpi/25.4
  val cap=kotlin.math.sqrt(maxPixels/(rawW*rawH)).coerceAtMost(1.0);val dpi=targetDpi*cap
  val width=kotlin.math.round(d.sheet.widthMm*dpi/25.4).toInt().coerceAtLeast(1);val height=kotlin.math.round(d.sheet.heightMm*dpi/25.4).toInt().coerceAtLeast(1)
  val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
  try {
   val bc=Canvas(bitmap);bc.drawColor(Color.WHITE);bc.scale((dpi/25.4).toFloat(),(dpi/25.4).toFloat());renderer.draw(bc,nodes)
   val pdf=PdfDocument()
   try {
    val pw=ceil(pdfPoints(d.sheet.widthMm)).toInt();val ph=ceil(pdfPoints(d.sheet.heightMm)).toInt();val page=pdf.startPage(PdfDocument.PageInfo.Builder(pw,ph,1).create())
    try {page.canvas.drawBitmap(bitmap,null,RectF(0f,0f,pw.toFloat(),ph.toFloat()),Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))} finally {pdf.finishPage(page)}
    pdf.writeTo(output)
   } finally {pdf.close()}
  } finally {bitmap.recycle()}
 }

 private fun toPdfPoints(v:Primitive):Primitive {
  val k=pdfPoints(1.0)
  fun q(p:Vec)=Vec(p.x*k,p.y*k)
  fun style(s:Style)=s.copy(widthMm=s.widthMm*k,textPaperMm=s.textPaperMm*k)
  return when(v){
   is Primitive.Path -> v.copy(points=v.points.map(::q),style=style(v.style))
   is Primitive.Circle -> v.copy(center=q(v.center),radius=v.radius*k,style=style(v.style))
   is Primitive.Text -> v.copy(at=q(v.at),size=v.size*k,style=style(v.style))
   is Primitive.Asset -> v.copy(at=q(v.at),width=v.width*k,height=v.height*k)
   is Primitive.Group -> v.copy(nodes=v.nodes.map(::toPdfPoints),translate=q(v.translate),clip=v.clip?.map(::q))
  }
 }
 fun png(output:OutputStream,d:Drawing,p:Project,dpi:Int=300,transparent:Boolean=false) {
  validateAssets(Scene.paper(d,p))
  require(dpi in 36..600);val width=round(d.sheet.widthMm*dpi/25.4).toInt();val height=round(d.sheet.heightMm*dpi/25.4).toInt()
  require(width.toLong()*height<=24000000){"Auflösung über 24 Megapixel. Bitte DPI reduzieren."}
  val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
  try {val c=Canvas(bitmap);if(!transparent)c.drawColor(Color.WHITE);c.scale(dpi/25.4f,dpi/25.4f);renderer.draw(c,Scene.paper(d,p));check(bitmap.compress(Bitmap.CompressFormat.PNG,100,output))}finally{bitmap.recycle()}
 }
 private fun validateAssets(nodes:List<Primitive>) {
  nodes.forEach { node -> when(node) {
   is Primitive.Group -> validateAssets(node.nodes)
   is Primitive.Asset -> {
    val file=asset(node.path)
    require(file.isFile) { "Externe Ressource fehlt: ${node.path}" }
    if(file.extension.lowercase()=="svg") sanitizeSvg(file.readText())
    else {
     val options=BitmapFactory.Options().apply { inJustDecodeBounds=true }
     BitmapFactory.decodeFile(file.path,options)
     require(options.outWidth>0 && options.outHeight>0) { "Bild nicht lesbar: ${node.path}" }
    }
   }
   else -> Unit
  } }
 }
 fun svg(output:OutputStream,d:Drawing,p:Project) {output.write(SvgWriter(asset).document(d.sheet.widthMm,d.sheet.heightMm,Scene.paper(d,p)).toByteArray())}
}
class SvgWriter(private val asset:(String)->File) {
 private var clipId=0
 private fun n(v:Double)=String.format(java.util.Locale.US,"%.6f",v).trimEnd('0').trimEnd('.')
 private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
 private fun style(s:Style)="stroke=\"${esc(s.stroke)}\" fill=\"${esc(s.fill?:"none")}\" stroke-width=\"${n(s.widthMm)}\" opacity=\"${n(s.opacity)}\" stroke-linejoin=\"round\""+(if(s.dashed)" stroke-dasharray=\"${n(s.widthMm*7)} ${n(s.widthMm*5)}\""else "")
 fun document(width:Double,height:Double,nodes:List<Primitive>):String = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"${n(width)}mm\" height=\"${n(height)}mm\" viewBox=\"0 0 ${n(width)} ${n(height)}\">${nodes.joinToString(""){write(it)}}</svg>"
 private fun write(v:Primitive):String = when(v) {
  is Primitive.Path -> "<${if(v.closed)"polygon"else"polyline"} points=\"${v.points.joinToString(" "){"${n(it.x)},${n(it.y)}"}}\" ${style(v.style)}/>"
  is Primitive.Circle -> "<circle cx=\"${n(v.center.x)}\" cy=\"${n(v.center.y)}\" r=\"${n(v.radius)}\" ${style(v.style)}/>"
  is Primitive.Text -> {
   val lines=v.value.lines();val width=(lines.maxOfOrNull{it.length}?:0)*v.size*.6;val left=v.at.x-when(v.style.align){"center"->width/2;"right"->width;else->0.0}
   val box=if(v.style.frame||v.style.background!=null)"<rect x=\"${n(left-v.size/3)}\" y=\"${n(v.at.y-v.size)}\" width=\"${n(width+2*v.size/3)}\" height=\"${n(lines.size*v.size*1.35)}\" fill=\"${esc(v.style.background?:"none")}\" stroke=\"${if(v.style.frame)esc(v.style.stroke)else"none"}\" stroke-width=\"${n(v.style.widthMm)}\"/>"else ""
   "<g transform=\"rotate(${n(v.angle)} ${n(v.at.x)} ${n(v.at.y)})\">$box<text x=\"${n(v.at.x)}\" y=\"${n(v.at.y)}\" font-family=\"sans-serif\" font-size=\"${n(v.size)}\" fill=\"${esc(v.style.stroke)}\" font-weight=\"${if(v.style.bold)"bold"else"normal"}\" font-style=\"${if(v.style.italic)"italic"else"normal"}\" text-anchor=\"${when(v.style.align){"center"->"middle";"right"->"end";else->"start"}}\">${lines.mapIndexed{i,s->"<tspan x=\"${n(v.at.x)}\" dy=\"${if(i==0)"0"else n(v.size*1.35)}\">${esc(s)}</tspan>"}.joinToString("")}</text></g>"
  }
  is Primitive.Group -> {
   val clip=v.clip?.let {val id="clip${clipId++}";"<defs><clipPath id=\"$id\"><polygon points=\"${it.joinToString(" "){p->"${n(p.x)},${n(p.y)}"}}\"/></clipPath></defs><g clip-path=\"url(#$id)\">"}?:""
   "$clip<g transform=\"translate(${n(v.translate.x)} ${n(v.translate.y)}) rotate(${n(v.angle)}) scale(${n(v.scale)} ${n(if(v.mirrorY)-v.scale else v.scale)})\">${v.nodes.joinToString(""){write(it)}}</g>"+if(v.clip!=null)"</g>"else""
  }
  is Primitive.Asset -> {
   val f=asset(v.path);require(f.exists()){ "Ressource fehlt: ${v.path}" };val bytes=if(f.extension=="svg")sanitizeSvg(f.readText()).toByteArray()else f.readBytes();val mime=if(f.extension=="svg")"image/svg+xml"else if(f.extension in setOf("jpg","jpeg"))"image/jpeg"else"image/png"
   "<image x=\"${n(v.at.x)}\" y=\"${n(v.at.y)}\" width=\"${n(v.width)}\" height=\"${n(v.height)}\" opacity=\"${n(v.opacity)}\" transform=\"rotate(${n(v.angle)} ${n(v.at.x)} ${n(v.at.y)})\" href=\"data:$mime;base64,${Base64.getEncoder().encodeToString(bytes)}\"/>"
  }
 }
}
