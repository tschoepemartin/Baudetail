# Baudetail in Android Studio öffnen und eine APK bauen

Die acht vorhandenen Module bleiben erhalten. Es ist kein neues Projekt und kein Kopieren einzelner Kotlin-Dateien erforderlich.

## Einmalige Einrichtung unter Windows

1. **ZIP entpacken**, zum Beispiel nach `C:\Android\Baudetail`. Im zu öffnenden Ordner müssen `settings.gradle.kts`, `gradlew.bat` und der Unterordner `app` liegen.
2. In [Android Studio](https://developer.android.com/studio) **Open** wählen und diesen Ordner öffnen. Android Studio Meerkat 2024.3.1 unterstützt das verwendete AGP 8.9; eine neuere Version muss weiterhin Projekte mit AGP 8.9 unterstützen. Einen angebotenen automatischen AGP-/Gradle-Upgrade für diesen Stand zunächst überspringen.
3. Unter **Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK** ein vollständiges **JDK 17** wählen. Falls es fehlt, über **Download JDK** Version 17 installieren. Eine reine Java-Laufzeit/JRE reicht nicht. Der Wrapper wählt Gradle 8.11.1 automatisch.
4. Im **SDK Manager** unter SDK Platforms **Android 15 / API 35** installieren. Unter SDK Tools bei **Show Package Details** die **Android SDK Build-Tools 35.0.0** auswählen. Für USB-Installation zusätzlich Platform-Tools installieren. NDK und CMake sind nicht erforderlich.
5. **Sync Project with Gradle Files** starten und den ersten Download abwarten. Der Gradle-Offline-Modus muss dabei ausgeschaltet sein. Android Studio legt den eigenen SDK-Pfad in `local.properties` an. Die benötigten Repositories und Abhängigkeiten stehen bereits vollständig im Projekt; siehe [Abhängigkeiten](ABHAENGIGKEITEN.md).

## Debug-APK mit dem in Android Studio eingestellten JDK

1. Rechts das Werkzeugfenster **Gradle** öffnen.
2. Dort **Execute Gradle Task / Run Gradle Task** wählen und `:app:assembleDebug` ausführen. Je nach Android-Studio-Version wird das Eingabefeld über das Gradle-/Elefant-Symbol geöffnet. Falls ein vollständiger Befehl erwartet wird, `gradle :app:assembleDebug` eingeben.
3. Auf **BUILD SUCCESSFUL** warten. Die installierbare, automatisch mit dem lokalen Debug-Schlüssel signierte Datei liegt dann unter:

```text
Baudetail\app\build\outputs\apk\debug\app-debug.apk
```

Die APK kann auf ein Android-Gerät ab Android 8.0 / API 26 kopiert und dort geöffnet werden. Android fragt beim ersten Installieren gegebenenfalls nach der Erlaubnis für die verwendete Datei-App. Alternativ das Smartphone per USB verbinden, USB-Debugging am Gerät erlauben und in Android Studio das Modul `app` auf dem Gerät starten. Für die App selbst werden keine pauschalen Speicherberechtigungen benötigt.

## Alternative im Terminal

Im Projektordner; das Terminal benötigt ebenfalls ein vollständiges JDK 17 über `JAVA_HOME` oder `PATH`. Die Gradle-JDK-Auswahl in Android Studio setzt diese Shell-Variablen nicht zwingend. Zuerst prüfen:

```powershell
.\gradlew.bat --version
```

Dann bauen und die fünf JVM-Testmodule prüfen:

```powershell
.\gradlew.bat :geometry:test :drawing-core:test :file-format:test :libraries:test :projects:test :app:assembleDebug
```

macOS/Linux: jeweils `./gradlew` statt `.\gradlew.bat`. Falls beim Entpacken das Ausführungsrecht verloren ging: `chmod +x gradlew`.

## Release

```powershell
.\gradlew.bat :app:assembleRelease
```

Ergebnis: `app\build\outputs\apk\release\app-release-unsigned.apk`. Diese Datei ist noch nicht signiert und deshalb nicht unmittelbar installierbar. Für eine verteilbare Release-APK in Android Studio **Build → Generate Signed Bundle / APK → APK** wählen und einen eigenen Keystore anlegen bzw. auswählen. Für spätere Updates denselben Schlüssel sicher aufbewahren. Das Projekt enthält keinen privaten Release-Schlüssel.

Ein App-Bundle lässt sich mit `:app:bundleRelease` erzeugen. Ein AAB ist keine direkt auf dem Handy installierbare APK.

## Wenn der lokale Build abbricht

| Meldung | Konkrete Prüfung |
|---|---|
| `Plugin ... was not found` / `Could not resolve ...` | Gradle-Offline-Modus ausschalten, Internetverbindung und gegebenenfalls eigenen Firmenproxy prüfen. Die genaue fehlende Koordinate steht im Build-Log. Keine zufälligen Maven-Mirrors hinzufügen. |
| `JAVA_COMPILER` fehlt / `No matching toolchains` | Vollständiges JDK 17 statt JRE auswählen; bei Terminalbetrieb `JAVA_HOME` prüfen. |
| `SDK location not found` | SDK Manager einmal öffnen; SDK-Pfad unter Android SDK auswählen. Android Studio erstellt `local.properties`. |
| `Failed to find Build Tools revision 35.0.0` | Genau diese Version im SDK Manager unter Show Package Details installieren. |
| `SDK licenses not accepted` | Lizenzdialog im SDK Manager abschließen. |
| APK-Installation schlägt wegen Signatur fehl | Eine schon installierte Baudetail-Version kann einen anderen Debug-Schlüssel haben. Zuerst Projekte vollständig exportieren; anschließend die alte App nur bei Bedarf deinstallieren und die neue APK installieren. |

Die App arbeitet nach Installation lokal. Der Internetzugriff beim ersten Build ist für die Entwicklungswerkzeuge und Bibliotheken erforderlich, nicht für die Nutzung von Baudetail.

Quellen: [Android-Build per Kommandozeile](https://developer.android.com/build/building-cmdline), [JDK-Konfiguration](https://developer.android.com/build/jdks), [AGP-8.9-Kompatibilität](https://developer.android.com/build/releases/agp-8-9-0-release-notes).
