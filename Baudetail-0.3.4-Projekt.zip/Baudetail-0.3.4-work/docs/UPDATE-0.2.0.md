# Baudetail 0.2.0 – Wiederhergestellter Update-Stand

Ausgangspunkt: vorhandenes Android-Studio-Projekt 0.1.1. Die verlorenen Änderungen
wurden gezielt auf dieser Basis ergänzt. Kein neues Package und keine Neuarchitektur.

## Installation und lokaler Build

App-ID `de.baudetail`, vorhandener Debug-Schlüssel, versionCode 3, versionName 0.2.0.
Die neue APK ist für die Installation über den mitgelieferten Teststand vorgesehen.
Nicht deinstallieren: Dadurch würden lokale App-Daten gelöscht.
Eine tatsächliche Installation auf Martins Gerät wurde hier nicht ausgeführt.

Android Studio: ZIP entpacken, den Ordner `Baudetail` öffnen, Gradle synchronisieren.
JDK 17 und Android SDK Platform 35 / Build Tools 35.0.0 verwenden.
Build: `./gradlew :app:assembleDebug` (Windows: `gradlew.bat :app:assembleDebug`).
APK: `app/build/outputs/apk/debug/app-debug.apk`.
Der erste Build lädt die Abhängigkeiten aus `gradle/libs.versions.toml` über Google
Maven, Maven Central und das Gradle Plugin Portal. Kein Internetbedarf in der App.

## Text-Crash und beschädigte Zeichnungen

Ursache: der reguläre Ausdruck für Textvariablen maskierte die abschließende
Klammer nicht. Androids ICU-Regex-Engine verwirft diesen Ausdruck; ein normaler
JVM-Test erkennt das nicht. Der korrigierte Ausdruck maskiert beide Klammern.
ICU-Gegenprobe: alt Fehler 66305, neu Status 0.
Der Fehler wurde beim Rendern ausgelöst und betraf deshalb auch bereits gespeicherte Texte.

Zusätzlich werden Objekte beim Laden einzeln geprüft. Null-Werte mit Defaults,
ungültige Textgröße, Rotation, Position und doppelte IDs werden soweit möglich
repariert. Unlesbare oder unbekannte Objekte werden übersprungen. Bei lokalem
Projektladen wird vor einer möglichen späteren Speicherung eine unveränderte
Originalkopie unter `files/baudetail/recovery` gesichert und ein Hinweis angezeigt.
Ein beschädigter Datei-/Projektkopf bleibt ein expliziter Ladefehler.
Formatversion der Pakete bleibt 1; zusätzliche Objekt-/Referenzfelder sind optional.

## Diagnose

Globaler Uncaught-Exception-Handler mit Weitergabe an den vorherigen Handler.
Lokale Berichte unter `files/diagnostics`, maximal 30, mit App-/Android-Version,
Gerät, internen Projekt-/Zeichnungs-IDs, Ansicht, Werkzeug, Thread, Exception-Klasse,
Stackframes einschließlich Ursachen und maximal 40 Ereignissen.
Schreibfehler werden abgefangen. Kein Netzwerk, keine persönlichen Projekttexte.
Exception-Nachrichten sind vorsorglich ausgenommen, da sie komplette JSON-Inhalte
enthalten können. Einstellungen → Diagnose bietet Ansehen, Export über SAF,
Teilen über Content-URI, Löschen und Alle löschen. Nach einem Crash gibt es einen Hinweis.
Der allgemeine Diagnoseexport enthält Versions- und Mengenangaben, keine Projektinhalte.

## Projekte und Bibliotheken

Long Press auf Projekt bzw. Zeichnung öffnet Aktionen. Export und Teilen führen zur
bestehenden Exportansicht. Löschbestätigung enthält den Namen. Umbenennen,
Duplizieren und Verschieben in eine andere Projektakte sind angeschlossen.
Projektname-Undo/Redo hat eigene Schaltflächen in der Projektakte und fünf persistente
Namensstände; Zeichnungsumbenennen verwendet den bestehenden Zeichnungs-Verlauf.
Die automatische Erzeugung der Demo-Bibliothek entfällt. Externe Bibliotheken bleiben erhalten.

## Treppen und Ansichten

Bauwerke → Treppe verwendet externe Bibliothekseinträge mit `assembly_role: stair_step`
oder Komponenten mit Stufennamen/-kategorie. Keine interne Produktliste.
Gemeinsame Parameter: Anzahl, Höhe, Auftritt, Breite, Gesamtmaße, Stufengefälle und
Laufrichtung. Wahlweise berechnet eine feste Gesamthöhe/-länge die Einzelmaße.
Live-Profilvorschau im Dialog; spätere Änderungen über Eigenschaften → Treppenparameter.
Draufsicht/Schnitt wird in der Zeichnung gespeichert und ist rückgängig machbar.
Top/Section/Symbol-Ressourcen kommen aus der Bibliothek, bei fehlender Grafik gibt
es eine geometrische Ersatzdarstellung. Draufsicht enthält Stufenkanten und Aufwärtspfeil.
Baugruppe kann als Einheit bearbeitet und per Undo-fähiger Aktion aufgelöst werden.

## Bemaßung

Neue Maße verwenden cm; vorhandene mm-Maße bleiben unverändert. Referenzen auf
Ecken, Kantenanteile, Schnittpunkte und Treppenpunkte aktualisieren Maßwerte.
Maßlinienverschiebung bleibt von den Referenzpunkten getrennt. Ansichten werden in
Treppenreferenzen gespeichert, damit ein Ansichtswechsel die Messstrecke nicht umdeutet.

## Bewusste Grenzen / offene Geräteabnahme

- Kein vollständiger neuer UI-Testlauf und keine Update-Installation auf einem Gerät.
- Vorige UI-Timeouts sind keine Nachweise für diesen wiederhergestellten Stand.
- Nach Auflösen einer Treppe werden zugehörige Maße derzeit statisch, statt auf
  individuelle Stufen umgebunden zu werden.
- Quergefälle und gesonderte Oben/Unten-Konfiguration fehlen.
- Hersteller-SVGs werden in das parametrierte Stufenmaß eingepasst; beliebige
  komplexe Geometrien benötigen eine visuelle Prüfung. Das Stufengefälle erscheint
  im technischen Profil; externe SVG-Konturen werden nicht geometrisch verformt.
- Projektverschieben ist keine atomare Transaktion über zwei Dateien. Das Ziel
  wird zuerst gespeichert, damit eine Unterbrechung keine Zeichnung verliert.
- Unbekannte Objektarten werden nicht interpretiert; lokale Originalkopie bleibt erhalten.
- Beim Paketimport gibt es noch keinen separaten objektweisen Reparaturbericht.
- Diagnoseexport zählt Bibliothekseinträge und deren Versionen, keine Paketinstallationseinheiten.
