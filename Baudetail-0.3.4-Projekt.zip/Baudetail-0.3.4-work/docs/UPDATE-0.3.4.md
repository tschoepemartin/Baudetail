# Baudetail 0.3.4 – Export-, Snap- und Beschriftungsfix

- PDF-Ausgabe nutzt exakt dieselbe Papierszene wie die Druckvorschau (WYSIWYG).
- Intelligentes Kanten-Snapping verwendet echte Außenkanten statt der alten Treppen-Punktfolge.
- Kantenmittelpunkte werden als Snap-Referenzen angeboten.
- Führende Bauteile können folgende Bauteile beim Einrasten automatisch ausrichten.
- Die relevante Planabmessung des folgenden Bauteils wird an die Länge der führenden Kante angepasst.
- Bei verknüpftem Fangen bleibt die Lage gekoppelt; Abmessungen werden bei Änderungen des führenden Bauteils synchronisiert.
- Pro Objekt bleibt ausschließlich eine objektgebundene, ein-/ausschaltbare und verschiebbare Standardbeschriftung.
- Version 0.3.4 / versionCode 8.
