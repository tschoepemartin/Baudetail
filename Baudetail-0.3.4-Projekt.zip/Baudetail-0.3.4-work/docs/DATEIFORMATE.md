# Dateiformate v1

Alle drei Endungen sind ZIP-Container mit UTF-8-JSON. Sie können mit gewöhnlichen ZIP- und JSON-Werkzeugen gelesen werden. Alle geometrischen Maße sind reale Millimeter; Papierabmessungen sind Papiermillimeter. `formatVersion` ist eine Ganzzahl, aktuell 1.

## Gemeinsames Manifest

```json
{
  "formatVersion": 1,
  "kind": "project",
  "name": "Mein Garten",
  "embedded": true,
  "resources": { "assets/beispiel.svg": "SHA-256 der Dateibytes" }
}
```

| Datei | `kind` | Pflichtinhalt | Zusätzlicher Inhalt |
|---|---|---|---|
| `.bproject` | `project` | `manifest.json`, `project.json` | Verwendete Ressourcen bei vollständiger Paketierung |
| `.bdetail` | `drawing` | `manifest.json`, `drawing.json` | `library-entries.json` und Grafikressourcen |
| `.bdlib` | `library` | `manifest.json`, `library.json` | SVG-Ansichten, Vorschauen, weitere lokale Dateien |

Das Manifest führt eingebettete Dateien mit SHA-256 auf. Absolute Pfade, `..`, Backslashes, doppelte Dateinamen und Pakete über 128 MiB entpackter Gesamtgröße werden abgelehnt. Das Paket wird nicht in beliebige Dateisystempfade entpackt.

## Zeichnung `.bdetail`

`Drawing` enthält ID, Name, Dokumenttyp, Objekte, Layer, Papierlayout, Maßstab, Ursprung, Bezugshöhe, Raster, Revision, Variablen und Schnittverknüpfungen. Die verbindliche Felddefinition steht in `drawing-core/.../Model.kt`.

Ein Objekt enthält unter anderem:

```json
{
  "id": "linie-1",
  "kind": "line",
  "points": [{"x":0,"y":0},{"x":1000,"y":0}],
  "layerId": "planning",
  "params": {},
  "style": {"stroke":"#273A3A","widthMm":0.25}
}
```

`style.widthMm` und `textPaperMm` sind Papiergrößen. `params` enthält objektspezifische Werte, beispielsweise `radiusMm`, `spacingMm`, `percent` oder `mode`. Unbekannte Attribute bleiben dort erhalten.

`library-entries.json` bewahrt Bibliotheksdefinitionen für die Einzelzeichnung. Beim Import haben bereits vorhandene Projektdefinitionen mit gleicher ID Vorrang. Die verknüpfte zweite Zeichnung einer Schnittmarke ist nicht automatisch Bestandteil einer einzelnen `.bdetail`; für vollständige Verknüpfungen `.bproject` verwenden.

## Projekt `.bproject`

`Project` enthält Stammdaten, Zeichnungen, Variantenverweise, Notizen, Zeichnungsrevisionen, Ressourcen und projektspezifische Bibliothekseinträge.

- **Vollständig paketieren:** Alle referenzierten Dateien, einschließlich Original-PDF eines Hintergrundes, werden eingebettet. Beim Import werden Ressourcen nach Inhalt adressiert und ihre Referenzen konsistent umgeschrieben.
- **Nur Projekt:** Ressourcenpfade bleiben Referenzen. Auf dem Zielgerät müssen diese Ressourcen bereits vorhanden sein. Der Import ersetzt fehlende Dateien nicht durch erfundene Inhalte.

Die Geräte-Testsimulation verwendet zwei getrennte Speicherorte. Ein tatsächlicher Zweigerätetest ist noch offen.

## Bibliothek `.bdlib`

`library.json` enthält `formatVersion`, `id`, `name`, `version` und `entries`. Jeder Eintrag hat mindestens `id`, `type`, `category`, `name`; optionale Angaben sind `manufacturer`, `series`, `attributes`, `views`, `preview`, `geometry`, `style`, `template` und `extensions`.

Unterstützte Verwendungstypen: `material`, `component`, `titleblock`, `text-template`. Andere Typbezeichnungen können importiert werden; ihr deklaratives SVG-/Geometriemodell kann als Bauteil platziert werden. Ein neues Datenfeld definiert nicht automatisch ein neues parametrisches Verhalten.

## Versionierung und Erweiterungen

- v1 ist der veröffentlichte Projektstand.
- Der gleich aufgebaute Legacy-v0-Projekt-/Zeichnungsdatensatz wird mit Standardwerten auf v1 gehoben.
- Größere unbekannte Versionen werden abgelehnt, damit keine Daten versehentlich mit älterem Schema überschrieben werden.
- Freie Attribute in `attributes`, `params` und `extensions` bleiben erhalten. Unbekannte Felder außerhalb dieser Erweiterungsbereiche werden beim Lesen toleriert, aber beim Schreiben nicht garantiert bewahrt.
- IDs müssen innerhalb der jeweiligen Sammlung eindeutig sein.

Die interne Speicherung `StoredProject` ist kein zusätzlicher öffentlicher Dateityp. Sie enthält zusammen mit dem Projekt den persistenten Undo-/Backup-Zustand.
