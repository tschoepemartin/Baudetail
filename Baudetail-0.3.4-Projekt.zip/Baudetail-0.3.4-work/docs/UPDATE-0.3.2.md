# Baudetail 0.3.2

Gezielter Korrekturstand auf Basis 0.3.1. App-ID, Paketname, Signaturschlüssel und Dateiformate bleiben unverändert. `versionCode=6`, `versionName=0.3.2`.

## Korrekturen

- PDF-Export rendert PDF-Geometrie nun direkt in PDF-Punkten statt über eine skalierte Android-Canvas. Damit sollen die zuvor sichtbaren fehlerhaften Buchstabenabstände vermieden werden.
- Beim PDF-Export wird ein veralteter/leer liegender Blattursprung erkannt. Liegt die Zeichnungsmitte außerhalb des konfigurierten Papierfensters, wird für den Export bei unverändertem Maßstab auf die tatsächliche Zeichnungsgeometrie zentriert, statt die komplette Zeichnung wegzuclippen.
- Plankopfvariablen werden vor dem Rendern vollständig aufgelöst. Fehlende Standardfelder werden leer ausgegeben und nicht mehr als `{platzhalter}` gedruckt.
- Automatische/assoziative Maße sind zusätzlich über die tatsächlich sichtbare Maßlinie, Hilfslinien und den Maßtext auswählbar. Verschieben bleibt mit der Quellgeometrie gekoppelt.
- Treppen verwenden in Schnitt **und Draufsicht dieselben realen Bibliotheks-Stufeninstanzen**. In Draufsicht werden darüber die üblichen Stufenkanten, Außenfluchten, Laufrichtung sowie OBEN/UNTEN gezeichnet. Stufentiefe und Auftritt bleiben getrennt; 40 cm Tiefe / 35 cm Auftritt ergeben 5 cm Überdeckung.
- Alte Rasen-Schnittkomponenten, deren Top-View fälschlich identisch mit der Schnittgrafik ist, erhalten in Draufsicht einen neutralen Flächen-Fallback statt der Schnittsilhouette. Die neue Grundbibliothek v2 liefert dafür echte Top-Assets.
- Bibliotheksformat bleibt abwärtskompatibel; Material `appearance.top`, `appearance.section` und `sectionPattern` werden weiter unterstützt.

## Bibliothek v2

Die separat erzeugte `Baudetail-GaLaBau-Grundbibliothek-v2.bdlib` bleibt technisch Paketformat 1, besitzt aber Inhaltsversion 2:

- Material + zugehörige Schnittfüllung sind physisch zu **einem** sichtbaren Materialeintrag zusammengeführt.
- Alle Materialien besitzen explizite `top`-/`section`-Appearance-Daten.
- Vorhandene Schnittschraffuren werden als `sectionPattern` weiterverwendet.
- Rasen-Schnittkomponenten besitzen echte Draufsicht-Assets.

## Build-Hinweis

In der aktuellen Chat-Ausführungsumgebung fehlen Android SDK und die Gradle-Distribution; externe Downloads sind dort gesperrt. Der Quellstand wurde deshalb hier nicht zu einer neuen APK kompiliert. Das Projekt ist für JDK 17, Android SDK 35, Build Tools 35.0.0 und Gradle 8.11.1 konfiguriert und kann unverändert in Android Studio gebaut werden.
