# Architektur

## Abhängigkeitsrichtung

`app → ui → projects → libraries → file-format → drawing-core → geometry`

`ui → export → drawing-core`

Die fünf Kernmodule sind reine JVM/Kotlin-Module. Android-Dateidialoge, SQLite-Metadatenindex und ViewModel liegen in `ui`; Android-Canvas und PDF-/PNG-Ausgabe liegen in `export`. Fachinhalte stammen aus `LibraryEntry` und externen Paketen.

## Koordinaten und Darstellung

- `Vec` speichert Double-Koordinaten in realen Millimetern.
- Die aktuelle v1-Arbeitsfläche verwendet X nach rechts und Y nach unten. Höhenkoten sind separat in Millimetern gespeichert und steigen positiv nach oben.
- Bildschirmzoom und Pan liegen ausschließlich in `DrawingCanvas` und verändern keine Geometrie.
- `Scene` erzeugt Vektorprimitive aus Dokument und parametrischen Objekten.
- PDF/SVG-Papierkoordinaten: reale Millimeter geteilt durch Maßstabsnenner. Die PDF-Ausgabe multipliziert Papiermillimeter mit `72 / 25,4`.
- A4/A3/A2 werden als freie Breite/Höhe unterstützt. PDF-Seitengrößen müssen durch Androids `PdfDocument.PageInfo` auf ganze PDF-Punkte gerundet werden; die Geometrieskalierung bleibt davon unabhängig.
- Der sichtbare Papierbereich markiert den exportierbaren Inhalt zwischen 10-mm-Rändern und Plankopf. Außerhalb kann frei gezeichnet werden.

## Daten, Befehle und Speicherung

`Entity`, `Drawing`, `Project`, `Layer`, `Sheet` und `LibraryEntry` sind serialisierbare Datenklassen. Unbekannte fachliche Attribute liegen in `JsonObject`.

`EditorHistory` hält bis zu 200 Sitzungsschritte, persistiert die letzten fünf rückgängig machbaren Zustände und bis zu zehn Sicherungsstände. Ein `StoredProject` enthält Projekt und Zeichnungshistorien gemeinsam. Temporäre Datei, `fsync` und atomarer Austausch verhindern getrennt geschriebene Projekt-/Undo-Stände. Das ViewModel serialisiert Speichervorgänge über eine Coroutine-Queue.

Revisionen enthalten unveränderliche Zeichnungssnapshots. Varianten sind derzeit unabhängige Kopien mit Ursprungsverweis. Ressourcen liegen nach SHA-256 adressiert und werden bei gleichen Bytes wiederverwendet.

## Referenzen

- Bemaßung: `Anchor(entityId, vertex)`; Auflösung bei Darstellung und Berechnung.
- Kreisradiusreferenzen berücksichtigen geänderte Radiusparameter.
- Schnitt: `targetDrawingId`, Gegenrichtung `sourceDrawingId`.
- Texte: `params.sourceId` plus Variablen wie `{name}`, `{widthMm}`, `{flaeche_m2}` und `{dicke_mm}`.
- Schichten: Dicke und Materialname erzeugen gemeinsam Geometrie und Beschriftung.

Es gibt noch keinen allgemeinen CAD-Constraint-Solver und keine automatische 3D-/Schnittableitung.

## Bibliotheken

`Catalog` kennt keine abschließende Kategorienliste. Kategorien sind Pfade, technische Attribute frei typisierte JSON-Daten. Hersteller und Serien sind Datenfelder. SVG-Ansichten sind lokale, deklarative Darstellungen; Skripte und externe Referenzen werden abgelehnt. Parametrische neue Verhaltensweisen benötigen weiterhin Engine-Unterstützung; neue Materialien, Namen, Produkte und deklarative Geometrien benötigen keine neue APK.

## Android-Zugriff

Externe Ordner und Dokumente werden über SAF geöffnet. Persistente URI-Freigaben werden gespeichert und geprüft. Freigaben für Exporte erfolgen über `FileProvider` und `FLAG_GRANT_READ_URI_PERMISSION`. Es gibt keine App-Internet-, Kamera- oder globale Speicherberechtigung. Grundlage ist die [Android-Dokumentation zu SAF](https://developer.android.com/training/data-storage/shared/documents-files).
