# Baudetail 0.3.0

Fortsetzung des vorhandenen 0.2.0-Projekts. Package und App-ID bleiben `de.baudetail`; der mitgelieferte Debug-Schlüssel bleibt erhalten. `versionCode=4`, `versionName=0.3.0`. Keine neue Bibliothek wurde erzeugt. Frühere Änderungen an Textverarbeitung, Diagnose, Dateiimport, Undo und Backups bleiben Bestandteil des Projekts.

## Bedienung

- Geschlossene Rechtecke, Kreise, Polygone und geschlossene Polylinien können Materialien erhalten. Polylinie am Startpunkt antippen schließt sie als Fläche. Alternativ: Eigenschaften → In Fläche umwandeln. Offene Linien bleiben Linien.
- Fläche auswählen → Bibliothek → Material → Auswahl zuweisen. Die Kontur bleibt erhalten. Draufsicht verwendet Oberflächenfarbe, Schnitt verwendet Schnittstil und die vorhandene Schraffur innerhalb der Kontur.
- Eigenschaften → Ebene / Höhen / Sichtbarkeit: Ebene, Z, Ober-/Unterkante und Sichtbarkeit einstellen. Oberflächenplan blendet Fundament/Unterbau aus; Fundamentplan zeigt diese Ebenen. Das ist 2D-Sichtlogik, keine 3D-Modellierung.
- Bauwerke → Treppe: Stufentyp aus `.bdlib`, reale Stufentiefe, Auftritt, Anzahl, Höhe, Breite, Gefälle und Laufrichtung einstellen. 400 mm Tiefe und 350 mm Auftritt ergeben 50 mm Überdeckung. Treppenstufen und einzeln eingefügte Stufen verwenden denselben Instanz- und Renderingpfad. Keine zusätzliche Außenkontur.
- Eigenschaften → Als Bauwerk speichern legt eine unabhängige globale Vorlage an. Startseite → Bauwerke verwalten: Vorschau, Name/Kategorie, Duplizieren, Import/Export, Löschen und Geometrie-Arbeitskopie. Änderungen einer Arbeitskopie aktualisieren die Vorlage ausschließlich über „Globale Vorlage aktualisieren“. Vorhandene Instanzen bleiben unverändert.
- Eigenschaften → Automatische Maße: Aus / Minimal / Ausführung / Vollständig / Benutzerdefiniert. Einzelne Maße lassen sich anschließend über „Maßtext und Maßlinie bearbeiten“ beschriften, versetzen und ausblenden. Ausgeblendete Maße über die Objektliste wählen. Längen haben Maßlinien; Fläche, Umfang, Anzahl und Gefälle werden als gekoppelte Beschriftungen ausgegeben.
- „Fang verknüpfen“ aktiviert dauerhafte Verbindungen beim Einfügen. Ohne diese Option wird nur die Position gefangen. Eigenschaften → Dauerhafte Anschlüsse lösen fixiert die aktuelle Position.
- Projekt-/Zeichnungsübersicht: Sortierung nach Änderungszeit, Name und Erstellung. Altbestände ohne Zeitangabe zeigen „unbekannt (Altbestand)“.

## Offene Formate / additive Erweiterungen

Paketformate bleiben Version 1, damit bestehende `.bdetail`, `.bproject` und `.bdlib` gelesen werden. Optionale JSON-Felder ergänzen das vorhandene Modell. Eine spätere Bibliotheksformatversion 2 ist vorbereitet, wird hier aber weder vorausgesetzt noch erzeugt. Ältere Apps ignorieren neue Felder; ein Zurückspeichern mit älteren Apps kann deren Informationen verlieren.

`Entity.placement`: `level`, optionale `zMm`, `topMm`, `bottomMm`, `visibleTop`, `visibleSection`, `hidden` (gestrichelt). Standard: Oberfläche, in beiden Ansichten sichtbar.

`Entity.bindings`: Liste aus `vertex` und `anchor`. Anchor speichert Objekt-ID plus Referenz auf Ecke, Kantenanteil, Schnittpunkt, Kreisrand, Komponente oder Treppenende. Begrenzte Auflösung schützt gegen zyklische Verbindungen. Referenzen sind kein allgemeiner CAD-Zwangsbedingungslöser.

`LibraryEntry.appearance`: `top` und `section` als Style, optional `sectionPattern` als relativer Ressourcenpfad und `tileWidthMm` / `tileHeightMm` (Standard 200 mm). Vorhandene `views.top`, `views.section`, `views.symbol` bleiben gültig. Einträge mit `material_id` oder eindeutig passendem Namenssuffix „Schnittfüllung“ werden im Picker zusammengeführt; alte Alias-IDs bleiben gespeichert.

`Entity.materialId` bezeichnet das Material einer Fläche. `materialSnapshot` und `params.asset_top/asset_section/asset_symbol` sichern Darstellungen in eigenen Vorlagen. Vollständiger Paketexport übernimmt auch diese Ressourcen.

Eigene Bauwerke sind Bibliothekseinträge vom Typ `assembly-template` mit unabhängiger Geometrie, ID, Name, Kategorie, Version und lokalem Nullpunkt. Die Vorschau wird vektoriell aus der Geometrie erzeugt. Eine eingefügte Instanz besitzt eigene IDs, eingefrorene Kinder und `templateId/templateVersion` ausschließlich als Herkunftsangaben.

Maße verwenden `sourceId` + `metric` beziehungsweise die vorhandenen `anchors`. Darstellungsparameter: `prefix`, `suffix`, `unit`, `decimals`, `textDx/textDy`, `dimDx/dimDy`, `offsetMm`, `hidden`. Geometrische Werte werden beim Rendern neu aufgelöst.

Zeichnungen erhalten `createdAt`/`updatedAt`, Projekte `createdAt` zusätzlich zum bisherigen Änderungsdatum. Werte sind Unix-Zeit in Millisekunden; 0 bedeutet unbekannten Altbestand. Der SQLite-Metadatenindex wird ohne Löschen vorhandener Daten erweitert.

## Grenzen und Geräteprüfung

- Der aktuelle Prüfbericht unterscheidet tatsächlich ausgeführte JVM-/Buildprüfungen von noch nicht ausgeführten Geräteabläufen. Kein UI-/Update-Gerätetest wird als bestanden ausgegeben.
- Fehlende Draufsicht wird nicht durch Schnittgrafik ersetzt. Es gibt dann eine geometrische Ersatzdarstellung. Eine fehlende herstellerspezifische Draufsicht kann ohne passende externe Grafik nicht rekonstruiert werden.
- Die Profilvorschau im Treppendialog ist schematisch; die Zeichenfläche rendert Bibliotheksstufen. SVGs werden auf die parametrisierten Bauteilmaße abgebildet. Längsgefälle dreht die Stufe; Quergefälle beeinflusst die mittige Schnitthöhe, es gibt keine dreidimensionale Verformung.
- Beim Auflösen der Treppe werden zugeordnete Maße/Anschlüsse auf ihren aktuellen Stand fixiert, statt automatisch auf einzelne neue Stufen umzubinden.
- Höhenangaben steuern Metadaten/Sichtbarkeit, keine automatische Projektion eines 3D-Modells. Pflanzplan ist zunächst ein Oberflächenprofil; keine automatische botanische Klassifizierung unbekannter Bibliothekskategorien.
- Schraffuren sind maßhaltige Kacheln. Über 10.000 Kacheln erscheint ein Hinweis zum Teilen der Fläche statt einer verzerrten Schraffur. Kreis-Schraffurclips verwenden 128 Segmente; Flächen-/Umfangswerte bleiben mathematisch exakt.
- Benutzerdefinierte Maßprofile werden durch Bearbeiten der erzeugten Einzelmaße eingestellt. Bei „Benutzerdefiniert“ werden zunächst alle verfügbaren Maße angelegt.
- Bibliotheksattribute bleiben frei. Unbekannte Maße/DN können nicht semantisch aus beliebigen Namen erschlossen werden; Werte müssen in unterstützten Attributen/Parametern hinterlegt sein.
