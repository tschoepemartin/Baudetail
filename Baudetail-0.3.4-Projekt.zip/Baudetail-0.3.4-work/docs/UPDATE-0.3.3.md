# Baudetail 0.3.3 – intelligentes Bauteil- und Export-Update

## Schwerpunkt
0.3.3 führt eine gemeinsame parametrische Logik für Bauteile ein. Schnitt und Draufsicht werden nicht mehr als unabhängig zu korrigierende Objekte behandelt, sondern verwenden denselben Einfügepunkt, dieselbe Rotation und dieselben Bauteilparameter.

## Enthalten
- stabiler Bauteil-Pivot bei Rotation; Ansichtswechsel verändert die Objektlage nicht
- Treppen: Stufengefälle wirkt auf die resultierende Gesamthöhe; bei fixer Gesamthöhe wird die erforderliche Stufenhöhe entsprechend berechnet
- intelligenter Variantenwechsel kompatibler Bibliotheksbauteile mit erhaltenem Bezugspunkt
- optionale, objektgebundene Beschriftungen mit Auto-/Manuelltext und Führung
- Mauerscheiben/Winkelstützelemente als echte L-Geometrie in Schnitt und abgeleitete Draufsicht
- Rohr-/Leitungsorientierung horizontal oder vertikal (oben/unten) für alle als Rohrfamilie definierten Einträge
- Material/Füllung direkt an geschlossene Zeichnungsobjekte zuweisbar; Draufsicht auto/flächig/senkrecht
- Drag-to-delete mit temporärem Löschziel und Bestätigung
- Toolbar-Reihenfolge: Bibliothek zuerst, Maßeingabe nach hinten
- Exportvorschau mit Papierformat, Orientierung, Maßstab und Ausschnitt
- Exportdateiname basiert auf Zeichnungsname; Dateiendung wird beim Speichern abgesichert
- Plankopftext als getrennte Textzeilen gerendert
- Versionsanzeige auf 0.3.3

## Bibliothek v3
Die passende `Baudetail-GaLaBau-Grundbibliothek-v3.bdlib` ergänzt Smart-Familien/Variantengruppen und Mauerscheiben-Varianten. Alte falsche L-Stein-Platzhalter wurden entfernt.

## Kompatibilität
Vorhandene 0.3.x-Projekte bleiben lesbar. Ältere platzierte Bauteile können weiterhin dargestellt werden; Smart-Funktionen greifen vollständig bei Einträgen mit den neuen Metadaten.
