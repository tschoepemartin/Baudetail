# Abhängigkeiten beim ersten Build

Alle direkten Versionen stehen in `gradle/libs.versions.toml`. Es gibt keine dynamischen `+`-Versionen, SNAPSHOTs, privaten Maven-Repositories oder Zugangsdaten im Projekt.

## Repositories

- Für Plugins: Google Maven, Maven Central und Gradle Plugin Portal.
- Für Modul-Abhängigkeiten: Google Maven und Maven Central; zusätzliche Modul-Repositories werden mit `FAIL_ON_PROJECT_REPOS` verhindert.
- Google Maven ist auf `com.android`, `androidx` und `com.google.testing.platform` einschließlich Untergruppen begrenzt. Kotlin- und normale Java-Abhängigkeiten werden dadurch nicht zuerst erfolglos bei Google gesucht.
- Die beiden Android-Plugin-IDs werden auf `com.android.tools.build:gradle:8.9.2` abgebildet; andere Plugins verwenden ihre offiziellen Plugin-Metadaten.
- Kein JCenter, JitPack, `mavenLocal()`, `flatDir`, unsicheres HTTP oder Spiegelserver.

## Entwicklungswerkzeuge außerhalb der APK

| Werkzeug / Plugin | Version / Quelle |
|---|---|
| Gradle Wrapper | 8.11.1 von `services.gradle.org`, gegebenenfalls Weiterleitung zum offiziellen Distributionshost; SHA-256 im Wrapper festgelegt |
| Android Gradle Plugin | `com.android.tools.build:gradle:8.9.2`, Google Maven |
| Kotlin Android/JVM | `org.jetbrains.kotlin:kotlin-gradle-plugin:2.1.10` plus Plugin-Marker-Metadaten |
| Kotlin Serialization | `org.jetbrains.kotlin:kotlin-serialization:2.1.10` und zugehöriger Compiler-Plugin-Baustein |
| Compose Compiler | `org.jetbrains.kotlin:compose-compiler-gradle-plugin:2.1.10` und zugehöriger Compiler-Plugin-Baustein |
| Kotlin Compiler/Stdlib | 2.1.10, automatisch durch das Kotlin-Plugin eingebunden |
| JDK | Vollständiges JDK 17, über Android Studio/JDK-Anbieter installieren |
| Android SDK | `platforms;android-35` und `build-tools;35.0.0`, über SDK Manager |
| Geräteinstallation | `platform-tools`; unter Windows gegebenenfalls Gerätetreiber |

AGP lädt unter anderem Builder, Manifest-Merger, Ressourcenwerkzeuge, Lint, D8/R8 und Bundletool einschließlich ihrer transitiven Java-Bibliotheken. AAPT2 benötigt ein zum Betriebssystem passendes ausführbares Artefakt; Windows und Linux unterscheiden sich dabei. SDK und JDK sind keine Maven-Abhängigkeiten. NDK, CMake und Emulator werden zum APK-Build nicht benötigt.

## Direkt deklarierte Bibliotheken

| Maven-Koordinate | Version | Module |
|---|---|---|
| `androidx.core:core-ktx` | 1.15.0 | ui (Build/Runtime) |
| `androidx.activity:activity-compose` | 1.10.1 | ui (Build/Runtime), app (Build/Runtime) |
| `androidx.compose:compose-bom` | 2025.02.00 | ui (Build/Runtime), app (Build/Runtime) |
| `androidx.compose.ui:ui` | BOM 2025.02.00 | ui (Build/Runtime) |
| `androidx.compose.runtime:runtime` | BOM 2025.02.00 | app (Build/Runtime) |
| `androidx.compose.foundation:foundation` | BOM 2025.02.00 | ui (Build/Runtime) |
| `androidx.compose.material3:material3` | BOM 2025.02.00 | ui (Build/Runtime) |
| `androidx.compose.material:material-icons-extended` | BOM 2025.02.00 | ui (Build/Runtime) |
| `androidx.lifecycle:lifecycle-runtime-compose` | 2.8.7 | ui (Build/Runtime) |
| `androidx.lifecycle:lifecycle-viewmodel-compose` | 2.8.7 | ui (Build/Runtime) |
| `androidx.lifecycle:lifecycle-viewmodel` | 2.8.7 | app (Build/Runtime) |
| `androidx.navigation:navigation-compose` | 2.8.9 | ui (Build/Runtime) |
| `org.jetbrains.kotlinx:kotlinx-serialization-json` | 1.8.0 | drawing-core (Build/Runtime), ui (Build/Runtime), file-format (Build/Runtime), geometry (Build/Runtime), projects (Build/Runtime), libraries (Build/Runtime) |
| `org.jetbrains.kotlinx:kotlinx-coroutines-android` | 1.10.1 | ui (Build/Runtime) |
| `androidx.documentfile:documentfile` | 1.0.1 | ui (Build/Runtime) |
| `com.caverock:androidsvg-aar` | 1.4 | export (Build/Runtime), ui (Build/Runtime) |
| `junit:junit` | 4.13.2 | drawing-core (JVM-Test), file-format (JVM-Test), geometry (JVM-Test), projects (JVM-Test), libraries (JVM-Test) |
| `androidx.test.ext:junit` | 1.2.1 | export (Android-Test) |
| `androidx.test:runner` | 1.6.2 | export (Android-Test) |
| `androidx.annotation:annotation` | 1.8.1 | export (Android-Test, Versionsconstraint) |

Das Compose-BOM 2025.02.00 legt für die verwendeten Compose-Runtime-/UI-/Foundation-/Icons-Bausteine Version 1.7.8 und für Material3 Version 1.3.1 fest. Es ist eine Versionsplattform, kein zusätzliches UI-Paket. Die Android-/JVM-Varianten werden anhand der veröffentlichten Modulmetadaten ausgewählt.

Weitere notwendige Downloads ergeben sich aus diesen Bibliotheken: insbesondere Kotlin-Stdlib, Serialization Core, Coroutines Core, Activity/Core/Lifecycle/SavedState, Navigation Runtime, Compose Animation/Text/Graphics/Layout, AndroidX Annotation/Collection, JUnit/Hamcrest sowie die Android-Test-Infrastruktur. Nur die direkten Zeilen ergeben deshalb noch keinen vollständigen Offline-Cache.

## Bereinigung

- `app` enthält direkt nur UI, Activity, Compose Runtime/BOM und den ViewModel-Basistyp. Doppelte Deklarationen für Foundation, Material3, Icons, Navigation, SAF, Coroutines und JSON wurden dort entfernt. Die zuständigen Fachmodule liefern ihre Laufzeitabhängigkeiten weiterhin mit.
- Das Serialization-Compiler-Plugin wurde in `app` und `export` entfernt; beide enthalten keine serialisierbaren Klassen.
- Unbenutzte Preview-/Tooling-Abhängigkeiten und Test-Abhängigkeiten in Modulen ohne entsprechende Tests wurden entfernt. Fünf JVM-Testsuiten und der Android-PDF-Test bleiben erhalten.
- Die verwendeten Material-Icons und AndroidSVG bleiben erhalten. Ein Ersatz würde funktionierenden UI-/Zeichencode verändern.
- Alle drei Android-Module legen Build Tools 35.0.0 ausdrücklich fest.
- `drawing-core` exportiert Serialization nun mit `api`, weil `JsonObject` Teil seiner öffentlichen Entity-Schnittstelle ist. Damit sehen auch separat kompilierte Verbraucher und der PDF-Test den erforderlichen Typ.
- Die Test-Infrastruktur wird auf Annotation 1.8.1 begrenzt, um ihre ältere transitive Beta-Version zu ersetzen.

## Cache und vollständige Auflösung

Ein Offline-Build braucht Wrapper, SDK, JDK sowie alle Artefakte **und Metadaten** für genau die gewählten Aufgaben und Betriebssystemvarianten. Einzelne vorher separat geladene Kotlin-/AndroidX-JARs ersetzen keinen Gradle-Cache. Ein Debug-Build allein garantiert keinen vollständigen Cache für Release oder Android-Gerätetests.

Das Quell-ZIP enthält keinen globalen Gradle-Cache und kein SDK/JDK. Android Studio lädt fehlende Bestandteile beim ersten regulären Build automatisch bzw. über den SDK Manager. Nach Installation arbeitet Baudetail vollständig lokal.

Die vollständigen tatsächlich aufgelösten Build-, App- und Android-Test-Abhängigkeitsbäume liegen in `reports/Gradle-Abhaengigkeiten.txt`. Eine zusätzliche Cache-Dateiliste steht in `reports/Gradle-Cache-Artefakte.tsv`; sie enthält auch zwischenzeitlich geladene Metadaten zur Versionsauflösung und ist nicht mit der Liste der endgültigen APK-Bibliotheken gleichzusetzen. AAPT2 verwendet in diesem Build die Version `8.9.2-12782657` (Classifier `linux`; lokal unter Windows `windows`).

Die Versionen können im Projektordner erneut ausgegeben werden:

```powershell
.\gradlew.bat buildEnvironment
.\gradlew.bat :app:dependencies --configuration debugRuntimeClasspath
.\gradlew.bat :app:dependencies --configuration releaseRuntimeClasspath
.\gradlew.bat :export:dependencies --configuration debugAndroidTestRuntimeClasspath
```

Nach einem erfolgreichen Online-Build kann derselbe Build-Aufruf mit `--offline` wiederholt werden. Dabei fehlende Artefakte nennt Gradle mit exakter Koordinate.

Quellen: [Gradle-Repositories](https://docs.gradle.org/current/userguide/declaring_repositories_basics.html), [Repository-Filter](https://docs.gradle.org/current/userguide/filtering_repository_content.html), [Android-Abhängigkeiten](https://developer.android.com/build/dependencies).

## Ergebnis der Cache-Prüfung

Zu Beginn fehlte der reguläre Gradle-Artefaktcache; der Offline-Build konnte nicht starten. Nach Korrektur der Java-Umgebung und vollständigem Online-Build gelang derselbe Build einschließlich Tests nach `clean` mit `--offline`. Es ist damit kein Maven-Zugriff für einen Wiederholungsbuild auf dieser vollständig eingerichteten Umgebung erforderlich. Ein neuer Rechner muss seinen eigenen Cache und seine plattformspezifischen Werkzeuge zunächst laden.


## Android-Regressionstests 0.1.1

Zusätzlich Robolectric 4.14.1, Compose ui-test-junit4 gemäß BOM 2025.02.00 und instrumentiertes Android-35-Abbild. Betroffene Maven-Testdownloads und letzter 403-Fehler stehen im aktuellen Prüfbericht. Die App selbst benötigt diese Testbibliotheken nicht.
