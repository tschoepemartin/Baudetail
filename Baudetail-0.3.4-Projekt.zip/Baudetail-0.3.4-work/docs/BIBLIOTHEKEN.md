# Eigene Bibliotheken, Planköpfe und Symbole

## Ordnerbibliothek

In den App-Einstellungen einen Ordner über den Android-Systemdialog auswählen. Darin können Kategorien beliebig gegliedert werden; die aktuelle Schutzgrenze für das Einlesen liegt bei 64 Ebenen und 50.000 besuchten Dateien. Nach Änderungen „Neu einlesen“ verwenden.

Einträge als UTF-8-JSON ablegen. Ressourcenpfade gelten relativ zum Verzeichnis dieser JSON-Datei. Vollständige `.bdlib`-Dateien können ebenfalls im gewählten Ordner liegen.

## Beispiel für ein Material

```json
{
  "formatVersion": 1,
  "id": "eigen-oberboden-015",
  "type": "material",
  "category": "Boden/Oberboden/0-15",
  "name": "Oberboden 0/15",
  "attributes": {"Körnung":"0/15","Lieferant":"Eigener Lieferant"},
  "style": {"stroke":"#5E5142","fill":"#CBB18F","widthMm":0.25}
}
```

Das neue Attribut wird beim Einlesen als Filterfeld verfügbar. Hersteller und Produktserien werden genauso als Daten geliefert.

## Bauteile mit mehreren Ansichten

```json
{
  "formatVersion": 1,
  "id": "meine-rinne",
  "type": "component",
  "category": "Entwässerung/Rinnen/Eigene",
  "name": "Rinne 150",
  "attributes": {
    "width_mm":1000,"height_mm":150,
    "section_width_mm":150,"section_height_mm":180,
    "Belastungsklasse":"C250"
  },
  "views":{"top":"top.svg","section":"section.svg","symbol":"symbol.svg"}
}
```

SVG mit `viewBox` und vollständig lokalen, deklarativen Pfaden anlegen. Zeichnungen vom Typ Schnitt oder Detail wählen die Schnittansicht; Draufsichten verwenden `top`. Die physischen Größen kommen aus den Attributen. Vorschauen werden gespeichert, aber die grafische Vorschauliste ist noch nicht umgesetzt.

## `.bdlib` erzeugen

Einen Quellordner mit `library.json` und den referenzierten SVG-Dateien anlegen. `library.json` umschließt die Einträge:

```json
{"formatVersion":1,"id":"meine-bibliothek","name":"Meine Bibliothek","version":1,"entries":[]}
```

Dann mit dem mitgelieferten Python-Werkzeug paketieren:

```bash
python tools/make-bdlib.py mein-quellordner Meine-Bibliothek.bdlib
```

Das Werkzeug erzeugt ZIP und Manifest samt Ressourcenprüfsummen. Danach in Baudetail importieren und bei ID-Konflikten zwischen Behalten, Ersetzen und Kopie wählen.

## Eigener Plankopf

`type` auf `titleblock` setzen, den Text in `template` speichern. Verfügbare Variablen: `{projekt}`, `{projektnummer}`, `{zeichnung}`, `{detailnummer}`, `{datum}`, `{maßstab}`, `{bearbeiter}`, `{revision}`, `{auftraggeber}` und frei hinzugefügte Variablen.

Der aktuelle Plankopf ist ein Textlayout in einem gezeichneten Rahmen. Grafische, frei positionierte Plankopffelder und Logos sind noch offen. Der bestehende Textplankopf kann in den Zeichnungseinstellungen bearbeitet und als externer Bibliothekseintrag verteilt werden.

## Eigene Symbole

Objekte markieren → Eigenschaften → „Als Bauteil speichern“. Geometrie wird auf einen lokalen Ursprung verschoben. Die interne Bibliothek erhält den Eintrag. Wenn ein beschreibbarer externer Ordner gewählt ist, werden JSON und referenzierte Ressourcen dorthin geschrieben.

Ohne externen Ordner bleibt das Objekt lokal verfügbar und kann über den Bibliotheksexport als `.bdlib` übertragen werden. Bei einem nicht beschreibbaren Ordner zeigt die App den eingeschränkten Zugriff an.
