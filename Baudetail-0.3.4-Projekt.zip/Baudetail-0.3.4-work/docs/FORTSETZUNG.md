Aktuell: 0.2.0, Build erfolgreich, 37 Kerntests bestanden. Offene Geräteabnahme und Grenzen siehe UPDATE-0.2.0.md. Keine alten APKs als aktuelles Update verwenden.
