# Bestandsprüfung – Fortsetzung des vorhandenen Projekts

Geprüft wird der bereits erstellte Quellstand; das Projekt wurde nicht neu angelegt.

## Module und Zuständigkeiten

| Modul | Vorhandene Implementierung | Verifikation / offene Arbeit |
|---|---|---|
| `app` | Activity, Intent-Empfang, Manifest, FileProvider, Adaptive Icon, mitgelieferte Paketdateien | Debug-/Release-Build erfolgreich; Gerätetest fehlt noch |
| `geometry` | Millimeterkoordinaten, Flächen, Längen, Schnittpunkte, Transformation, Kalibrierungsgrundlagen | Kotlin-Kompilierung und Geometrietests erfolgreich |
| `drawing-core` | Datenmodell, Primitive/Scene, Fang, Bearbeiten, Historie, Maßreferenzen, Schichtaufbau, Mengen, Gefälle, Verlegemuster | Kernprüfungen einschließlich ergänzter Winkel-/Kettenmaße und dynamischer Texte erfolgreich |
| `file-format` | ZIP-Pakete, versioniertes Manifest, JSON, SHA-256 für Ressourcen, Pfad- und Größenprüfung | Roundtrip- und beschädigte-Pakete-Tests vorhanden und erfolgreich |
| `libraries` | Freie Kategorien, beliebige Attribute, Filter, Importkonflikte, Favoriten, Deaktivieren, Verlauf | 10.000 Datensätze und Konfliktbehandlung getestet; SAF-Gerätetest fehlt |
| `projects` | Atomare Speicherung, persistente Historie, Ressourcenimport und Projekttransfer | Wiederöffnen und zweiter Speicherort getestet |
| `export` | Gemeinsame Vektorszene für PDF/PNG/SVG; Android-Canvas; eingebettete Grafikressourcen | `PdfDocument.use`-Fehler behoben; vollständige Export-Quellen gegen API 35 kompiliert |
| `ui` | Compose-Navigation, Projektakten, Editor, Toolbox, Eigenschaften, Layer, Bibliothek, Setup, SAF-Auswahl und Teilen | Modularer Gradle-Build für Debug/Release erfolgreich; Gerätetest noch offen |

Die vorgeschlagenen Fachmodule `materials`, `components`, `symbols`, `vegetation` und `text-templates` sind bisher keine separaten Gradle-Module. Ihre Datensätze liegen im allgemeinen Bibliotheksmodell. Das ist eine bewusst beibehaltene Modulgrenze und kein fest codierter Produktkatalog.

## Bereits implementierte Arbeitsabläufe

- Projekt anlegen, Projektstammdaten ändern, Zeichnungen öffnen und neue Ansichten anlegen.
- Maßstab, Papierabmessungen, Papierausschnitt, Ursprung, Raster und Bezugshöhe bearbeiten.
- Linien, Polylinien, Rechtecke, Kreise, Bögen, Polygone, freie Konturen und Flächen zeichnen.
- Auswählen, Mehrfachauswahl, gruppieren, bewegen, drehen, spiegeln, skalieren, duplizieren, löschen, sperren und Reihenfolge ändern.
- Verknüpfte Schnittmarke und Rücksprung, Flächenmengen, Heckenanzahl, parametrische Bäume, Gefälle und Höhenkoten.
- Referenzierte Bemaßung; Ketten- und Winkelmaß wurden ergänzt und im Kern geprüft.
- Schichtaufbau mit geometrisch und textlich gekoppelter Dicke; einfache Verlegemuster.
- Externe `.bdlib`, einzelne JSON-Einträge im SAF-Ordner, freie Attributfilter und Bibliotheksobjekte mit SVG-Ansichten.
- Persistente URI-Freigabe, System-Dateiauswahl, Projekt-/Zeichnungs-/Bibliotheksimport und Export, Sharesheet.
- Automatisches Speichern nach Befehlen, fünf persistente Undo-Schritte und zehn Wiederherstellungsstände pro Zeichnung.
- Beispielgarten und Schnitt A–A, 22 mitgelieferte Bibliothekseinträge.

## Begonnen, eingeschränkt oder noch offen

| Bereich | Tatsächlicher Stand |
|---|---|
| Installierbare APK | Debug-APK erstellt und Signatur geprüft; Release-APK erstellt, zum eigenen Signieren. Der frühere Maven-/JDK-Abbruch wurde behoben. |
| Android-Gerät / Emulator | Kein Ausführungs- und Gestentest; kein S-Pen-Nachweis. |
| PDF-Maßhaltigkeit | Rechenweg und Szenenskalierung getestet. Android-PDF-Rastertest und zugehörige Test-APK kompiliert, aber noch nicht auf Android ausgeführt. |
| Bibliotheksvisualisierung | Suchliste vorhanden; Produktvorschauen, grafischer Browser und vollständige Ansichtsauswahl noch nicht ausgebaut. |
| Hersteller / 10.000 Einträge | Datenmodell offen, 10.000-Einträge-Kerntest erfolgreich; keine reale Smartphone-Leistungsmessung. |
| Varianten | Vollständige Zeichnungskopien mit `variantOf`; noch kein speichersparendes Delta-Modell. |
| Revisionen | Unveränderliche Zeichnungssnapshots und Wiederherstellung als Kopien; keine vollständige historische Projektakte. |
| Gebäudeöffnungen | Frei gezeichnete Konturen möglich; kein eigener parametrischer Tür-/Fenstereditor. |
| Pflanzplanung | Bäume, Hecken, Flächen und Attribute vorhanden; noch keine automatische Verteilung einzelner Pflanzen auf Flächen. |
| Bemaßung / Fang | Punktreferenzen vorhanden; noch keine CAD-Zwangsbedingungen und keine allgemeine Kreis-/Bogenschnittpunktanalyse. |
| Schraffuren / freie Verbände | Einfache rechteckige Verlegemuster vorhanden; noch keine frei programmierbaren Schraffurrezepte oder gemischten Plattenverbände. |
| Plankopf | Textvorlagen und Variablen; Logo und grafischer Plankopfeditor fehlen. |
| Texte | Texteingabe über Dialog; kein Textcursor direkt im Canvas. |
| PDF-Hintergrund | Gewählte PDF-Seite als Rasterreferenz; keine vektorielle PDF-Übernahme. |
| SVG | Deklarativer, lokaler Teilumfang. Skripte und externe Inhalte werden abgelehnt. |
| Dateiversionen | v1 und akzeptierter Legacy-v0-Aufbau. Keine bekannten weiteren historischen Formate. |
| DXF / automatische Schnittableitung | Noch nicht implementiert. |
| Accessibility | Compose-Beschriftungen und Theme-Modi vorhanden; TalkBack-/Schriftgrößenprüfung auf Gerät fehlt. |
| Dokumentation / Schemata | Build-Anleitung, Architektur, drei Paketformate, Bibliotheksanleitung und Eintragsschema sind vorhanden. Ein vollständiges JSON-Schema für das gesamte Zeichnungsmodell steht noch aus. |

## Konsistenzprüfung

- Acht in `settings.gradle.kts` aufgeführte Module existieren mit eigener Build-Datei.
- Kotlin und Compose-Compiler sind im Version Catalog gemeinsam auf 2.1.10 gesetzt.
- AGP 8.9.2, Gradle 8.11.1, Java 17, compile/target SDK 35 und min SDK 26 sind vorgesehen.
- Die acht NavHost-Routen `home`, `projects`, `drawing`, `library`, `project-settings`, `settings`, `import`, `export` und der separate Setup-Ablauf sind vorhanden. Setup ist absichtlich kein eigener NavHost-Eintrag.
- Manifest und Sharesheet verwenden konsistent `${applicationId}.files` bzw. den Paketnamen.
- Keine Internet-, Kamera- oder pauschale Speicherberechtigung ist im App-Manifest eingetragen.
- APK-Erstellung, Manifest-Merge und R8 haben im vollständigen Gradle-Build bestanden. Die Navigation auf einem echten Android-Gerät ist noch nicht geprüft.

## In dieser Fortsetzung gewählter Abschnitt

Kompilierungsfehler im Export beheben, Exportressourcen streng prüfen, ursprüngliche importierte PDFs beim Projekttransfer erhalten und Android-/Compose-Quellen mit lokal verfügbaren Abhängigkeiten kompilieren. Diese Arbeiten sind abgeschlossen. Der vorhandene Millimeterkern und die Paketformate bleiben erhalten. Der vollständige Gradle-Build ist inzwischen erfolgreich; als nächstes steht der Gerätetest an, siehe `FORTSETZUNG.md`.

## Ergebnis dieser Fortsetzung

- Bestehende Module und Architektur beibehalten.
- PDF-Ressourcenfreigabe korrigiert (`PdfDocument` implementiert kein `Closeable`).
- Namenskonflikt zwischen `theme`-Setter und öffentlicher Methode behoben.
- Nullable-SAF-Ordnerpfad beim Export eigener Symbole korrigiert.
- Original-PDFs werden zusammen mit ihrer Rastervorschau übertragen.
- Einzelzeichnungen nehmen Bibliotheksdefinitionen in `library-entries.json` mit.
- Eigene Symbole schreiben referenzierte Grafikdateien in den externen Ordner.
- Beschädigte Projektdateien bleiben als Fehlereintrag in der Projektübersicht sichtbar.
- Negative Höhenkoten können in den Eigenschaften bearbeitet werden.
- Legenden berücksichtigen nun auch Vegetation und Materialien aus Schichtaufbauten.
- Die nachfolgende gezielte Gradle-Fortsetzung hat drei modulübergreifende Smart-Cast-Fehler und eine fehlende öffentliche JSON-Abhängigkeit aufgedeckt; diese sind behoben. Debug-, Release- und Android-Test-APK wurden erfolgreich gebaut. Aktuelle Prüfergebnisse stehen im Prüfbericht.
