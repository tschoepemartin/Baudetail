Der Wiederaufnahmestand wurde erfolgreich gebaut. Maßgeblich: UPDATE-0.2.0.md und ../reports/0.2.0/Pruefbericht.md. Frühere Berichte unter 0.1.1 beziehen sich auf den Basisstand.
