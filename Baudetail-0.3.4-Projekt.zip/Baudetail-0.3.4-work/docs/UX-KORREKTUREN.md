# Zeichenbedienung – Lieferung 0.1.1

## Änderungen

- Rechteck, Kreis, Gebäudegrundform, rechteckige Pflanzfläche, Linie und 90°-Bogen: drücken, ziehen, loslassen. Vorschau und Maße werden während der Geste gezeichnet. Polygon-/Polylinien-Werkzeuge behalten die Mehrpunkteingabe.
- Zweiter Finger verwirft die laufende Zeichen-/Objektgeste und übernimmt Zoom/Pan. Loslassen erzeugt danach kein Objekt.
- Maßeingabe für neue Formen über „Maße eingeben“. Position, Breite/Tiefe, Linienlänge/Winkel oder Radius. Deutsche Dezimalzahlen sind zulässig.
- Gewählte Rechtecke, vierseitige Gebäudegrundformen, Kreise und Linien: „Eigenschaften → Geometrie: Maße und Position“. Änderungen bearbeiten reale Millimeterkoordinaten und erhalten Objekt-IDs/Eckpunktreihenfolge für gekoppelte Maße.
- Auswahl: Rahmen, unterer rechter Skalierungsgriff, oberer Drehgriff. Griff-Treffbereiche 48 dp; sichtbare Griffe deutlich kleiner. Bei Mehrfachauswahl gemeinsames Verschieben, numerische Transformationen weiterhin verfügbar.
- Raster und Fang getrennt: Statusleiste öffnet jeweils Einstellungen mit Ein/Aus, Schrittvorgaben und freier Millimetereingabe. Raster 100 mm und Fang 10 mm sind gleichzeitig möglich.
- Fangmodi einzeln wählbar: Raster, Endpunkt, Kantenmittelpunkt, Schnittpunkt, Kante/Kreisrand, Kreiszentrum. Fangmarkierung benennt den verwendeten Modus.
- Ortho direkt in der Statusleiste; Winkelfang frei zwischen 0° (aus) und 180° einstellbar.
- Canvas wird vor dem Weltkoordinaten-Transform auf seine Ansichtsgrenzen beschnitten. Papier und Geometrien dürfen dadurch nicht über Werkzeug-/Statusleisten zeichnen.
- Der globale Ladebalken sitzt in einer Box ohne weitergereichte Mindesthöhe. Seine Höhe ist auf 3 dp begrenzt.
- Kompaktere Kopfleiste: Speichern und Export im Zeichnungsmenü; Undo/Redo und Eigenschaften direkt erreichbar.
- Bei verlorenem SAF-Ordnerzugriff erscheint ein Hinweis mit erneuter Systemordnerauswahl. Keine globale Speicherberechtigung hinzugefügt.

## Formate / Beispiele

`.bdetail`, `.bproject` und `.bdlib` bleiben Formatversion 1. Editorpräferenzen sind eine additive, unabhängig versionierte Erweiterung `extensions.drawingInput` mit `schemaVersion: 1`. Alte Dateien ohne diese Erweiterung erhalten sichere Standardwerte. Geometrien bleiben in Millimetern. Die mitgelieferten Beispieldaten wurden bislang nicht geändert.

## Ergänzungen im Abschluss

Live-Breite und Live-Höhe stehen getrennt an den Formkanten. Schrift und sichtbare Griffe berücksichtigen die Gerätedichte; Live-Schrift berücksichtigt die Schriftvergrößerung. Rechteckige Formen können bei aktivem Ortho aufgezogen werden. Beim Verschieben wird Ortho/Winkelfang relativ zum Objektanker angewendet. Bogendrehung aktualisiert den tatsächlich dargestellten Startwinkel; Bogenauswahl berücksichtigt Radius und Winkelbereich.

## Overlay-Ursache

Die native Canvas-Zeichnung war nicht konsequent auf ihre Ansichtsgrenzen beschnitten. Transformierte Papierflächen konnten deshalb in benachbarte Bedienelemente hineinzeichnen. Zusätzlich konnte die Root-Surface ihre Mindesthöhe an den Ladebalken weiterreichen. Viewport-Clipping und eine begrenzte Ladebalken-Box korrigieren diese beiden Codeprobleme. Eine abschließende Sichtprüfung auf dem Nutzergerät steht aus.

## Beispiel-Crash und Tests

Keine belastbar nachgewiesene Ursache des ursprünglich gemeldeten Geräteabsturzes. Die Beispielgeometrien sind renderbar; es wurden keine Beispieldaten entfernt oder vereinfacht. Debug-/Release-Build und Kernprüfungen erfolgreich. Vollständige Android-Navigation noch nicht bestätigt. Details und Grenzen im aktuellen Bericht `../reports/0.1.1/Pruefbericht.md`.

## Bekannte Grenzen dieser Änderungen

- Numerische Formeingabe erfolgt über „Maße eingeben“ bzw. nachträglich über die Eigenschaften, nicht über eine eingeblendete Tastatur während eines gehaltenen Fingers.
- Der Skalierungsgriff skaliert proportional; unabhängige Breite/Höhe sind numerisch änderbar.
- Bogenerstellung erzeugt einen 90°-Bogen. Keine Drei-Punkt-Bogenbedienung.
- Schnittpunktfang berechnet gerade Segmente; Kreis-/Bogenschnittpunkte und tangentialer Fang sind noch nicht implementiert. Bei Kreisen sind Zentrum und Rand fangbar.
- Kantenmittelpunkte sind über „Mitte“ aktivierbar; ein separater Flächenschwerpunkt-Fang ist nicht enthalten.
- Raster wird bei weitem Herauszoomen ausgedünnt dargestellt. Der eingestellte reale Fangschritt bleibt unabhängig erhalten.
- S Pen, Android-16-Geräteverhalten und vollständiger SAF-Neustartablauf sind noch nicht auf dem Zielgerät abgenommen.
