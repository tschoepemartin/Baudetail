# Baudetail 0.3.0

Update auf Basis des vorhandenen 0.2.0-Projekts. [Änderungen, Bedienung und Grenzen](docs/UPDATE-0.3.0.md). Aktueller Build-/Testnachweis: `reports/0.3.0/Pruefbericht.md`. Historische Berichte gelten nur für ihre jeweilige Version.

App-ID `de.baudetail`, versionCode 4, bestehender Debug-Schlüssel. APK über 0.2.0 installieren; nicht deinstallieren.


Native Android-Anwendung für maßhaltige 2D-Außenanlagen- und Detailplanung. Kotlin, Jetpack Compose, lokale Projektakten, Millimetergeometrie und externe versionierte Bibliothekspakete.

**Historischer Stand 0.1.1:** Debug- und Release-Build erfolgreich; Debug-Signatur geprüft; 48 Kerntests bestanden. Touch-/Raster-/Layoutänderungen enthalten. Der ursprüngliche Geräte-Crash und der vollständige Android-Ablauf sind noch nicht abschließend bestätigt. Aktueller [Prüfbericht](reports/0.1.1/Pruefbericht.md) und [Änderungen](docs/UX-KORREKTUREN.md).

- **Direkt installieren:** `apks/Baudetail-debug.apk`
- **Release zum selbst Signieren:** `apks/Baudetail-release-unsigned.apk`
- **Schritt für Schritt lokal bauen:** [APK-Bauanleitung](docs/APK-LOKAL-BAUEN.md)
- **Downloads beim ersten Build:** [Abhängigkeiten](docs/ABHAENGIGKEITEN.md)

Der frühere Maven-Abbruch war auf die Proxy-/JDK-Konfiguration der Ausführungsumgebung zurückzuführen. Diese Einstellungen wurden außerhalb des Projekts korrigiert; im Lieferpaket sind keine containerspezifischen Proxy-, SDK- oder JDK-Pfade eingetragen.

## In Android Studio öffnen

1. Das ZIP entpacken und den Ordner `Baudetail` über **Open** öffnen.
2. Android Studio Meerkat 2024.3.1 oder eine neuere stabile Version mit Unterstützung für AGP 8.9 verwenden.
3. Gradle JDK auf **JDK 17** stellen. Android SDK Platform 35 und Build Tools 35.0.0 installieren.
4. Gradle-Synchronisierung ausführen. Beim ersten Build werden die festgelegten Abhängigkeiten aus Google Maven und Maven Central benötigt.
5. Ein Gerät ab Android 8.0 / API 26 auswählen. Modul `app` starten.

Es müssen keine Kotlin-Dateien einzeln kopiert werden. `local.properties` wird von Android Studio mit dem lokalen SDK-Pfad erstellt und gehört nicht ins Lieferpaket.

Die Kombination AGP 8.9, Gradle 8.11.1, SDK 35 und JDK 17 folgt der [offiziellen AGP-Kompatibilitätstabelle](https://developer.android.com/build/releases/agp-8-9-0-release-notes). Kotlin und Compose-Compiler sind im Version Catalog gemeinsam auf 2.1.10 festgelegt, entsprechend der [Compose-Plugin-Konfiguration](https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler).

## Build und Tests

Windows PowerShell:

```powershell
.\gradlew.bat :geometry:test :drawing-core:test :file-format:test :libraries:test :projects:test :app:assembleDebug
.\gradlew.bat :app:assembleRelease
```

Linux / macOS:

```bash
./gradlew :geometry:test :drawing-core:test :file-format:test :libraries:test :projects:test :app:assembleDebug
./gradlew :app:assembleRelease
```

Erwartete Ausgaben nach einem **erfolgreichen** Build:

- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release, zunächst unsigniert: `app/build/outputs/apk/release/app-release-unsigned.apk`
- AAB: `./gradlew :app:bundleRelease`

Für eine verteilbare Release-Version den eigenen Signaturschlüssel über Android Studio „Generate Signed Bundle / APK“ konfigurieren. Ein öffentlicher Entwicklungsschlüssel für Debug ist unter `debug-signing/` enthalten; kein Release-Schlüssel wird mitgeliefert.

Android-PDF-Maßtest auf angeschlossenem Gerät/Emulator:

```bash
./gradlew :export:connectedDebugAndroidTest
```

Der offizielle Gradle Wrapper samt JAR und Prüfsumme für Gradle 8.11.1 ist enthalten. Die aktuelle Dokumentation unter `reports/0.1.1/` enthält den erfolgreichen Gradle-Gesamtbuild, die Kerntests, APK-Prüfungen und die noch offenen Geräteprüfungen.

## Erster Start und Bedienung

- Im Setup optional das Beispielprojekt installieren. Es wird keine Demo-Bibliothek automatisch angelegt. Externe .bdlib importieren.
- Einen externen Bibliotheksordner optional auswählen; er kann später in den Einstellungen geändert werden.
- Projektakte öffnen, Gartenplan oder Schnitt wählen.
- Rechteck, Kreis, Linie, Gebäudegrundform und rechteckige Fläche durch Drücken und Ziehen aufziehen. Andere Werkzeuge verwenden Punkteingabe. Polygone, Hecken und Polylinien mit **Abschließen** beenden.
- Mit zwei Fingern verschieben und zoomen. „Finger navigiert“ reserviert Finger für Navigation und Stift für Zeichnen.
- Bereits ausgewählte Objekte ziehen. Lange tippen oder „Mehrfachauswahl“ verwenden, um eine Auswahl zu erweitern.
- Über „Eigenschaften“ Positionen, Eckpunkte, Maße und Parameter numerisch bearbeiten. Dezimalkomma wird akzeptiert.
- Schnittmarken öffnen ihre verknüpfte Zeichnung; dort führt „Zum Ausgangsplan“ zurück.
- „1:x“ öffnet Maßstab, Papiermaße, Raster, Bezugshöhe und Plankopf. „Einpassen“ verändert ausschließlich die Ansicht.
- Hintergründe importieren; danach über die Eigenschaften zwei bekannte Punkte kalibrieren.
- Export bietet PDF, PNG, SVG, `.bdetail`, `.bproject` und `.bdlib`. Für Gerätetransfer „Vollständig paketieren“ aktivieren.
- PDF mit **100 % / tatsächlicher Größe** drucken und das Kontrollmaß prüfen.

## Projektstruktur

Siehe [Architektur](docs/ARCHITECTURE.md), [Bestandsprüfung](docs/Bestandspruefung.md) und [Dateiinventar](reports/Dateiinventar.txt).

## Eigene Bibliotheken und Dateiformate

- [Offene Dateiformate](docs/DATEIFORMATE.md)
- [Bibliotheken, Symbole und Planköpfe erstellen](docs/BIBLIOTHEKEN.md)
- [Bibliothekseintrag: JSON-Schema](schemas/library-entry.schema.json)
- `examples/sample-library.bdlib`, `examples/sample-project.bproject`, `examples/Schnitt-A-A.bdetail`

## Bekannte Grenzen

[Bestandsprüfung](docs/Bestandspruefung.md) und [Prüfbericht](reports/Pruefbericht.md) sind verbindlich für den erreichten Stand. Insbesondere fehlen noch Gerätetests, grafische Planköpfe mit Logo, speichersparende Varianten und weitere in der Gesamtspezifikation beschriebene Komfortfunktionen. PDF-Hintergründe werden pro gewählter Seite als Rasterreferenz eingebunden; das Original bleibt für den vollständigen Projekttransfer erhalten. Automatische Schnittgeometrie und DXF sind noch nicht umgesetzt.


