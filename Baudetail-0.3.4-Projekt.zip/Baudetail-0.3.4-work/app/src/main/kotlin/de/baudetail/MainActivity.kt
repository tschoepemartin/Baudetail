package de.baudetail
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import de.baudetail.ui.*
class MainActivity:ComponentActivity(){
 private val model:BaudetailViewModel by viewModels()
 override fun onCreate(state:Bundle?){super.onCreate(state);enableEdgeToEdge();setContent{BaudetailRoot(model)};if(state==null)receive(intent)}
 override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);receive(intent)}
 @Suppress("DEPRECATION") private fun receive(intent:Intent?){val uri=if(intent?.action==Intent.ACTION_SEND)intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)else if(intent?.action==Intent.ACTION_VIEW)intent.data else null;uri?.let(model::stagePackage)}
}
