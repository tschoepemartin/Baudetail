package de.baudetail

import android.app.Application
import de.baudetail.ui.diagnostics.Diagnostics

class BaudetailApplication:Application(){
 override fun onCreate(){super.onCreate();Diagnostics.install(this)}
}
