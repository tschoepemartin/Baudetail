package de.baudetail

import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import de.baudetail.core.*
import de.baudetail.format.Packages
import de.baudetail.geometry.*
import de.baudetail.ui.drawing.DrawingCanvas
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],qualifiers="w960dp-h600dp-land")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class CanvasTest {
 @get:Rule val ui=createAndroidComposeRule<MainActivity>()
 private val project get()=File("src/main/assets/sample-project.bproject").inputStream().use(Packages::read).project()
 private fun show(d:Drawing,p:Project=project,onCreate:(Entity)->Unit={}){
  ui.runOnUiThread{ui.activity.setContent{MaterialTheme{DrawingCanvas(d,p,{File(it)},"rect",emptySet(),emptyList(),true,false,0,Modifier.fillMaxSize(),{_,_->},{},{},{_,_->},onCreate,{})}}}
  ui.waitForIdle()
 }
 @Test fun gardenFirstFrame(){show(project.drawings.single{it.name=="Gartenplan"});ui.onNodeWithTag("drawing-canvas").assertIsDisplayed()}
 @Test fun sectionFirstFrame(){show(project.drawings.single{it.name=="Schnitt A–A"});ui.onNodeWithTag("drawing-canvas").assertIsDisplayed()}
 @Test fun emptyAndDrag(){val added=mutableListOf<Entity>();show(Drawing(),onCreate={added.add(it)});val canvas=ui.onNodeWithTag("drawing-canvas");canvas.performTouchInput{swipe(Offset(width*.2f,height*.2f),Offset(width*.65f,height*.65f),500)};ui.runOnIdle{assertEquals(1,added.size);assertTrue(area(added.single().points)>0)}}
}
