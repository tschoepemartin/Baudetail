package de.baudetail

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.platform.app.InstrumentationRegistry
import de.baudetail.core.*
import de.baudetail.export.CanvasRenderer
import de.baudetail.geometry.*
import de.baudetail.format.Packages
import de.baudetail.ui.BaudetailViewModel
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

@org.junit.runner.RunWith(org.robolectric.RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk=[35],qualifiers="w960dp-h600dp-land")
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
class NavigationTest {
 @get:Rule val ui=createAndroidComposeRule<MainActivity>()
 private fun model()=ViewModelProvider(ui.activity)[BaudetailViewModel::class.java]
 @Test fun stairMenuOpensAndSaves031() {
  val vm=model()
  ui.waitUntil(15000){!vm.loading}
  ui.runOnIdle{vm.finishSetup(true)}
  ui.waitUntil(15000){!vm.loading&&vm.records.isNotEmpty()}
  ui.onNodeWithText(vm.records.first().name).performScrollTo().performClick()
  ui.waitUntil(15000){vm.project!=null&&!vm.loading}
  ui.onNodeWithText("Gartenplan").performScrollTo().performClick()
  ui.runOnIdle {
   val step=LibraryEntry(id="test-step-031",type="component",category="Stufen",name="Teststufe 15/40/100")
   vm.catalog.import(LibraryPackage(entries=listOf(step)),de.baudetail.libraries.ConflictPolicy.REPLACE)
   vm.saveCatalog()
  }
  ui.onNodeWithText("Bauwerke").performScrollTo().performClick()
  ui.onNodeWithText("Treppe",useUnmergedTree=true).performClick()
  ui.onNodeWithText("Bauwerke · Treppe").assertIsDisplayed()
  ui.onNodeWithText("Übernehmen").performClick()
  ui.runOnIdle {assertTrue(vm.drawing!!.entities.any{isStair(it)})}
 }
 @Test fun bundledScenesPaintOnAndroid() {
  val context=InstrumentationRegistry.getInstrumentation().targetContext
  val pack=context.assets.open("sample-project.bproject").use(Packages::read)
  val project=pack.project()
  val bitmap=Bitmap.createBitmap(1200,800,Bitmap.Config.ARGB_8888)
  val renderer=CanvasRenderer{error("Unexpected asset $it")}
  for(d in project.drawings+Drawing(name="Leer")){
   val canvas=Canvas(bitmap);canvas.drawColor(android.graphics.Color.WHITE);canvas.scale(.04f,.04f)
   renderer.draw(canvas,Scene.drawing(d,project))
   if(d.entities.isNotEmpty()){val pixels=IntArray(bitmap.width*bitmap.height);bitmap.getPixels(pixels,0,bitmap.width,0,0,bitmap.width,bitmap.height);assertTrue(d.name,pixels.any{it!=android.graphics.Color.WHITE})}
  }
  bitmap.recycle()
 }
 @Test fun exampleNavigationAndEmptyDrawing() {
  val vm=model()
  ui.waitUntil(15000){check(vm.error==null){"App-Fehler: ${vm.error}"};!vm.loading}
  ui.runOnIdle{vm.finishSetup(true)}
  ui.waitUntil(15000){check(vm.error==null){"App-Fehler: ${vm.error}"};!vm.loading&&vm.records.isNotEmpty()}
  val name=vm.records.first().name
  ui.onNodeWithText(name).performScrollTo().performClick()
  ui.waitUntil(15000){check(vm.error==null){"App-Fehler: ${vm.error}"};vm.project!=null&&!vm.loading}
  ui.onNodeWithText("Gartenplan").performScrollTo().performClick()
  ui.onNodeWithText("Gartenplan").assertIsDisplayed()
  ui.onNodeWithContentDescription("Projektakte").performClick()
  ui.onNodeWithText("Schnitt A–A").performScrollTo().performClick()
  ui.onNodeWithText("Schnitt A–A").assertIsDisplayed()
  ui.runOnIdle{assertEquals("Schnitt A–A",vm.drawing?.name);vm.addDrawing("Touch-Test","Freies Blatt")}
  ui.onNodeWithText("Touch-Test").assertIsDisplayed()
  ui.runOnIdle{vm.tool="rect";vm.edit(vm.drawing!!.copy(gridMm=100.0).withInput(DrawingInput(snapMm=10.0)))}
  val canvas=ui.onNodeWithTag("drawing-canvas")
  canvas.performTouchInput{down(Offset(width*.25f,height*.3f));moveTo(Offset(width*.65f,height*.65f),500)}
  ui.runOnIdle{assertTrue("Preview must not commit",vm.drawing!!.entities.isEmpty())}
  canvas.performTouchInput{up()}
  ui.runOnIdle{val e=vm.drawing!!.entities.single();assertEquals("rect",e.kind);assertTrue(area(e.points)>0);assertTrue(e.points.all{kotlin.math.abs(it.x/10-kotlin.math.round(it.x/10))<1e-7})}
  ui.runOnIdle{vm.tool="select"}
  canvas.performTouchInput{swipe(Offset(width*.65f,height*.65f),Offset(width*.75f,height*.75f),500)}
  ui.runOnIdle{val e=vm.drawing!!.entities.single();assertTrue(area(e.points)>0);vm.update(resizeRectangle(e,4000.0,3000.0));vm.tool="circle"}
  canvas.performTouchInput{swipe(Offset(width*.3f,height*.4f),Offset(width*.45f,height*.55f),500)}
  ui.runOnIdle{assertEquals("circle",vm.drawing!!.entities.last().kind);vm.tool="line"}
  canvas.performTouchInput{swipe(Offset(width*.2f,height*.2f),Offset(width*.7f,height*.2f),500)}
  ui.runOnIdle{assertEquals("line",vm.drawing!!.entities.last().kind)}
  val count=vm.drawing!!.entities.size
  canvas.performTouchInput{pinch(Offset(width*.3f,height*.4f),Offset(width*.7f,height*.4f),Offset(width*.2f,height*.4f),Offset(width*.8f,height*.4f),500)}
  ui.runOnIdle{assertEquals("Pinch must not draw",count,vm.drawing!!.entities.size);vm.persist()}
  ui.waitUntil(15000){check(vm.error==null){"App-Fehler: ${vm.error}"};!vm.saving}
  val projectId=vm.project!!.id;val drawingId=vm.drawingId
  ui.runOnIdle{vm.open(projectId)}
  ui.waitUntil(15000){check(vm.error==null){"App-Fehler: ${vm.error}"};!vm.loading}
  ui.runOnIdle{vm.openDrawing(drawingId);assertEquals(count,vm.drawing!!.entities.size);assertEquals(100.0,vm.drawing!!.gridMm,0.0);assertEquals(10.0,vm.drawing!!.input().snapMm,0.0)}
 }
}
