# Kotlin serialization uses generated serializers; AndroidSVG uses runtime classes.
-keep class com.caverock.androidsvg.** { *; }
-dontwarn org.xmlpull.v1.**
