package de.baudetail.format
import de.baudetail.core.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
class RecoveryTest {
 @Test fun brokenObjectDoesNotDestroyOtherGeometry(){
  val raw=BaudetailJson.parseToJsonElement("""{"entities":[{"kind":"text","text":null,"points":null,"style":{"textPaperMm":-3}},{"kind":"line","points":[{"x":0,"y":0},{"x":100,"y":0}]},{"kind":"text","points":"broken"}]}""")
  val result=recoverDocument(raw);val d=BaudetailJson.decodeFromJsonElement<Drawing>(result.value)
  assertEquals(2,d.entities.size);assertTrue(result.repaired>=2);validateDrawing(d)
 }
}
