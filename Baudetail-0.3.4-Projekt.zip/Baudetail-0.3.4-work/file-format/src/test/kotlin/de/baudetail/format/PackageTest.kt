package de.baudetail.format
import de.baudetail.core.*
import org.junit.Test
import org.junit.Assert.*
import java.io.*
import java.util.zip.*
class PackageTest {
 @Test fun fullTransfer(){val p=Project(name="Transfer",resources=listOf("assets/a.svg"));val bytes="<svg/>".toByteArray();val out=ByteArrayOutputStream();Packages.project(out,p,mapOf("assets/a.svg" to bytes));val pack=Packages.read(out.toByteArray().inputStream());assertEquals(p,pack.project());assertArrayEquals(bytes,pack.files["assets/a.svg"])}
 @Test fun referenceOnlyTransfer(){val out=ByteArrayOutputStream();Packages.project(out,Project(),emptyMap(),false);assertFalse(Packages.read(out.toByteArray().inputStream()).manifest.embedded)}
 @Test(expected=IllegalArgumentException::class) fun rejectsTraversal(){val out=ByteArrayOutputStream();ZipOutputStream(out).use{it.putNextEntry(ZipEntry("../escape"));it.write(1);it.closeEntry()};Packages.read(out.toByteArray().inputStream())}
 @Test(expected=IllegalArgumentException::class) fun corruptResource(){val out=ByteArrayOutputStream();ZipOutputStream(out).use{it.putNextEntry(ZipEntry("manifest.json"));it.write("""{"formatVersion":1,"kind":"project","name":"bad","resources":{"assets/a":"bad"}}""".toByteArray());it.closeEntry();it.putNextEntry(ZipEntry("assets/a"));it.write(0);it.closeEntry()};Packages.read(out.toByteArray().inputStream())}
 @Test(expected=IllegalArgumentException::class) fun newerFormat(){val out=ByteArrayOutputStream();ZipOutputStream(out).use{it.putNextEntry(ZipEntry("manifest.json"));it.write("""{"formatVersion":99,"kind":"project","name":"new"}""".toByteArray());it.closeEntry()};Packages.read(out.toByteArray().inputStream())}
 @Test fun standaloneDrawingPreservesLibrary(){val out=ByteArrayOutputStream();val entry=LibraryEntry(id="x",type="material",category="Eigene",name="Material X");Packages.drawing(out,Drawing(),emptyMap(),listOf(entry));val pack=Packages.read(out.toByteArray().inputStream());assertEquals(listOf(entry),pack.drawingEntries());assertTrue(Packages.resources(pack).isEmpty())}
 @Test fun legacyProjectMigrates(){val out=ByteArrayOutputStream();Packages.project(out,Project(formatVersion=0,drawings=listOf(Drawing(formatVersion=0))),emptyMap());val p=Packages.read(out.toByteArray().inputStream()).project();assertEquals(1,p.formatVersion);assertEquals(1,p.drawings.single().formatVersion)}
}
