package de.baudetail.format

import de.baudetail.core.*
import de.baudetail.geometry.Vec
import kotlinx.serialization.json.*

/** Recovery is limited to individual entities; malformed package metadata still fails explicitly. */
data class RecoveredDocument(val value:JsonElement,val repaired:Int)
fun recoverDocument(input:JsonElement):RecoveredDocument {
 var repaired=0
 fun entities(items:JsonArray,depth:Int=0):JsonArray {
  if(depth>32){repaired+=items.size;return JsonArray(emptyList())}
  val ids=mutableSetOf<String>()
  return JsonArray(items.mapNotNull { raw ->
   try {
    val obj=raw as? JsonObject ?: error("Objekt erwartet")
    val clean=obj.toMutableMap()
    (clean["children"] as? JsonArray)?.let {clean["children"]=entities(it,depth+1)}
    val e=BaudetailJson.decodeFromJsonElement<Entity>(JsonObject(clean))
    require(e.kind in setOf("line","polyline","rect","circle","arc","polygon","area","building","arrow","leader","guide","text","elevation","slope","dimension","section","tree","hedge","stack","legend","component","image","assembly")){"Unbekannter Objekttyp"}
    val safeStyle=e.style.copy(
     opacity=e.style.opacity.takeIf{it.isFinite()}?.coerceIn(0.0,1.0)?:1.0,
     widthMm=e.style.widthMm.takeIf{it.isFinite()&&it>0}?:0.25,
     textPaperMm=e.style.textPaperMm.takeIf{it.isFinite()&&it>0&&it<=1000}?:3.0)
    var fixed=e.copy(id=e.id.takeIf{it.isNotBlank()&&it !in ids}?:uid(),
     points=if(e.kind=="text")e.points.filter{it.finite()}.ifEmpty{listOf(Vec())}else e.points,
     rotation=e.rotation.takeIf{it.isFinite()}?:0.0,style=safeStyle,
     layerId=e.layerId.ifBlank{"planning"})
    if(isStair(fixed)){
     if(stairGoing(fixed)<=0||stairGoing(fixed)>stairDepth(fixed))fixed=fixed.withStr("lengthMode","step").withNum("goingMm",stairGoing(fixed).coerceIn(1.0,stairDepth(fixed).coerceAtLeast(1.0)))
     if(stairRise(fixed)<=0)fixed=fixed.withStr("heightMode","step").withNum("riseMm",150.0)
    }
    validateDrawing(Drawing(entities=listOf(fixed)))
    ids.add(fixed.id)
    if(fixed!=e || obj.any{it.value==JsonNull && it.key in setOf("text","style","points","rotation","id","layerId")})repaired++
    BaudetailJson.encodeToJsonElement(fixed)
   } catch(e:Exception){repaired++;null}
  })
 }
 fun walk(node:JsonElement):JsonElement=when(node){
  is JsonArray->JsonArray(node.map(::walk))
  is JsonObject->JsonObject(node.mapValues{(key,value)->if(key=="entities"&&value is JsonArray)entities(value)else walk(value)})
  else->node
 }
 val result=walk(input)
 return RecoveredDocument(result,repaired)
}
