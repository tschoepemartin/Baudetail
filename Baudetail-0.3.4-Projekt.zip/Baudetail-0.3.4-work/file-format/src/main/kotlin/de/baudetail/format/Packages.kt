package de.baudetail.format

import de.baudetail.core.*
import kotlinx.serialization.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import java.io.*
import java.security.MessageDigest
import java.util.zip.*

val BaudetailJson=Json { prettyPrint=true; ignoreUnknownKeys=true; coerceInputValues=true; encodeDefaults=true; isLenient=false; allowSpecialFloatingPointValues=false }
@Serializable data class PackageManifest(val formatVersion:Int=1,val kind:String,val name:String,val embedded:Boolean=true,val resources:Map<String,String> = emptyMap())
data class OpenedPackage(val manifest:PackageManifest,val files:Map<String,ByteArray>) {
 fun project():Project {
  require(manifest.kind=="project")
  val p=BaudetailJson.decodeFromJsonElement<Project>(recoverDocument(BaudetailJson.parseToJsonElement(text("project.json"))).value)
  require(p.formatVersion in 0..1);p.drawings.forEach(::validateDrawing)
  require(p.drawings.map{it.id}.distinct().size==p.drawings.size)
  return p.copy(formatVersion=1,drawings=p.drawings.map{it.copy(formatVersion=1)},revisions=p.revisions.map { r->r.copy(drawings=r.drawings.map { d->validateDrawing(d);d.copy(formatVersion=1) }) })
 }
 fun drawing():Drawing {require(manifest.kind=="drawing");return BaudetailJson.decodeFromJsonElement<Drawing>(recoverDocument(BaudetailJson.parseToJsonElement(text("drawing.json"))).value).also(::validateDrawing).copy(formatVersion=1)}
 fun drawingEntries():List<LibraryEntry> = files["library-entries.json"]?.let { BaudetailJson.decodeFromString<List<LibraryEntry>>(it.toString(Charsets.UTF_8)) } ?: emptyList()
 fun library():LibraryPackage {require(manifest.kind=="library");return BaudetailJson.decodeFromString<LibraryPackage>(text("library.json")).also {require(it.formatVersion in 0..1); require(it.entries.size<=50000); require(it.entries.map {e->e.id}.distinct().size==it.entries.size)} }
 private fun text(name:String)=files[name]?.toString(Charsets.UTF_8)?:error("Paketdatei fehlt: $name")
}
object Packages {
 const val MAX_BYTES=128L*1024*1024
 fun safeName(name:String):Boolean = name.isNotEmpty() && !name.startsWith('/') && !name.contains('\\') && !name.contains(':') && name.split('/').none {it==".."||it=="."||it.isEmpty()}
 fun hash(bytes:ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") {"%02x".format(it)}
 fun read(input:InputStream):OpenedPackage {
  val files=linkedMapOf<String,ByteArray>();var total=0L
  ZipInputStream(BufferedInputStream(input)).use { zip ->
   var entry=zip.nextEntry
   while(entry!=null) {
    if(!entry.isDirectory) {
     val name=entry.name;require(safeName(name)){"Unsicherer Paketpfad"};require(!files.containsKey(name)){"Doppelter Paketpfad"};require(files.size<20000){"Paket enthält zu viele Dateien"}
     val out=ByteArrayOutputStream();val buf=ByteArray(8192)
     while(true){val n=zip.read(buf);if(n<0)break;total+=n;require(total<=MAX_BYTES){"Paket ist größer als 128 MiB"};out.write(buf,0,n)}
     files[name]=out.toByteArray()
    }
    zip.closeEntry();entry=zip.nextEntry
   }
  }
  val raw=files["manifest.json"]?:error("Kein Baudetail-Paket: manifest.json fehlt")
  val manifest=BaudetailJson.decodeFromString<PackageManifest>(raw.toString(Charsets.UTF_8))
  require(manifest.formatVersion in 0..1){"Paketversion ${manifest.formatVersion} benötigt eine neuere App"}
  require(manifest.kind in setOf("project","drawing","library")){"Unbekannter Pakettyp"}
  manifest.resources.forEach { (name,digest)-> val bytes=files[name]?:error("Ressource fehlt: $name");require(hash(bytes)==digest){"Beschädigte Ressource: $name"} }
  return OpenedPackage(manifest.copy(formatVersion=1),files)
 }
 fun write(output:OutputStream,kind:String,name:String,payloadName:String,payload:String,resources:Map<String,ByteArray>,embedded:Boolean=true) {
  require(resources.keys.all(::safeName));require(resources.values.sumOf{it.size.toLong()}<=MAX_BYTES)
  val manifest=PackageManifest(kind=kind,name=name,embedded=embedded,resources=resources.mapValues {hash(it.value)})
  ZipOutputStream(BufferedOutputStream(output)).use {zip->
   fun put(n:String,b:ByteArray){zip.putNextEntry(ZipEntry(n).also{it.time=0});zip.write(b);zip.closeEntry()}
   put("manifest.json",BaudetailJson.encodeToString(manifest).toByteArray());put(payloadName,payload.toByteArray());resources.toSortedMap().forEach { (n,b)->put(n,b) }
  }
 }
 fun project(output:OutputStream,p:Project,resources:Map<String,ByteArray>,full:Boolean=true) = write(output,"project",p.name,"project.json",BaudetailJson.encodeToString(p),if(full) resources else emptyMap(),full)
 fun drawing(output:OutputStream,d:Drawing,resources:Map<String,ByteArray>,entries:List<LibraryEntry> = emptyList()) = write(output,"drawing",d.name,"drawing.json",BaudetailJson.encodeToString(d),resources+("library-entries.json" to BaudetailJson.encodeToString(entries).toByteArray()))
 fun library(output:OutputStream,l:LibraryPackage,resources:Map<String,ByteArray>) = write(output,"library",l.name,"library.json",BaudetailJson.encodeToString(l),resources)
 fun resources(pack:OpenedPackage)=pack.files.filterKeys { it !in setOf("manifest.json","project.json","drawing.json","library.json","library-entries.json") }
}
