# Baudetail 0.3.1 – Abschluss und Prüfbericht

## Lieferstand

Direkt fortgesetzt am neuesten gesicherten `Baudetail-0.3.1-checkpoint.zip` aus „Projekt Baudetail 2“ (24.09.2026, 08:52 UTC). Keine App-Funktionen neu geschrieben, keine zusätzlichen Features, keine neue Bibliothek erzeugt. In diesem Abschlusslauf waren keine Änderungen am App-Quellcode erforderlich.

Der Quellstand wurde vor dem finalen Build nochmals dauerhaft als `Baudetail-0.3.1-prebuild-checkpoint.zip` gesichert.

Debug-Build `:app:assembleDebug`: **erfolgreich**.

- App-ID: `de.baudetail` (unverändert)
- versionName: `0.3.1`
- versionCode: `5` (0.3.0 hatte `4`)
- APK-Signatur verifiziert; Zertifikat identisch mit der beigefügten 0.3.0-APK.
- Zertifikat SHA-256: `fe7e0e1918e30e630f6e455d1327a59fbf4a6ae88bc18aaa977459286ed0ae5f`
- Bestehender Debug-Schlüssel und Dateiformatimplementierungen erhalten.

## Enthaltene Korrekturen des Checkpoints

- Auswahlmenü schließt zuerst sich selbst und öffnet danach den vorhandenen Treppendialog.
- Alte Material-/Schnittfüllungs-Zuordnungen über `materialId`, `material_id` und vorhandene Kompatibilitätsregeln ergeben einen sichtbaren Materialeintrag; die SVG-Ressourcen bleiben verwendbar.
- Geschlossene Polylinien verwenden denselben Flächen-/Schraffurpfad wie Rechtecke und Polygone.
- Treppen-Draufsicht mit parallelen Stufenkanten aus den vorhandenen Parametern, ohne Schnittrechtecke; Laufrichtung und oben/unten bleiben enthalten.
- Schnitt-/Draufsichtwechsel stellt das Oberflächenprofil wieder her; Rasen verwendet keine Schnitt-/Symbolgrafik als Top-Fallback.
- Einzelstufe und Bauwerksstufe verwenden denselben Komponentenrenderer; 400 mm Tiefe und 350 mm Auftritt ergeben 50 mm Überdeckung.
- Beschriftung „Verknüpft fangen“ und zurückgenommene Platzierung gemäß gesichertem Stand.

## Nur gezielte Prüfungen

| Prüfung | Ergebnis |
|---|---|
| Bauwerke → Treppe öffnen und übernehmen | Vorhandener UI-Test gestartet, aber **nicht ausführbar**: Robolectric konnte seine Android-Testlaufzeit wegen `UnknownHostException` nicht laden. Die eigentlichen UI-Schritte wurden daher nicht ausgeführt. Kein daraus nachgewiesener App-Fehler. |
| Material und zugehörige Schnittfüllung als ein sichtbarer Eintrag | Bestanden: `Material031Test`, 1 Test mit mehreren Zuordnungsvarianten; Prüfung der von der UI verwendeten Katalogliste. |
| Material/Schraffur auf Rechteck, Polygon, Kreis und geschlossener Polylinie innerhalb der Kontur | Bestanden: `Cad031Test.materialClipsAllClosedShapesIncludingPolyline`; offene Polylinie bleibt ungefüllt. |
| Treppen-Draufsicht: parallele Kanten, Breite, Auftritt; 5 cm Überdeckung im Schnitt und gleicher Einzelstufenrenderer | Bestanden: `Cad031Test.stairsOverlapAndTopEdgesStayAligned`. |
| Schnitt → Draufsicht: Fundamente im Oberflächenprofil ausgeblendet | Bestanden: `Cad031Test.switchingFromSectionRestoresSurfaceVisibility`. |
| Rasen: passende Top-/Schnittgrafik, unveränderte Position | Bestanden: `Cad031Test.grassNeverUsesSectionOrSymbolInTop`. |

**5 gezielte Kern-/Bibliothekstests bestanden, 0 Fehler.** Ein gezielter UI-Test scheiterte bereits an der Testumgebung. Entsprechend der Vorgabe keine allgemeinen UI-Testreihen und keine längere Fehlersuche an Robolectric.

Befehle:

```text
:drawing-core:test --tests '*Cad031Test' :libraries:test --tests '*Material031Test'
:app:testDebugUnitTest --tests 'de.baudetail.NavigationTest.stairMenuOpensAndSaves031'
:app:assembleDebug
```

Keine reale Geräteinstallation, keine vollständige visuelle Abnahme und kein neuer Dateiformat-Rundlauftest. Der bestandene Build und die Signaturprüfung ersetzen diese Prüfungen nicht. Die XML-Ergebnisse und der Abschlussbuild-Log liegen im Projekt unter `reports/0.3.1`.

## Installation und eigener Build

APK öffnen und **Aktualisieren** wählen. Die vorhandene App nicht vorher deinstallieren.

Projekt-ZIP entpacken und `Baudetail` in Android Studio öffnen. JDK 17, Android SDK 35 und Build Tools 35.0.0 verwenden, Gradle synchronisieren und `:app:assembleDebug` ausführen. Den enthaltenen Debug-Schlüssel unverändert lassen. Lokale SDK-Pfade, heruntergeladene Toolchain und Build-Caches sind nicht Teil des Projekt-ZIPs.

APK SHA-256: `64708d942875a7244d285480ff64ec4b451fc152786784de8bd46dfa8911cc93`
