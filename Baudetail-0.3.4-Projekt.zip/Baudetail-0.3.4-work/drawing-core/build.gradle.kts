plugins { `java-library`; alias(libs.plugins.kotlin.jvm); alias(libs.plugins.kotlin.serialization) }
kotlin { jvmToolchain(17) }
dependencies {
 // Entity exposes JsonObject in its public API; consumers need that type too.
 api(libs.serialization)
 testImplementation(libs.junit)
 api(project(":geometry"))
}
