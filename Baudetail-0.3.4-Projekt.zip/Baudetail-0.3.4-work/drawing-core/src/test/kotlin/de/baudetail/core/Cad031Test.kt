package de.baudetail.core
import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
class Cad031Test {
 private val concrete=LibraryEntry(id="beton",type="material",category="Beton",name="C20/25",appearance=MaterialAppearance(top=Style(fill="#888888"),sectionPattern="concrete.svg"))
 private fun assets(nodes:List<Primitive>):List<String> = nodes.flatMap{when(it){is Primitive.Asset->listOf(it.path);is Primitive.Group->assets(it.nodes);else->emptyList()}}
 @Test fun materialClipsAllClosedShapesIncludingPolyline(){
  val points=rectangle(Vec(10.0,20.0),Vec(1010.0,520.0))
  for(kind in listOf("rect","polygon","circle","polyline")){
   val e=Entity(kind=kind,points=if(kind=="circle")listOf(Vec(10.0,20.0))else if(kind=="polyline")points+points.first()else points,materialId=concrete.id).withNum("radiusMm",200.0)
   val p=Project(libraryEntries=listOf(concrete));val d=Drawing().withProfile("Schnitt")
   assertTrue(kind,closedContour(e));val hatch=Scene.entity(e,d,p).filterIsInstance<Primitive.Group>().single()
   assertEquals(contour(e),hatch.clip);assertTrue(assets(listOf(hatch)).all{it=="concrete.svg"})
   assertTrue(assets(Scene.entity(e,d.withViewMode("top"),p)).isEmpty())
  }
  val open=Entity(kind="polyline",points=points,materialId=concrete.id)
  assertTrue(assets(Scene.entity(open,Drawing().withProfile("Schnitt"),Project(libraryEntries=listOf(concrete)))).isEmpty())
 }
 @Test fun grassNeverUsesSectionOrSymbolInTop(){
  val grass=LibraryEntry(id="grass",type="component",category="Vegetation",name="Rasen",geometry=listOf(Entity(kind="polygon",points=listOf(Vec(),Vec(20.0,-300.0),Vec(40.0,0.0)))),views=mapOf("section" to "grass-cut.svg","symbol" to "grass-cut.svg","top" to "grass-top.svg"))
  val e=componentInstance(grass,Vec(50.0,60.0));val p=Project(libraryEntries=listOf(grass));val cut=Drawing().withProfile("Schnitt");val top=cut.withViewMode("top")
  assertEquals(listOf("grass-top.svg"),assets(Scene.entity(e,top,p)))
  assertEquals(listOf("grass-cut.svg"),assets(Scene.entity(e,cut,p)))
  val onlyCut=grass.copy(views=mapOf("section" to "grass-cut.svg","symbol" to "grass-cut.svg"))
  assertTrue(assets(Scene.entity(componentInstance(onlyCut,Vec()),top,Project(libraryEntries=listOf(onlyCut)))).isEmpty())
  assertEquals(e.points,viewEntity(e,top).points);assertEquals(e.points,viewEntity(e,cut).points)
 }
 @Test fun stairsOverlapAndTopEdgesStayAligned(){
  val step=LibraryEntry(id="step",type="component",category="Stufen",name="15/40/100",attributes=buildJsonObject{put("depth_mm",400);put("height_mm",150);put("length_mm",1000)},geometry=listOf(Entity(kind="polygon",points=listOf(Vec(),Vec(400.0,0.0),Vec(390.0,150.0),Vec(0.0,150.0)))),views=mapOf("section" to "step.svg"))
  val s=Entity(kind="assembly",points=listOf(Vec(25.0,70.0)),children=listOf(componentInstance(step,Vec()))).withStr("assemblyType","stair").withNum("widthMm",1000.0).withNum("goingMm",350.0)
  val p=Project(libraryEntries=listOf(step));val cut=Drawing().withProfile("Schnitt");val steps=stairSteps(s,cut,p)
  assertEquals(50.0,steps[0].points[0].x+stairDepth(steps[0])-steps[1].points[0].x,0.0)
  assertEquals(Scene.entity(componentInstance(step,steps[0].points[0]),cut,p),Scene.entity(steps[0],cut,p))
  val top=cut.withViewMode("top");val nodes=Scene.entity(s,top,p)
  assertTrue(assets(nodes).isEmpty());val edges=nodes.filterIsInstance<Primitive.Path>().filter{it.points.size==2&&it.points[0].x==it.points[1].x}
  assertEquals(stairCount(s)+1,edges.size);assertTrue(edges.all{it.points[1].y-it.points[0].y==1000.0})
  assertEquals(350.0,edges[1].points[0].x-edges[0].points[0].x,0.0)
  assertTrue(nodes.filterIsInstance<Primitive.Text>().map{it.value}.containsAll(listOf("OBEN","UNTEN")))
  assertEquals(Scene.entity(s,cut,p),Scene.entity(s,top.withViewMode("section"),p))
 }
 @Test fun switchingFromSectionRestoresSurfaceVisibility(){
  val e=Entity(kind="rect",placement=Placement(level="Fundament"));val cut=Drawing().withProfile("Schnitt")
  assertFalse(visibleIn(e,cut.withViewMode("top")));assertTrue(visibleIn(e,cut.withProfile("Fundamentplan")))
 }
}
