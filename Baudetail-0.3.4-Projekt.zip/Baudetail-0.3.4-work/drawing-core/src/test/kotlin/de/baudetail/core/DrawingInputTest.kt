package de.baudetail.core

import de.baudetail.geometry.*
import org.junit.Assert.*
import org.junit.Test

class DrawingInputTest {
 @Test fun arcRotationUpdatesRenderedAngles(){val e=shapeFromDrag("arc",Vec(),Vec(100.0,0.0));val r=transform(e,angle=90.0,center=Vec());assertEquals(90.0,r.num("startAngle"),1e-8);assertTrue(hitTest(Vec(0.0,100.0),r,1.0));assertFalse(hitTest(Vec(100.0,0.0),r,1.0));assertEquals(200.0,entityBounds(r).width,1e-8)}
 @Test fun independentGridAndSnap(){val d=Drawing(gridMm=100.0).withInput(DrawingInput(gridVisible=false,snapMm=10.0));assertEquals(100.0,d.gridMm,0.0);assertEquals(Vec(20.0,40.0),snap(Vec(23.0,37.0),d,d.input().options(1.0)).point)}
 @Test fun rectangleDimensionsRemainAssociative(){val e=shapeFromDrag("rect",Vec(),Vec(1000.0,500.0));val measure=Entity(kind="dimension",anchors=listOf(Anchor(e.id,0),Anchor(e.id,1)));val changed=resizeRectangle(e,4000.0,3000.0,Vec(20.0,30.0),30.0);assertEquals(4000.0,dimensionValue(measure,Drawing(entities=listOf(changed,measure))),1e-6);assertEquals(12.0,area(changed.points)/1e6,1e-6)}
 @Test fun circleResizesGeometryAndRadius(){val e=shapeFromDrag("circle",Vec(),Vec(500.0,0.0));val r=resizeCircle(e,800.0,Vec(100.0,100.0));assertEquals(800.0,r.points[0].distance(r.points[1]),1e-8);assertEquals(800.0,r.num("radiusMm"),0.0)}
 @Test fun lineLengthAndAngle(){val e=resizeLine(Entity(points=listOf(Vec(),Vec(1.0,0.0))),2000.0,90.0);assertEquals(2000.0,e.points[1].y,1e-8)}
 @Test fun disabledModesDoNotSnap(){val d=Drawing(entities=listOf(Entity(points=listOf(Vec(),Vec(100.0,0.0)))));val p=Vec(49.0,2.0);assertEquals(p,snap(p,d,SnapOptions(grid=false,modes=emptySet())).point)}
 @Test fun circleCenterIsSeparateMode(){val e=shapeFromDrag("circle",Vec(),Vec(500.0,0.0));val d=Drawing(entities=listOf(e));assertEquals("Zentrum",snap(Vec(2.0,3.0),d,SnapOptions(grid=false,modes=setOf("Zentrum"))).reason)}
 @Test fun orthoSurvivesOffGridOrigin(){val p=Vec(3.0,7.0);val r=snap(Vec(107.0,10.0),Drawing(),SnapOptions(geometry=false,ortho=true,gridMm=10.0),p);assertEquals(7.0,r.point.y,0.0)}
 @Test fun unknownExtensionsSurvive(){val d=Drawing().withInput(DrawingInput(snapMm=5.0,angleStep=15.0));assertEquals(5.0,d.input().snapMm,0.0);assertEquals(15.0,d.input().angleStep,0.0);assertEquals(1,d.formatVersion)}
}
