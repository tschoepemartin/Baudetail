package de.baudetail.core
import de.baudetail.geometry.*
import org.junit.Assert.*
import org.junit.Test

class UpdateTest {
 @Test fun textSupportsUnicodeAndMultiline(){assertEquals("Größe 35\nÄÖÜ ±0,00",interpolate("Größe {mass}\nÄÖÜ ±0,00",mapOf("mass" to "35")))}
 @Test fun sharedStairParametersDriveAssociativeDimensions(){
  val stair=Entity(kind="assembly",points=listOf(Vec())).withStr("assemblyType","stair").withNum("stepCount",6.0).withNum("goingMm",350.0).withNum("totalHeightMm",900.0).withStr("heightMode","total")
  assertEquals(150.0,stairRise(stair),0.0)
  val dim=Entity(kind="dimension",anchors=listOf(Anchor(stair.id,0,"stair"),Anchor(stair.id,2,"stair")))
  val d=Drawing(entities=listOf(stair,dim))
  assertEquals(350.0,dimensionValue(dim,d),0.001)
  assertEquals(400.0,dimensionValue(dim,d.copy(entities=listOf(stair.withNum("goingMm",400.0),dim))),0.001)
 }
 @Test fun dimensionMoveKeepsReferences(){val e=Entity(kind="dimension",anchors=listOf(Anchor("x"),Anchor("y")));val moved=transform(e,translation=Vec(20.0,30.0));assertEquals(e.anchors,moved.anchors);assertEquals(20.0,moved.num("dimDx"),0.0)}
 @Test fun viewSwitchIsUndoable(){val d=Drawing();val h=EditorHistory(DrawingHistory(d));h.commit(d.withViewMode("section"));h.undo();assertEquals("top",h.current.viewMode())}
}
