package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import java.util.UUID
import kotlin.math.*

fun uid() = UUID.randomUUID().toString()
@Serializable data class Layer(val id:String=uid(),val name:String="Planung",val visible:Boolean=true,val locked:Boolean=false,val printable:Boolean=true)
@Serializable data class Style(val stroke:String="#273A3A",val fill:String?=null,val widthMm:Double=0.25,val dashed:Boolean=false,val opacity:Double=1.0,val textPaperMm:Double=3.0,val bold:Boolean=false,val italic:Boolean=false,val align:String="left",val frame:Boolean=false,val background:String?=null)
@Serializable data class Anchor(val entityId:String,val vertex:Int=0,val reference:String="",val view:String="top",val fraction:Double=0.0,val otherEntityId:String?=null,val otherVertex:Int=0,val offset:Vec=Vec())
@Serializable data class Pattern(val widthMm:Double=200.0,val heightMm:Double=100.0,val jointMm:Double=4.0,val angle:Double=0.0,val offset:Double=0.5,val origin:Vec=Vec())
@Serializable data class Stratum(val materialId:String="",val name:String="Schicht",val thicknessMm:Double=80.0,val color:String="#D3D0C7")
@Serializable data class Placement(val level:String="Oberfläche",val zMm:Double?=null,val topMm:Double?=null,val bottomMm:Double?=null,val visibleTop:Boolean=true,val visibleSection:Boolean=true,val hidden:Boolean=false)
@Serializable data class PointBinding(val vertex:Int,val anchor:Anchor)
@Serializable data class MaterialAppearance(val top:Style?=null,val section:Style?=null,val sectionPattern:String?=null,val tileWidthMm:Double=200.0,val tileHeightMm:Double=200.0)
@Serializable data class Entity(
 val id:String=uid(),val kind:String="line",val points:List<Vec> = emptyList(),val layerId:String="planning",
 val name:String="",val text:String="",val style:Style=Style(),val locked:Boolean=false,val groupId:String?=null,
 val status:String="Planung",val materialId:String?=null,val libraryId:String?=null,val view:String="top",
 val params:JsonObject=JsonObject(emptyMap()),val anchors:List<Anchor> = emptyList(),val targetDrawingId:String?=null,
 val pattern:Pattern?=null,val strata:List<Stratum> = emptyList(),val asset:String?=null,val rotation:Double=0.0,
 val materialSnapshot:MaterialAppearance?=null,val placement:Placement=Placement(),val bindings:List<PointBinding> = emptyList(),val objectVersion:Int=1,val children:List<Entity> = emptyList(),val quantityUnit:String?=null,val extensions:JsonObject=JsonObject(emptyMap())
) {
 fun num(key:String,default:Double=0.0) = (params[key] as? JsonPrimitive)?.doubleOrNull?.takeIf { it.isFinite() } ?: default
 fun str(key:String,default:String="") = (params[key] as? JsonPrimitive)?.contentOrNull ?: default
 fun withNum(key:String,value:Double) = copy(params=JsonObject(params+(key to JsonPrimitive(value))))
 fun withStr(key:String,value:String) = copy(params=JsonObject(params+(key to JsonPrimitive(value))))
}
@Serializable data class Sheet(val widthMm:Double=297.0,val heightMm:Double=210.0,val scale:Double=50.0,val showPaper:Boolean=true,val origin:Vec=Vec(),val titleTemplate:String="{projekt} | {zeichnung}\nNr. {projektnummer} · {bearbeiter} · {datum}\nMaßstab 1:{maßstab} · Revision {revision}")
@Serializable data class Drawing(val createdAt:Long=0,val updatedAt:Long=0,
 val formatVersion:Int=1,val id:String=uid(),val name:String="Lageplan",val type:String="Lageplan",val entities:List<Entity> = emptyList(),
 val layers:List<Layer> = defaultLayers(),val sheet:Sheet=Sheet(),val origin:Vec=Vec(),val elevationDatumMm:Double=0.0,
 val gridMm:Double=100.0,val sourceDrawingId:String?=null,val variantOf:String?=null,val revision:String="A",val variables:Map<String,String> = emptyMap(),
 val extensions:JsonObject=JsonObject(emptyMap())
)
@Serializable data class Revision(val id:String=uid(),val title:String,val timestamp:Long=System.currentTimeMillis(),val drawings:List<Drawing>)
@Serializable data class Project(val createdAt:Long=0,
 val formatVersion:Int=1,val id:String=uid(),val name:String="Neues Projekt",val metadata:Map<String,String> = emptyMap(),
 val drawings:List<Drawing> = listOf(Drawing()),val notes:String="",val revisions:List<Revision> = emptyList(),val resources:List<String> = emptyList(),
 val libraryEntries:List<LibraryEntry> = emptyList(),val updatedAt:Long=System.currentTimeMillis(),val extensions:JsonObject=JsonObject(emptyMap())
)
@Serializable data class LibraryEntry(
 val formatVersion:Int=1,val id:String,val type:String,val category:String,val name:String,val version:Int=1,
 val manufacturer:String?=null,val series:String?=null,val attributes:JsonObject=JsonObject(emptyMap()),val views:Map<String,String> = emptyMap(),
 val materialId:String?=null,val appearance:MaterialAppearance?=null,val preview:String?=null,val geometry:List<Entity> = emptyList(),val style:Style=Style(),val template:String?=null,
 val extensions:JsonObject=JsonObject(emptyMap())
)
@Serializable data class LibraryPackage(val formatVersion:Int=1,val id:String=uid(),val name:String="Bibliothek",val version:Int=1,val entries:List<LibraryEntry> = emptyList())
@Serializable data class DrawingHistory(val current:Drawing,val past:List<Drawing> = emptyList(),val future:List<Drawing> = emptyList(),val backups:List<Drawing> = emptyList())
fun defaultLayers() = listOf("Bestand","Planung","Abbruch","Gebäude","Gelände","Vegetation","Entwässerung","Leitungen","Materialien","Bemaßung","Text","Hilfslinien").mapIndexed { i,s -> Layer(if(i==1) "planning" else "layer-$i",s, printable=s!="Hilfslinien") }
fun resolvedPoints(e:Entity,d:Drawing):List<Vec> = resolveConnections(e,d,emptySet())
private fun resolveConnections(e:Entity,d:Drawing,visited:Set<String>):List<Vec> {
 if(e.id in visited||visited.size>32)return e.points
 val refs=e.bindings.map{it.anchor}+e.anchors;val ids=refs.flatMap{listOfNotNull(it.entityId,it.otherEntityId)}.toSet()
 val targets=d.entities.map{if(it.id in ids&&it.id !in visited)it.copy(points=resolveConnections(it,d,visited+e.id),bindings=emptyList())else it}
 val snapshot=d.copy(entities=targets);val points=anchoredPoints(e,snapshot).toMutableList()
 e.bindings.forEach{b->if(b.vertex in points.indices)points[b.vertex]=anchoredPoints(Entity(points=listOf(points[b.vertex]),anchors=listOf(b.anchor)),snapshot).first()}
 return points
}
private fun anchoredPoints(e:Entity,d:Drawing):List<Vec> = if(e.anchors.isEmpty()) e.points else e.anchors.mapIndexed { i,a ->
 val target=d.entities.find { it.id==a.entityId }
 val base=if(target!=null&&a.reference=="stairEnd")assemblyPoint(target,Vec(stairLength(target),0.0))
 else if(target!=null&&a.reference in setOf("component","smart"))smartSnapReferencePoints(target,d.withViewMode(a.view)).getOrNull(a.vertex)?:e.points.getOrElse(i){Vec()}
 else if(target!=null&&a.reference=="smartEdge") {val c=smartSnapOutline(target,d.withViewMode(a.view));val first=c.getOrNull(a.vertex);val last=if(c.isEmpty())null else c.getOrNull((a.vertex+1)%c.size);if(first==null||last==null)e.points.getOrElse(i){Vec()}else first+(last-first)*a.fraction}
 else if(target?.kind=="circle"&&a.reference=="circleEdge")(target.points.firstOrNull()?:Vec())+Vec(cos(a.fraction),sin(a.fraction))*target.num("radiusMm")
 else if(target!=null && a.reference in setOf("edge","intersection")) {
  val rawPoints=when { isStair(target)->stairReferencePoints(target,a.view); target.kind=="component"->componentReferencePoints(target,d.withViewMode(a.view)); else->target.points }
  val points=if(target.kind=="component")rawPoints.take(4)else rawPoints
  val first=points.getOrNull(a.vertex);val last=if(points.isEmpty())null else points.getOrNull((a.vertex+1)%points.size)
  val otherTarget=d.entities.find{it.id==a.otherEntityId};val otherRaw=when { otherTarget==null->emptyList();isStair(otherTarget)->stairReferencePoints(otherTarget,a.view);otherTarget.kind=="component"->componentReferencePoints(otherTarget,d.withViewMode(a.view));else->otherTarget.points };val other=if(otherTarget?.kind=="component")otherRaw.take(4)else otherRaw
  if(first==null||last==null)e.points.getOrElse(i){Vec()}
  else if(a.reference=="intersection"&&other.isNotEmpty())intersection(first,last,other.getOrElse(a.otherVertex){Vec()},other[(a.otherVertex+1)%other.size])?:e.points.getOrElse(i){Vec()}
  else first+(last-first)*a.fraction
 }
 else if(target!=null && isStair(target) && a.reference=="stair") stairReferencePoints(target,a.view).getOrNull(a.vertex)?:e.points.getOrElse(i){Vec()}
 else if(target?.kind=="circle" && a.vertex==1 && target.points.isNotEmpty()) { val center=target.points[0];val vector=(target.points.getOrNull(1)?:center+Vec(1.0,0.0))-center;center+vector*(target.num("radiusMm",vector.length())/vector.length().coerceAtLeast(1e-9)) }
 else target?.points?.getOrNull(a.vertex) ?: e.points.getOrElse(i) { Vec() }
 base+a.offset
}
fun entityBounds(e:Entity):Bounds {
 val p=e.points.firstOrNull() ?: Vec()
 return when(e.kind) {
 "circle","arc","tree" -> { val r=if(e.kind=="tree") e.num("crownMm",2000.0)/2 else e.num("radiusMm",e.points.getOrNull(1)?.distance(p) ?: 500.0); Bounds(p-Vec(r,r),p+Vec(r,r)) }
 "assembly" -> Bounds.of(stairReferencePoints(e,"top")+stairReferencePoints(e,"section"))
 "image","component","stack" -> { if(e.str("frozenTemplate")=="true"&&e.children.isNotEmpty()){val b=Bounds.of(e.children.flatMap{listOf(entityBounds(it).min,entityBounds(it).max)});val scale=e.num("templateScale",1.0);return Bounds(p+b.min*scale,p+b.max*scale)};val h=if(e.kind=="stack") e.strata.sumOf { it.thicknessMm } else e.num("heightMm",500.0); Bounds(p,p+Vec(e.num("widthMm",1000.0),h)) }
 else -> Bounds.of(e.points)
 }
}
fun transform(e:Entity,translation:Vec=Vec(),angle:Double=0.0,factor:Double=1.0,mirror:Boolean=false,center:Vec=smartPivot(e)):Entity {
 require(factor>0 && factor.isFinite())
 if(e.kind=="dimension"&&e.anchors.isNotEmpty()&&angle==0.0&&factor==1.0&&!mirror)return e.withNum("dimDx",e.num("dimDx")+translation.x).withNum("dimDy",e.num("dimDy")+translation.y)
 fun t(p:Vec):Vec { val q=(p-center)*factor;return (center+Vec(if(mirror) -q.x else q.x,q.y)).rotate(angle,center)+translation }
 val sizes=setOf("radiusMm","widthMm","heightMm","crownMm","spacingMm","rootMm","pitMm","riseMm","goingMm","depthMm","stepHeightMm","stairWidthMm","topWidthMm","topHeightMm","sectionWidthMm","sectionHeightMm","templateScale","totalHeightMm","totalLengthMm")
 return e.copy(points=e.points.map(::t),rotation=(if(mirror&&(isStair(e)||e.kind=="component"))180.0-e.rotation else e.rotation)+angle,params=JsonObject(e.params.mapValues { (k,v) -> if(k=="mirrored"&&mirror)JsonPrimitive(if(e.num(k)==1.0)0.0 else 1.0) else if(e.kind=="arc"&&k=="startAngle") JsonPrimitive((if(mirror)180-e.num(k)else e.num(k))+angle) else if(e.kind=="arc"&&k=="sweepAngle"&&mirror) JsonPrimitive(-e.num(k,90.0)) else if(k in sizes && v is JsonPrimitive && v.doubleOrNull!=null) JsonPrimitive(v.double*factor) else v }),strata=e.strata.map { it.copy(thicknessMm=it.thicknessMm*factor) })
}
fun validateDrawing(d:Drawing) {
 require(d.formatVersion in 0..1) { "Dateiformat zu neu: ${d.formatVersion}" }
 require(d.sheet.scale>0 && d.sheet.scale.isFinite()) { "Ungültiger Maßstab" }
 require(d.sheet.widthMm in 20.0..5000.0 && d.sheet.heightMm in 20.0..5000.0) { "Papierformat ungültig" }
 require(d.gridMm>0 && d.gridMm.isFinite())
 require(d.entities.size<=100000) { "Zu viele Objekte" }
 require(d.entities.map { it.id }.distinct().size==d.entities.size) { "Doppelte Objekt-ID" }
 d.entities.forEach { e -> require(e.points.all { it.finite() }) { "Ungültige Koordinaten" }; require(e.style.opacity in 0.0..1.0); require(e.style.widthMm>0 && e.style.textPaperMm>0);require(e.strata.all { it.thicknessMm>0 })
 require(listOf("radiusMm","widthMm","heightMm","spacingMm","crownMm").all { key -> key !in e.params || (key=="heightMm" && e.kind=="elevation") || e.num(key)>0 }) { "Abmessungen müssen positiv sein" }
 if(isStair(e))require(stairRise(e)>0&&stairEffectiveRise(e)>0&&stairGoing(e)>0&&stairGoing(e)<=stairDepth(e)){"Auftritt/Stufenhöhe bzw. Stufengefälle ergeben keine gültige Treppe"}
 e.pattern?.let { pattern -> require(pattern.widthMm>0 && pattern.heightMm>0 && pattern.jointMm>=0);val b=Bounds.of(e.points.map{(it-pattern.origin).rotate(-pattern.angle)});val cells=(b.width/(pattern.widthMm+pattern.jointMm)+5)*(b.height/(pattern.heightMm+pattern.jointMm)+5);require(cells<=40000) { "Muster über 40.000 Steine. Fläche teilen oder größere Steine verwenden." } } }
}
fun variables(p:Project,d:Drawing):Map<String,String> {
 val base=p.metadata+d.variables
 return base+mapOf(
  "projekt" to p.name,
  "bauvorhaben" to (base["bauvorhaben"] ?: p.name),
  "zeichnung" to d.name,
  "projektnummer" to base["projektnummer"].orEmpty(),
  "bearbeiter" to base["bearbeiter"].orEmpty(),
  "auftraggeber" to base["auftraggeber"].orEmpty(),
  "planer" to base["planer"].orEmpty(),
  "detailnummer" to base["detailnummer"].orEmpty(),
  "baustelle" to base["baustelle"].orEmpty(),
  "maßstab" to fmt(d.sheet.scale,2),
  "revision" to d.revision,
  "datum" to java.time.LocalDate.now().toString()
 )
}
/** Resolve plan-head variables before rendering. Unknown placeholders are deliberately blank in print/export. */
fun interpolate(template:String,vars:Map<String,String>) = Regex("\\{([^{}]+)\\}").replace(template) { vars[it.groupValues[1]].orEmpty() }
fun fmt(v:Double,decimals:Int=2):String = String.format(java.util.Locale.GERMANY,"%.${decimals}f",v).let { if(decimals>0) it.trimEnd('0').trimEnd(',').ifEmpty { "0" } else it }

fun textVariables(e:Entity,d:Drawing,p:Project):Map<String,String> {
 val target=d.entities.find {it.id==e.str("sourceId")}
 return variables(p,d)+(target?.let { t -> t.params.mapValues { (_,v)-> (v as? JsonPrimitive)?.content ?: v.toString() }+mapOf("name" to t.name,"laenge_m" to fmt(length(t.points)/1000),"flaeche_m2" to fmt(area(t.points)/1e6),"dicke_mm" to fmt(t.strata.sumOf{it.thicknessMm})) } ?: emptyMap())
}
