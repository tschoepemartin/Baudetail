package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*

/** Shared semantic family used for intelligent component replacement/rendering. */
fun LibraryEntry.smartFamily():String {
 val explicit=(attributes["component_family"] as? JsonPrimitive)?.contentOrNull.orEmpty()
 if(explicit.isNotBlank()) return explicit
 val key=(category+"/"+name).lowercase()
 return when {
  "rohre/" in key || "rohr" in key || "leitung" in key -> "pipe"
  "mauerbau" in key && ("l-stein" in key || "winkel" in key || "mauerscheib" in key) -> "retaining_wall"
  "einfassungen/borde" in key || "bord " in key -> "curb"
  "rinne" in key -> "channel"
  "rasen" in key -> "grass"
  else -> "component"
 }
}

fun Entity.smartFamily():String = str("componentFamily").ifBlank {
 when {
  isStair(this) -> "stair"
  else -> "component"
 }
}

fun LibraryEntry.attrNumber(vararg keys:String, default:Double=0.0):Double {
 for(key in keys) {
  val p=attributes[key] as? JsonPrimitive ?: continue
  p.doubleOrNull?.let { if(it.isFinite()) return it }
 }
 return default
}

fun LibraryEntry.variantGroup():String = (attributes["variant_group"] as? JsonPrimitive)?.contentOrNull
 ?: when(smartFamily()) {
  "pipe" -> category
  "curb" -> category
  "retaining_wall" -> "Mauerbau/Mauerscheiben"
  "channel" -> category
  "grass" -> category
  else -> category
 }

/** Swap a placed smart component to another compatible library entry while preserving its anchor/OK and editing state. */
fun replaceComponentVariant(old:Entity,entry:LibraryEntry):Entity {
 require(old.kind=="component") { "Nur Bauteile können typgleich ersetzt werden" }
 require(old.smartFamily()==entry.smartFamily() || old.smartFamily()=="component") { "Bauteil gehört zu einer anderen Kategorie" }
 val at=old.points.firstOrNull()?:Vec()
 val fresh=componentInstance(entry,at)
 val keepKeys=setOf("orientation","verticalDirection","verticalLengthMm","labelEnabled","labelMode","labelText","labelDx","labelDy","fillMode","fillTop","fillSection","snapPriority")
 val merged=fresh.params.toMutableMap()
 old.params.forEach { (k,v) -> if(k in keepKeys) merged[k]=v }
 return fresh.copy(
  id=old.id, layerId=old.layerId, status=old.status, rotation=old.rotation,
  locked=old.locked, groupId=old.groupId, placement=old.placement,
  style=old.style, materialId=old.materialId, materialSnapshot=old.materialSnapshot,
  quantityUnit=old.quantityUnit, extensions=old.extensions, bindings=old.bindings, anchors=old.anchors,
  params=JsonObject(merged)
 )
}

fun smartPivot(e:Entity):Vec = if((e.kind=="component" || isStair(e)) && e.points.isNotEmpty()) e.points.first() else entityBounds(e).center

/** Outer construction rectangle used for intelligent component-to-component snapping.
 * Unlike the former generic point list this deliberately contains only the real
 * outside edges that may be used as an installation/reference edge. */
fun smartSnapOutline(e:Entity,d:Drawing):List<Vec> {
 val origin=e.points.firstOrNull()?:Vec()
 if(isStair(e)) {
  val local=if(d.viewMode()=="top") rectangle(Vec(),Vec(stairLength(e),e.num("widthMm",1200.0)))
   else {val b=Bounds.of(stairLocalPoints(e,"section"));rectangle(b.min,b.max)}
  return local.map{assemblyPoint(e,it)}
 }
 if(e.kind=="component") {
  val (w,h)=when {
   isRetainingWall(e) && d.viewMode()=="top" -> e.num("elementLengthMm",1000.0) to e.num("footDepthMm",400.0)
   isRetainingWall(e) -> e.num("footDepthMm",400.0) to e.num("wallHeightMm",800.0)
   isPipe(e) && d.viewMode()=="top" && e.str("orientation","horizontal")=="vertical" -> e.num("dnMm",100.0) to e.num("dnMm",100.0)
   isPipe(e) && d.viewMode()=="top" -> e.num("topWidthMm",1000.0) to e.num("dnMm",100.0)
   isPipe(e) && e.str("orientation","horizontal")=="vertical" -> e.num("dnMm",100.0) to e.num("verticalLengthMm",1000.0)
   isPipe(e) -> e.num("dnMm",100.0) to e.num("dnMm",100.0)
   d.viewMode()=="top" -> e.num("topWidthMm",e.num("widthMm",1000.0)) to e.num("topHeightMm",e.num("heightMm",500.0))
   else -> e.num("sectionWidthMm",e.num("widthMm",1000.0)) to e.num("sectionHeightMm",e.num("heightMm",500.0))
  }
  val mirrored=e.num("mirrored")==1.0
  return rectangle(Vec(),Vec(w,h)).map{q->origin+Vec(q.x,if(mirrored)-q.y else q.y).rotate(e.rotation)}
 }
 return rectangle(entityBounds(e).min,entityBounds(e).max)
}
fun smartSnapReferencePoints(e:Entity,d:Drawing):List<Vec> {
 val c=smartSnapOutline(e,d);if(c.size<4)return c
 val mids=(0..3).map{i->(c[i]+c[(i+1)%4])*0.5}
 return c+Bounds.of(c).center+mids
}
fun smartSnapSegments(e:Entity,d:Drawing):List<Pair<Vec,Vec>> {
 val c=smartSnapOutline(e,d);return if(c.size>=4)(0..3).map{i->c[i] to c[(i+1)%4]} else c.zipWithNext()
}
fun smartSnapEdgeIndexFromReferenceIndex(index:Int):Int? = if(index in 5..8) index-5 else null
fun smartEdgeLength(e:Entity,d:Drawing,index:Int):Double {val c=smartSnapOutline(e,d);return if(c.size>=4)c[index.mod(4)].distance(c[(index+1).mod(4)]) else 0.0}

/** Match the plan dimension represented by one outside edge. DN/pipe diameter is
 * intentionally never stretched by this mechanism. */
fun withSmartEdgeLength(e:Entity,edge:Int,length:Double,view:String):Entity {
 if(length<=0||!length.isFinite())return e
 if(isStair(e)) return if(edge%2==1)e.withNum("widthMm",length) else e
 if(e.kind!="component"||isPipe(e))return e
 val horizontal=edge%2==0
 return when {
  isRetainingWall(e)&&view=="top" -> if(horizontal)e.withNum("elementLengthMm",length).withNum("topWidthMm",length) else e.withNum("footDepthMm",length).withNum("topHeightMm",length)
  view=="top" -> if(horizontal)e.withNum("topWidthMm",length) else e.withNum("topHeightMm",length)
  else -> if(horizontal)e.withNum("sectionWidthMm",length) else e.withNum("sectionHeightMm",length)
 }
}

/** Keep dimensions of linked followers equal to the reference edge of the leading
 * component. The link is deliberately view-specific (normally top view). */
fun syncSmartFollowers(input:Drawing):Drawing {
 var d=input
 repeat(4){
  var changed=false
  val next=d.entities.map{e->
   val targetId=e.str("followTargetId");val sourceEdge=e.num("followSourceEdge",-1.0).toInt();val targetEdge=e.num("followTargetEdge",-1.0).toInt();val view=e.str("followView","top")
   if(targetId.isBlank()||sourceEdge !in 0..3||targetEdge !in 0..3)e else {
    val target=d.entities.find{it.id==targetId}?:return@map e
    val vd=d.withViewMode(view);val len=smartEdgeLength(target,vd,targetEdge);val n=withSmartEdgeLength(e,sourceEdge,len,view)
    if(n!=e)changed=true;n
   }
  }
  d=d.copy(entities=next);if(!changed)return d
 }
 return d
}

fun retainingWallSection(e:Entity):List<Vec> {
 val h=e.num("wallHeightMm",e.num("sectionHeightMm",800.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("sectionWidthMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val slab=e.num("footThicknessMm",100.0).coerceIn(1.0,h)
 val side=e.str("footSide","right")
 val pts=if(side=="left") listOf(Vec(foot,0.0),Vec(foot-wall,0.0),Vec(foot-wall,h-slab),Vec(0.0,h-slab),Vec(0.0,h),Vec(foot,h))
 else listOf(Vec(0.0,0.0),Vec(wall,0.0),Vec(wall,h-slab),Vec(foot,h-slab),Vec(foot,h),Vec(0.0,h))
 return pts
}

fun retainingWallTop(e:Entity):Pair<List<Vec>,List<Vec>> {
 val length=e.num("elementLengthMm",e.num("topWidthMm",1000.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("topHeightMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val wallRect=rectangle(Vec(),Vec(length,wall))
 val footRect=rectangle(Vec(),Vec(length,foot))
 return wallRect to footRect
}

fun isPipe(e:Entity)=e.kind=="component"&&e.smartFamily()=="pipe"
fun isRetainingWall(e:Entity)=e.kind=="component"&&e.smartFamily()=="retaining_wall"
