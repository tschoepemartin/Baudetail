package de.baudetail.libraries

import de.baudetail.core.*
import de.baudetail.format.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*

enum class ConflictPolicy { KEEP, REPLACE, COPY }
@Serializable data class CatalogState(val entries:List<LibraryEntry> = emptyList(),val disabled:Set<String> = emptySet(),val favorites:Set<String> = emptySet(),val recent:List<String> = emptyList())
class Catalog(var state:CatalogState=CatalogState()) {
 fun entries()=unifiedMaterials(state.entries.filter {it.id !in state.disabled})
 fun search(query:String="",category:String="",filters:Map<String,String> = emptyMap()):List<LibraryEntry> = entries().filter { e->
  (category.isEmpty()||e.category==category||e.category.startsWith("$category/")) &&
  listOf(e.name,e.category,e.manufacturer.orEmpty(),e.series.orEmpty(),e.attributes.toString()).any {it.contains(query,true)} && filters.all {(k,v)->e.attributes[k]?.let { (it as? JsonPrimitive)?.content ?: it.toString() }==v}
 }
 fun attributes(entries:List<LibraryEntry> = entries()):Map<String,List<String>> = entries.flatMap {it.attributes.entries}.groupBy {it.key}.mapValues {(_,v)->v.map { (it.value as? JsonPrimitive)?.content ?: it.value.toString() }.distinct().sorted()}
 fun import(pack:LibraryPackage,policy:ConflictPolicy):List<String> {
  require(pack.formatVersion<=1);val all=state.entries.associateBy {it.id}.toMutableMap();val added=mutableListOf<String>()
  pack.entries.forEach {entry->
   require(entry.id.isNotBlank()&&entry.category.isNotBlank()&&entry.name.isNotBlank()){ "Bibliothekseintrag unvollständig" }
   require(entry.views.values.all(Packages::safeName));entry.preview?.let {require(Packages.safeName(it))}
   val e=if(all.containsKey(entry.id))when(policy){ConflictPolicy.KEEP->null;ConflictPolicy.REPLACE->entry;ConflictPolicy.COPY->entry.copy(id=uid(),name=entry.name+" (Kopie)")}else entry
   e?.let {all[it.id]=it;added.add(it.id)}
  }
  state=state.copy(entries=all.values.toList());return added
 }
 fun toggleFavorite(id:String) {state=state.copy(favorites=if(id in state.favorites)state.favorites-id else state.favorites+id)}
 fun setEnabled(id:String,enabled:Boolean){state=state.copy(disabled=if(enabled)state.disabled-id else state.disabled+id)}
 fun remove(id:String){state=state.copy(entries=state.entries.filterNot {it.id==id},disabled=state.disabled-id,favorites=state.favorites-id)}
 fun used(id:String){state=state.copy(recent=(listOf(id)+state.recent.filterNot {it==id}).take(30))}
}
