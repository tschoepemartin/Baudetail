package de.baudetail.libraries
import de.baudetail.core.*
import kotlinx.serialization.json.*

/** Keep original IDs in storage for existing drawings; expose one material per representation pair. */
fun unifiedMaterials(entries:List<LibraryEntry>):List<LibraryEntry>{
 fun link(e:LibraryEntry)=e.materialId
  ?:(e.attributes["materialId"] as? JsonPrimitive)?.contentOrNull
  ?:(e.attributes["material_id"] as? JsonPrimitive)?.contentOrNull
  ?:(e.extensions["materialId"] as? JsonPrimitive)?.contentOrNull
 fun isFill(e:LibraryEntry)=e.name.contains("Schnittfüllung",true)||e.name.contains("Schnittfuellung",true)||e.type in setOf("section-fill","sectionFill","hatch")
 val merged=entries.associateBy{it.id}.toMutableMap()
 val aliases=mutableSetOf<String>()
 val suffix=Regex("(?i)\\s*[-–·:]?\\s*(schnittfüllung|schnittfuellung|schnitt)\\s*$")
 val prefix=Regex("(?i)^\\s*(schnittfüllung|schnittfuellung)\\s*[-–·:]?\\s*")
 for(fill in entries){
  val id=link(fill)
  val name=fill.name.replace(prefix,"").replace(suffix,"").trim()
  val base=entries.find{it.id!=fill.id&&!isFill(it)&&it.type=="material"&&
   ((id!=null&&(it.id==id||link(it)==id))||(name!=fill.name&&it.name.equals(name,true)))}?:continue
  val asset=fill.appearance?.sectionPattern?:fill.views["section"]?:fill.views["symbol"]?:fill.views["top"]?:continue
  val current=merged.getValue(base.id)
  val appearance=current.appearance?:MaterialAppearance(top=base.style)
  merged[base.id]=current.copy(appearance=appearance.copy(top=appearance.top?:base.style,section=appearance.section?:fill.style,sectionPattern=appearance.sectionPattern?:asset),views=current.views+("section" to (current.views["section"]?:asset)))
  aliases.add(fill.id)
 }
 return entries.filterNot{it.id in aliases}.map{merged.getValue(it.id)}
}
