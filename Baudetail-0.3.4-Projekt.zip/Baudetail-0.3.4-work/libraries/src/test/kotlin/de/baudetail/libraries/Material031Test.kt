package de.baudetail.libraries
import de.baudetail.core.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
class Material031Test {
 @Test fun legacyLinksMergeIntoOneVisibleMaterial(){
  val base=LibraryEntry(id="soil",type="material",category="Böden",name="Oberboden 0/10",style=Style(fill="#654321"))
  for(fill in listOf(
   base.copy(id="cut",type="component",name="Schnittfüllung Oberboden 0/10",materialId="soil"),
   base.copy(id="cut",type="component",name="Schnittfüllung Oberboden 0/10",attributes=buildJsonObject{put("materialId","soil")}),
   base.copy(id="cut",type="component",name="Schnittfüllung Oberboden 0/10",attributes=buildJsonObject{put("material_id","soil")})
  )){
   val catalog=Catalog(CatalogState(entries=listOf(base,fill.copy(views=mapOf("section" to "soil.svg")))))
   val merged=catalog.entries().single();assertEquals("soil",merged.id);assertEquals(base.style,merged.appearance!!.top);assertEquals("soil.svg",merged.appearance!!.sectionPattern)
   assertEquals(2,catalog.state.entries.size)
  }
 }
}
