package de.baudetail.libraries
import de.baudetail.core.*
import org.junit.Test
import org.junit.Assert.*
class Material030Test {
 @Test fun legacyFillIsOneMaterialWithoutDeletingAlias(){val s=LibraryEntry(id="beton",type="material",category="Beton",name="Beton C20/25",style=Style(fill="#AAAAAA"));val f=s.copy(id="beton-cut",name="Beton C20/25 – Schnittfüllung",views=mapOf("section" to "hatch.svg"));val c=Catalog(CatalogState(listOf(s,f)));val m=c.entries().single();assertEquals("beton",m.id);assertEquals("hatch.svg",m.appearance?.sectionPattern);assertEquals(2,c.state.entries.size)}
}
