package de.baudetail.libraries
import de.baudetail.core.*
import de.baudetail.format.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import org.junit.Test
import org.junit.Assert.*
import java.io.ByteArrayOutputStream
class CatalogTest {
 @Test fun externalPackageAndUnknownAttributes(){val entry=BaudetailJson.decodeFromString<LibraryEntry>("""{"id":"external","type":"component","category":"a/b/c/d/e","name":"Neu","attributes":{"future_attribute":42,"nested":{"more":true}},"unrecognized":"ignored"}""");val out=ByteArrayOutputStream();Packages.library(out,LibraryPackage(entries=listOf(entry)),emptyMap());val catalog=Catalog();catalog.import(Packages.read(out.toByteArray().inputStream()).library(),ConflictPolicy.KEEP);assertEquals(1,catalog.search(category="a/b").size);assertEquals(listOf("42"),catalog.attributes()["future_attribute"])}
 @Test fun conflictPolicies(){val first=LibraryEntry(id="id",type="material",name="alt",category="Boden");val cat=Catalog(CatalogState(listOf(first)));val lib=LibraryPackage(entries=listOf(first.copy(name="neu")));cat.import(lib,ConflictPolicy.KEEP);assertEquals("alt",cat.entries().first().name);cat.import(lib,ConflictPolicy.REPLACE);assertEquals("neu",cat.entries().first().name);cat.import(lib,ConflictPolicy.COPY);assertEquals(2,cat.entries().size)}
 @Test fun handlesTenThousandEntries(){val cat=Catalog();cat.import(LibraryPackage(entries=(0 until 10000).map{LibraryEntry(id="id-$it",name="Produkt $it",type="component",category="Katalog/${it%40}")}),ConflictPolicy.KEEP);assertEquals(10000,cat.entries().size);assertEquals(250,cat.search(category="Katalog/3").size)}
}
