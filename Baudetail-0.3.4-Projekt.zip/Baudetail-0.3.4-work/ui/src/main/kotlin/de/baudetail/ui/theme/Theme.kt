package de.baudetail.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
object UiMetrics {val touch=48.dp;val gap=12.dp;val panel=300.dp;val radius=12.dp;val icon=24.dp}
val lightPalette=lightColorScheme(primary=Color(0xFF166554),secondary=Color(0xFF516764),tertiary=Color(0xFF87663A),background=Color(0xFFF5F7F4),surface=Color(0xFFFCFDF9),surfaceVariant=Color(0xFFE4EBE5),onPrimary=Color.White)
val darkPalette=darkColorScheme(primary=Color(0xFF90D5BE),secondary=Color(0xFFB3CCC4),background=Color(0xFF101B18),surface=Color(0xFF17231F),surfaceVariant=Color(0xFF2A3932))
val contrastPalette=lightColorScheme(primary=Color.Black,onPrimary=Color.White,background=Color.White,surface=Color.White,onSurface=Color.Black,outline=Color.Black,onSurfaceVariant=Color.Black)
@Composable fun BaudetailTheme(mode:String,content:@Composable ()->Unit){val dark=mode=="Dunkel"||(mode=="System"&&isSystemInDarkTheme());MaterialTheme(colorScheme=if(mode=="Hoher Kontrast")contrastPalette else if(dark)darkPalette else lightPalette,typography=Typography(),content=content)}
