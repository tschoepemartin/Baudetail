package de.baudetail.ui.components
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.export.CanvasRenderer
import de.baudetail.ui.BaudetailViewModel
@Composable fun AssemblyPreview(entry:LibraryEntry,vm:BaudetailViewModel){val renderer=remember{CanvasRenderer(vm.store::assetFile)}
 Canvas(Modifier.fillMaxWidth().height(130.dp)){val d=Drawing(entities=entry.geometry,sheet=Sheet(scale=1.0));val b=Bounds.of(entry.geometry.flatMap{listOf(entityBounds(it).min,entityBounds(it).max)});val scale=minOf(size.width/b.width.toFloat().coerceAtLeast(1f),size.height/b.height.toFloat().coerceAtLeast(1f))*.85f
  drawIntoCanvas{val c=it.nativeCanvas;c.save();c.translate(8f,8f);c.scale(scale,scale);c.translate(-b.min.x.toFloat(),-b.min.y.toFloat());renderer.draw(c,Scene.drawing(d,Project(libraryEntries=vm.catalog.entries())));c.restore()}
 }
}
