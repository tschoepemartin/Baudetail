package de.baudetail.ui.diagnostics

import android.app.Application
import android.os.Build
import java.io.File
import java.time.Instant
import java.util.ArrayDeque

/** Local only. No drawing names, text contents or exception messages in automatic reports. */
object Diagnostics {
 private var app:Application?=null
 private val events=ArrayDeque<String>()
 @Volatile var drawingId=""
 @Volatile var projectId=""
 @Volatile var view=""
 @Volatile var tool=""
 private fun directory()=File(requireNotNull(app).filesDir,"diagnostics").also{it.mkdirs()}
 fun version():String=runCatching {
  val a=requireNotNull(app)
  @Suppress("DEPRECATION") val p=a.packageManager.getPackageInfo(a.packageName,0)
  @Suppress("DEPRECATION") val code=if(Build.VERSION.SDK_INT>=28)p.longVersionCode else p.versionCode.toLong()
  "${p.versionName} ($code)"
 }.getOrDefault("unbekannt")
 fun install(application:Application){
  app=application
  val previous=Thread.getDefaultUncaughtExceptionHandler()
  Thread.setDefaultUncaughtExceptionHandler {thread,error->
   try {record(thread,error)}catch(ignored:Throwable){}
   if(previous!=null)previous.uncaughtException(thread,error)
   else {android.os.Process.killProcess(android.os.Process.myPid());kotlin.system.exitProcess(10)}
  }
 }
 @Synchronized fun log(event:String){try{events.addLast("${Instant.now()} ${event.take(160)}");while(events.size>40)events.removeFirst()}catch(ignored:Throwable){}}
 fun summary():String="Datum: ${Instant.now()}\nApp: ${version()}\nAndroid: ${Build.VERSION.RELEASE} (${Build.VERSION.SDK_INT})\nGerät: ${Build.MANUFACTURER} ${Build.MODEL}\n"
 fun record(thread:Thread,error:Throwable){try{
  val report=buildString {
   append(summary());append("Projekt-ID: $projectId\nZeichnungs-ID: $drawingId\nAnsicht: $view\nWerkzeug: $tool\nThread: ${thread.name}\n")
   // Exception messages can contain user text or complete JSON: deliberately omitted.
   val seen=java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable,Boolean>())
   fun stack(t:Throwable,prefix:String){if(!seen.add(t))return;append(prefix).append(t.javaClass.name).append('\n');t.stackTrace.forEach{append("  at $it\n")};t.suppressed.forEach{stack(it,"Suppressed: ")};t.cause?.let{stack(it,"Caused by: ")}}
   stack(error,"")
   synchronized(this@Diagnostics){events.forEach{append(it).append('\n')}}
  }
  val file=File(directory(),"crash-${System.currentTimeMillis()}.txt")
  java.io.FileOutputStream(file).use{it.write(report.toByteArray());it.fd.sync()}
  File(directory(),"pending").writeText(file.name)
  reports().drop(30).forEach{it.delete()}
 }catch(ignored:Throwable){} }
 fun reports():List<File> =runCatching{directory().listFiles().orEmpty().filter{it.name.startsWith("crash-")&&it.extension=="txt"}.sortedByDescending{it.name}}.getOrDefault(emptyList())
 fun pending()=runCatching{File(directory(),"pending").exists()}.getOrDefault(false)
 fun dismiss(){runCatching{File(directory(),"pending").delete()}}
 fun read(file:File)=runCatching{file.readText()}.getOrDefault("Bericht kann nicht gelesen werden.")
 fun delete(file:File):Boolean=runCatching{file.delete()}.getOrDefault(false)
 fun deleteAll(){reports().forEach(::delete);dismiss()}
}
