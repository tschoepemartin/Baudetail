package de.baudetail.ui.screens
import androidx.compose.foundation.layout.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import de.baudetail.libraries.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun LibraryScreen(vm:BaudetailViewModel,onBack:()->Unit,onImport:()->Unit,onFolder:()->Unit,onUse:(LibraryEntry)->Unit,assembliesOnly:Boolean=false,onEdit:()->Unit={}){
 var rename by remember{mutableStateOf<LibraryEntry?>(null)};var exportEntry by remember{mutableStateOf<LibraryEntry?>(null)}
 val save=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){uri->if(uri!=null)exportEntry?.let{vm.exportEntry(it,uri)}}
 var query by remember{mutableStateOf("")};var category by remember{mutableStateOf("")};var onlyFav by remember{mutableStateOf(false)};var showDisabled by remember{mutableStateOf(false)};var filterDialog by remember{mutableStateOf(false)};var categoryDialog by remember{mutableStateOf(false)}
 var chosen by remember{mutableStateOf<LibraryEntry?>(null)};val filters=remember{mutableStateMapOf<String,String>()}
 val version=vm.libraryVersion;val catalog=vm.catalog
 val items=remember(query,category,onlyFav,showDisabled,version,filters.toMap(),catalog){(if(showDisabled)unifiedMaterials(catalog.state.entries) else catalog.search(query,category,filters.toMap())).filter{(!onlyFav||it.id in catalog.state.favorites)&&it.name.contains(query,true)&&(!assembliesOnly||it.type=="assembly-template")}}
 Scaffold(topBar={TopAppBar(title={Text("${if(assembliesOnly)"Bauwerke"else"Bibliothek"} · ${items.size}")},navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Zurück")}},actions={IconButton(onClick=onImport){Icon(Icons.Default.FileOpen,"Bibliothek importieren")};IconButton(onClick=vm::reloadLibrary,enabled=vm.treeUri!=null){Icon(Icons.Default.Refresh,"Neu einlesen")}})}){padding->Column(Modifier.padding(padding).padding(12.dp)){
 OutlinedTextField(query,{query=it},label={Text("Material, Produkt oder Attribut suchen")},modifier=Modifier.fillMaxWidth(),leadingIcon={Icon(Icons.Default.Search,null)})
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={categoryDialog=true}){Text(category.ifEmpty{"Alle Kategorien"})};TextButton(onClick={filterDialog=true}){Text("Filter (${filters.size})")};IconToggleButton(onlyFav,{onlyFav=it}){Icon(if(onlyFav)Icons.Default.Star else Icons.Default.StarBorder,"Favoriten")}}
 Row{Checkbox(showDisabled,{showDisabled=it});Text("Auch deaktivierte Einträge",Modifier.padding(top=12.dp));TextButton(onClick=onFolder){Text("Ordner")}}
 if(items.isEmpty())Text("Keine passenden Einträge. Suche oder Filter ändern, oder eine .bdlib importieren.")
 LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.weight(1f)){items(items,key={it.id}){e->OutlinedCard(onClick={chosen=e}){Row(Modifier.fillMaxWidth().padding(12.dp)){Column(Modifier.weight(1f)){Text(e.name,style=MaterialTheme.typography.titleMedium);Text(e.category,style=MaterialTheme.typography.bodySmall);Text(e.attributes.entries.take(4).joinToString(" · "){"${it.key}: ${it.value}"},style=MaterialTheme.typography.bodySmall)};IconButton(onClick={catalog.toggleFavorite(e.id);vm.saveCatalog()}){Icon(if(e.id in catalog.state.favorites)Icons.Default.Star else Icons.Default.StarBorder,"Favorit umschalten")}}}}}
 }}
 if(categoryDialog){val categories=listOf("")+catalog.entries().map{it.category}.flatMap{val s=it.split('/');s.indices.map{i->s.take(i+1).joinToString("/")}}.distinct().sorted();ChoiceDialog("Kategorie",categories.map{it.ifEmpty{"Alle Kategorien"}},{categoryDialog=false}){category=categories[it]}}
 if(filterDialog){val attrs=catalog.attributes();FormDialog("Dynamische Attributfilter",attrs.keys.take(30).map{Field(it,it,filters[it].orEmpty())},{filterDialog=false}){values->filters.clear();filters.putAll(values.filterValues{it.isNotBlank()})}}
 rename?.let{entry->FormDialog("Bauwerksvorlage bearbeiten",listOf(Field("name","Name",entry.name),Field("category","Kategorie",entry.category)),{rename=null}){v->catalog.import(LibraryPackage(entries=listOf(entry.copy(name=v.getValue("name"),category=v.getValue("category"),version=entry.version+1))),ConflictPolicy.REPLACE);vm.saveCatalog()}}
 chosen?.let{entry->AlertDialog(onDismissRequest={chosen=null},title={Text(entry.name)},text={Column{Text(entry.category)
 if(entry.type=="assembly-template"){
  de.baudetail.ui.components.AssemblyPreview(entry,vm);Text("${entry.geometry.size} Objekte · Version ${entry.version} · Nullpunkt 0/0")
  TextButton(onClick={rename=entry;chosen=null}){Text("Umbenennen / Kategorie")}
  TextButton(onClick={vm.editAssembly(entry);chosen=null;onEdit()}){Text("Geometrie bearbeiten (Arbeitskopie)")}
  TextButton(onClick={catalog.import(LibraryPackage(entries=listOf(entry.copy(id=uid(),name=entry.name+" (Kopie)",version=1))),ConflictPolicy.COPY);vm.saveCatalog();chosen=null}){Text("Duplizieren")}
  TextButton(onClick={exportEntry=entry;save.launch(entry.name+".bdlib")}){Text("Exportieren")}
 }
 Text(entry.attributes.entries.joinToString("\n"){"${it.key}: ${it.value}"});TextButton(onClick={catalog.setEnabled(entry.id,entry.id in catalog.state.disabled);vm.saveCatalog();chosen=null}){Text(if(entry.id in catalog.state.disabled)"Aktivieren"else"Deaktivieren")};TextButton(onClick={catalog.remove(entry.id);vm.saveCatalog();chosen=null}){Text("Aus Bibliothek löschen")}}},confirmButton={TextButton(onClick={onUse(entry);chosen=null},enabled=vm.project!=null&&entry.id !in catalog.state.disabled){Text(if(entry.type=="material")"Auswahl zuweisen"else"Verwenden")}},dismissButton={TextButton(onClick={chosen=null}){Text("Schließen")}})}
}
