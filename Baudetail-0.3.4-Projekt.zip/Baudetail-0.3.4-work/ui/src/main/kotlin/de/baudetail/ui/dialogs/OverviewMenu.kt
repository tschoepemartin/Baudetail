package de.baudetail.ui.dialogs

import androidx.compose.material3.*
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.*
import de.baudetail.core.*
import de.baudetail.ui.*

@Composable fun OverviewMenu(vm:BaudetailViewModel,id:String,name:String,drawing:Boolean,onDismiss:()->Unit,onOpen:()->Unit,onExport:()->Unit){
 var action by remember{mutableStateOf("")}
 val choices=if(drawing)listOf("Öffnen","Umbenennen","Duplizieren","Exportieren / Teilen","In Projekt verschieben","Löschen")else listOf("Öffnen","Umbenennen","Duplizieren","Exportieren / Teilen","Projektinformationen","Löschen")
 if(action.isEmpty())AlertDialog(onDismissRequest=onDismiss,title={Text(name)},text={Column{choices.forEach{choice->TextButton(onClick={action=choice}){Text(choice)}}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})
 when(action){
  "Öffnen"->{LaunchedEffect(Unit){onOpen();onDismiss()}}
  "Exportieren / Teilen"->{LaunchedEffect(Unit){onExport();onDismiss()}}
  "Umbenennen"->FormDialog("Umbenennen",listOf(Field("name","Name",name)),onDismiss){if(drawing)vm.renameDrawing(id,it.getValue("name"))else vm.projectAction(id,"rename",it.getValue("name"))}
  "Duplizieren"->{LaunchedEffect(Unit){if(drawing)vm.duplicateDrawing(id)else vm.projectAction(id,"duplicate");onDismiss()}}
  "Löschen"->AlertDialog(onDismissRequest=onDismiss,title={Text("Wirklich löschen?")},text={Text("${if(drawing)"Zeichnung"else"Projekt"} „$name“ wirklich löschen?")},confirmButton={TextButton(onClick={if(drawing)vm.deleteDrawing(id)else vm.projectAction(id,"delete");onDismiss()}){Text("Löschen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
  "In Projekt verschieben"->{val targets=vm.records.filter{it.id!=vm.project?.id};ChoiceDialog("Zielprojekt",targets.map{it.name},onDismiss){vm.moveDrawing(id,targets[it].id)}}
  "Projektinformationen"->AlertDialog(onDismissRequest=onDismiss,title={Text(name)},text={Text("${vm.records.find{it.id==id}?.drawings?:0} Zeichnungen\nProjekt-ID: $id")},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})
 }
}
