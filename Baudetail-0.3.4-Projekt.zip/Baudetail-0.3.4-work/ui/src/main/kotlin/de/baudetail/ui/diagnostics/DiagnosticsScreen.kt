package de.baudetail.ui.diagnostics

import android.content.ClipData
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import de.baudetail.ui.*
import java.io.File

@Composable fun DiagnosticsScreen(vm:BaudetailViewModel,onBack:()->Unit){
 val context=LocalContext.current
 var reports by remember{mutableStateOf(Diagnostics.reports())}
 var current by remember{mutableStateOf<File?>(null)}
 var pending by remember{mutableStateOf("")}
 var problem by remember{mutableStateOf<String?>(null)}
 val save=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){uri->
  if(uri!=null)runCatching{context.contentResolver.openOutputStream(uri,"wt")?.use{it.write(pending.toByteArray())}?:error("Datei nicht beschreibbar")}.onFailure{problem="Bericht konnte nicht exportiert werden."}
 }
 fun share(file:File){runCatching{
  val output=File(context.cacheDir,"exports/${file.name}");output.parentFile?.mkdirs();file.copyTo(output,true)
  val uri=FileProvider.getUriForFile(context,"${context.packageName}.files",output)
  context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newRawUri("Crashbericht",uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Crashbericht teilen"))
 }.onFailure{problem="Bericht konnte nicht geteilt werden."}}
 Page("Diagnose",onBack){
  Text("Crashberichte bleiben lokal. Projekttexte und persönliche Namen werden nicht automatisch aufgenommen.")
  Button(onClick={pending=Diagnostics.summary()+"Projekte: ${vm.records.size}\nZeichnungen: ${vm.records.sumOf{it.drawings}}\nBibliothekseinträge: ${vm.catalog.entries().size}\n"+vm.catalog.entries().joinToString("\n"){"${it.id}: Version ${it.version}"};save.launch("Baudetail-Diagnose.txt")}){Text("Diagnosebericht exportieren")}
  if(reports.isEmpty())Text("Keine Crashberichte vorhanden.")
  reports.forEach{file->
   Text(file.name)
   Text(Diagnostics.read(file).lineSequence().firstOrNull{it.startsWith("java.")||it.startsWith("android.")||it.startsWith("kotlin.")}.orEmpty())
   Text(Diagnostics.read(file).lineSequence().firstOrNull{it.startsWith("App:")}.orEmpty())
   Row{TextButton(onClick={current=file}){Text("Ansehen")};TextButton(onClick={pending=Diagnostics.read(file);save.launch(file.name)}){Text("Exportieren")}}
   Row{TextButton(onClick={share(file)}){Text("Teilen")};TextButton(onClick={if(!Diagnostics.delete(file))problem="Löschen fehlgeschlagen";reports=Diagnostics.reports()}){Text("Löschen")}}
  }
  if(reports.isNotEmpty())OutlinedButton(onClick={Diagnostics.deleteAll();reports=Diagnostics.reports()}){Text("Alle löschen")}
 }
 current?.let{file->AlertDialog(onDismissRequest={current=null},title={Text("Crashbericht")},text={Text(Diagnostics.read(file),Modifier.verticalScroll(rememberScrollState()))},confirmButton={TextButton(onClick={current=null}){Text("Schließen")}})}
 problem?.let{AlertDialog(onDismissRequest={problem=null},text={Text(it)},confirmButton={TextButton(onClick={problem=null}){Text("OK")}})}
}
