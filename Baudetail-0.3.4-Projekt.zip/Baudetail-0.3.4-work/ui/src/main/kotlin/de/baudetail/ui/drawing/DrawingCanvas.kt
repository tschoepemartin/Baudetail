package de.baudetail.ui.drawing

import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Modifier
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.export.CanvasRenderer
import java.io.File
import kotlin.math.*

@OptIn(ExperimentalComposeUiApi::class)
@Composable fun DrawingCanvas(
 d:Drawing,p:Project,asset:(String)->File,tool:String,selected:Set<String>,preview:List<Vec>,grid:Boolean,penMode:Boolean,fit:Int,
 modifier:Modifier=Modifier,onTap:(Vec,Boolean)->Unit,onFreehand:(List<Vec>)->Unit,onMove:(Vec,SnapResult?,Vec?)->Unit,onDeleteRequested:()->Unit={},onCoordinates:(Vec,Double)->Unit,onCreate:(Entity)->Unit,onChange:(Entity)->Unit
){
 var zoom by rememberSaveable(d.id){mutableDoubleStateOf(0.06)};var ox by rememberSaveable(d.id){mutableDoubleStateOf(60.0)};var oy by rememberSaveable(d.id){mutableDoubleStateOf(60.0)}
 var width by remember{mutableIntStateOf(1)};var height by remember{mutableIntStateOf(1)}
 val renderer=remember{CanvasRenderer(asset)}
 val density=LocalDensity.current
 val touchPx=24f*density.density
 val labelPx=14f*density.density*density.fontScale
 val gripPx=7f*density.density
 val rotationOffset=36f*density.density
 val input=d.input()
 var live by remember(d.id,tool){mutableStateOf<Entity?>(null)}
 var snapMark by remember(d.id,tool){mutableStateOf<SnapResult?>(null)}
 var handle by remember{mutableStateOf("")}
 var original by remember{mutableStateOf<Entity?>(null)}
 fun caught(v:Vec,previous:Vec?=null,exclude:Set<String> = emptySet()):Vec {val result=snap(v,d.copy(entities=d.entities.filterNot{it.id in exclude}),input.options(touchPx/zoom),previous);snapMark=result.takeIf{it.reason.isNotEmpty()};return result.point}
 var down by remember{mutableStateOf(Vec())};var last by remember{mutableStateOf(Vec())};var downWorld by remember{mutableStateOf(Vec())};var moved by remember{mutableStateOf(false)};var pinch by remember{mutableStateOf(false)};var panMode by remember{mutableStateOf(false)};var dragSnap by remember{mutableStateOf<SnapResult?>(null)};var dragSourceOffset by remember{mutableStateOf<Vec?>(null)}
 var previousDistance by remember{mutableDoubleStateOf(1.0)};var previousCenter by remember{mutableStateOf(Vec())};var downTime by remember{mutableLongStateOf(0)};var stroke by remember{mutableStateOf<List<Vec>>(emptyList())};var dragDelta by remember{mutableStateOf(Vec())};var dragging by remember{mutableStateOf(false)}
 val scene=remember(d,p){Scene.drawing(d,p)}
 fun world(v:Vec)=Vec((v.x-ox)/zoom,(v.y-oy)/zoom)
 LaunchedEffect(d.id,fit,width,height){if(width>1&&height>1){val pts=d.entities.filter{visibleIn(it,d)}.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)};val b=if(pts.isEmpty())Bounds(Vec(),Vec(10000.0,7000.0))else Bounds.of(pts);zoom=min((width-100).coerceAtLeast(100)/b.width.coerceAtLeast(200.0),(height-100).coerceAtLeast(100)/b.height.coerceAtLeast(200.0)).coerceIn(0.001,20.0);ox=width/2.0-b.center.x*zoom;oy=height/2.0-b.center.y*zoom}}
 Canvas(modifier.testTag("drawing-canvas").clipToBounds().background(Color.White).onSizeChanged{width=it.width;height=it.height}.pointerInteropFilter{event->
  val pos=Vec(event.x.toDouble(),event.y.toDouble())
  when(event.actionMasked){
   MotionEvent.ACTION_DOWN->{
    down=pos;last=pos;downWorld=world(pos);moved=false;pinch=false;downTime=event.eventTime
    panMode=tool=="pan"||(penMode&&event.getToolType(0)!=MotionEvent.TOOL_TYPE_STYLUS)
    stroke=if(tool=="freehand"&&!panMode)listOf(downWorld)else emptyList();dragDelta=Vec();dragSnap=null;dragSourceOffset=null;live=null;handle="";original=null
    val e=d.entities.singleOrNull{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true}
    if(tool=="select"&&!panMode&&e!=null){val b=viewBounds(e,d);original=e
     handle=when{e.str("labelEnabled")=="true"&&downWorld.distance(objectLabelPosition(e,d))<touchPx*2/zoom->"label";downWorld.distance(Vec(b.center.x,b.min.y-rotationOffset/zoom))<touchPx/zoom->"rotate";downWorld.distance(b.max)<touchPx/zoom->"scale";else->""}
    }
    dragging=tool=="select"&&!panMode&&(handle.isNotEmpty()||d.entities.any{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true&&visibleIn(it,d)&&hitTest(downWorld,it,d,touchPx/zoom)})
    if(tool in dragShapeTools&&!panMode)downWorld=caught(downWorld)
    true
   }
   MotionEvent.ACTION_POINTER_DOWN->{pinch=true;dragging=false;live=null;stroke=emptyList();snapMark=null;if(event.pointerCount>=2){previousDistance=hypot((event.getX(1)-event.getX(0)).toDouble(),(event.getY(1)-event.getY(0)).toDouble());previousCenter=Vec((event.getX(0)+event.getX(1))/2.0,(event.getY(0)+event.getY(1))/2.0)};true}
   MotionEvent.ACTION_MOVE->{
    if(event.pointerCount>=2){val center=Vec((event.getX(0)+event.getX(1))/2.0,(event.getY(0)+event.getY(1))/2.0);val dist=hypot((event.getX(1)-event.getX(0)).toDouble(),(event.getY(1)-event.getY(0)).toDouble());val anchor=world(previousCenter);zoom=(zoom*(dist/previousDistance.coerceAtLeast(1.0))).coerceIn(0.0005,50.0);ox=center.x-anchor.x*zoom;oy=center.y-anchor.y*zoom;previousCenter=center;previousDistance=dist;pinch=true}
    else if(!pinch){if(pos.distance(down)>8*density.density)moved=true;if(panMode){ox+=pos.x-last.x;oy+=pos.y-last.y}else if(tool=="freehand"&&pos.distance(last)>2){stroke=stroke+world(pos)}else if(dragging){
      val e=original
      if(e!=null&&handle.isNotEmpty()) {val bounds=viewBounds(e,d);val target=world(pos)
       live=when(handle){
        "label"->{val center=bounds.center;e.withNum("labelDx",target.x-center.x).withNum("labelDy",target.y-center.y)}
        "rotate"->{val snapped=caught(target,exclude=selected);val center=smartPivot(e);val a=atan2(downWorld.y-center.y,downWorld.x-center.x);val b=atan2(snapped.y-center.y,snapped.x-center.x);val step=if(input.ortho)90.0 else input.angleStep;val degrees=Math.toDegrees(b-a);transform(e,angle=if(step>0)round(degrees/step)*step else degrees,center=center)}
        else->{val snapped=caught(target,exclude=selected);val anchor=bounds.min;val factor=(snapped.distance(anchor)/bounds.max.distance(anchor).coerceAtLeast(1e-9)).coerceIn(0.001,1000.0);transform(e,factor=factor,center=anchor)}
       }
      } else {
       val moving=d.entities.singleOrNull{it.id in selected};val raw=world(pos)-downWorld;val others=d.copy(entities=d.entities.filterNot{it.id in selected})
       if(moving!=null&&(moving.kind=="component"||isStair(moving))){
        val origin=moving.points.firstOrNull()?:downWorld;val refs=smartSnapReferencePoints(moving,d)
        data class Choice(val result:SnapResult,val offset:Vec,val correction:Double,val rank:Int)
        val choices=refs.mapNotNull{ref->val r=snap(ref+raw,others,input.options(touchPx/zoom));if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else Choice(r,ref-origin,r.point.distance(ref+raw),when(r.priority){"high"->0;"low"->2;else->1})}
        val best=choices.minWithOrNull(compareBy<Choice>{it.rank}.thenBy{it.correction})
        if(best!=null){dragDelta=raw+(best.result.point-(origin+best.offset+raw));dragSnap=best.result;dragSourceOffset=best.offset;snapMark=best.result}
        else {val r=snap(origin+raw,others,input.options(touchPx/zoom),origin);dragDelta=r.point-origin;dragSnap=r.takeIf{it.anchor!=null};dragSourceOffset=Vec();snapMark=r.takeIf{it.reason.isNotEmpty()}}
       } else {val anchor=d.entities.firstOrNull{it.id in selected}?.points?.firstOrNull()?:downWorld;val r=snap(anchor+raw,others,input.options(touchPx/zoom),anchor);dragDelta=r.point-anchor;dragSnap=r.takeIf{it.anchor!=null};dragSourceOffset=Vec();snapMark=r.takeIf{it.reason.isNotEmpty()}}
      }
     }else if(tool in dragShapeTools){val target=caught(world(pos),if(tool in setOf("rect","building","area"))null else downWorld);if(target.distance(downWorld)>1e-9&&(tool !in setOf("rect","building","area")||(abs(target.x-downWorld.x)>1e-9&&abs(target.y-downWorld.y)>1e-9)))live=shapeFromDrag(tool,downWorld,target)else live=null};last=pos}
    onCoordinates(world(pos),zoom);true
   }
   MotionEvent.ACTION_UP->{if(!pinch){if(!panMode){val deleteDrop=dragging&&moved&&handle.isEmpty()&&pos.x>width-110*density.density&&pos.y<125*density.density;if(deleteDrop)onDeleteRequested()else if(tool=="freehand"&&stroke.size>1)onFreehand(stroke)else if(moved&&live!=null){if(dragging)onChange(live!!)else onCreate(live!!)}else if(dragging&&moved)onMove(dragDelta,dragSnap,dragSourceOffset)else if(!moved)onTap(world(pos),event.eventTime-downTime>500)} };dragging=false;dragDelta=Vec();stroke=emptyList();live=null;snapMark=null;handle="";pinch=false;true}
   MotionEvent.ACTION_CANCEL->{dragging=false;dragDelta=Vec();stroke=emptyList();live=null;snapMark=null;handle="";pinch=false;true}
   else->true
  }
 }){
  val canvas=drawContext.canvas.nativeCanvas;canvas.save();canvas.clipRect(0f,0f,size.width,size.height);canvas.translate(ox.toFloat(),oy.toFloat());canvas.scale(zoom.toFloat(),zoom.toFloat())
  if(d.sheet.showPaper){val a=d.sheet.origin;val rect=android.graphics.RectF(a.x.toFloat(),a.y.toFloat(),(a.x+(d.sheet.widthMm-20)*d.sheet.scale).toFloat(),(a.y+(d.sheet.heightMm-42)*d.sheet.scale).toFloat());canvas.drawRect(rect,android.graphics.Paint().apply{color=android.graphics.Color.rgb(245,248,244)});canvas.drawRect(rect,android.graphics.Paint().apply{color=android.graphics.Color.LTGRAY;style=android.graphics.Paint.Style.STROKE;strokeWidth=(1/zoom).toFloat()})}
  if(grid){var spacing=d.gridMm;while(spacing*zoom<14)spacing*=5;val min=world(Vec());val max=world(Vec(width.toDouble(),height.toDouble()));val pen=android.graphics.Paint().apply{color=android.graphics.Color.rgb(217,226,222);strokeWidth=(1/zoom).toFloat()};var x=floor((min.x-d.origin.x)/spacing)*spacing+d.origin.x;var count=0;while(x<max.x&&count++<500){canvas.drawLine(x.toFloat(),min.y.toFloat(),x.toFloat(),max.y.toFloat(),pen);x+=spacing};var y=floor((min.y-d.origin.y)/spacing)*spacing+d.origin.y;count=0;while(y<max.y&&count++<500){canvas.drawLine(min.x.toFloat(),y.toFloat(),max.x.toFloat(),y.toFloat(),pen);y+=spacing}}
  renderer.draw(canvas,scene)
  val selectionStyle=Style(stroke="#D0802E",widthMm=2/zoom)
  selected.forEach{id->d.entities.find{it.id==id&&visibleIn(it,d)}?.let{e->val b=viewBounds(e,d);renderer.draw(canvas,listOf(Primitive.Path(rectangle(b.min,b.max),true,selectionStyle)));if(tool=="select"&&selected.size==1&&!e.locked&&d.layers.find{it.id==e.layerId}?.locked!=true){
    val rotation=Vec(b.center.x,b.min.y-rotationOffset/zoom)
    val grips=mutableListOf<Primitive>(Primitive.Path(listOf(Vec(b.center.x,b.min.y),rotation),style=selectionStyle),Primitive.Circle(b.max,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")),Primitive.Circle(rotation,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))
    if(e.str("labelEnabled")=="true")grips.add(Primitive.Circle(objectLabelPosition(e,d),gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))
    renderer.draw(canvas,grips)
   };if(dragging&&handle.isEmpty())renderer.draw(canvas,Scene.entity(transform(e,translation=dragDelta),d,p))}}
  renderer.draw(canvas,listOf(Primitive.Path(preview+stroke,style=Style(stroke="#1879A2",widthMm=2/zoom))))
  live?.let{e->
   renderer.draw(canvas,Scene.entity(e.copy(style=e.style.copy(stroke="#1879A2",opacity=.7)),d,p))
   val b=viewBounds(e,d);val font=labelPx/zoom
   val labelStyle=Style(stroke="#12516A",background="#FFFFFF",align="center")
   val labels=if(e.kind in setOf("rect","building","area")&&e.points.size==4) {
    listOf(Primitive.Text(Vec(b.center.x,b.min.y-font*.7),"${fmt(e.points[0].distance(e.points[1]))} mm",font,labelStyle),Primitive.Text(Vec(b.max.x+font*.8,b.center.y),"${fmt(e.points[0].distance(e.points[3]))} mm",font,labelStyle.copy(align="left")))
   } else listOf(Primitive.Text(b.min-Vec(0.0,font*.7),if(e.kind in setOf("circle","arc"))"R ${fmt(e.num("radiusMm"))} mm"else "${fmt(length(e.points))} mm",font,labelStyle.copy(align="left")))
   renderer.draw(canvas,labels)
  }
  snapMark?.let{mark->renderer.draw(canvas,listOf(Primitive.Circle(mark.point,gripPx/zoom,selectionStyle.copy(stroke="#B63586")),Primitive.Text(mark.point+Vec(labelPx/zoom,-labelPx/zoom),mark.reason,labelPx/zoom,Style(stroke="#B63586",background="#FFFFFF"))))}
  preview.forEach{renderer.draw(canvas,listOf(Primitive.Circle(it,4/zoom,selectionStyle.copy(fill="#D0802E"))))}
  renderer.draw(canvas,listOf(Primitive.Path(listOf(d.origin-Vec(60/zoom,0.0),d.origin+Vec(60/zoom,0.0)),style=Style(stroke="#B0BDB8",widthMm=1/zoom)),Primitive.Path(listOf(d.origin-Vec(0.0,60/zoom),d.origin+Vec(0.0,60/zoom)),style=Style(stroke="#B0BDB8",widthMm=1/zoom))))
  canvas.restore()
  if(dragging&&handle.isEmpty()&&selected.isNotEmpty()){
   val r=android.graphics.RectF(size.width-94*density.density,18*density.density,size.width-18*density.density,94*density.density)
   val over=last.x>size.width-110*density.density&&last.y<125*density.density
   val fill=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=if(over)android.graphics.Color.rgb(210,70,60)else android.graphics.Color.rgb(245,225,222);style=android.graphics.Paint.Style.FILL}
   val strokePaint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(150,45,40);style=android.graphics.Paint.Style.STROKE;strokeWidth=2*density.density}
   canvas.drawRoundRect(r,14*density.density,14*density.density,fill);canvas.drawRoundRect(r,14*density.density,14*density.density,strokePaint)
   val cx=r.centerX();val cy=r.centerY();canvas.drawRect(cx-14*density.density,cy-10*density.density,cx+14*density.density,cy+18*density.density,strokePaint);canvas.drawLine(cx-18*density.density,cy-16*density.density,cx+18*density.density,cy-16*density.density,strokePaint);canvas.drawLine(cx-7*density.density,cy-21*density.density,cx+7*density.density,cy-21*density.density,strokePaint)
  }
 }
}
