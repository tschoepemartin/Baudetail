package de.baudetail.ui.dialogs

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*

@Composable fun StairDialog(entries:List<LibraryEntry>,initial:Entity,onDismiss:()->Unit,onSave:(Entity,LibraryEntry)->Unit){
 val types=entries.filter{it.isStairStep()}.distinctBy{it.id}
 var entryId by remember{mutableStateOf(initial.libraryId?:types.firstOrNull()?.id)}
 val labels=linkedMapOf("stepCount" to "Stufenanzahl (1–100)","riseMm" to "Stufenhöhe mm","goingMm" to "Auftritt mm","depthMm" to "Stufentiefe mm (Bibliotheksmaß)","crossSlope" to "Quergefälle %","widthMm" to "Treppenbreite mm","totalHeightMm" to "Gesamthöhe mm","totalLengthMm" to "Gesamtlänge mm","slope" to "Stufengefälle %","rotation" to "Laufrichtung °")
 val defaults=mapOf("stepCount" to 5.0,"riseMm" to 150.0,"goingMm" to 350.0,"depthMm" to (types.find{it.id==entryId}?.attribute("depth_mm",types.find{it.id==entryId}?.attribute("section_width_mm",400.0)?:400.0)?:400.0),"crossSlope" to 0.0,"widthMm" to 1200.0,"totalHeightMm" to 750.0,"totalLengthMm" to 1750.0,"slope" to 0.0,"rotation" to initial.rotation)
 val values=remember{mutableStateMapOf<String,String>().apply{labels.keys.forEach{put(it,fmt(initial.num(it,defaults.getValue(it))))}}}
 var fixedHeight by remember{mutableStateOf(initial.str("heightMode")=="total")}
 var fixedLength by remember{mutableStateOf(initial.str("lengthMode")=="total")}
 var menu by remember{mutableStateOf(false)}
 val numbers=values.mapValues{parseNumber(it.value)}
 val numericValid=numbers.values.all{it!=null} && numbers.getValue("stepCount")?.let{it in 1.0..100.0&&it%1.0==0.0}==true && listOf("riseMm","goingMm","widthMm","totalHeightMm","totalLengthMm").all{(numbers[it]?:0.0)>0}
 var preview=initial.withStr("assemblyType","stair").withStr("heightMode",if(fixedHeight)"total"else"step").withStr("lengthMode",if(fixedLength)"total"else"step").withNum("mirrored",initial.num("mirrored"))
 numbers.forEach{(k,v)->if(v!=null)preview=preview.withNum(k,v)}
 val valid=numericValid&&stairGoing(preview)>0&&stairGoing(preview)<=stairDepth(preview)
 preview=preview.copy(kind="assembly",libraryId=entryId,rotation=numbers["rotation"]?:initial.rotation)
 val line=MaterialTheme.colorScheme.primary
 AlertDialog(onDismissRequest=onDismiss,title={Text("Bauwerke · Treppe")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  if(types.isEmpty())Text("Keine Stufen in der Bibliothek. Importiere passende .bdlib-Bauteile oder kennzeichne sie mit assembly_role = stair_step.")
  Box{OutlinedButton(onClick={menu=true}){Text(types.find{it.id==entryId}?.name?:"Stufentyp wählen")};DropdownMenu(menu,{menu=false}){types.forEach{entry->DropdownMenuItem(text={Text(entry.name)},onClick={entryId=entry.id;values["depthMm"]=fmt(entry.attribute("depth_mm",entry.attribute("section_width_mm",400.0)));values["riseMm"]=fmt(entry.attribute("section_height_mm",entry.attribute("height_mm",150.0)));values["widthMm"]=fmt(entry.attribute("length_mm",1000.0));menu=false})}}}
  Text("Stufentiefe ${fmt(stairDepth(preview))} mm · Überdeckung ${fmt(stairDepth(preview)-stairGoing(preview))} mm")
  labels.forEach{(key,label)->OutlinedTextField(values[key].orEmpty(),{values[key]=it},label={Text(label)},singleLine=true)}
  Row{Checkbox(fixedHeight,{fixedHeight=it});Text("Gesamthöhe fix → Stufenhöhe berechnen")}
  Row{Checkbox(fixedLength,{fixedLength=it});Text("Gesamtlänge fix → Auftritt berechnen")}
  if(valid){Text("${stairCount(preview)} Stufen · ${fmt(stairRise(preview))} mm hoch · ${fmt(stairGoing(preview))} mm Auftritt")
   Canvas(Modifier.fillMaxWidth().height(100.dp)){
    val pts=stairLocalPoints(preview,"section");val b=Bounds.of(pts);val scale=minOf(size.width/(b.width.toFloat()+1),size.height/(b.height.toFloat()+1))*.9f
    fun offset(v:Vec)=Offset(8+(v.x-b.min.x).toFloat()*scale,4+(v.y-b.min.y).toFloat()*scale)
    pts.zipWithNext().forEach{(a,c)->drawLine(line,offset(a),offset(c),2f)}
   }
  }else Text("Bitte gültige Maße und eine ganze Stufenanzahl eingeben.")
 }},confirmButton={TextButton(enabled=valid&&types.any{it.id==entryId},onClick={val entry=types.first{it.id==entryId};onSave(preview.copy(name=entry.name,materialId=entry.id),entry);onDismiss()}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
