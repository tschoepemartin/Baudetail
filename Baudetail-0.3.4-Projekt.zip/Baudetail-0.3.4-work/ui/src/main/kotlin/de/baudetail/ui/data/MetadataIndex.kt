package de.baudetail.ui.data
import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import de.baudetail.projects.ProjectRecord
class MetadataIndex(context:Context):SQLiteOpenHelper(context,"projects-index.db",null,2) {
 override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE projects(id TEXT PRIMARY KEY, name TEXT NOT NULL, updated INTEGER NOT NULL, drawings INTEGER NOT NULL, created INTEGER NOT NULL DEFAULT 0)")}
 override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){if(oldVersion<2)db.execSQL("ALTER TABLE projects ADD COLUMN created INTEGER NOT NULL DEFAULT 0")}
 fun replace(records:List<ProjectRecord>){writableDatabase.apply{beginTransaction();try{delete("projects",null,null);records.forEach{insertOrThrow("projects",null,ContentValues().apply{put("id",it.id);put("name",it.name);put("updated",it.updatedAt);put("drawings",it.drawings);put("created",it.createdAt)})};setTransactionSuccessful()}finally{endTransaction()}}}
 fun list():List<ProjectRecord> = readableDatabase.rawQuery("SELECT id,name,updated,drawings,created FROM projects ORDER BY updated DESC",null).use{c->buildList{while(c.moveToNext())add(ProjectRecord(c.getString(0),c.getString(1),c.getLong(2),c.getInt(3),c.getLong(4)))}}
}
