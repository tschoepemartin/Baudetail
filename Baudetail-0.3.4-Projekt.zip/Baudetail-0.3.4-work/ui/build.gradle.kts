plugins { alias(libs.plugins.android.library); alias(libs.plugins.kotlin.android); alias(libs.plugins.kotlin.serialization); alias(libs.plugins.compose.compiler) }
android {
 namespace = "de.baudetail.ui"
 compileSdk = 35
 buildToolsVersion = "35.0.0"
 defaultConfig { minSdk = 26 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
 buildFeatures { compose = true }
}
dependencies {
 api(project(":projects"))
 api(project(":export"))
 implementation(libs.core)
 implementation(libs.serialization)
 implementation(platform(libs.compose.bom))
 implementation(libs.compose.ui)
 implementation(libs.compose.foundation)
 implementation(libs.compose.material3)
 implementation(libs.compose.icons)
 implementation(libs.activity)
 implementation(libs.lifecycle)
 implementation(libs.viewmodel.compose)
 implementation(libs.navigation)
 implementation(libs.coroutines)
 implementation(libs.documentfile)
 implementation(libs.androidsvg)
}
