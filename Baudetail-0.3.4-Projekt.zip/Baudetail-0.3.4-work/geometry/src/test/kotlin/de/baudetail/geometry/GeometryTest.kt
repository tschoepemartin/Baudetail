package de.baudetail.geometry
import org.junit.Test
import org.junit.Assert.*
class GeometryTest {
 @Test fun physicalScale(){assertEquals(100.0,paperMm(1000.0,10.0),0.0);assertEquals(283.46456692913387,pdfPoints(paperMm(1000.0,10.0)),1e-10)}
 @Test fun slope(){assertEquals(2.0,slopePercent(5000.0,100.0),0.0)}
 @Test fun realArea(){val p=rectangle(Vec(),Vec(4000.0,3000.0));assertEquals(12.0,area(p)/1e6,0.0);assertEquals(14000.0,length(p,true),0.0)}
 @Test fun concaveArea(){assertEquals(3.0,area(listOf(Vec(),Vec(2.0,0.0),Vec(2.0,1.0),Vec(1.0,1.0),Vec(1.0,2.0),Vec(0.0,2.0))),0.0)}
 @Test fun intersection(){assertEquals(Vec(5.0,5.0),intersection(Vec(),Vec(10.0,10.0),Vec(0.0,10.0),Vec(10.0,0.0)));assertNull(intersection(Vec(),Vec(1.0,1.0),Vec(2.0,0.0),Vec(3.0,1.0)))}
 @Test fun hedgeIncludesEnds(){assertEquals(14,hedgeCount(5000.0,400.0));assertEquals(1,hedgeCount(0.0,400.0))}
 @Test fun germanDecimals(){assertEquals(12.5,parseNumber("12,5")!!,0.0);assertNull(parseNumber("NaN"));assertNull(parseNumber("1,2,3"))}
 @Test(expected=IllegalArgumentException::class) fun invalidScale(){paperMm(10.0,0.0)}
 @Test fun rotateDoesNotChangeLength(){assertEquals(5000.0,Vec(3000.0,4000.0).rotate(37.0).length(),1e-8)}
}
