package de.baudetail.geometry

import kotlinx.serialization.Serializable
import kotlin.math.*

@Serializable data class Vec(val x: Double = 0.0, val y: Double = 0.0) {
    operator fun plus(v: Vec) = Vec(x + v.x, y + v.y)
    operator fun minus(v: Vec) = Vec(x - v.x, y - v.y)
    operator fun times(s: Double) = Vec(x * s, y * s)
    fun length() = hypot(x, y)
    fun distance(v: Vec) = (this - v).length()
    fun rotate(degrees: Double, center: Vec = Vec()): Vec {
        val a = Math.toRadians(degrees); val p = this - center
        return center + Vec(p.x * cos(a) - p.y * sin(a), p.x * sin(a) + p.y * cos(a))
    }
    fun finite() = x.isFinite() && y.isFinite() && abs(x) <= 1e12 && abs(y) <= 1e12
}
@Serializable data class Bounds(val min: Vec, val max: Vec) {
    val width get() = max.x - min.x
    val height get() = max.y - min.y
    val center get() = (min + max) * 0.5
    fun contains(p: Vec, tolerance: Double = 0.0) = p.x >= min.x-tolerance && p.x <= max.x+tolerance && p.y >= min.y-tolerance && p.y <= max.y+tolerance
    companion object { fun of(p: List<Vec>) = if (p.isEmpty()) Bounds(Vec(), Vec()) else Bounds(Vec(p.minOf { it.x },p.minOf { it.y }),Vec(p.maxOf { it.x },p.maxOf { it.y })) }
}
fun length(points: List<Vec>, closed: Boolean = false): Double = points.zipWithNext().sumOf { (a,b) -> a.distance(b) } + if(closed && points.size>2) points.last().distance(points.first()) else 0.0
fun area(points: List<Vec>): Double = if(points.size<3) 0.0 else abs(points.indices.sumOf { i -> val a=points[i]; val b=points[(i+1)%points.size]; a.x*b.y-b.x*a.y }) / 2
fun cross(a: Vec,b: Vec) = a.x*b.y-a.y*b.x
fun closestOnSegment(p: Vec, a: Vec, b: Vec): Vec { val d=b-a; val l=d.x*d.x+d.y*d.y; if(l<1e-15) return a; return a + d*((((p-a).x*d.x+(p-a).y*d.y)/l).coerceIn(0.0,1.0)) }
fun intersection(a: Vec,b: Vec,c: Vec,d: Vec): Vec? {
    val r=b-a; val s=d-c; val den=cross(r,s); if(abs(den)<1e-10) return null
    val t=cross(c-a,s)/den; val u=cross(c-a,r)/den
    return if(t in -1e-9..1.000000001 && u in -1e-9..1.000000001) a+r*t else null
}
fun inside(p: Vec, poly: List<Vec>): Boolean {
    var result=false
    if(poly.size<3) return false
    var j=poly.lastIndex
    for(i in poly.indices) { val a=poly[i]; val b=poly[j]; if((a.y>p.y)!=(b.y>p.y) && p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x) result=!result; j=i }
    return result
}
fun slopePercent(distanceMm: Double, deltaMm: Double): Double { require(distanceMm>0 && distanceMm.isFinite() && deltaMm.isFinite()); return 100*deltaMm/distanceMm }
fun paperMm(realMm: Double, scale: Double): Double { require(scale>0 && scale.isFinite()); return realMm/scale }
fun pdfPoints(mm: Double) = mm*72.0/25.4
fun hedgeCount(lengthMm: Double, spacingMm: Double, includeEnds: Boolean = true): Int { require(spacingMm>0 && lengthMm>=0); return if(lengthMm==0.0) 1 else ceil(lengthMm/spacingMm).toInt() + if(includeEnds) 1 else 0 }
fun parseNumber(input: String): Double? = input.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }
fun rectangle(a: Vec,b: Vec) = listOf(a,Vec(b.x,a.y),b,Vec(a.x,b.y))
fun pointAt(points: List<Vec>, distance: Double): Vec {
    var rest=distance
    for((a,b) in points.zipWithNext()) { val len=a.distance(b); if(rest<=len && len>0) return a+(b-a)*(rest/len); rest-=len }
    return points.lastOrNull() ?: Vec()
}
