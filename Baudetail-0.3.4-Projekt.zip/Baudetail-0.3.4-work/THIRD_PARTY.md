# Drittanbieter

- Gradle Wrapper 8.11.1: aus dem offiziellen Gradle-Repository, Apache License 2.0. Quellen und Lizenz: https://github.com/gradle/gradle/tree/v8.11.1
- Kotlin, Coroutines und kotlinx.serialization: JetBrains / Kotlin-Projekt; über Maven referenziert.
- AndroidX / Jetpack Compose: Android Open Source Project; über Google Maven referenziert.
- AndroidSVG 1.4: Paul LeBeau, Apache License 2.0; über Maven referenziert.

Im Quellpaket ist nur die Gradle-Wrapper-JAR als Build-Binärdatei mitgeliefert. Android-/AndroidX-/Kotlin-Laufzeitbibliotheken werden regulär über die festgelegten Abhängigkeiten bezogen. Beispielgeometrien und Bibliothekseinträge wurden für dieses Projekt angelegt; keine Herstellerproduktdaten werden als geprüft oder zertifiziert dargestellt.
