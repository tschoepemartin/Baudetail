plugins { `java-library`; alias(libs.plugins.kotlin.jvm); alias(libs.plugins.kotlin.serialization) }
kotlin { jvmToolchain(17) }
dependencies {
 implementation(libs.serialization)
 testImplementation(libs.junit)
 api(project(":libraries"))
}
