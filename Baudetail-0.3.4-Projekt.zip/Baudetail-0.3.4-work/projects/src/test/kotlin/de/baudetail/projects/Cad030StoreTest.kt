package de.baudetail.projects
import de.baudetail.core.*
import de.baudetail.format.*
import de.baudetail.geometry.*
import org.junit.Test
import org.junit.Assert.*
import java.nio.file.Files
import java.io.ByteArrayOutputStream
class Cad030StoreTest {
 @Test fun snapshotResourcesAndConnectionsTravel(){val first=Files.createTempDirectory("cad030-a").toFile();val second=Files.createTempDirectory("cad030-b").toFile();try{
  val a=ProjectStore(first);val asset=a.putAsset("<svg/>".toByteArray(),"svg");val source=Entity(points=listOf(Vec(),Vec(400.0,0.0)));val linked=Entity(points=listOf(Vec(),Vec(400.0,50.0)),bindings=listOf(PointBinding(0,Anchor(source.id,1))))
  val child=Entity(kind="rect",points=rectangle(Vec(),Vec(1000.0,500.0)),materialSnapshot=MaterialAppearance(sectionPattern=asset),placement=Placement("Fundament",-100.0,0.0,-300.0));val instance=instantiateTemplate(templateEntry("Fundament","Eigene Bauwerke",listOf(child),Vec()),Vec())
  val drawing=Drawing(createdAt=100,updatedAt=200,entities=listOf(source,linked,instance)).withProfile("Schnitt");val project=Project(createdAt=100,drawings=listOf(drawing));val bytes=ByteArrayOutputStream();Packages.project(bytes,project,a.resources(project));val pack=Packages.read(bytes.toByteArray().inputStream());val b=ProjectStore(second);val imported=b.remap(pack.project(),b.importResources(pack));b.save(imported);val result=b.load(project.id).project
  assertEquals(100L,result.createdAt);assertEquals(200L,result.drawings.single().updatedAt);assertEquals(Vec(400.0,0.0),resolvedPoints(result.drawings.single().entities[1],result.drawings.single())[0]);assertEquals(1,b.resources(result).size);assertEquals("Fundament",result.drawings.single().entities[2].children[0].placement.level);assertTrue(b.list().single().updatedAt>=200)
 }finally{first.deleteRecursively();second.deleteRecursively()}}
}
