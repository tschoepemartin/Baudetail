package de.baudetail.projects
import de.baudetail.core.*
import de.baudetail.format.*
import org.junit.Test
import org.junit.Assert.*
import java.nio.file.Files
import java.io.ByteArrayOutputStream
class StoreTest {
 @Test fun reopenPersistentHistoryAndBackups(){val root=Files.createTempDirectory("baudetail-test").toFile();try{val h=EditorHistory(DrawingHistory(Drawing()));repeat(12){h.commit(h.current.copy(name="Change $it"))};val p=Project(drawings=listOf(h.current));ProjectStore(root).save(p,mapOf(h.current.id to h.persisted()));val loaded=ProjectStore(root).load(p.id);val reopened=EditorHistory(loaded.histories.getValue(h.current.id));assertEquals(10,reopened.persisted().backups.size);repeat(5){reopened.undo()};assertFalse(reopened.canUndo);assertEquals("Change 6",reopened.current.name)}finally{root.deleteRecursively()}}
 @Test fun secondDeviceCanContinueEditing(){val first=Files.createTempDirectory("device-a").toFile();val second=Files.createTempDirectory("device-b").toFile();try{val a=ProjectStore(first);val path=a.putAsset("<svg/>".toByteArray(),"svg");val p=Project(drawings=listOf(Drawing(entities=listOf(Entity(kind="image",asset=path)))));val out=ByteArrayOutputStream();Packages.project(out,p,a.resources(p));val pack=Packages.read(out.toByteArray().inputStream());val b=ProjectStore(second);val imported=b.remap(pack.project(),b.importResources(pack));b.save(imported.copy(name="Weiterbearbeitet"));assertEquals("Weiterbearbeitet",b.load(p.id).project.name);assertArrayEquals("<svg/>".toByteArray(),b.resources(imported).values.first())}finally{first.deleteRecursively();second.deleteRecursively()}}
 @Test fun originalPdfTravelsWithBackground(){val root=Files.createTempDirectory("pdf-source-test").toFile();try{val store=ProjectStore(root);val source=store.putAsset("%PDF-example".toByteArray(),"pdf");val preview=store.putAsset(byteArrayOf(1,2,3),"png");val e=Entity(kind="image",asset=preview).withStr("sourceAsset",source);val p=Project(drawings=listOf(Drawing(entities=listOf(e))));assertEquals(setOf(source,preview),store.resources(p).keys)}finally{root.deleteRecursively()}}
 @Test fun corruptedProjectIsVisible(){val root=Files.createTempDirectory("corrupt-project-test").toFile();try{java.io.File(root,"broken.json").writeText("not json");val record=ProjectStore(root).list().single();assertEquals("broken",record.id);assertTrue(record.name.startsWith("Beschädigtes"))}finally{root.deleteRecursively()}}
}
