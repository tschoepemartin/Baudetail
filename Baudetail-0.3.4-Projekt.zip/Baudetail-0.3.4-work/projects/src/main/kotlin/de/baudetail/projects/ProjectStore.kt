package de.baudetail.projects

import de.baudetail.core.*
import de.baudetail.format.*
import de.baudetail.libraries.*
import kotlinx.serialization.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import java.io.*
import java.nio.file.Files
import java.nio.file.StandardCopyOption

@Serializable data class ProjectRecord(val id:String,val name:String,val updatedAt:Long,val drawings:Int,val createdAt:Long=0)
@Serializable data class StoredProject(val project:Project,val histories:Map<String,DrawingHistory> = emptyMap())
/** One atomic transaction holds project and persistent undo state. No separate partially committed files. */
class ProjectStore(val root:File) {
 init {root.mkdirs()}
 var lastRecoveryCount:Int=0;private set
 private fun id(id:String):String {require(Regex("[a-zA-Z0-9_-]{1,100}").matches(id));return id}
 private fun file(id:String)=File(root,"${id(id)}.json")
 @Synchronized fun list():List<ProjectRecord> = root.listFiles().orEmpty().filter {it.extension=="json"&&it.name!="catalog.json"}.mapNotNull { f->
  runCatching {val p=BaudetailJson.decodeFromString<StoredProject>(f.readText()).project;ProjectRecord(p.id,p.name,p.updatedAt,p.drawings.size,p.createdAt)}.getOrElse { ProjectRecord(f.nameWithoutExtension,"Beschädigtes Projekt (${f.nameWithoutExtension.take(8)})",f.lastModified(),0) }
 }.sortedByDescending {it.updatedAt}
 @Synchronized fun load(id:String):StoredProject {
  val f=file(id);require(f.exists()){ "Projektdatei fehlt" }
  val raw=f.readText()
  val recovered=recoverDocument(BaudetailJson.parseToJsonElement(raw))
  val stored=BaudetailJson.decodeFromJsonElement<StoredProject>(recovered.value)
  stored.project.drawings.forEach(::validateDrawing)
  if(recovered.repaired>0)atomicWrite(File(root,"recovery/${f.nameWithoutExtension}-${System.currentTimeMillis()}.json"),raw.toByteArray())
  lastRecoveryCount=recovered.repaired
  return stored
 }
 @Synchronized fun save(project:Project,histories:Map<String,DrawingHistory> = emptyMap()) {
  project.drawings.forEach(::validateDrawing)
  atomicWrite(file(project.id),BaudetailJson.encodeToString(StoredProject(project.copy(updatedAt=System.currentTimeMillis()),histories)).toByteArray())
 }
 @Synchronized fun deleteProject(projectId:String){val f=file(projectId);if(f.exists())require(f.delete()){"Projekt konnte nicht gelöscht werden"}}
 fun assetFile(path:String):File {require(Packages.safeName(path));return File(root,"resources/$path")}
 @Synchronized fun putAsset(bytes:ByteArray,extension:String):String {
  require(bytes.size<=64*1024*1024);require(Regex("[a-zA-Z0-9]{1,8}").matches(extension));val path="assets/${Packages.hash(bytes)}.$extension";val f=assetFile(path);if(!f.exists())atomicWrite(f,bytes);return path
 }
 @Synchronized fun importResources(pack:OpenedPackage):Map<String,String> = Packages.resources(pack).mapValues { (name,bytes)->putAsset(bytes,name.substringAfterLast('.').takeIf {it.matches(Regex("[a-zA-Z0-9]{1,8}"))}?:"bin") }
 fun remap(e:Entity,map:Map<String,String>):Entity = e.copy(materialSnapshot=e.materialSnapshot?.let{it.copy(sectionPattern=it.sectionPattern?.let{path->map[path]?:path})},params=JsonObject(e.params.mapValues{(k,v)->if(k.startsWith("asset_")&&v is JsonPrimitive)JsonPrimitive(map[v.content]?:v.content)else v}),asset=e.asset?.let{map[it]?:it},children=e.children.map {remap(it,map)}).let { mapped -> if(e.str("sourceAsset").isNotBlank()) mapped.withStr("sourceAsset",map[e.str("sourceAsset")]?:e.str("sourceAsset")) else mapped }
 fun remap(e:LibraryEntry,map:Map<String,String>):LibraryEntry = e.copy(appearance=e.appearance?.let{it.copy(sectionPattern=it.sectionPattern?.let{path->map[path]?:path})},views=e.views.mapValues {map[it.value]?:it.value},preview=e.preview?.let{map[it]?:it},geometry=e.geometry.map {remap(it,map)})
 fun remap(p:Project,map:Map<String,String>):Project = p.copy(resources=p.resources.map {map[it]?:it},drawings=p.drawings.map {it.copy(entities=it.entities.map {e->remap(e,map)})},libraryEntries=p.libraryEntries.map {remap(it,map)},revisions=p.revisions.map {r->r.copy(drawings=r.drawings.map {it.copy(entities=it.entities.map {e->remap(e,map)})})})
 fun resources(p:Project):Map<String,ByteArray> {
  val paths=mutableSetOf<String>();fun visit(e:Entity){e.materialSnapshot?.sectionPattern?.let(paths::add);e.params.filterKeys{it.startsWith("asset_")}.values.forEach{(it as? JsonPrimitive)?.contentOrNull?.let(paths::add)};e.asset?.let(paths::add);e.str("sourceAsset").takeIf{it.isNotBlank()}?.let(paths::add);e.children.forEach(::visit)}
  p.drawings.forEach {it.entities.forEach(::visit)};p.revisions.forEach {r->r.drawings.forEach {it.entities.forEach(::visit)}}
  paths.addAll(p.resources);p.libraryEntries.forEach {paths.addAll(it.views.values);it.appearance?.sectionPattern?.let(paths::add);it.preview?.let(paths::add);it.geometry.forEach(::visit)}
  return paths.associateWith { path->val f=assetFile(path);require(f.exists()){ "Externe Ressource fehlt: $path" };f.readBytes() }
 }
 fun loadCatalog():CatalogState = File(root,"catalog.json").let {if(it.exists()) BaudetailJson.decodeFromString(it.readText()) else CatalogState()}
 @Synchronized fun saveCatalog(state:CatalogState)=atomicWrite(File(root,"catalog.json"),BaudetailJson.encodeToString(state).toByteArray())
 companion object {
  fun atomicWrite(file:File,bytes:ByteArray) {
   file.parentFile?.mkdirs();val temp=File(file.parentFile,"${file.name}.tmp")
   FileOutputStream(temp).use {it.write(bytes);it.fd.sync()}
   try {Files.move(temp.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING)}catch(e:java.nio.file.AtomicMoveNotSupportedException){Files.move(temp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING)}
  }
 }
}
