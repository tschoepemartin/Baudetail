# Debug-Schlüssel ab 0.1.1

Nur für Entwicklung: Alias `androiddebugkey`, Store-/Schlüsselpasswort jeweils `android`. Dieser bewusst mitgelieferte Testschlüssel ermöglicht gleich signierte Folgeversionen. Für Release-Veröffentlichungen einen eigenen privaten Schlüssel verwenden.

Die alte APK 0.1.0 hat eine andere Signatur. Vor dem Wechsel eigene Projekte vollständig als `.bproject` exportieren. Erst dann alte App deinstallieren, neue APK installieren und Projekte importieren. Deinstallation löscht appinterne Projekte.
