# Baudetail 0.6.7

Fokus-Update für Rinnen/Borde sowie Darstellungsfeinschliff.

- Die App unterstützt die neuen parametrischen Rinneneigenschaften (Typ, Rost/Abdeckung, Belastungsklasse).
- Die neuen Standardbauteile werden NICHT fest in die App-Bibliothek eingebaut, sondern als separate externe Bibliothek geliefert: `Baudetail-Bibliothek-0.6.7.bdlib`.
- Externe Bibliothek enthält u. a. Kastenrinne, Fassadenrinne, Schlitzrinne sowie Bordstein 8/25/100.
- Treppen-Draufsicht: „UNTEN“ und „OBEN“ kleiner und näher an der Pfeillinie.
- Automatische Objektbeschriftungen wählen stabilere, objektbezogene Lagen statt einer starren Fernplatzierung.
- Automatische Maße wurden nicht verändert.
- Veralteter Standard-KG-DN100-Eintrag ohne die eigene parametrische Rohrlogik wurde aus der eingebauten Standardbibliothek entfernt.

- Alte generische Bibliothekseinträge „KG DN …“ und „KG2000 DN …“ werden beim Start aus dem persistenten Standardkatalog entfernt; die parametrischen `cmp-kg2000-*`-Bauteile bleiben erhalten.
