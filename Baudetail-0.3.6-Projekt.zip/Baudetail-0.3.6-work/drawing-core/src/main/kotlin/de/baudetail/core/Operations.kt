package de.baudetail.core

import de.baudetail.geometry.*
import kotlin.math.*

class EditorHistory(initial:DrawingHistory) {
 private val past=initial.past.toMutableList(); private val future=initial.future.toMutableList(); private val backups=initial.backups.toMutableList()
 var current=initial.current; private set
 val canUndo get()=past.isNotEmpty()
 val canRedo get()=future.isNotEmpty()
 fun commit(next:Drawing):Boolean { validateDrawing(next); if(next==current)return false; past.add(current); if(past.size>200)past.removeAt(0); future.clear(); checkpoint();current=next;return true }
 private fun checkpoint() { backups.add(current);while(backups.size>10)backups.removeAt(0) }
 fun undo() { if(canUndo) {future.add(current);checkpoint(); current=past.removeAt(past.lastIndex)} }
 fun redo() { if(canRedo) {past.add(current);checkpoint();current=future.removeAt(future.lastIndex)} }
 fun persisted()=DrawingHistory(current,past.takeLast(5),future.takeLast(5),backups.toList())
 fun restore(index:Int) { val d=backups[index]; commit(d) }
}
data class SnapOptions(val grid:Boolean=true,val geometry:Boolean=true,val ortho:Boolean=false,val angleStep:Double=0.0,val gridMm:Double=100.0,val toleranceMm:Double=100.0,val modes:Set<String> = setOf("Raster","Endpunkt","Mitte","Schnittpunkt","Kante","Zentrum"))
data class SnapResult(val point:Vec,val reason:String,val anchor:Anchor?=null,val priority:String="normal")
private data class SnapCandidate(val point:Vec,val reason:String,val entityId:String?=null,val priority:Int=1)
private fun snapPriority(e:Entity)=when(e.str("snapPriority","normal")){"high"->0;"low"->2;else->1}
fun snap(point:Vec,d:Drawing,options:SnapOptions,previous:Vec?=null):SnapResult {
 var p=point; var reason=""
 if(previous!=null) { val delta=p-previous
  if(options.ortho) {p=if(abs(delta.x)>abs(delta.y)) Vec(p.x,previous.y) else Vec(previous.x,p.y);reason="Ortho"}
  else if(options.angleStep>0) { val a=round(Math.toDegrees(atan2(delta.y,delta.x))/options.angleStep)*options.angleStep; p=previous+Vec(cos(Math.toRadians(a)),sin(Math.toRadians(a)))*delta.length(); reason="Winkel" }
 }
 val candidates=mutableListOf<SnapCandidate>()
 if(options.geometry) {
  val segments=mutableListOf<Triple<Vec,Vec,String?>>()
  for(e in d.entities.filter { d.layers.find { l->l.id==it.layerId }?.visible != false && visibleIn(it,d) }) {
   val pr=snapPriority(e)
   val smart=isStair(e)||e.kind=="component"
   val pts=if(smart)smartSnapReferencePoints(e,d)else resolvedPoints(e,d)
   val edgePts=if(smart)smartSnapOutline(e,d)else pts
   if(smart){edgePts.forEach{candidates.add(SnapCandidate(it,"Endpunkt",e.id,pr))};pts.getOrNull(4)?.let{candidates.add(SnapCandidate(it,"Zentrum",e.id,pr))};pts.drop(5).take(4).forEach{candidates.add(SnapCandidate(it,"Mitte",e.id,pr))}}
   else if(e.kind !in setOf("circle","tree"))pts.forEach {candidates.add(SnapCandidate(it,"Endpunkt",e.id,pr))} else pts.firstOrNull()?.let{candidates.add(SnapCandidate(it,"Zentrum",e.id,pr))}
   val closed=e.kind in setOf("polygon","area","rect","building")
   val seg=if(e.kind in setOf("circle","tree"))emptyList() else if(smart)smartSnapSegments(e,d) else edgePts.zipWithNext()+(if(closed&&edgePts.size>2) listOf(edgePts.last() to edgePts.first()) else emptyList())
   for((a,b) in seg) {candidates.add(SnapCandidate((a+b)*0.5,"Mitte",e.id,pr));candidates.add(SnapCandidate(closestOnSegment(p,a,b),"Kante",e.id,pr));if(Bounds.of(listOf(a,b)).contains(p,options.toleranceMm))segments.add(Triple(a,b,e.id))}
   if(e.kind=="circle" || e.kind=="tree") { val c=pts.firstOrNull()?:continue; val r=if(e.kind=="tree") e.num("crownMm",2000.0)/2 else e.num("radiusMm",500.0);val v=p-c;if(v.length()>0)candidates.add(SnapCandidate(c+v*(r/v.length()),"Kreis",e.id,pr)) }
  }
  val nearby=segments.take(250)
  for(i in nearby.indices)for(j in i+1 until nearby.size) intersection(nearby[i].first,nearby[i].second,nearby[j].first,nearby[j].second)?.let { candidates.add(SnapCandidate(it,"Schnittpunkt",null,1)) }
 }
 candidates.removeAll { (if(it.reason=="Kreis")"Kante"else it.reason) !in options.modes }
 fun allowed(v:Vec):Boolean {
  if(previous==null||(!options.ortho&&options.angleStep<=0))return true
  val ray=p-previous;val target=v-previous
  return abs(cross(ray,target))<=1e-6*ray.length().coerceAtLeast(1.0)
 }
 candidates.removeAll{!allowed(it.point)}
 val inRange=candidates.filter{it.point.distance(p)<=options.toleranceMm}
 val exact=inRange.filter { it.reason !in setOf("Kante", "Kreis") }
 val pool=exact.ifEmpty{inRange}
 val nearest=pool.minWithOrNull(compareBy<SnapCandidate>{it.priority}.thenBy{it.point.distance(p)})
 if(nearest!=null && (!options.ortho || previous==null || abs(nearest.point.x-previous.x)<1e-6 || abs(nearest.point.y-previous.y)<1e-6)) {
  val entity=d.entities.find{it.id==nearest.entityId};val pr=entity?.str("snapPriority","normal")?:"normal"
  return SnapResult(nearest.point,nearest.reason,anchorAt(nearest.point,d),pr)
 }
 if(options.grid && options.gridMm>0) {p=if(previous!=null && (options.ortho||options.angleStep>0)){val delta=p-previous;val len=delta.length();if(len>1e-9)previous+delta*(round(len/options.gridMm)*options.gridMm/len)else previous}else Vec(round((p.x-d.origin.x)/options.gridMm)*options.gridMm+d.origin.x,round((p.y-d.origin.y)/options.gridMm)*options.gridMm+d.origin.y);reason="Raster"}
 return SnapResult(p,reason)
}
fun hitTest(p:Vec,e:Entity,tolerance:Double):Boolean {
 val pts=e.points
 return when(e.kind) {
 "arc" -> { val c=pts.firstOrNull()?:Vec();val v=p-c;val start=e.num("startAngle");val sweep=e.num("sweepAngle",90.0);val a=Math.toDegrees(atan2(v.y,v.x));val delta=if(sweep>=0)((a-start)%360+360)%360 else ((start-a)%360+360)%360;abs(v.length()-e.num("radiusMm",500.0))<=tolerance&&(abs(sweep)>=360||delta<=abs(sweep)+1e-6) }
 "circle","tree" -> p.distance(pts.firstOrNull()?:Vec()) <= (if(e.kind=="tree") e.num("crownMm",2000.0)/2 else e.num("radiusMm",500.0))+tolerance
 "area","polygon","rect","building" -> inside(p,pts)||pts.zipWithNext().any {(a,b)->closestOnSegment(p,a,b).distance(p)<tolerance}
 "assembly" -> entityBounds(e).contains(p,tolerance)
 "component","image","stack" -> entityBounds(e).contains(p.rotate(-e.rotation,pts.firstOrNull()?:Vec()),tolerance)
 "text","elevation","legend" -> (pts.firstOrNull()?:Vec()).distance(p)<tolerance*3
 else -> pts.zipWithNext().any {(a,b)->closestOnSegment(p,a,b).distance(p)<tolerance} || pts.any {it.distance(p)<tolerance}
 }
}

fun hitTest(p:Vec,e:Entity,d:Drawing,tolerance:Double):Boolean {
 if(isFoundation(e)){val pts=foundationOutline(e,d);return inside(p,pts)||pts.zipWithNext().any{(a,b)->closestOnSegment(p,a,b).distance(p)<tolerance}}
 if(e.str("labelEnabled")=="true" && p.distance(objectLabelPosition(e,d))<=tolerance*3.0)return true
 if(isStair(e))return Bounds.of(stairReferencePoints(e,d.viewMode())).contains(p,tolerance)
 if(e.kind!="dimension") return hitTest(p,viewEntity(e,d),tolerance)
 val textSize=e.style.textPaperMm*d.sheet.scale
 val metric=e.str("metric")
 val witnesses=if(metric.isNotEmpty())d.entities.find{it.id==e.str("sourceId")}?.let{metricWitnesses(it,metric,d)} else resolvedPoints(e,d)
 if(witnesses==null||witnesses.size<2){
  val at=(e.points.firstOrNull()?:Vec())+Vec(e.num("textDx"),e.num("textDy"))
  return p.distance(at)<=tolerance*2.5
 }
 val a=witnesses[0];val b=witnesses[1];val raw=b-a;val dist=raw.length();val mode=e.str("mode","aligned");val off=e.num("offsetMm",d.sheet.scale*8)
 val base=when(mode){"horizontal"->Vec(0.0,off);"vertical"->Vec(off,0.0);else->if(dist>1e-9)Vec(-raw.y/dist,raw.x/dist)*off else Vec(0.0,off)}
 val anchor=e.points.firstOrNull()?:a;val origin=Vec(e.num("metricOriginX",anchor.x),e.num("metricOriginY",anchor.y));val metricShift=if(metric.isNotEmpty())anchor-origin else Vec()
 val shift=Vec(e.num("dimDx"),e.num("dimDy"))+metricShift
 val aa=a+base+shift;val bb=when(mode){"horizontal"->Vec(b.x+shift.x,aa.y);"vertical"->Vec(aa.x,b.y+shift.y);else->b+base+shift}
 if(closestOnSegment(p,aa,bb).distance(p)<=tolerance)return true
 if(closestOnSegment(p,a,aa).distance(p)<=tolerance||closestOnSegment(p,b,bb).distance(p)<=tolerance)return true
 val textAt=(aa+bb)*0.5+Vec(e.num("textDx"),-textSize*.35+e.num("textDy"))
 val approxWidth=dimensionLabel(e,d).length*textSize*.62
 return Bounds(textAt-Vec(approxWidth/2,textSize),textAt+Vec(approxWidth/2,textSize*.5)).contains(p,tolerance)
}

data class Quantity(val key:String,val label:String,val unit:String,val value:Double)
fun quantities(d:Drawing,entries:List<LibraryEntry> = emptyList()):List<Quantity> {
 val rows=d.entities.mapNotNull { e ->
  if(e.status=="Abbruch") return@mapNotNull null
  val unit=e.quantityUnit ?: if(closedContour(e))"m²"else when(e.kind){"area"->"m²";"hedge","tree","component"->"Stk";else->return@mapNotNull null}
  val value=when(unit){"m²"->surfaceArea(e.copy(points=resolvedPoints(e,d)))/1e6;"m"->length(e.points)/1000;"Stk"->if(e.kind=="hedge") hedgeCount(length(e.points),e.num("spacingMm",400.0)).toDouble() else e.num("count",1.0);"m³"->area(e.points)*e.num("depthMm",100.0)/1e9;else->e.num("count",1.0)}
  val key=e.materialId?:e.libraryId?:e.name.ifEmpty {e.kind}; val label=entries.find {it.id==key}?.name?:e.name.ifEmpty {e.kind}
  Quantity(key,label,unit,value)
 }
 return rows.groupBy {it.key to it.unit}.values.map {g->g.first().copy(value=g.sumOf {it.value})}
}
fun dimensionValue(e:Entity,d:Drawing):Double {
 if(e.str("metric").isNotEmpty())return d.entities.find{it.id==e.str("sourceId")}?.let{metricValue(it,e.str("metric"))}?:0.0
 val pts=resolvedPoints(e,d);if(pts.size<2)return 0.0
 val delta=pts[1]-pts[0]
 return when(e.str("mode","aligned")){"horizontal"->abs(delta.x);"vertical"->abs(delta.y);"radius"->delta.length();"diameter"->2*delta.length();"angle"->{if(pts.size<3)0.0 else {val a=pts[0]-pts[1];val b=pts[2]-pts[1];Math.toDegrees(acos(((a.x*b.x+a.y*b.y)/(a.length()*b.length())).coerceIn(-1.0,1.0)))}};else->delta.length()}
}
fun slopeLabel(e:Entity,d:Drawing):String {
 val pts=resolvedPoints(e,d); val dist=if(pts.size>1)pts[0].distance(pts[1]) else 0.0
 val percent=if(e.str("mode","manual")=="auto" && dist>0) slopePercent(dist,e.num("startHeightMm")-e.num("endHeightMm")) else e.num("percent",2.0)
 return when(e.str("unit","%")){"cm/m"->"${fmt(percent)} cm/m";"1:x"->if(percent==0.0)"eben" else "1:${fmt(100/abs(percent))}";else->"${fmt(percent)} %"}
}
fun calibrate(e:Entity,a:Vec,b:Vec,realMm:Double):Entity {require(realMm>0 && a.distance(b)>1e-9);return transform(e,factor=realMm/a.distance(b),center=e.points.firstOrNull()?:Vec())}

data class LegendItem(val key:String,val label:String,val style:Style)
fun legendItems(d:Drawing,entries:List<LibraryEntry>):List<LegendItem> {
 val result=linkedMapOf<String,LegendItem>()
 for(e in d.entities) {
  val key=e.materialId?:e.libraryId?:if(e.kind in setOf("tree","hedge"))"${e.kind}:${e.name}"else null
  if(key!=null) {val library=entries.find{it.id==key};result.putIfAbsent(key,LegendItem(key,library?.name?:e.name.ifBlank{if(e.kind=="tree")"Baum"else"Hecke"},library?.style?:e.style))}
  for(layer in e.strata){val k=layer.materialId.ifBlank{layer.name};val library=entries.find{it.id==k};result.putIfAbsent(k,LegendItem(k,library?.name?:layer.name,library?.style?:Style(fill=layer.color)))}
 }
 return result.values.toList()
}
