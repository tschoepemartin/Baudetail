package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*

/** Shared semantic family used for intelligent component replacement/rendering. */
fun LibraryEntry.smartFamily():String {
 val explicit=(attributes["component_family"] as? JsonPrimitive)?.contentOrNull.orEmpty()
 if(explicit.isNotBlank()) return explicit
 val key=(category+"/"+name).lowercase()
 return when {
  "rohre/" in key || "rohr" in key || "leitung" in key -> "pipe"
  "mauerbau" in key && ("l-stein" in key || "winkel" in key || "mauerscheib" in key) -> "retaining_wall"
  "einfassungen/borde" in key || "bord " in key -> "curb"
  "rinne" in key -> "channel"
  "rasen" in key -> "grass"
  else -> "component"
 }
}

fun Entity.smartFamily():String = str("componentFamily").ifBlank {
 when {
  isStair(this) -> "stair"
  else -> "component"
 }
}

fun LibraryEntry.attrNumber(vararg keys:String, default:Double=0.0):Double {
 for(key in keys) {
  val p=attributes[key] as? JsonPrimitive ?: continue
  p.doubleOrNull?.let { if(it.isFinite()) return it }
 }
 return default
}

fun LibraryEntry.variantGroup():String = (attributes["variant_group"] as? JsonPrimitive)?.contentOrNull
 ?: when(smartFamily()) {
  "pipe" -> category
  "curb" -> category
  "retaining_wall" -> "Mauerbau/Mauerscheiben"
  "channel" -> category
  "grass" -> category
  else -> category
 }

/** Swap a placed smart component to another compatible library entry while preserving its anchor/OK and editing state. */
fun replaceComponentVariant(old:Entity,entry:LibraryEntry):Entity {
 require(old.kind=="component") { "Nur Bauteile können typgleich ersetzt werden" }
 require(old.smartFamily()==entry.smartFamily() || old.smartFamily()=="component") { "Bauteil gehört zu einer anderen Kategorie" }
 val at=old.points.firstOrNull()?:Vec()
 val fresh=componentInstance(entry,at)
 val keepKeys=setOf("orientation","verticalDirection","verticalLengthMm","labelEnabled","labelMode","labelText","labelDx","labelDy","fillMode","fillTop","fillSection","snapPriority")
 val merged=fresh.params.toMutableMap()
 old.params.forEach { (k,v) -> if(k in keepKeys) merged[k]=v }
 return fresh.copy(
  id=old.id, layerId=old.layerId, status=old.status, rotation=old.rotation,
  locked=old.locked, groupId=old.groupId, placement=old.placement,
  style=old.style, materialId=old.materialId, materialSnapshot=old.materialSnapshot,
  quantityUnit=old.quantityUnit, extensions=old.extensions, bindings=old.bindings, anchors=old.anchors,
  params=JsonObject(merged)
 )
}

fun smartPivot(e:Entity):Vec = if((e.kind=="component" || isStair(e)) && e.points.isNotEmpty()) e.points.first() else entityBounds(e).center

/** Smart objects keep a separate 2D presentation pose per view.
 * Moving/rotating a component in plan therefore no longer destroys the already
 * arranged section (and vice versa). The base point remains the semantic model
 * origin; only the view offset/rotation is changed. */
fun smartViewOffset(e:Entity,view:String)=Vec(e.num("${view}Dx"),e.num("${view}Dy"))
fun smartViewRotation(e:Entity,view:String)=e.rotation+e.num("${view}RotationDelta")
fun smartViewOrigin(e:Entity,view:String)=(e.points.firstOrNull()?:Vec())+smartViewOffset(e,view)
fun smartPivot(e:Entity,d:Drawing):Vec = if(e.kind=="component"||isStair(e)) smartViewOrigin(e,d.viewMode()) else smartPivot(e)
fun moveSmartInView(e:Entity,view:String,delta:Vec):Entity =
 if(e.kind=="component"||isStair(e)) e.withNum("${view}Dx",e.num("${view}Dx")+delta.x).withNum("${view}Dy",e.num("${view}Dy")+delta.y) else transform(e,translation=delta)
fun rotateSmartInView(e:Entity,view:String,deltaDegrees:Double):Entity =
 if(e.kind=="component"||isStair(e)) e.withNum("${view}RotationDelta",e.num("${view}RotationDelta")+deltaDegrees) else transform(e,angle=deltaDegrees,center=smartPivot(e))

/** Outer construction rectangle used for intelligent component-to-component snapping.
 * Unlike the former generic point list this deliberately contains only the real
 * outside edges that may be used as an installation/reference edge. */
fun smartSnapOutline(e:Entity,d:Drawing):List<Vec> {
 val origin=e.points.firstOrNull()?:Vec()
 if(isStair(e)) {
  val local=if(d.viewMode()=="top") rectangle(Vec(),Vec(stairLength(e),e.num("widthMm",1200.0)))
   else {val b=Bounds.of(stairLocalPoints(e,"section"));rectangle(b.min,b.max)}
  return local.map{assemblyPoint(e,it,d.viewMode())}
 }
 if(e.kind=="component") return componentReferencePoints(e,d).take(4)
 return rectangle(entityBounds(e).min,entityBounds(e).max)
}
fun smartSnapReferencePoints(e:Entity,d:Drawing):List<Vec> {
 val c=smartSnapOutline(e,d);if(c.size<4)return c
 val mids=(0..3).map{i->(c[i]+c[(i+1)%4])*0.5}
 return c+Bounds.of(c).center+mids
}
fun smartSnapSegments(e:Entity,d:Drawing):List<Pair<Vec,Vec>> {
 val c=smartSnapOutline(e,d);return if(c.size>=4)(0..3).map{i->c[i] to c[(i+1)%4]} else c.zipWithNext()
}
fun smartSnapEdgeIndexFromReferenceIndex(index:Int):Int? = if(index in 5..8) index-5 else null
fun smartEdgeLength(e:Entity,d:Drawing,index:Int):Double {val c=smartSnapOutline(e,d);return if(c.size>=4)c[index.mod(4)].distance(c[(index+1).mod(4)]) else 0.0}

/** Match the plan dimension represented by one outside edge. DN/pipe diameter is
 * intentionally never stretched by this mechanism. */
fun withSmartEdgeLength(e:Entity,edge:Int,length:Double,view:String):Entity {
 if(length<=0||!length.isFinite())return e
 if(isStair(e)) return if(edge%2==1)e.withNum("widthMm",length) else e
 if(e.kind!="component"||isPipe(e))return e
 val horizontal=edge%2==0
 return when {
  isRetainingWall(e)&&view=="top" -> if(horizontal)e.withNum("elementLengthMm",length).withNum("topWidthMm",length) else e.withNum("footDepthMm",length).withNum("topHeightMm",length)
  view=="top" -> if(horizontal)e.withNum("topWidthMm",length) else e.withNum("topHeightMm",length)
  else -> if(horizontal)e.withNum("sectionWidthMm",length) else e.withNum("sectionHeightMm",length)
 }
}

/** Keep linked smart objects connected in BOTH plan and section while preserving
 * their independent view layout. Plan edges may inherit the leading edge length
 * (e.g. 1000 mm stair width -> 1000 mm lawn connection); section thicknesses
 * are never stretched to a stair height. */
fun syncSmartFollowers(input:Drawing):Drawing {
 var d=input
 repeat(4){
  var changed=false
  val next=d.entities.map{e->
   val targetId=e.str("followTargetId");val sourceEdge=e.num("followSourceEdge",-1.0).toInt();val targetEdge=e.num("followTargetEdge",-1.0).toInt()
   if(targetId.isBlank()||sourceEdge !in 0..3||targetEdge !in 0..3)e else {
    val target=d.entities.find{it.id==targetId}?:return@map e
    var n=e
    for(view in listOf("top","section")){
     val vd=d.withViewMode(view)
     var sourceOutline=smartSnapOutline(n,vd);val targetOutline=smartSnapOutline(target,vd)
     if(sourceOutline.size<4||targetOutline.size<4)continue
     val tv=targetOutline[(targetEdge+1)%4]-targetOutline[targetEdge]
     val sv=sourceOutline[(sourceEdge+1)%4]-sourceOutline[sourceEdge]
     if(tv.length()>1e-9&&sv.length()>1e-9){
      fun parallelDelta(a:Double):Double = ((a+90.0)%180.0+180.0)%180.0-90.0
      val angle=parallelDelta(Math.toDegrees(kotlin.math.atan2(tv.y,tv.x)-kotlin.math.atan2(sv.y,sv.x)))
      if(kotlin.math.abs(angle)>1e-7)n=rotateSmartInView(n,view,angle)
     }
     // Only plan geometry inherits the edge length. This is the physical width/length
     // relationship the user expects; section layer thicknesses keep their own size.
     if(view=="top")n=withSmartEdgeLength(n,sourceEdge,tv.length(),view)
     sourceOutline=smartSnapOutline(n,vd)
     val sourceCorner=e.num("followSourceCorner",sourceEdge.toDouble()).toInt().coerceIn(0,3)
     val targetCorner=e.num("followTargetCorner",targetEdge.toDouble()).toInt().coerceIn(0,3)
     val correction=targetOutline[targetCorner]-sourceOutline[sourceCorner]
     if(correction.length()>1e-7)n=moveSmartInView(n,view,correction)
    }
    if(n!=e)changed=true;n
   }
  }
  d=d.copy(entities=next);if(!changed)return d
 }
 return d
}

fun retainingWallSection(e:Entity):List<Vec> {
 val h=e.num("wallHeightMm",e.num("sectionHeightMm",800.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("sectionWidthMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val slab=e.num("footThicknessMm",100.0).coerceIn(1.0,h)
 val side=e.str("footSide","right")
 val pts=if(side=="left") listOf(Vec(foot,0.0),Vec(foot-wall,0.0),Vec(foot-wall,h-slab),Vec(0.0,h-slab),Vec(0.0,h),Vec(foot,h))
 else listOf(Vec(0.0,0.0),Vec(wall,0.0),Vec(wall,h-slab),Vec(foot,h-slab),Vec(foot,h),Vec(0.0,h))
 return pts
}

fun retainingWallTop(e:Entity):Pair<List<Vec>,List<Vec>> {
 val length=e.num("elementLengthMm",e.num("topWidthMm",1000.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("topHeightMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val wallRect=rectangle(Vec(),Vec(length,wall))
 val footRect=rectangle(Vec(),Vec(length,foot))
 return wallRect to footRect
}

fun isPipe(e:Entity)=e.kind=="component"&&e.smartFamily()=="pipe"
fun isRetainingWall(e:Entity)=e.kind=="component"&&e.smartFamily()=="retaining_wall"
