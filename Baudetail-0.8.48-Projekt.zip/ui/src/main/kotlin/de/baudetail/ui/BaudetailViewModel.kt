package de.baudetail.ui

import android.app.Application
import de.baudetail.ui.diagnostics.Diagnostics
import android.content.Intent
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.format.*
import de.baudetail.projects.*
import de.baudetail.libraries.*
import de.baudetail.export.*
import de.baudetail.ui.data.MetadataIndex
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import java.io.*

class BaudetailViewModel(app:Application):AndroidViewModel(app) {
 val store=ProjectStore(File(app.filesDir,"baudetail"))
 private val prefs=app.getSharedPreferences("baudetail",0)
 private val index=MetadataIndex(app)
 private val saveQueue=Channel<StoredProject>(Channel.UNLIMITED)
 private val histories=mutableMapOf<String,EditorHistory>()
 var project by mutableStateOf<Project?>(null);private set
 var drawingId by mutableStateOf("");private set
 val drawing:Drawing? get()=project?.drawings?.find{it.id==drawingId}
 var records by mutableStateOf<List<ProjectRecord>>(emptyList());private set
 var catalog by mutableStateOf(Catalog());private set
 var libraryVersion by mutableIntStateOf(0);private set
 var loading by mutableStateOf(true);private set
 var error by mutableStateOf<String?>(null)
 var notice by mutableStateOf<String?>(null)
 var setupComplete by mutableStateOf(prefs.getBoolean("setup",false));private set
 var theme by mutableStateOf(prefs.getString("theme","System")?:"System");private set
 var treeUri by mutableStateOf(prefs.getString("tree",null));private set
 var treeProblem by mutableStateOf(false);private set
 var treeStatus by mutableStateOf("Kein externer Ordner gewählt");private set
 var selected by mutableStateOf<Set<String>>(emptySet())
 var tool by mutableStateOf("select")
 var entryToPlace by mutableStateOf<LibraryEntry?>(null)
 var exportFormat by mutableStateOf("pdf")
 var exportDpi by mutableIntStateOf(300)
 var exportDual by mutableStateOf(false)
 var exportDualSelection by mutableStateOf("section")
 var exportSectionScale by mutableDoubleStateOf(50.0)
 var exportTopScale by mutableDoubleStateOf(50.0)
 var exportSectionX by mutableDoubleStateOf(10.0)
 var exportSectionY by mutableDoubleStateOf(10.0)
 var exportTopX by mutableDoubleStateOf(153.5)
 var exportTopY by mutableDoubleStateOf(10.0)
 var exportSectionOriginX by mutableDoubleStateOf(0.0)
 var exportSectionOriginY by mutableDoubleStateOf(0.0)
 var exportTopOriginX by mutableDoubleStateOf(0.0)
 var exportTopOriginY by mutableDoubleStateOf(0.0)
 var exportScale by mutableDoubleStateOf(50.0)
 var exportWidthMm by mutableDoubleStateOf(297.0)
 var exportHeightMm by mutableDoubleStateOf(210.0)
 var exportOriginX by mutableDoubleStateOf(0.0)
 var exportOriginY by mutableDoubleStateOf(0.0)
 private var exportDrawingId by mutableStateOf("")
 var transparent by mutableStateOf(false)
 var fullExport by mutableStateOf(true)
 var pendingPackage by mutableStateOf<OpenedPackage?>(null)
 var saving by mutableStateOf(false);private set

 private fun standardStairTemplateEntry()=LibraryEntry(
  id="bauwerk-standard-treppe",type="stair-template",category="Bauwerke",name="Treppe",version=1,
  attributes=buildJsonObject{put("portable_kind","parametric_stair");put("description","Parametrisches Treppenbauwerk")},
  extensions=buildJsonObject{put("previewKind","stair")}
 )
 private var dirtySaves=0
 val canUndo get()=histories[drawingId]?.canUndo==true
 val canRedo get()=histories[drawingId]?.canRedo==true
 init {
  // Offline textures shipped with the app; available to Canvas and PDF via ProjectStore.
  runCatching {
   val folder=store.assetFile("grass-textures/placeholder.webp").parentFile!!
   folder.mkdirs()
   app.assets.list("grass-textures")?.forEach { name ->
    val dest=File(folder,name)
    if(!dest.exists() || name.contains("-vegetation-"))app.assets.open("grass-textures/$name").use { input -> dest.outputStream().use { input.copyTo(it) } }
   }
  }
  viewModelScope.launch(Dispatchers.IO) {
   for(item in saveQueue) {
    try {store.save(item.project,item.histories);index.replace(store.list())}
    catch(e:Exception){withContext(Dispatchers.Main){error="Speichern fehlgeschlagen: ${e.message}. Projekt bleibt im Arbeitsspeicher."}}
    finally {withContext(Dispatchers.Main){dirtySaves--;saving=dirtySaves>0}}
   }
  }
  work {
   val result=withContext(Dispatchers.IO){
    var state=store.loadCatalog()
    // 0.6.7: Es gibt keine separate Beispielbibliothek mehr. Die einzige
    // mitgelieferte Standardbibliothek ist die echte GaLaBau-Grundbibliothek.
    // Sie wird beim Start als verwaltete Basis eingelesen; eigene Benutzer-
    // Einträge bleiben erhalten.
    val bundled=getApplication<Application>().assets.open("Baudetail-GaLaBau-Grundbibliothek-v11.bdlib").use(Packages::read)
    val resourceMap=store.importResources(bundled)
    val managed=bundled.library().entries.map{store.remap(it,resourceMap)}
    val managedIds=managed.map{it.id}.toSet()
    val oldSampleIds=setOf("soil15","soil25","gravel8","gravel16","grit","frost","concrete","grass","perennials","paving","slab","steel","channel","inlet","kg100","drain","fleece","infiltration","tree","foundation","haunch","title-standard")
    val legacyKg=Regex("""^KG(?:2000)?\s*DN\s*\d+$""",RegexOption.IGNORE_CASE)
    val removeIds=state.entries.filter{e->
     e.id in oldSampleIds ||
     (legacyKg.matches(e.name.trim())&&!e.id.startsWith("cmp-kg2000-",true)) ||
     (e.id.startsWith("cmp-entwaesserung-rinnen-",true)&&e.category=="Entwässerung/Rinnen"&&e.id !in managedIds) ||
     e.id=="cmp-fassade-gebaeudeanschluesse-fassadenrinne"
    }.map{it.id}.toSet()
    val retained=state.entries.filterNot{it.id in removeIds||it.id in managedIds}
    val stairDescriptor=standardStairTemplateEntry()
    state=state.copy(
     entries=(retained+managed+stairDescriptor).distinctBy{it.id},
     disabled=(state.disabled-removeIds).filter{it in (retained+managed).map{e->e.id}.toSet()}.toSet(),
     favorites=state.favorites-removeIds,
     recent=state.recent.filterNot{it in removeIds}
    )
    store.saveCatalog(state)
    index.replace(store.list());state to index.list()
   }
   catalog=Catalog(result.first);records=result.second;checkTree();syncOwnAssembliesToTree()
  }
 }
 fun work(block:suspend ()->Unit){viewModelScope.launch{loading=true;try{block()}catch(e:Exception){error=e.message?:"Vorgang fehlgeschlagen"}finally{loading=false}}}
 fun report(e:Throwable){Diagnostics.log("Fehler: ${e.javaClass.simpleName}");error=e.message?:"Vorgang fehlgeschlagen"}
 fun changeTheme(value:String){theme=value;prefs.edit().putString("theme",value).apply()}
 fun finishSetup(example:Boolean){work{if(example) installExample();prefs.edit().putBoolean("setup",true).commit();setupComplete=true;refresh()}}
 private suspend fun installExample(){val p=withContext(Dispatchers.IO){getApplication<Application>().assets.open("sample-project.bproject").use(Packages::read).let{pack->store.remap(pack.project(),store.importResources(pack))}};withContext(Dispatchers.IO){if(store.list().none{it.id==p.id})store.save(p)}}
 fun refresh(){work{records=withContext(Dispatchers.IO){index.replace(store.list());index.list()}}}
 fun open(id:String){work{val value=withContext(Dispatchers.IO){store.load(id)};activate(value)}}
 private fun normalizeAutoMeasures(d:Drawing):Drawing {
  // Preserve every existing dimension verbatim, including custom text/line offsets,
  // label size, ids and unknown future parameters. Only add genuinely missing metrics.
  val existing=d.entities.filter{it.kind=="dimension"&&it.num("auto")==1.0}
  val additions=mutableListOf<Entity>()
  d.entities.filterNot{it.kind=="dimension"}.forEach{source->
   val profile=source.str(if(d.viewMode()=="section")"autoMeasureSection" else "autoMeasureTop",source.str("autoMeasureProfile").ifBlank{"Aus"})
   if(profile!="Aus"){
    val prior=existing.filter{it.str("sourceId")==source.id}
    additions+=automaticMeasures(source,d,profile).filter{candidate->prior.none{it.str("metric")==candidate.str("metric")}}
   }
  }
  return if(additions.isEmpty())d else d.copy(entities=d.entities+additions)
 }
 private fun activate(value:StoredProject){
  Diagnostics.projectId=value.project.id;Diagnostics.log("Projekt geöffnet")
  if(store.lastRecoveryCount>0)notice="${store.lastRecoveryCount} fehlerhafte Objekte wurden repariert oder übersprungen. Eine Kopie der Originaldatei wurde gesichert."
  val normalized=value.project.drawings.map{syncSmartFollowers(normalizeAutoMeasures(it))};val migrated=value.project.copy(drawings=normalized);project=migrated;histories.clear()
  normalized.forEach{d->val old=value.histories[d.id]?:DrawingHistory(d);histories[d.id]=EditorHistory(old.copy(current=d))}
  drawingId=normalized.firstOrNull()?.id?:"";selected=emptySet();if(migrated!=value.project){notice="Automatische Maße wurden auf das neue Maßmodell aktualisiert.";persist()}
 }
 fun createProject(name:String){val p=Project(name=name.trim().ifEmpty{"Neues Projekt"},createdAt=System.currentTimeMillis(),drawings=listOf(Drawing(createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis())));activate(StoredProject(p));persist()}
 fun openDrawing(id:String){if(project?.drawings?.any{it.id==id}==true){drawingId=id;Diagnostics.drawingId=id;Diagnostics.view=drawing?.type.orEmpty();Diagnostics.log("Zeichnung geöffnet");selected=emptySet();tool="select"}}
 var linkedSnap by mutableStateOf(false)
 fun edit(value:Drawing){try{val old=drawing?:return;if(value==old)return;val switched=if(value.viewMode()!=old.viewMode())normalizeAutoMeasures(value)else value;val next=syncSmartFollowers(switched).copy(updatedAt=System.currentTimeMillis());if(histories.getOrPut(old.id){EditorHistory(DrawingHistory(old))}.commit(next)){project=project?.copy(drawings=project!!.drawings.map{if(it.id==next.id)next else it});persist()}}catch(e:Exception){report(e)}}
 fun add(input:Entity){val shape=if(input.kind=="polyline"&&closedContour(input))asArea(input)else input;val e=if(linkedSnap&&shape.kind!="dimension"&&shape.kind!="elevation"&&drawing!=null)shape.copy(bindings=shape.points.mapIndexedNotNull{i,p->anchorAt(p,drawing!!)?.let{PointBinding(i,it)}})else shape;Diagnostics.log("Objekt einfügen: ${e.kind}");val d=drawing?:return;if(d.layers.find{it.id==e.layerId}?.locked==true){error="Layer ist gesperrt";return};edit(d.copy(entities=d.entities+e));selected=setOf(e.id);tool="select"}
 fun update(e:Entity){val d=drawing?:return;val old=d.entities.find{it.id==e.id}?:return;if(d.layers.find{it.id==old.layerId}?.locked==true){error="Layer ist gesperrt. Zuerst den Layer entsperren.";return};edit(d.copy(entities=d.entities.map{if(it.id==e.id)e else it}))}
 fun removeSelected(){
  val d=drawing?:return
  val deletable=d.entities.filter{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true}.map{it.id}.toMutableSet()
  var changed=true
  while(changed){changed=false;d.entities.filter{it.str("sourceId") in deletable&&(isFoundation(it)||it.kind=="dimension"||it.num("auto")==1.0)}.forEach{if(deletable.add(it.id))changed=true}}
  edit(d.copy(entities=d.entities.filterNot{it.id in deletable}));selected=emptySet()
 }
 fun modifySelected(change:(Entity)->Entity){val d=drawing?:return;edit(d.copy(entities=d.entities.map{if(it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true)change(it)else it}))}
 fun moveSelected(delta:Vec,snap:SnapResult?=null,sourceOffset:Vec?=null,rotationDelta:Double=0.0){
  val d=drawing?:return;val one=selected.singleOrNull();val snapAnchor=snap?.anchor
  var movedEntities=d.entities.map{obj->
   if(obj.id !in selected||obj.locked||d.layers.find{it.id==obj.layerId}?.locked==true)obj else {
    val constrainedDelta=if(obj.kind=="dimension"){
     // Dimensions may be moved freely in 2D. Close-to-axis drags still feel
     // CAD-like by softly snapping to horizontal/vertical; diagonal placement
     // remains possible when the user clearly drags diagonally.
     val len=delta.length()
     if(len<1e-9)delta else {
      val a=((Math.toDegrees(kotlin.math.atan2(delta.y,delta.x))%180)+180)%180
      when{
       kotlin.math.min(a,kotlin.math.abs(180-a))<=8.0 -> Vec(delta.x,0.0)
       kotlin.math.abs(a-90.0)<=8.0 -> Vec(0.0,delta.y)
       else -> delta
      }
     }
    } else delta
    var moved=when{
     obj.str("grassObject")=="true"&&d.viewMode()=="section"->obj.withNum("grassSectionDxMm",obj.num("grassSectionDxMm")+constrainedDelta.x).withNum("grassSectionDyMm",obj.num("grassSectionDyMm")+constrainedDelta.y)
     obj.str("grassObject")=="true"->obj.withNum("grassSectionOriginX",obj.num("grassSectionOriginX",obj.points.minOfOrNull{it.x}?:0.0)).withNum("grassSectionOriginY",obj.num("grassSectionOriginY",obj.points.minOfOrNull{it.y}?:0.0)).let{transform(it,translation=constrainedDelta)}
     obj.isParametricBuildUp()&&d.viewMode()!="section"->obj.withNum("buildUpTopDxMm",(if(obj.str("buildUpAnchorV2")=="true")obj.num("buildUpTopDxMm")else 0.0)+constrainedDelta.x).withNum("buildUpTopDyMm",(if(obj.str("buildUpAnchorV2")=="true")obj.num("buildUpTopDyMm")else 0.0)+constrainedDelta.y).withStr("buildUpAnchorV2","true")
     obj.kind=="component"||isStair(obj)->{val rotated=if(kotlin.math.abs(rotationDelta)>1e-9)rotateSmartInView(obj,d.viewMode(),rotationDelta)else obj;moveSmartInView(rotated,d.viewMode(),constrainedDelta)}
     obj.kind=="elevation"->moveAnnotationInView(obj,d.viewMode(),constrainedDelta)
     obj.kind=="dimension"&&obj.num("auto")==1.0->obj.withNum("dimDx",obj.num("dimDx")+constrainedDelta.x).withNum("dimDy",obj.num("dimDy")+constrainedDelta.y)
     else->transform(obj,translation=constrainedDelta)
    }
    // Section paving snap must align the *real* OK levels as well as the
    // visible endpoints. Otherwise a newly added adjacent slab retains its
    // old datum (e.g. -0.17 m despite visually meeting -0.08 m).
    val joinAnchor = snapAnchor
    if(obj.id==one && obj.isParametricBuildUp() && d.viewMode()=="section" && joinAnchor != null && joinAnchor.reference in setOf("pavingSurfaceJoin","constructionSurfaceJoin")){
     val target=d.entities.find{it.id==joinAnchor.entityId && it.isParametricBuildUp()}
     if(target!=null){
      val edge=buildUpSurfaceEdge(moved)
      val targetPoint=if(joinAnchor.vertex==0)buildUpSurfaceEdge(target).first else buildUpSurfaceEdge(target).second
      val sourceEnd=if(edge.first.distance(targetPoint)<=edge.second.distance(targetPoint))0 else 1
      moved=buildUpAlignLevelAtJoin(moved,target,sourceEnd,joinAnchor.vertex,d.elevationDatumMm)
     }
    }
    if(obj.kind=="component"||isStair(obj)){
     // A manual drag releases the semantic 0.6.2 cross-view link. If this
     // release ends on a new semantic snap, the block below creates a fresh link.
     moved=moved.withStr("viewLinkTargetId","").withStr("viewLinkSourceKey","").withStr("viewLinkTargetKey","").withStr("viewLinkCreatedView","")
    }
    if(obj.id==one&&snapAnchor!=null&&moved.points.isNotEmpty()){
     val target=d.entities.find{it.id==snapAnchor.entityId}
     val smart=obj.kind=="component"||isStair(obj)
     fun prioRank(x:Entity?)=when(x?.str("snapPriority","normal")){"high"->0;"low"->2;else->1}
     val targetLeads=target!=null&&prioRank(target)<prioRank(obj)
     val origin=if(smart)smartViewOrigin(obj,d.viewMode()) else (obj.points.firstOrNull()?:Vec());val refs=if(smart)smartSnapReferencePoints(obj,d)else emptyList()
     val sourceIndex=sourceOffset?.let{off->refs.indexOfFirst{(it-origin).distance(off)<1e-4}}?:-1
     val sourceEdge=smartSnapEdgeIndexFromReferenceIndex(sourceIndex)
     val targetEdge=when(snapAnchor.reference){"smart","component"->smartSnapEdgeIndexFromReferenceIndex(snapAnchor.vertex);"smartEdge","edge"->snapAnchor.vertex.takeIf{it in 0..3};else->null}
     val semanticSourceKey=if(smart)smartSemanticSnapKey(obj,d,origin+(sourceOffset?:Vec()))else null
     val semanticTargetKey=if(target!=null&&(target.kind=="component"||isStair(target)))smartSemanticSnapKey(target,d,snap?.point?:Vec())else null
     val semanticLinked=semanticSourceKey!=null&&semanticTargetKey!=null&&target!=null
     if(smart&&target!=null&&targetLeads&&sourceEdge!=null&&targetEdge!=null){
      val targetOutline=smartSnapOutline(target,d);val sourceOutline=smartSnapOutline(obj,d)
      if(targetOutline.size>=4&&sourceOutline.size>=4){
       val tv=targetOutline[(targetEdge+1)%4]-targetOutline[targetEdge];val sv=sourceOutline[(sourceEdge+1)%4]-sourceOutline[sourceEdge]
       fun parallelDelta(a:Double):Double{var x=((a+90.0)%180.0+180.0)%180.0-90.0;return x}
       val angle=parallelDelta(Math.toDegrees(kotlin.math.atan2(tv.y,tv.x)-kotlin.math.atan2(sv.y,sv.x)))
       moved=rotateSmartInView(moved,d.viewMode(),angle)
       moved=withSmartEdgeLength(moved,sourceEdge,tv.length(),d.viewMode())
       val sourceAfter=smartSnapOutline(moved,d);val sa=sourceAfter[sourceEdge];val sb=sourceAfter[(sourceEdge+1)%4]
       val ta=targetOutline[targetEdge];val tb=targetOutline[(targetEdge+1)%4]
       val reversed=sa.distance(tb)+sb.distance(ta)<sa.distance(ta)+sb.distance(tb)
       // Anchor the endpoint that does not move when this edge's length changes.
       val stableSourceCorner=intArrayOf(0,1,3,0)[sourceEdge];val sourceStarts=stableSourceCorner==sourceEdge
       val targetCorner=if(!reversed){if(sourceStarts)targetEdge else (targetEdge+1)%4}else{if(sourceStarts)(targetEdge+1)%4 else targetEdge}
       val targetPoint=targetOutline[targetCorner];val sourcePoint=sourceAfter[stableSourceCorner]
       val correction=targetPoint-sourcePoint;moved=moveSmartInView(moved,d.viewMode(),correction)
       moved=moved.withStr("followTargetId",target.id).withNum("followTargetEdge",targetEdge.toDouble()).withNum("followSourceEdge",sourceEdge.toDouble()).withNum("followSourceCorner",stableSourceCorner.toDouble()).withNum("followTargetCorner",targetCorner.toDouble()).withStr("followView",d.viewMode())
       // Smart links are represented by the semantic edge/corner relation above.
       // A global PointBinding would move both views together and is therefore
       // deliberately not created for these view-aware objects.
      }
     } else if(linkedSnap&&!semanticLinked && snapAnchor.reference!="pavingSurfaceJoin"){
      val off=sourceOffset?:Vec();val binding=PointBinding(0,snapAnchor.copy(offset=Vec(-off.x,-off.y)));moved=moved.copy(bindings=moved.bindings.filterNot{it.vertex==0}+binding)
     }
     if(semanticLinked){
      moved=moved.withStr("viewLinkTargetId",target!!.id).withStr("viewLinkSourceKey",semanticSourceKey!!).withStr("viewLinkTargetKey",semanticTargetKey!!).withStr("viewLinkCreatedView",d.viewMode())
      // A section only tells us which cross-section faces touch.  Preserve that
      // relation explicitly for plan and choose the longitudinal end from the
      // current plan arrangement instead of reusing meaningless section X/Y.
      if(d.viewMode()=="section"&&semanticSourceKey!!.startsWith("face:")&&semanticTargetKey!!.startsWith("face:")){
       val td=d.withViewMode("top")
       fun ends(x:Entity):List<Vec>{val c=smartSnapOutline(x,td);return if(c.size>=4)listOf((c[0]+c[3])*.5,(c[1]+c[2])*.5)else listOf(viewBounds(x,td).center)}
       val te=ends(target);val se=ends(moved);val sc=viewBounds(moved,td).center
       val targetEnd=te.indices.minByOrNull{te[it].distance(sc)}?:0
       val sourceEnd=se.indices.minByOrNull{se[it].distance(te[targetEnd])}?:0
       moved=moved.withNum("viewLinkTopTargetEnd",targetEnd.toDouble()).withNum("viewLinkTopSourceEnd",sourceEnd.toDouble())
      }
     }
    }
    moved
   }
  }
  // A moved relative elevation marker is a real geometric probe, not merely a
  // presentation offset. Re-attach it at its new position so sloped surfaces
  // immediately produce the correct local height (front/back edges may differ).
  if(one!=null){
   val idx=movedEntities.indexOfFirst{it.id==one}
   val ev=movedEntities.getOrNull(idx)
   if(idx>=0&&ev?.kind=="elevation"&&ev.str("elevationRole","manual")=="relative"){
    val at=ev.points.firstOrNull()
    if(at!=null){
     val probe=d.copy(entities=movedEntities.filterNot{it.id==ev.id})
     val a=anchorAt(at,probe)
     movedEntities=movedEntities.toMutableList().also{list->list[idx]=ev.copy(anchors=if(a!=null)listOf(a)else emptyList())}
    }
   }
  }
  // Persist the manual presentation offset of automatic dimensions on their source object.
  // This prevents a later profile refresh/rebuild from snapping a dragged measure back
  // to its generated default lane while the geometric witness points remain associative.
  val movedAuto=movedEntities.filter{it.id in selected&&it.kind=="dimension"&&it.num("auto")==1.0&&it.str("sourceId").isNotBlank()}
  if(movedAuto.isNotEmpty()){
   fun key(metric:String,field:String)="autoMeasure_${metric.replace(Regex("[^A-Za-z0-9]"),"_")}_$field"
   val bySource=movedAuto.groupBy{it.str("sourceId")}
   movedEntities=movedEntities.map{entity->
    val dims=bySource[entity.id]?:return@map entity
    var source=entity
    dims.forEach{dim->
     val metric=dim.str("metric")
     for(field in listOf("dimDx","dimDy","textDx","textDy"))source=source.withNum(key(metric,field),dim.num(field))
    }
    source
   }
  }
  edit(d.copy(entities=movedEntities))
 }

 fun duplicateSelected(){
  val d=drawing?:return;val roots=d.entities.filter{it.id in selected};val ids=roots.map{it.id}.toMutableSet();var changed=true
  while(changed){changed=false;d.entities.filter{it.str("sourceId") in ids&&(isFoundation(it)||it.kind=="dimension"||it.num("auto")==1.0)}.forEach{if(ids.add(it.id))changed=true}}
  val all=d.entities.filter{it.id in ids};val map=all.associate{it.id to uid()}
  val copies=all.map{e->var c=transform(e,Vec(d.gridMm,d.gridMm)).copy(id=map.getValue(e.id),anchors=e.anchors.map{it.copy(entityId=map[it.entityId]?:it.entityId)},groupId=null);val source=e.str("sourceId");if(source in map)c=c.withStr("sourceId",map.getValue(source));c}
  edit(d.copy(entities=d.entities+copies));selected=roots.mapNotNull{map[it.id]}.toSet()
 }
 fun mirrorSelected(){
  val d=drawing?:return
  val chosen=d.entities.filter{it.id in selected}
  if(chosen.isEmpty())return
  if(chosen.size==1){
   val obj=chosen.first()
   val before=viewBounds(obj,d)
   var mirrored=transform(obj,mirror=true,center=before.center)
   val after=viewBounds(mirrored,d)
   val delta=before.center-after.center
   mirrored=if(obj.kind=="component"||isStair(obj)) moveSmartInView(mirrored,d.viewMode(),delta) else transform(mirrored,translation=delta)
   edit(d.copy(entities=d.entities.map{if(it.id==obj.id)mirrored else it}))
  }else{
   val groupCenter=Bounds.of(chosen.flatMap{val b=viewBounds(it,d);listOf(b.min,b.max)}).center
   edit(d.copy(entities=d.entities.map{obj->
    if(obj.id !in selected)obj else {
     val before=viewBounds(obj,d)
     var mirrored=transform(obj,mirror=true,center=groupCenter)
     val expectedCenter=Vec(2*groupCenter.x-before.center.x,before.center.y)
     val after=viewBounds(mirrored,d)
     val delta=expectedCenter-after.center
     if(obj.kind=="component"||isStair(obj)) moveSmartInView(mirrored,d.viewMode(),delta) else transform(mirrored,translation=delta)
    }
   }))
  }
 }
 fun orderSelected(front:Boolean){val d=drawing?:return;val sel=d.entities.filter{it.id in selected};val rest=d.entities.filterNot{it.id in selected};edit(d.copy(entities=if(front)rest+sel else sel+rest))}
 fun undo(){histories[drawingId]?.let{it.undo();replaceCurrent(it.current)}}
 fun redo(){histories[drawingId]?.let{it.redo();replaceCurrent(it.current)}}
 private fun replaceCurrent(d:Drawing){project=project?.copy(drawings=project!!.drawings.map{if(it.id==d.id)d else it});selected=emptySet();persist()}
 fun backups()=histories[drawingId]?.persisted()?.backups.orEmpty()
 fun restoreBackup(index:Int){histories[drawingId]?.let{it.restore(index);replaceCurrent(it.current)}}
 fun persist(){val p=project?:return;dirtySaves++;saving=true;saveQueue.trySend(StoredProject(p,histories.mapValues{it.value.persisted()}))}
 fun updateProject(name:String,metadata:Map<String,String>,notes:String){project=project?.copy(name=name,metadata=metadata,notes=notes);persist()}
 fun addDrawing(name:String,type:String,variant:Boolean=false){val p=project?:return;val d=if(variant&&drawing!=null)drawing!!.copy(id=uid(),name=name,variantOf=drawingId,createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis())else Drawing(name=name,type=type,createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis());project=p.copy(drawings=p.drawings+d);histories[d.id]=EditorHistory(DrawingHistory(d));drawingId=d.id;selected=emptySet();persist()}
 fun renameHistory(redo:Boolean=false):Boolean = ((project?.extensions?.get(if(redo)"nameRedo"else"nameUndo") as? JsonArray)?.isNotEmpty()==true)
 fun undoProjectName(redo:Boolean=false){val p=project?:return;val from=if(redo)"nameRedo"else"nameUndo";val to=if(redo)"nameUndo"else"nameRedo";val names=(p.extensions[from] as? JsonArray).orEmpty();val name=(names.lastOrNull() as? JsonPrimitive)?.contentOrNull?:return
  project=p.copy(name=name,extensions=JsonObject(p.extensions+mapOf(from to JsonArray(names.dropLast(1)),to to JsonArray(((p.extensions[to] as? JsonArray).orEmpty()+JsonPrimitive(p.name)).takeLast(5)))))
  persist()
 }
 fun renameDrawing(id:String,name:String){val d=project?.drawings?.find{it.id==id}?:return;openDrawing(id);edit(d.copy(name=name.trim().ifBlank{d.name}))}
 fun duplicateDrawing(id:String){val d=project?.drawings?.find{it.id==id}?:return;val copy=d.copy(id=uid(),name=d.name+" (Kopie)",createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis());project=project?.copy(drawings=project!!.drawings+copy);histories[copy.id]=EditorHistory(DrawingHistory(copy));persist()}
 fun deleteDrawing(id:String){val p=project?:return;project=p.copy(drawings=p.drawings.filterNot{it.id==id}.map{d->d.copy(sourceDrawingId=d.sourceDrawingId?.takeUnless{it==id},entities=d.entities.map{e->if(e.targetDrawingId==id)e.copy(targetDrawingId=null)else e})});histories.remove(id);if(drawingId==id)drawingId=project?.drawings?.firstOrNull()?.id.orEmpty();persist()}
 fun projectAction(id:String,action:String,name:String=""){work{
  while(saving)delay(50)
  val stored=withContext(Dispatchers.IO){store.load(id)}
  when(action){
   "rename"->{val changed=stored.copy(project=stored.project.copy(name=name.trim().ifBlank{stored.project.name},extensions=JsonObject(stored.project.extensions+mapOf("nameUndo" to JsonArray(((stored.project.extensions["nameUndo"] as? JsonArray).orEmpty()+JsonPrimitive(stored.project.name)).takeLast(5)),"nameRedo" to JsonArray(emptyList())))));withContext(Dispatchers.IO){store.save(changed.project,changed.histories)};if(project?.id==id)activate(changed)}
   "duplicate"->{val p=stored.project;val mapping=p.drawings.associate{it.id to uid()};val copy=p.copy(id=uid(),name=p.name+" (Kopie)",drawings=p.drawings.map{d->d.copy(id=mapping.getValue(d.id),sourceDrawingId=mapping[d.sourceDrawingId],entities=d.entities.map{it.copy(targetDrawingId=mapping[it.targetDrawingId]?:it.targetDrawingId)})});withContext(Dispatchers.IO){store.save(copy)}}
   "delete"->{withContext(Dispatchers.IO){store.deleteProject(id)};if(project?.id==id){project=null;drawingId="";histories.clear()}}
  }
  records=withContext(Dispatchers.IO){store.list()}
 }}
 fun moveDrawing(id:String,targetId:String){work{
  while(saving)delay(50)
  val source=project?:return@work;val d=source.drawings.find{it.id==id}?:return@work
  require(source.id!=targetId){"Zielprojekt ist bereits das aktuelle Projekt"}
  withContext(Dispatchers.IO){val target=store.load(targetId);require(target.project.drawings.none{it.id==id}){"Zeichnungs-ID im Ziel vorhanden"};store.save(target.project.copy(drawings=target.project.drawings+d,libraryEntries=(target.project.libraryEntries+source.libraryEntries).distinctBy{it.id}),target.histories+(id to (histories[id]?.persisted()?:DrawingHistory(d))))}
  deleteDrawing(id)
 }}
 fun addRevision(title:String){val p=project?:return;project=p.copy(revisions=p.revisions+Revision(title=title,drawings=p.drawings));persist();notice="Revision unveränderbar gespeichert"}
 fun restoreRevision(id:String){val p=project?:return;val revision=p.revisions.find{it.id==id}?:return;val map=revision.drawings.associate{it.id to uid()};val copies=revision.drawings.map{d->d.copy(id=map.getValue(d.id),name=d.name+" · "+revision.title,sourceDrawingId=map[d.sourceDrawingId],entities=d.entities.map{it.copy(targetDrawingId=map[it.targetDrawingId]?:it.targetDrawingId)})};project=p.copy(drawings=p.drawings+copies);copies.forEach{histories[it.id]=EditorHistory(DrawingHistory(it))};drawingId=copies.firstOrNull()?.id?:drawingId;persist()}
 fun addSection(points:List<Vec>,label:String="A–A") {
  val p=project?:return;val d=drawing?:return;val cut=Drawing(name="Schnitt $label",type="Schnitt",createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis(),sourceDrawingId=d.id,sheet=Sheet(scale=10.0))
  project=p.copy(drawings=p.drawings+cut);histories[cut.id]=EditorHistory(DrawingHistory(cut))
  add(Entity(kind="section",points=points,text=label,targetDrawingId=cut.id))
 }
 fun attachLibraryForPlacedVariant(entry:LibraryEntry){val p=project?:return;project=p.copy(libraryEntries=p.libraryEntries.filterNot{it.id==entry.id}+entry);catalog.used(entry.id);saveCatalog();persist()}
 fun attachEntry(entry:LibraryEntry) {
  val p=project?:return;project=p.copy(libraryEntries=p.libraryEntries.filterNot{it.id==entry.id}+entry);catalog.used(entry.id);saveCatalog()
  if(entry.type=="material"){if(drawing?.entities?.none{it.id in selected&&closedContour(it)}!=false){notice="Zuerst eine geschlossene Fläche auswählen.";return};modifySelected{if(closedContour(it))it.copy(materialId=entry.id,materialSnapshot=null,quantityUnit="m²")else it}}
  else if(entry.type=="titleblock"||entry.type=="text-template") {if(entry.type=="titleblock")drawing?.let{edit(it.copy(sheet=it.sheet.copy(titleTemplate=entry.template?:"")))}else{entryToPlace=entry;tool="library"}}
  else {entryToPlace=entry;tool="library"}
 }
 fun saveStair(input:Entity,entry:LibraryEntry){val e=input.copy(children=listOf(componentInstance(entry,Vec())));require(stairGoing(e)>0&&stairGoing(e)<=stairDepth(e)){"Auftritt größer als Stufentiefe"};
  val p=project?:return
  project=p.copy(libraryEntries=p.libraryEntries.filterNot{it.id==entry.id}+entry)
  if(drawing?.entities?.any{it.id==e.id}==true)update(e)else add(e)
 }
 fun dissolveStair(e:Entity){val d=drawing?:return;val p=project?:return
  val steps=stairSteps(e,d,p)
  val refs=d.entities.map{obj->if(obj.id==e.id)obj else if(obj.anchors.any{it.entityId==e.id}||obj.bindings.any{it.anchor.entityId==e.id}||obj.str("sourceId")==e.id)obj.copy(points=resolvedPoints(obj,d),anchors=emptyList(),bindings=emptyList(),text=if(obj.kind=="dimension")dimensionLabel(obj,d)else obj.text,kind=if(obj.kind=="dimension")"text"else obj.kind,params=JsonObject(obj.params-setOf("sourceId","metric")))else obj}
  edit(d.copy(entities=refs.filterNot{it.id==e.id}+steps));selected=steps.map{it.id}.toSet()
 }
 fun dissolveTemplate(e:Entity){
  val d=drawing?:return;if(!isFrozenTemplate(e))return
  val sec=d.withViewMode("section");val top=d.withViewMode("top")
  val idMap=e.children.associate{it.id to uid()}
  fun remapRefs(x:Entity):Entity{
   var r=x.copy(id=idMap[x.id]?:x.id,groupId=null,anchors=x.anchors.map{a->a.copy(entityId=idMap[a.entityId]?:a.entityId,otherEntityId=a.otherEntityId?.let{oldId->idMap[oldId]?:oldId})},bindings=x.bindings.map{b->b.copy(anchor=b.anchor.copy(entityId=idMap[b.anchor.entityId]?:b.anchor.entityId,otherEntityId=b.anchor.otherEntityId?.let{oldId->idMap[oldId]?:oldId}))})
   for(k in listOf("viewLinkTargetId","followTargetId","sourceId")){val old=r.str(k);if(old in idMap)r=r.withStr(k,idMap.getValue(old))}
   return r
  }
  val children=e.children.map{child->
   var c=remapRefs(child)
   if(c.kind=="component"||isStair(c)){
    val secOrigin=frozenTemplatePoint(e,smartViewOrigin(child,"section"),sec)
    val topOrigin=frozenTemplatePoint(e,smartViewOrigin(child,"top"),top)
    val base=c.points.firstOrNull()?:Vec();c=transform(c,translation=secOrigin-base)
    c=c.withNum("sectionDx",0.0).withNum("sectionDy",0.0).withNum("topDx",topOrigin.x-secOrigin.x).withNum("topDy",topOrigin.y-secOrigin.y)
    c=c.withNum("sectionRotationDelta",c.num("sectionRotationDelta")+smartViewRotation(e,"section")).withNum("topRotationDelta",c.num("topRotationDelta")+smartViewRotation(e,"top"))
   }else{
    c=c.copy(points=c.points.map{pt->frozenTemplatePoint(e,pt,sec)})
   }
   c
  }
  val refs=d.entities.map{obj->if(obj.id==e.id)obj else if(obj.anchors.any{it.entityId==e.id}||obj.bindings.any{it.anchor.entityId==e.id}||obj.str("sourceId")==e.id)obj.copy(points=resolvedPoints(obj,d),anchors=emptyList(),bindings=emptyList(),text=if(obj.kind=="dimension")dimensionLabel(obj,d)else obj.text,kind=if(obj.kind=="dimension")"text"else obj.kind,params=JsonObject(obj.params-setOf("sourceId","metric")))else obj}
  edit(syncSmartFollowers(d.copy(entities=refs.filterNot{it.id==e.id}+children)));selected=children.map{it.id}.toSet();notice="Bauwerk aufgelöst · intelligente Einzelbauteile und Snappunkte sind wieder aktiv."
 }
 fun placeEntry(at:Vec){val entry=entryToPlace?:return;add(when(entry.type){"text-template"->Entity(kind="text",points=listOf(at),text=entry.template?:entry.name);"assembly-template"->instantiateTemplate(entry,at);else->componentInstance(entry,at)})}
 fun saveAssembly(name:String,category:String="Eigene Bauwerke",updateId:String?=null){
  val d=drawing?:return;val items=d.entities.filter{it.id in selected};require(items.isNotEmpty()){"Objekte auswählen"}
  val topD=d.withViewMode("top");val sectionD=d.withViewMode("section")
  fun boundsIn(view:Drawing):Bounds {val pts=items.flatMap{obj->val b=viewBounds(obj,view);rectangle(b.min,b.max)};return Bounds.of(pts)}
  val topOrigin=boundsIn(topD).min;val sectionOrigin=boundsIn(sectionD).min
  fun freeze(e:Entity,normalizePose:Boolean):Entity{
   val m=project?.libraryEntries?.find{it.id==e.materialId};val lib=project?.libraryEntries?.find{it.id==e.libraryId}
   var result=e.copy(points=resolvedPoints(e,d),bindings=emptyList(),materialSnapshot=m?.appearance?:m?.let{MaterialAppearance(top=it.style,section=it.style,sectionPattern=it.views["section"])},children=e.children.map{freeze(it,false)})
   lib?.views?.forEach{(k,v)->result=result.withStr("asset_"+k,v)}
   if(isStair(result)&&result.children.isEmpty()&&lib!=null)result=result.copy(children=listOf(componentInstance(lib,Vec())))
   if(normalizePose){
    if(result.kind=="component"||isStair(result)){
     val secAt=smartViewOrigin(e,"section")-sectionOrigin;val topAt=smartViewOrigin(e,"top")-topOrigin
     val oldBase=result.points.firstOrNull()?:Vec();result=transform(result,translation=secAt-oldBase)
     result=result.withNum("sectionDx",0.0).withNum("sectionDy",0.0).withNum("topDx",topAt.x-secAt.x).withNum("topDy",topAt.y-secAt.y)
    }else result=transform(result,translation=Vec()-sectionOrigin)
   }
   return result
  }
  val entry=templateEntry(name,category,items.map{freeze(it,true)},Vec(),catalog.entries().find{it.id==updateId});catalog.import(LibraryPackage(entries=listOf(entry)),ConflictPolicy.REPLACE);saveCatalog();work{writeEntryToTree(entry)};notice="Bauwerksvorlage gespeichert; Schnitt und Draufsicht wurden gemeinsam aktualisiert. Vorhandene Instanzen bleiben unverändert."
 }
 fun editAssembly(entry:LibraryEntry){if(project==null)createProject("Vorlagenwerkstatt");addDrawing(entry.name+" · Vorlagen-Arbeitskopie","Freies Blatt");val d=drawing?:return;edit(d.copy(entities=entry.geometry,extensions=JsonObject(d.extensions+("editingTemplateId" to JsonPrimitive(entry.id)))));selected=entry.geometry.map{it.id}.toSet()}
 fun exportEntry(entry:LibraryEntry,uri:Uri){work{withContext(Dispatchers.IO){val resources=store.resources(Project(drawings=emptyList(),libraryEntries=listOf(entry)));getApplication<Application>().contentResolver.openOutputStream(uri,"wt")?.use{Packages.library(it,LibraryPackage(name=entry.name,entries=listOf(entry)),resources)}?:error("Datei nicht schreibbar")};notice="Bauwerk exportiert"}}
 fun setAutoMeasures(e:Entity,profile:String,view:String=drawing?.viewMode()?:"section"){
  val d=drawing?:return;val existing=d.entities.filter{it.str("sourceId")==e.id&&it.num("auto")==1.0}
  fun key(metric:String,field:String)="autoMeasure_${metric.replace(Regex("[^A-Za-z0-9]"),"_")}_$field"
  var source=e.withStr(if(view=="section")"autoMeasureSection" else "autoMeasureTop",profile)
  existing.forEach{old->val metric=old.str("metric");listOf("dimDx","dimDy","textDx","textDy").forEach{field->source=source.withNum(key(metric,field),old.num(field))}}
  val targetDrawing=d.withViewMode(view)
  val fresh=automaticMeasures(source,targetDrawing,profile).map{new->
   val metric=new.str("metric");val old=existing.find{it.str("metric")==metric}
   var result=if(old==null)new else new.copy(id=old.id)
   for(field in listOf("dimDx","dimDy","textDx","textDy")){
    val stored=key(metric,field);val value=when{old!=null->old.num(field,new.num(field));stored in source.params->source.num(stored,new.num(field));else->new.num(field)}
    result=result.withNum(field,value)
   }
   result
  }
  val existingIds=existing.map{it.id}.toSet();edit(d.copy(entities=d.entities.map{if(it.id==e.id)source else it}.filterNot{it.id in existingIds}+fresh))
 }
 fun setUnderfoundation(source:Entity,enabled:Boolean){val d=drawing?:return;val existing=foundationFor(source,d);if(!enabled){if(existing!=null)edit(d.copy(entities=d.entities.filterNot{it.id==existing.id}));return};if(existing!=null)return
  val all=(catalog.entries()+project!!.libraryEntries);val concrete=all.firstOrNull{it.type=="material"&&it.name.contains("C20/25",true)}
  if(concrete!=null&&project!!.libraryEntries.none{it.id==concrete.id})project=project!!.copy(libraryEntries=project!!.libraryEntries+concrete)
  val sourceBounds=viewBounds(source,d);val defaultWidth=if(isStair(source))source.num("widthMm",1000.0)+200.0 else sourceBounds.width+200.0;val type=if(isStair(source))"without_wedge" else "with_wedge"
  val f=Entity(kind="foundation",points=listOf(source.points.firstOrNull()?:Vec()),name="Unterfundament",layerId=source.layerId,placement=source.placement.copy(level="Fundament",visibleTop=false,visibleSection=true),materialId=concrete?.id,style=Style(stroke="#777773",fill="#C8C8C3"),params=buildJsonObject{put("sourceId",source.id);put("thicknessMm",200.0);put("foundationWidthMm",defaultWidth);put("foundationType",type);put("wedgeEnabled",(type=="with_wedge").toString());put("embedMode","auto");put("embedMm",sourceBounds.height/3.0);put("wedgeSide","both");put("stairFoundationExecution",if(isStair(source))"sloped" else "");put("showInTop","false");put("snapPriority","low")})
  edit(d.copy(entities=d.entities+f));selected=setOf(source.id)
 }
 fun setFoundationWedge(source:Entity,enabled:Boolean){val d=drawing?:return;val f=foundationFor(source,d)?:run{setUnderfoundation(source,true);return};update(f.withStr("foundationType",if(enabled)"with_wedge" else "without_wedge").withStr("wedgeEnabled",enabled.toString()))}
 fun updateFoundation(source:Entity,thickness:Double,width:Double,type:String,embedMode:String,embed:Double,wedgeSide:String,stairExecution:String="sloped"){val d=drawing?:return;val f=foundationFor(source,d)?:return;update(f.withNum("thicknessMm",thickness).withNum("foundationWidthMm",width).withStr("foundationType",type).withStr("wedgeEnabled",(type=="with_wedge").toString()).withStr("embedMode",embedMode).withNum("embedMm",embed).withStr("wedgeSide",wedgeSide).withStr("stairFoundationExecution",if(isStair(source))stairExecution else f.str("stairFoundationExecution")))}
 fun detachConnections(e:Entity){val d=drawing?:return;update(e.copy(points=resolvedPoints(e,d),bindings=emptyList(),anchors=emptyList()))}
 fun saveSymbol(name:String){val d=drawing?:return;val entities=d.entities.filter{it.id in selected};if(entities.isEmpty())return
  val bounds=Bounds.of(entities.flatMap{listOf(entityBounds(it).min,entityBounds(it).max)})
  val entry=LibraryEntry(id=uid(),type="component",category="Eigene Bauteile",name=name,attributes=buildJsonObject{put("width_mm",bounds.width.coerceAtLeast(1.0));put("height_mm",bounds.height.coerceAtLeast(1.0))},geometry=entities.map{transform(it,translation=Vec()-bounds.min).copy(anchors=emptyList())})
  catalog.import(LibraryPackage(entries=listOf(entry)),ConflictPolicy.REPLACE);saveCatalog();work{writeEntryToTree(entry)}
 }
 private suspend fun writeEntryToTree(entry:LibraryEntry){withContext(Dispatchers.IO){val tree=treeUri?.let{DocumentFile.fromTreeUri(getApplication(),Uri.parse(it))};if(tree==null||!tree.canWrite()){withContext(Dispatchers.Main){notice="Bauteil intern gespeichert. Externen Ordner zum Synchronisieren einrichten."};return@withContext}
  val resources=store.resources(Project(drawings=emptyList(),libraryEntries=listOf(entry)))
  if(entry.type=="assembly-template"||entry.type=="stair-template"||entry.category.startsWith("Eigene Bauwerke",true)){
   // Eigene Bauwerke are portable one-file library packages.  Keeping them in
   // /Bauwerke makes a single stair/assembly easy to exchange with colleagues.
   val folder=tree.findFile("Bauwerke")?.takeIf{it.isDirectory} ?: tree.createDirectory("Bauwerke") ?: error("Bauwerke-Ordner kann nicht angelegt werden")
   val stem=entry.name.replace(Regex("[^A-Za-z0-9ÄÖÜäöüß._ -]"),"_").trim().ifBlank{"Bauwerk"}.take(60)
   val marker=entry.id.take(8)
   folder.listFiles().filter{it.isFile&&it.name?.endsWith("-$marker.bdlib",true)==true}.forEach{it.delete()}
   val file=folder.createFile("application/octet-stream","$stem-$marker.bdlib")?:error("Bauwerksdatei konnte nicht angelegt werden")
   getApplication<Application>().contentResolver.openOutputStream(file.uri,"wt")?.use{out->Packages.library(out,LibraryPackage(name=entry.name,entries=listOf(entry)),resources)}?:error("Bauwerksdatei kann nicht geschrieben werden")
   return@withContext
  }
  for((path,bytes) in resources) {
   require(Packages.safeName(path))
   val parts=path.split('/');var folder:DocumentFile=requireNotNull(tree)
   for(segment in parts.dropLast(1)) folder=folder.findFile(segment)?.takeIf{it.isDirectory} ?: folder.createDirectory(segment) ?: error("Ressourcenordner kann nicht angelegt werden")
   val target=folder.findFile(parts.last()) ?: folder.createFile("application/octet-stream",parts.last()) ?: error("Ressource kann nicht angelegt werden")
   getApplication<Application>().contentResolver.openOutputStream(target.uri,"wt")?.use{it.write(bytes)} ?: error("Ressource kann nicht geschrieben werden")
  }
  val file=tree.findFile("${entry.id}.json") ?: tree.createFile("application/json","${entry.id}.json")?:error("Bibliotheksdatei konnte nicht angelegt werden")
  getApplication<Application>().contentResolver.openOutputStream(file.uri,"wt")!!.use{it.write(BaudetailJson.encodeToString(entry).toByteArray())}
 }}
 private suspend fun syncOwnAssembliesToTree(){
  val tree=treeUri?.let{DocumentFile.fromTreeUri(getApplication(),Uri.parse(it))}?:return
  if(!tree.canWrite())return
  (catalog.entries().filter{it.type=="assembly-template"||it.category.startsWith("Eigene Bauwerke",true)}+standardStairTemplateEntry()).distinctBy{it.id}.forEach{writeEntryToTree(it)}
 }
 fun saveCatalog(){libraryVersion++;val snapshot=catalog.state;viewModelScope.launch(Dispatchers.IO){runCatching{store.saveCatalog(snapshot)}.onFailure{withContext(Dispatchers.Main){report(it)}}}}
 fun chooseTree(uri:Uri){work{
  withContext(Dispatchers.IO){val cr=getApplication<Application>().contentResolver;val flags=Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
   try{cr.takePersistableUriPermission(uri,flags)}catch(e:SecurityException){cr.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
  }
  treeUri=uri.toString();prefs.edit().putString("tree",uri.toString()).commit();checkTree();reloadTree();syncOwnAssembliesToTree()
 }}
 suspend fun checkTree(){treeStatus=withContext(Dispatchers.IO){try{val u=treeUri?:return@withContext "Kein externer Ordner gewählt";val cr=getApplication<Application>().contentResolver;if(cr.persistedUriPermissions.none{it.uri.toString()==u&&it.isReadPermission})return@withContext "Zugriff verloren – Ordner erneut wählen";val doc=DocumentFile.fromTreeUri(getApplication(),Uri.parse(u));if(doc?.canRead()!=true)"Ordner nicht erreichbar – erneut wählen" else if(doc.canWrite())"Ordner erreichbar · Lesen und Schreiben"else"Ordner erreichbar · Nur Lesen"}catch(e:Exception){"Zugriff verloren – Ordner erneut wählen"}};treeProblem=treeUri!=null&&!treeStatus.startsWith("Ordner erreichbar")}
 fun reloadLibrary(){work{checkTree();reloadTree()}}
 private suspend fun reloadTree(){val u=treeUri?:return;val collected=withContext(Dispatchers.IO){
  val root=DocumentFile.fromTreeUri(getApplication(),Uri.parse(u))?:error("Bibliotheksordner fehlt");require(root.canRead()){ "Zugriff verloren. Ordner bitte erneut auswählen." }
  val found=mutableListOf<LibraryEntry>();val errors=mutableListOf<String>();var visited=0
  // External v16 material manifests are data, not LibraryEntry JSON files.
  // Copy referenced WebP resources into the project asset store so projects and
  // exports work even after the SAF folder is disconnected.
  fun readExternalMaterial(file:DocumentFile,folder:DocumentFile):LibraryEntry {
   val json=Json.parseToJsonElement(readBytes(file.uri,128*1024).toString(Charsets.UTF_8)).jsonObject
   val id=json["id"]?.jsonPrimitive?.content ?: error("Material-ID fehlt")
   require(id.matches(Regex("[a-zA-Z0-9_-]{1,100}"))){"Ungültige Material-ID"}
   val name=json["name"]?.jsonPrimitive?.content ?: error("Materialname fehlt")
   val source=json["textures"]?.jsonArray?.map{it.jsonPrimitive.content}.orEmpty().take(16)
   val assets=source.map{filename->
    require(filename.matches(Regex("[a-zA-Z0-9_-]+\\.webp"))){"Ungültiger Texturdateiname"}
    val resource=folder.findFile(filename)?:error("Textur fehlt: $filename")
    store.putAsset(readBytes(resource.uri,4*1024*1024),"webp")
   }
   val meta=buildJsonObject { put("textureType",json["surfaceType"]?.jsonPrimitive?.content.orEmpty());put("externalMaterialId",id) }
   return LibraryEntry(id=id,type="material",category="Beläge/Externe Materialien",name=name,
    extensions=buildJsonObject {put("baudetailMaterial",meta);put("baudetailTextureAssets",JsonArray(assets.map(::JsonPrimitive)))})
  }
  fun walk(dir:DocumentFile,depth:Int){require(depth<=64){"Bibliothek tiefer als 64 Ebenen"};for(f in dir.listFiles()){visited++;require(visited<=50000){"Bibliothek enthält zu viele Dateien"};if(f.isDirectory)walk(f,depth+1)else if(f.name?.endsWith(".bdlib",true)==true){runCatching{val pack=readPackage(f.uri);val mapping=store.importResources(pack);found.addAll(pack.library().entries.map{store.remap(it,mapping)})}.onFailure{errors.add("${f.name}: ${it.message}")}}else if(f.name=="material.json" && dir.name!="Bauwerke") {runCatching{found.add(readExternalMaterial(f,dir))}.onFailure{errors.add("${dir.name}/material.json: ${it.message}")}}else if(f.name?.endsWith(".json",true)==true){runCatching{
   val entry=BaudetailJson.decodeFromString<LibraryEntry>(readBytes(f.uri).toString(Charsets.UTF_8));val paths=mutableListOf<String>();paths.addAll(entry.views.values);entry.preview?.let(paths::add)
   entry.appearance?.sectionPattern?.let(paths::add)
   fun collect(e:Entity){e.materialSnapshot?.sectionPattern?.let(paths::add);e.params.filterKeys{it.startsWith("asset_")}.values.forEach{(it as? JsonPrimitive)?.contentOrNull?.let(paths::add)};e.asset?.let(paths::add);e.children.forEach(::collect)}
   entry.geometry.forEach(::collect)
   val mapping=paths.distinct().associateWith{path->require(Packages.safeName(path));var resource=dir;for(segment in path.split('/'))resource=resource.findFile(segment)?:error("Ressource fehlt: $path");store.putAsset(readBytes(resource.uri),path.substringAfterLast('.'))};found.add(store.remap(entry,mapping))
  }.onFailure{errors.add("${f.name}: ${it.message}")}}
  }}
  walk(root,0);found to errors
 }
 // Reconcile the external library's previous plant-container variants.
 // Preserve all unrelated, private and project-local catalog entries.
 val incomingIds=collected.first.map{it.id}.toSet()
 val singlePlanterPresent="cmp-ausstattung-pflanztrog" in incomingIds
 if(singlePlanterPresent){
  val legacy=catalog.state.entries.filter{it.id !in incomingIds && it.category.startsWith("Ausstattung/Pflanzgefäße/Pflanztrog",true) && it.name.startsWith("Pflanztrog –",true)}.map{it.id}.toSet()
  if(legacy.isNotEmpty())catalog.state=catalog.state.copy(entries=catalog.state.entries.filterNot{it.id in legacy},disabled=catalog.state.disabled-legacy,favorites=catalog.state.favorites-legacy,recent=catalog.state.recent.filterNot{it in legacy})
 }
 catalog.import(LibraryPackage(entries=collected.first.distinctBy{it.id}),ConflictPolicy.REPLACE);saveCatalog();notice="${collected.first.size} Einträge eingelesen";if(collected.second.isNotEmpty())error=collected.second.take(8).joinToString("\n")
 }
 private fun readBytes(uri:Uri,limit:Int=64*1024*1024):ByteArray {
  val input=getApplication<Application>().contentResolver.openInputStream(uri)?:error("Datei nicht lesbar")
  input.use{val out=ByteArrayOutputStream();val buffer=ByteArray(8192);while(true){val n=it.read(buffer);if(n<0)break;require(out.size()+n<=limit){ "Datei zu groß" };out.write(buffer,0,n)};return out.toByteArray()}
 }
 private fun readPackage(uri:Uri):OpenedPackage = getApplication<Application>().contentResolver.openInputStream(uri)?.use(Packages::read)?:error("Datei nicht lesbar")
 fun stagePackage(uri:Uri){work{pendingPackage=withContext(Dispatchers.IO){readPackage(uri)}}}
 fun importPending(asCopy:Boolean=false,policy:ConflictPolicy=ConflictPolicy.KEEP){val pack=pendingPackage?:return;work{
  val mapping=withContext(Dispatchers.IO){store.importResources(pack)}
  when(pack.manifest.kind){
   "project"->{var p=store.remap(pack.project(),mapping);if(asCopy)p=p.copy(id=uid(),name=p.name+" (Kopie)");val existing=withContext(Dispatchers.IO){store.list().find{it.id==p.id}};if(existing!=null&&!asCopy){open(existing.id)}else{activate(StoredProject(p));persist()}}
   "drawing"->{val d=pack.drawing().let{it.copy(id=uid(),entities=it.entities.map{e->store.remap(e,mapping)})};if(project==null)createProject(pack.manifest.name);project=project!!.copy(drawings=project!!.drawings+d,libraryEntries=(project!!.libraryEntries+pack.drawingEntries().map{store.remap(it,mapping)}).distinctBy{it.id});histories[d.id]=EditorHistory(DrawingHistory(d));drawingId=d.id;persist()}
   "library"->{val lib=pack.library();val remapped=lib.entries.map{store.remap(it,mapping)};if(remapped.any{it.id=="cmp-kg2000-pipe"}){val incoming=remapped.map{it.id}.toSet();catalog.state=catalog.state.copy(entries=catalog.state.entries.filterNot{old->old.id !in incoming && (old.category.startsWith("Rohre/KG",true)||old.name.matches(Regex("""KG\s*2000?\s*DN.*""",RegexOption.IGNORE_CASE))||old.name.matches(Regex("""KG\s+DN.*""",RegexOption.IGNORE_CASE)))},disabled=catalog.state.disabled.filterNot{it.startsWith("cmp-kg")}.toSet())};catalog.import(lib.copy(entries=remapped),policy);saveCatalog();notice="Bibliothek importiert"}
  };pendingPackage=null
 }}
 fun importBackground(uri:Uri,page:Int=0){work{
  val e=withContext(Dispatchers.IO){
   val bytes=readBytes(uri);val cr=getApplication<Application>().contentResolver;val mime=cr.getType(uri).orEmpty();var extension=when{mime.contains("pdf")||bytes.take(4).toByteArray().toString(Charsets.US_ASCII)=="%PDF"->"pdf";mime.contains("svg")||bytes.toString(Charsets.UTF_8).trimStart().startsWith("<")->"svg";else->"png"}
   var width=1000.0;var height=1000.0;var data=bytes;var originalAsset:String?=null
   if(extension=="pdf") {
    val original=store.putAsset(bytes,"pdf");originalAsset=original;val f=store.assetFile(original)
    ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY).use{fd->PdfRenderer(fd).use{r->require(page in 0 until r.pageCount){"PDF enthält ${r.pageCount} Seiten"};r.openPage(page).use{pg->val factor=minOf(2.0,4096.0/maxOf(pg.width,pg.height));val bmp=Bitmap.createBitmap((pg.width*factor).toInt().coerceAtLeast(1),(pg.height*factor).toInt().coerceAtLeast(1),Bitmap.Config.ARGB_8888);bmp.eraseColor(android.graphics.Color.WHITE);pg.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);val out=ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.PNG,100,out);data=out.toByteArray();width=pg.width.toDouble();height=pg.height.toDouble();bmp.recycle()}}};extension="png"
   } else if(extension=="svg"){sanitizeSvg(bytes.toString(Charsets.UTF_8));val svg=com.caverock.androidsvg.SVG.getFromString(bytes.toString(Charsets.UTF_8));val box=svg.documentViewBox;width=box?.width()?.toDouble()?:1000.0;height=box?.height()?.toDouble()?:1000.0}
   else {val options=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,options);require(options.outWidth>0){"Bildformat ungültig"};require(options.outWidth.toLong()*options.outHeight<=32000000){"Bild über 32 Megapixel. Bitte verkleinern."};width=options.outWidth.toDouble();height=options.outHeight.toDouble();extension=if(options.outMimeType=="image/jpeg")"jpg"else"png"}
   val path=store.putAsset(data,extension);Entity(kind="image",points=listOf(Vec()),asset=path,name="Hintergrund",locked=false,params=buildJsonObject{put("widthMm",width);put("heightMm",height);originalAsset?.let{put("sourceAsset",it)}},style=Style(opacity=0.7))
  };add(e);notice="Hintergrund eingefügt. Zwei Punkte über Kalibrieren auswählen."
 }}
 fun prepareExport(){val d=drawing?:return;if(exportDrawingId!=d.id){exportDrawingId=d.id;exportScale=d.sheet.scale;exportWidthMm=d.sheet.widthMm;exportHeightMm=d.sheet.heightMm;val visible=d.entities.filter{visibleIn(it,d)};if(visible.isNotEmpty()){val b=Bounds.of(visible.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)});exportOriginX=b.min.x;exportOriginY=b.max.y
  listOf("section","top").forEach{mode->val view=d.withViewMode(mode);val items=view.entities.filter{visibleIn(it,view)};if(items.isNotEmpty()){val bb=Bounds.of(items.flatMap{listOf(viewBounds(it,view).min,viewBounds(it,view).max)});if(mode=="section"){exportSectionOriginX=bb.min.x;exportSectionOriginY=bb.min.y}else{exportTopOriginX=bb.min.x;exportTopOriginY=bb.min.y}}}}else{exportOriginX=d.sheet.origin.x;exportOriginY=d.sheet.origin.y}}}
 fun dualExportNodes(d:Drawing,p:Project):List<Primitive> {
  val w=(d.sheet.widthMm-30.0)/2.0
  val sx=exportSectionX.coerceIn(0.0,d.sheet.widthMm-w)
  val tx=exportTopX.coerceIn(0.0,d.sheet.widthMm-w)
  return Scene.paperDual(d,p,Vec(sx,exportSectionY),Vec(tx,exportTopY),exportSectionScale.coerceAtLeast(1.0),exportTopScale.coerceAtLeast(1.0),Vec(exportSectionOriginX,exportSectionOriginY),Vec(exportTopOriginX,exportTopOriginY))
 }
 /** Select the view whose actual projected drawing bounds contain the touch. */
 fun selectDualAtPaper(x:Double,y:Double){
  val d=exportDrawing()?:return
  fun hit(mode:String,posX:Double,posY:Double,originX:Double,originY:Double,scale:Double):Boolean{
   val v=d.withViewMode(mode)
   val items=v.entities.filter{visibleIn(it,v)}
   if(items.isEmpty())return false
   val b=Bounds.of(items.flatMap{listOf(viewBounds(it,v).min,viewBounds(it,v).max)})
   val left=posX+(b.min.x-originX)/scale;val right=posX+(b.max.x-originX)/scale
   val top=posY+8.0+(b.min.y-originY)/scale;val bottom=posY+8.0+(b.max.y-originY)/scale
   return x in (left-4.0)..(right+4.0) && y in (top-4.0)..(bottom+4.0)
  }
  if(hit("top",exportTopX,exportTopY,exportTopOriginX,exportTopOriginY,exportTopScale))exportDualSelection="top"
  else if(hit("section",exportSectionX,exportSectionY,exportSectionOriginX,exportSectionOriginY,exportSectionScale))exportDualSelection="section"
 }
 fun moveDualOnPaper(dx:Double,dy:Double){if(exportDualSelection=="section"){exportSectionX+=dx;exportSectionY+=dy}else{exportTopX+=dx;exportTopY+=dy}}
 fun exportDrawing():Drawing?{val d=drawing?:return null;prepareExport();return d.copy(sheet=d.sheet.copy(scale=exportScale.coerceAtLeast(.1),widthMm=exportWidthMm.coerceAtLeast(20.0),heightMm=exportHeightMm.coerceAtLeast(20.0),origin=Vec(exportOriginX,exportOriginY),showPaper=true))}
 fun setExportPaper(width:Double,height:Double){exportWidthMm=width;exportHeightMm=height}
 /** Move only the paper-space translation. Never modify exportScale here. */
 fun moveExportOnPaper(dxPaperMm:Double,dyPaperMm:Double){exportOriginX-=dxPaperMm*exportScale;exportOriginY-=dyPaperMm*exportScale}
 fun resetExportPosition(){val d=drawing?:return;val visible=d.entities.filter{visibleIn(it,d)};if(visible.isEmpty()){exportOriginX=d.sheet.origin.x;exportOriginY=d.sheet.origin.y;return};val b=Bounds.of(visible.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)});exportOriginX=b.min.x;exportOriginY=b.max.y}
 fun centerExport(){val d=exportDrawing()?:return;val visible=d.entities.filter{visibleIn(it,d)};if(visible.isEmpty())return;val b=Bounds.of(visible.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)});val printableW=(d.sheet.widthMm-20.0).coerceAtLeast(1.0)*d.sheet.scale;val printableH=(d.sheet.heightMm-42.0).coerceAtLeast(1.0)*d.sheet.scale;exportOriginX=b.center.x-printableW/2;exportOriginY=b.center.y+printableH/2}
 fun exportOverflow():Boolean{val d=exportDrawing()?:return false;val visible=d.entities.filter{visibleIn(it,d)};if(visible.isEmpty())return false;val b=Bounds.of(visible.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)});val box=Bounds(Vec(exportOriginX,exportOriginY-(d.sheet.heightMm-42.0)*d.sheet.scale),Vec(exportOriginX+(d.sheet.widthMm-20.0)*d.sheet.scale,exportOriginY));return !box.contains(b.min)||!box.contains(b.max)}
 private fun uriWithExtension(uri:Uri,format:String):Uri{val resolver=getApplication<Application>().contentResolver;val name=runCatching{resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())c.getString(0)else null}}.getOrNull().orEmpty();if(name.endsWith(".$format",true))return uri;val fixed=(name.substringBeforeLast('.',name).ifBlank{drawing?.name?:"Baudetail"})+".$format";return runCatching{DocumentsContract.renameDocument(resolver,uri,fixed)?:uri}.getOrDefault(uri)}
 fun exportTo(uri:Uri){val p=project?:return;val d=exportDrawing()?:return;val format=exportFormat;work{withContext(Dispatchers.IO){val target=uriWithExtension(uri,format);getApplication<Application>().contentResolver.openOutputStream(target,"wt")?.use{writeExport(it,format,p,d)}?:error("Datei kann nicht geschrieben werden")};notice="Export gespeichert"}}
 private fun writeExport(out:OutputStream,format:String,p:Project,d:Drawing){val service=ExportService(store::assetFile);when(format){"pdf"->service.pdf(out,d,p,if(exportDual)dualExportNodes(d,p)else null);"png"->service.png(out,d,p,exportDpi,transparent);"svg"->service.svg(out,d,p);"bproject"->Packages.project(out,p,if(fullExport)store.resources(p)else emptyMap(),fullExport);"bdetail"->Packages.drawing(out,d,store.resources(p.copy(drawings=listOf(d),revisions=emptyList())),p.libraryEntries);"bdlib"->{val entries=catalog.entries();val lib=LibraryPackage(name="Baudetail Bibliothek",entries=entries);val resources=store.resources(Project(drawings=emptyList(),libraryEntries=entries));Packages.library(out,lib,resources)};else->error("Unbekanntes Exportformat")}}
 fun share(onReady:(File)->Unit){val p=project?:return;val d=exportDrawing()?:return;work{val safe=d.name.replace(Regex("[\\/:*?\"<>|]"),"_").ifBlank{"Baudetail"};val file=withContext(Dispatchers.IO){File(getApplication<Application>().cacheDir,"exports/$safe.$exportFormat").also{it.parentFile!!.mkdirs();it.outputStream().use{out->writeExport(out,exportFormat,p,d)}}};onReady(file)}}
 override fun onCleared(){saveQueue.close();index.close();super.onCleared()}
}
