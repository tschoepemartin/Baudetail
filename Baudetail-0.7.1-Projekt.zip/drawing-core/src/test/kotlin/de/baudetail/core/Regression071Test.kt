package de.baudetail.core

import org.junit.Assert.*
import org.junit.Test

class Regression071Test {
 @Test fun defaultsUseRequestedBeddingAndFrostThicknesses(){
  val entry=LibraryEntry(id="x",type="component",category="Aufbau",name="Pflasteraufbau begehbar",attributes=kotlinx.serialization.json.buildJsonObject{put("Schichten","Pflaster 8 cm | Bettung 4 cm | Frostschutz 25 cm")})
  val s=entry.defaultBuildUpStrata();assertEquals(40.0,s[1].thicknessMm,0.01);assertEquals(300.0,s[2].thicknessMm,0.01);assertEquals("Splitt 2/5",s[1].materialId);assertEquals("FS-Kies 0/32",s[2].materialId)
 }
 @Test fun planBoundsUseFullPathWidthNotSectionThickness(){
  val e=Entity(kind="stack",points=listOf(de.baudetail.geometry.Vec(0.0,0.0)),params=kotlinx.serialization.json.buildJsonObject{put("widthMm",2400.0);put("topDepthMm",1300.0)},strata=listOf(Stratum(thicknessMm=80.0),Stratum(thicknessMm=40.0),Stratum(thicknessMm=300.0)))
  val d=Drawing().withViewMode("top");val b=viewBounds(e,d);assertEquals(2400.0,b.width,0.01);assertEquals(1300.0,b.height,0.01);assertTrue(hitTest(de.baudetail.geometry.Vec(1200.0,1200.0),e,d,1.0))
 }
 @Test fun buildUpLabelDoesNotDuplicateGradingOrThickness(){
  val e=Entity(kind="stack",strata=listOf(Stratum("Betonpflaster","Pflaster",80.0),Stratum("Splitt 2/5","Bettung",40.0,"#fff","2/5"),Stratum("FS-Kies 0/32","Frostschutz",300.0,"#fff","0/32")))
  val label=buildUpLabel(e);assertTrue(label.contains("Betonpflaster 8 cm"));assertTrue(label.contains("Splitt 2/5 4 cm"));assertTrue(label.contains("FS-Kies 0/32 30 cm"));assertFalse(label.contains("2/5 4 cm · 2/5"))
 }
}
