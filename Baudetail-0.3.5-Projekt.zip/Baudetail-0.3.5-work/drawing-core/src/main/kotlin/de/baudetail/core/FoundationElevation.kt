package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*

fun isFoundation(e:Entity)=e.kind=="foundation"
fun supportsFoundation(e:Entity)=isStair(e)||(e.kind=="component"&&e.smartFamily() !in setOf("grass","pipe"))
fun foundationFor(source:Entity,d:Drawing)=d.entities.find{isFoundation(it)&&it.str("sourceId")==source.id}

/** Smart underfoundation geometry. It is stored as its own object, but derives its
 * position and length from the linked component so type/size changes stay coherent. */
fun foundationOutline(e:Entity,d:Drawing):List<Vec> {
 val source=d.entities.find{it.id==e.str("sourceId")} ?: return e.points
 val b=viewBounds(source,d)
 val over=e.num("overhangMm",100.0).coerceAtLeast(0.0)
 val thick=e.num("thicknessMm",200.0).coerceAtLeast(1.0)
 return if(d.viewMode()=="section") rectangle(Vec(b.min.x-over,b.max.y),Vec(b.max.x+over,b.max.y+thick))
 else rectangle(Vec(b.min.x-over,b.min.y-over),Vec(b.max.x+over,b.max.y+over))
}
fun foundationWedges(e:Entity,d:Drawing):List<List<Vec>> {
 if(e.str("wedgeEnabled","false")!="true"||d.viewMode()!="section")return emptyList()
 val source=d.entities.find{it.id==e.str("sourceId")}?:return emptyList()
 val b=viewBounds(source,d);val w=e.num("wedgeWidthMm",150.0).coerceAtLeast(1.0);val h=e.num("wedgeHeightMm",150.0).coerceAtLeast(1.0)
 val side=e.str("wedgeSide","both")
 val left=listOf(Vec(b.min.x,b.max.y),Vec(b.min.x-w,b.max.y),Vec(b.min.x,b.max.y-h))
 val right=listOf(Vec(b.max.x,b.max.y),Vec(b.max.x+w,b.max.y),Vec(b.max.x,b.max.y-h))
 return when(side){"left"->listOf(left);"right"->listOf(right);else->listOf(left,right)}
}

fun annotationViewOffset(e:Entity,view:String)=Vec(e.num("${view}Dx"),e.num("${view}Dy"))
fun moveAnnotationInView(e:Entity,view:String,delta:Vec)=e.withNum("${view}Dx",e.num("${view}Dx")+delta.x).withNum("${view}Dy",e.num("${view}Dy")+delta.y)

fun elevationLeader(d:Drawing):Entity?=d.entities.lastOrNull{it.kind=="elevation"&&it.str("elevationRole")=="leader"}
fun elevationValueMm(e:Entity,d:Drawing):Double {
 val role=e.str("elevationRole",e.str("mode","manual"))
 if(role=="leader"||role=="manual"||role=="absolute")return e.num("heightMm")
 val leader=elevationLeader(d)?:return e.num("heightMm")
 val leaderAt=resolvedPoints(leader,d).firstOrNull()?:leader.points.firstOrNull()?:Vec()
 val here=resolvedPoints(e,d).firstOrNull()?:e.points.firstOrNull()?:Vec()
 // CAD section Y grows downwards: points above the reference have a higher elevation.
 return leader.num("heightMm")+(leaderAt.y-here.y)+e.num("heightOffsetMm")
}
