package de.baudetail.ui

import de.baudetail.ui.diagnostics.*
import android.content.ClipData
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.compose.*
import de.baudetail.core.*
import de.baudetail.libraries.*
import de.baudetail.ui.dialogs.*
import de.baudetail.ui.screens.*
import de.baudetail.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun BaudetailRoot(vm:BaudetailViewModel){
 val nav=rememberNavController();val context=LocalContext.current
 var crashNotice by remember{mutableStateOf(Diagnostics.pending())}
 SideEffect{Diagnostics.tool=vm.tool;Diagnostics.drawingId=vm.drawingId;Diagnostics.projectId=vm.project?.id.orEmpty();Diagnostics.view=vm.drawing?.type.orEmpty()}
 val tree=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){it?.let(vm::chooseTree)}
 val open=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(vm::stagePackage)}
 var dismissedTreeProblem by remember{mutableStateOf(false)}
 var pendingBackground by remember { mutableStateOf<android.net.Uri?>(null) }
 val background=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){pendingBackground=it}
 val save=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){it?.let(vm::exportTo)}
 val owner=LocalLifecycleOwner.current
 DisposableEffect(owner){val observer=LifecycleEventObserver{_,event->if(event==Lifecycle.Event.ON_STOP)vm.persist()};owner.lifecycle.addObserver(observer);onDispose{owner.lifecycle.removeObserver(observer)}}
 BaudetailTheme(vm.theme){
  Surface(Modifier.fillMaxSize()){Box(Modifier.fillMaxSize()){
   if(!vm.setupComplete&&!vm.loading){SetupScreen(vm,chooseFolder={tree.launch(null)})}
   else NavHost(nav,startDestination="home"){
    composable("home"){HomeScreen(vm,onProject={nav.navigate("projects")},onNew={name->vm.createProject(name);nav.navigate("projects")},onOpen={open.launch(arrayOf("*/*"))},onLibrary={nav.navigate("library")},onSettings={nav.navigate("settings")},onExport={nav.navigate("export")},onAssemblies={nav.navigate("assemblies")})}
    composable("projects"){ProjectsScreen(vm,onBack={nav.popBackStack()},onDraw={nav.navigate("drawing")},onSettings={nav.navigate("project-settings")},onExport={nav.navigate("export")})}
    composable("drawing"){DrawingScreen(vm,onBack={nav.popBackStack()},onLibrary={nav.navigate("library")},onExport={nav.navigate("export")},onBackground={background.launch(arrayOf("image/*","application/pdf"))})}
    composable("library"){LibraryScreen(vm,onBack={nav.popBackStack()},onImport={nav.navigate("import")},onFolder={tree.launch(null)},onUse={vm.attachEntry(it);if(vm.drawing!=null)nav.navigate("drawing")})}
    composable("assemblies"){LibraryScreen(vm,onBack={nav.popBackStack()},onImport={nav.navigate("import")},onFolder={tree.launch(null)},onUse={vm.attachEntry(it);if(vm.drawing!=null)nav.navigate("drawing")},assembliesOnly=true,onEdit={nav.navigate("drawing")})}
    composable("project-settings"){ProjectSettingsScreen(vm,onBack={nav.popBackStack()})}
    composable("settings"){SettingsScreen(vm,onBack={nav.popBackStack()},onFolder={tree.launch(null)},onDiagnostics={nav.navigate("diagnostics")})}
    composable("diagnostics"){DiagnosticsScreen(vm,onBack={nav.popBackStack()})}
    composable("import"){Page("Datei importieren",{nav.popBackStack()}){Text("Baudetail-Projekt, Zeichnung oder Bibliothek auswählen. ZIP-Pakete werden vor dem Import geprüft.");Button(onClick={open.launch(arrayOf("*/*"))}){Text(".bproject / .bdetail / .bdlib auswählen")}}}
    composable("export"){ExportScreen(vm,onBack={nav.popBackStack()},onSave={save.launch("Baudetail.${vm.exportFormat}")},onShare={vm.share{file->val uri=FileProvider.getUriForFile(context,"${context.packageName}.files",file);val intent=Intent(Intent.ACTION_SEND).apply{type=mime(vm.exportFormat);putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newRawUri("Baudetail",uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};context.startActivity(Intent.createChooser(intent,"Baudetail teilen"))}})}
   }
   if(vm.loading)LinearProgressIndicator(Modifier.fillMaxWidth().height(3.dp).align(androidx.compose.ui.Alignment.TopCenter))
  }
  }
  if(crashNotice&&vm.setupComplete)AlertDialog(onDismissRequest={crashNotice=false;Diagnostics.dismiss()},title={Text("Absturzbericht gespeichert")},text={Text("Baudetail wurde unerwartet beendet. Ein lokaler Bericht wurde gespeichert.")},confirmButton={TextButton(onClick={crashNotice=false;Diagnostics.dismiss();nav.navigate("diagnostics")}){Text("Bericht ansehen")}},dismissButton={TextButton(onClick={crashNotice=false;Diagnostics.dismiss()}){Text("Später")}})
  pendingBackground?.let { uri -> FormDialog("Hintergrund importieren",listOf(Field("page","PDF-Seite (bei Bildern ohne Wirkung)","1",true,true)),{pendingBackground=null}) { values -> val page=de.baudetail.geometry.parseNumber(values.getValue("page"))!!.toInt()-1;vm.importBackground(uri,page) } }
  if(vm.treeProblem&&!dismissedTreeProblem)AlertDialog(onDismissRequest={dismissedTreeProblem=true},title={Text("Bibliotheksordner nicht verfügbar")},text={Text(vm.treeStatus+". Deine lokalen Projekte bleiben verfügbar.")},confirmButton={TextButton(onClick={dismissedTreeProblem=true;tree.launch(null)}){Text("Ordner erneut wählen")}},dismissButton={TextButton(onClick={dismissedTreeProblem=true}){Text("Später")}})
  vm.error?.let{AlertDialog(onDismissRequest={vm.error=null},title={Text("Vorgang nicht möglich")},text={Text(it)},confirmButton={TextButton(onClick={vm.error=null}){Text("OK")}})}
  vm.notice?.let{AlertDialog(onDismissRequest={vm.notice=null},text={Text(it)},confirmButton={TextButton(onClick={vm.notice=null}){Text("OK")}})}
  vm.pendingPackage?.let{pack->
   if(pack.manifest.kind=="library")ChoiceDialog("${pack.manifest.name}: Konflikte behandeln",listOf("Vorhandenes behalten","Neue Version verwenden","Als Kopie importieren"),{vm.pendingPackage=null}){vm.importPending(policy=ConflictPolicy.entries[it])}
   else AlertDialog(onDismissRequest={vm.pendingPackage=null},title={Text(pack.manifest.name)},text={Text(if(pack.manifest.kind=="project")"Projekt öffnen oder als eigenständige Kopie importieren? Ein bereits vorhandenes Projekt wird beim Öffnen lokal weitergeführt."else"Zeichnung in die aktuelle Projektakte importieren?")},confirmButton={TextButton(onClick={vm.importPending();nav.navigate("projects")}){Text(if(pack.manifest.kind=="project")"Projekt öffnen"else"Importieren")}},dismissButton={if(pack.manifest.kind=="project")TextButton(onClick={vm.importPending(asCopy=true);nav.navigate("projects")}){Text("Als neues Projekt")}})
  }
 }
}
fun mime(format:String)=when(format){"pdf"->"application/pdf";"png"->"image/png";"svg"->"image/svg+xml";"bproject"->"application/vnd.baudetail.project";"bdetail"->"application/vnd.baudetail.drawing";"bdlib"->"application/vnd.baudetail.library";else->"application/octet-stream"}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Page(title:String,onBack:(()->Unit)?=null,content:@Composable ColumnScope.()->Unit){Scaffold(topBar={TopAppBar(title={Text(title)},navigationIcon={if(onBack!=null)IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Zurück")}})}){padding->Column(Modifier.padding(padding).padding(20.dp).fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)}}
