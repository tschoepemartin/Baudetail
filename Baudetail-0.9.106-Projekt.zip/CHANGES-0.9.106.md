# BauDetail 0.9.106 – Römischer Verband

- Übernimmt die sieben Steinrechtecke und die Modulabmessungen exakt aus `freie-muster/naturstein/free-roemisch.json` der vorhandenen externen Bibliothek.
- Beim Wählen von Römischer Verband ohne externes Muster wird die Geometrie als offline-fähiger Snapshot im Plan gespeichert (nur bei 4 mm Fuge).
- Die Zeichenengine verwendet gespeicherte externe Geometrie unabhängig von der Musterverband-Checkbox.
- Keine erfundene 4x4-Anordnung mehr für den Standardfall.
- Hinweis: Das freie Modul besitzt feste Steinmaße 308x204, 204x204, 100x100, 204x100 mm; andere Steinformate werden hiermit nicht skaliert.
- Noch nicht auf Android gebaut/getestet.
