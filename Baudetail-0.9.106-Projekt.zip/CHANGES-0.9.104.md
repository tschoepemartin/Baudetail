# BauDetail 0.9.104 – Externe Muster, Metadaten und Auswahl

- ZIP-Metadaten werden auch bei unbekannter ZIP-Eintragsgröße gelesen (Android-ZipInputStream liefert häufig -1); dabei bleibt das Einlesen auf 256 KiB je JSON-Datei begrenzt.
- Der Pflastereditor zeigt lesbare Produkt-/Musternamen an und löst sie beim Speichern zurück auf die eindeutige Muster-ID.
- Die eigentliche Geometrie wird weiterhin erst beim Auswählen geladen.
- App-Version auf 0.9.104 angehoben.

**Nicht verifiziert:** Android-Kompilierung, Zugriff auf die Bibliothek auf dem Smartphone, Flächenunion, komplexe Steingeometrie und Naturstein-Bildtexturen. Die externe Bibliothek bleibt unverändert.
