# 0.9.103 – Bibliotheksmetadaten und Fehlerhinweise

- GODELMANN-Namen auch bei unbekannter ZIP-Entry-Größe lesen (ZipInputStream liefert oft -1).
- Hersteller/Produktserie und Verlegemustername in der Auswahl zusammenführen.
- Bei inkompatiblen römischen Steinformaten keine stumme leere Steinzeichnung mehr.

Nicht vollständig gelöst: polygonale Module, echte Mehrformat-Verlegemodule, Materialtexturen ohne Bildressourcen, Flächenunion. Nicht kompiliert.
