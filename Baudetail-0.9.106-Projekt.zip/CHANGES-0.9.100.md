# BauDetail 0.9.100 – Korrekturstand

- Normale Verbandsauswahl immer sichtbar, unabhängig von Musterverband-Checkbox.
- Interne Verbände unabhängig vom externen Bibliotheksschalter gezeichnet.
- Steinformate bei Mehrformatverbänden unabhängig vom externen Schalter sichtbar.
- Bibliotheksstatus beim Neuladen zurückgesetzt und Anzahl auswählbarer Muster im Status ergänzt.

**Offen:** Externe Bibliothek auf Android nachweislich erkennen; vollständige Modulgeometrie und Natursteintexturen vereinheitlichen; Flächenunion und fachlich korrekten Römischen Verband validieren. Keine Behauptung, dass diese Punkte bereits gelöst sind.
