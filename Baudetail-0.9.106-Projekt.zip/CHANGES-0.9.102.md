# 0.9.102 – Gemeinsame Geometrie für Steine und Texturen

- Draufsicht Pflaster: Die Bildtexturen werden nicht länger über ein eigenständiges rechteckiges Raster gezeichnet. Sie folgen jetzt exakt den vom Verband erzeugten Einzelsteinen, einschließlich Mehrformat- und externen Rechteckmodulen.
- Die Vektorfugen bleiben im selben Stein-Zeichenpfad; keine überlagerten Texturraster mit falschen Fugenpositionen.
- Externe Musterauswahl beschränkt sich auf als wiederholbar markierte und konvertierte Muster.

## Noch nicht gelöst
- Bibliothekszugriff und Index auf einem echten Android-Gerät nicht verifiziert.
- Polygone, Drehungen einzelner externer Steine, 100% originale Herstellergeometrie nicht vollständig unterstützt.
- Die interne Römisch-Routine ist weiterhin kein geprüfter Original-Verlegeplan.
- Flächenunion nicht überarbeitet.
- Nicht alle Natursteinmaterialien besitzen hinterlegte Bilddateien; für diese bleibt die bestehende generierte Materialoberfläche.
- Kein bestätigter Android-Build und kein Gerätetest.
