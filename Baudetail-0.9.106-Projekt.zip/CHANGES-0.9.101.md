# BauDetail 0.9.101 – Bibliothekseinlesung

- Beim App-Start wird nach dem Prüfen des gespeicherten Bibliotheksordners auch der vollständige externe Bibliotheksindex erneut geladen. Zuvor wurden die externen Muster nur bei explizitem Reload/Ordnerwechsel erfasst; der Muster-Dropdown konnte deshalb trotz vorhandener .bdlib leer sein.
- Beim einmaligen Durchlauf des externen Archivs werden lesbare Musternamen aus den einzelnen Muster-JSONs erfasst, da das Manifest nur IDs und Dateipfade enthält. Dadurch zeigt die Auswahl verständliche Bezeichnungen.
- Weiterhin werden nur validierte/erzeugte Mustereinträge angeboten; die Engine akzeptiert weiterhin nur achsparallele rechteckige wiederholbare Module.

## Noch offen
- Exakte polygonale/gedrehte Herstellergeometrie, komplette Mehrformat- und Natursteintexturen, geometrisch robuste Flächenunion.
- GitHub-Kompilierung und Android-Gerätetest stehen aus.
