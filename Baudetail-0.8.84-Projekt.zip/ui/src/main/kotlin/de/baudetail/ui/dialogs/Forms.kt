package de.baudetail.ui.dialogs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import de.baudetail.geometry.parseNumber

data class Field(val key:String,val label:String,val initial:String="",val numeric:Boolean=false,val positive:Boolean=false,val choices:List<String> = emptyList(),val checkbox:Boolean=false,val enabledWhen:String?=null)
@Composable fun FormDialog(title:String,fields:List<Field>,onDismiss:()->Unit,onSubmit:(Map<String,String>)->Unit){
 val values=remember(fields){mutableStateMapOf<String,String>().apply{fields.forEach{put(it.key,it.initial)}}}
 var error by remember{mutableStateOf<String?>(null)};var openChoice by remember{mutableStateOf<String?>(null)}
 AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  fields.forEach{f->
   val enabled=f.enabledWhen?.let{values[it].orEmpty().lowercase() in setOf("ja","true","1","an")}?:true
   when{
   f.checkbox->{Row(Modifier.fillMaxWidth()){Checkbox(values[f.key].orEmpty().lowercase() in setOf("ja","true","1","an"),{checked->
     if(f.key=="pavingModeRaster" || f.key=="pavingModeStone"){
      if(checked){values["pavingModeRaster"]=if(f.key=="pavingModeRaster")"ja" else "nein";values["pavingModeStone"]=if(f.key=="pavingModeStone")"ja" else "nein"}
     } else values[f.key]=if(checked)"ja"else"nein"
    });Text(f.label,Modifier.padding(top=12.dp))}}
   f.choices.isNotEmpty()->{Box{OutlinedButton(onClick={openChoice=f.key},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text("${f.label}: ${values[f.key].orEmpty()}");Spacer(Modifier.weight(1f));Text("▾")}};DropdownMenu(expanded=openChoice==f.key,onDismissRequest={openChoice=null}){f.choices.forEach{choice->DropdownMenuItem(text={Row(Modifier.fillMaxWidth()){Text(choice);Spacer(Modifier.weight(1f));if(values[f.key]==choice)Text("✓")}},onClick={values[f.key]=choice;openChoice=null})}}}}
   else->OutlinedTextField(values[f.key].orEmpty(),{values[f.key]=it},enabled=enabled,label={Text(f.label)},keyboardOptions=KeyboardOptions(keyboardType=if(f.numeric && !f.positive)KeyboardType.Text else if(f.numeric)KeyboardType.Decimal else KeyboardType.Text),modifier=Modifier.fillMaxWidth(),minLines=if(f.key=="notes"||f.key=="text"||f.key=="template")3 else 1)
  }}
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 }},confirmButton={TextButton(onClick={val bad=fields.firstOrNull{it.numeric&&(it.enabledWhen==null||values[it.enabledWhen]=="ja")&&(parseNumber(values[it.key].orEmpty())==null||(it.positive&&(parseNumber(values[it.key].orEmpty())?:0.0)<=0))};if(bad!=null)error="${bad.label}: gültige ${if(bad.positive)"positive "else""}Zahl eingeben"else try{onSubmit(values.toMap());onDismiss()}catch(e:Exception){error=e.message}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
@Composable fun ChoiceDialog(title:String,choices:List<String>,onDismiss:()->Unit,selectedIndex:Int?=null,onChoose:(Int)->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())){choices.forEachIndexed{i,s->TextButton(onClick={onDismiss();onChoose(i)},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text(s);Spacer(Modifier.weight(1f));if(selectedIndex==i)Text("✓")}}}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})}

@Composable fun ElevationDialog(title:String,initialRole:String,initialHeight:String,initialPrefix:String,initialFontMm:Double,initialArrowMm:Double,onDismiss:()->Unit,onSubmit:(String,Double,String,Double,Double)->Unit){
 ElevationDialogWithLeaders(title,initialRole,initialHeight,initialPrefix,initialFontMm,initialArrowMm,emptyList(),"",{},"Keine Oberfläche erkannt",2,onDismiss,{role,value,prefix,font,arrow,_->onSubmit(role,value,prefix,font,arrow)})
}
@Composable
fun ElevationDialogWithLeaders(
 title: String,
 initialRole: String,
 initialHeight: String,
 initialPrefix: String,
 initialFontMm: Double,
 initialArrowMm: Double,
 planLeaders: List<Pair<String, String>>,
 selectedPlanLeaderId: String,
 onPlanLeaderSelected: (String) -> Unit,
 surfaceLabel: String,
 initialDecimals: Int,
 onDismiss: () -> Unit,
 onSubmit: (String, Double, String, Double, Double, Int) -> Unit
){
 var decimals by remember{mutableIntStateOf(initialDecimals.coerceIn(2,4))};var decimalExpanded by remember{mutableStateOf(false)};var role by remember{mutableStateOf(initialRole)};var height by remember{mutableStateOf(initialHeight)};var prefix by remember{mutableStateOf(initialPrefix)};var fontMm by remember{mutableStateOf(initialFontMm.toString())};var arrowMm by remember{mutableStateOf(initialArrowMm.toString())};var error by remember{mutableStateOf<String?>(null)}
 val roles=listOf("relative" to "Relativ automatisch","leader" to "Leader / Bezugshöhe","manual" to "Manuell")
 AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("Gemessene Oberfläche: $surfaceLabel",style=MaterialTheme.typography.bodySmall)
  Box { OutlinedButton(onClick={decimalExpanded=true}){Text("Nachkommastellen: $decimals ▾")};DropdownMenu(expanded=decimalExpanded,onDismissRequest={decimalExpanded=false}){(2..4).forEach{n->DropdownMenuItem(text={Text("$n Nachkommastellen")},onClick={decimals=n;decimalExpanded=false})}}}
  Text("Art");roles.forEach{(key,label)->Row(Modifier.fillMaxWidth()){RadioButton(selected=role==key,onClick={role=key});Text(label,Modifier.padding(top=12.dp));Spacer(Modifier.weight(1f));if(role==key)Text("✓",Modifier.padding(top=12.dp))}}
  if(role=="relative" && planLeaders.isNotEmpty()){
   var leaderExpanded by remember{mutableStateOf(false)}
   Box { OutlinedButton(onClick={leaderExpanded=true}){Text(planLeaders.firstOrNull{it.first==selectedPlanLeaderId}?.second?:"Leader auswählen ▾")}
    DropdownMenu(expanded=leaderExpanded,onDismissRequest={leaderExpanded=false}){planLeaders.forEach{(id,label)->DropdownMenuItem(text={Text(label)},onClick={onPlanLeaderSelected(id);leaderExpanded=false})}}
   }
  }
  OutlinedTextField(height,{height=it},label={Text(if(role=="relative")"Zusatz/Offset (m)" else "Höhe (m)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Text),modifier=Modifier.fillMaxWidth())
  OutlinedTextField(prefix,{prefix=it},label={Text("Bezeichnung optional, z. B. OK / UK / Sohle")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(fontMm,{fontMm=it},label={Text("Schriftgröße auf Papier (mm)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
  OutlinedTextField(arrowMm,{arrowMm=it},label={Text("Pfeilgröße auf Papier (mm)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
  if(role=="relative")Text("Die Höhe wird aus dem Leader und der geometrischen Höhendifferenz des gefangenen Bauteilpunkts berechnet.",style=MaterialTheme.typography.bodySmall)
  error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 }},confirmButton={TextButton(onClick={val n=parseNumber(height);if(n==null||parseNumber(fontMm)==null||parseNumber(arrowMm)==null||(parseNumber(fontMm)?:0.0)<=0||(parseNumber(arrowMm)?:0.0)<=0)error="Gültige Zahlen eingeben" else {onSubmit(role,n,prefix,parseNumber(fontMm)!!,parseNumber(arrowMm)!!,decimals);onDismiss()}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
