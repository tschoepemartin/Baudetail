# 0.8.18 – Gefällezeichen bei Maßstabswechseln

Gefällepfeile an Pflasteraufbauten werden auf maximal 44 mm Papierbreite begrenzt (vorher bis 280 mm). Der Textabstand wird in Papiermillimetern berechnet. Die Trefffläche zum Verschieben nutzt dieselbe Breitenbegrenzung. Auch freie Gefälleobjekte und Stufengefälle erhalten konsistente Beschriftungsabstände.

Die Änderung erfolgt beim Rendern; bestehende Projektdateien müssen nicht migriert werden. Geometrie, physische Druckskalierung, Plankopf und 100-mm-Kontrollmaß bleiben unverändert.

Build und visueller A3-Test stehen aus.
