package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

/** Additive editor preferences, versioned independently inside the v1 extension container. */
data class DrawingInput(
 val gridVisible:Boolean=true, val snapEnabled:Boolean=true, val snapMm:Double=10.0,
 val ortho:Boolean=false, val angleStep:Double=0.0, val edgeStepMm:Double=100.0,
 val modes:Set<String> = setOf("Raster","Endpunkt","Mitte","Schnittpunkt","Kante","Zentrum")
) {
 fun options(tolerance:Double)=SnapOptions(snapEnabled&&"Raster" in modes,snapEnabled,ortho,angleStep,snapMm,tolerance,modes)
}
fun Drawing.input():DrawingInput {
 val o=extensions["drawingInput"] as? JsonObject?:return DrawingInput()
 fun b(k:String,default:Boolean)=(o[k] as? JsonPrimitive)?.booleanOrNull?:default
 fun n(k:String,default:Double)=(o[k] as? JsonPrimitive)?.doubleOrNull?.takeIf{it.isFinite()}?:default
 return DrawingInput(b("gridVisible",true),b("snapEnabled",true),n("snapMm",10.0).coerceAtLeast(0.001),b("ortho",false),n("angleStep",0.0).coerceIn(0.0,180.0),n("edgeStepMm",100.0).coerceAtLeast(0.0),(o["modes"] as? JsonArray)?.mapNotNull{(it as? JsonPrimitive)?.contentOrNull}?.toSet()?:DrawingInput().modes)
}
fun Drawing.withInput(v:DrawingInput)=copy(extensions=JsonObject(extensions+("drawingInput" to buildJsonObject {
 put("schemaVersion",1);put("gridVisible",v.gridVisible);put("snapEnabled",v.snapEnabled);put("snapMm",v.snapMm);put("ortho",v.ortho);put("angleStep",v.angleStep);put("edgeStepMm",v.edgeStepMm);put("modes",JsonArray(v.modes.map{JsonPrimitive(it)}))
})))
val dragShapeTools=setOf("rect","circle","building","area","arc","line","arrow","leader","dimension")
fun shapeFromDrag(kind:String,a:Vec,b:Vec):Entity {
 require(a.finite()&&b.finite()&&a.distance(b)>1e-9)
 return when(kind) {
 "rect","building","area"->Entity(kind=kind,points=rectangle(a,b),name=when(kind){"building"->"Gebäudeumriss";"area"->"Pflanzfläche";else->"Rechteck"},style=Style(fill=when(kind){"building"->"#DFE1DD";"area"->"#DCE8C9";else->null}),quantityUnit=if(kind=="area")"m²"else null)
 "circle","arc"->Entity(kind=kind,points=listOf(a,b)).withNum("radiusMm",a.distance(b)).let{if(kind=="arc")it.withNum("startAngle",Math.toDegrees(atan2(b.y-a.y,b.x-a.x))).withNum("sweepAngle",90.0)else it}
 "leader"->Entity(kind="leader",points=listOf(a,b),text="Hinweis")
 "dimension"->Entity(kind="dimension",points=listOf(a,b),params=buildJsonObject{put("mode","aligned");put("unit","cm");put("rotationMode","snap");put("angleSnapStep",15.0);put("offsetMm",0.0)})
 else->Entity(kind=kind,points=listOf(a,b))
 }
}
/** Vertex order is retained so associative dimensions keep referencing the same corners. */
fun resizeRectangle(e:Entity,width:Double,height:Double,origin:Vec=e.points.first(),angle:Double=rectangleAngle(e)):Entity {
 require(e.points.size==4&&width>0&&height>0&&width.isFinite()&&height.isFinite())
 val oldCross=cross(e.points[1]-e.points[0],e.points[3]-e.points[0])
 val v=Vec(0.0,if(oldCross<0)-height else height)
 return e.copy(points=listOf(Vec(),Vec(width,0.0),Vec(width,0.0)+v,v).map{origin+it.rotate(angle)},rotation=angle)
}
/** Resize a rotated parametric rectangle in its own coordinate system.
 * Retains the original center and rotation metadata. Never derives the new
 * dimensions from the axis-aligned world bounds. */
fun resizeParametricRectangle(e:Entity,length:Double,width:Double):Entity {
 require(e.points.size==4&&length>0&&width>0&&length.isFinite()&&width.isFinite())
 val p=e.points
 val axis=p[1]-p[0]
 val edge=p[3]-p[0]
 val ux=if(axis.length()>1e-9)axis*(1.0/axis.length()) else Vec(1.0,0.0).rotate(e.rotation)
 val uy=if(edge.length()>1e-9)edge*(1.0/edge.length()) else Vec(-ux.y,ux.x)
 val center=Vec(p.sumOf{it.x}/4.0,p.sumOf{it.y}/4.0)
 val halfX=ux*(length/2.0)
 val halfY=uy*(width/2.0)
 return e.copy(points=listOf(center-halfX-halfY,center+halfX-halfY,center+halfX+halfY,center-halfX+halfY))
}
fun rectangleAngle(e:Entity)=e.points.takeIf{it.size>=2}?.let{Math.toDegrees(atan2(it[1].y-it[0].y,it[1].x-it[0].x))}?:0.0
fun resizeLine(e:Entity,length:Double,angle:Double,origin:Vec=e.points.first()):Entity {
 require(length>0&&length.isFinite()&&angle.isFinite());return e.copy(points=listOf(origin,origin+Vec(length,0.0).rotate(angle)))
}
fun resizeCircle(e:Entity,radius:Double,center:Vec=e.points.first()):Entity {
 require(radius>0&&radius.isFinite());val direction=(e.points.getOrNull(1)?:center+Vec(1.0,0.0))-e.points.first()
 val unit=if(direction.length()>1e-9)direction*(1/direction.length())else Vec(1.0,0.0)
 return e.copy(points=listOf(center,center+unit*radius)).withNum("radiusMm",radius)
}
