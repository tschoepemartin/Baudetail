package de.baudetail.core
import kotlinx.serialization.json.*

import de.baudetail.geometry.*
import kotlin.math.*


/** Deterministic, vector-only surface texture. Shared by canvas and PDF renderer. */
fun pavingTexture(poly:List<Vec>,material:String,width:Double,depth:Double,style:Style,scale:Double,textureType:String=""):Primitive {
 val marks=mutableListOf<Primitive>()
 val fine=textureType in setOf("limestone","porcelain","wood","sandstone","natural_stone","marble")||material.contains("Feinstein",true)||material.contains("Jura",true)||material.contains("Naturstein",true)||material.contains("Sandstein",true)
 val granite=textureType=="granite"||material.contains("Granit",true)
 val cobble=textureType in setOf("cobble","mosaic","natural_cobble")||material.contains("kopf",true)||material.contains("Kleinstein",true)||material.contains("Mosaik",true)
 if(fine){
  val count=(width/105.0).toInt().coerceIn(1,65)
  for(i in 0 until count){
   val x=(i+.35)*width/count
   val y=depth*(.15+((i*37)%71)/100.0)
   val dx=(if(i%2==0)1 else -1)*minOf(95.0,width/count*.65)
   marks.add(Primitive.Path(listOf(Vec(x-dx*.6,y+10),Vec(x,y),Vec(x+dx,y-13)),style=style.copy(stroke=if(material.contains("Holzoptik",true))"#87745E" else "#A99E8E",fill=null,widthMm=.10*scale,opacity=.48)))
  }
 }else if(granite||cobble){
  val spacing=if(cobble)85.0 else 55.0
  val nx=(width/spacing).toInt().coerceIn(1,100);val ny=(depth/spacing).toInt().coerceIn(1,80)
  for(ix in 0 until nx)for(iy in 0 until ny){
   if((ix*17+iy*13)%4==0){val x=(ix+.4)*width/nx;val y=(iy+.5)*depth/ny
    marks.add(Primitive.Circle(Vec(x,y),if(cobble)3.5 else 2.0,style.copy(stroke="#686B68",fill=null,widthMm=.08*scale,opacity=.55)))
   }
  }
 }
 return Primitive.Group(marks,clip=poly)
}
/** Per-stone image variants with vector joints kept separate. Plan view only. */
/** Align the actual vector joints and per-stone images to the same cut-side grid.
 *  cutX: left/right/both; cutY: top/bottom/both. Local axes rotate with the pattern.
 *  An explicitly entered origin is retained as a phase offset. */
fun alignedPavingPattern(poly:List<Vec>,p:Pattern):Pattern {
 if(poly.size<3)return p
 val b=Bounds.of(poly.map{it.rotate(-p.angle)})
 fun inset(span:Double,tile:Double,joint:Double,side:String):Double {
  val step=tile+joint
  if(step<=0.0)return 0.0
  val full=kotlin.math.floor((span+joint+1e-7)/step).toInt().coerceAtLeast(0)
  val used=if(full==0)0.0 else full*tile+(full-1)*joint
  val remainder=(span-used).coerceAtLeast(0.0)
  return when(side){"left","top"->remainder;"both"->remainder/2.0;else->0.0}
 }
 val x=b.min.x+inset(b.width,p.widthMm,p.jointMm,p.cutX)
 val y=b.min.y+inset(b.height,p.heightMm,p.jointMm,p.cutY)
 return p.copy(origin=Vec(x,y).rotate(p.angle)+p.origin)
}
/** Repeat a physical-size material tile rather than stretching a single bitmap.
 * The same vector clipping applies to preview, print and PDF export. */
fun tiledMaterialSurface(poly:List<Vec>,asset:String,tileMm:Double=350.0):Primitive {
 if(asset.isBlank() || poly.size<3)return Primitive.Group(emptyList())
 val b=Bounds.of(poly)
 // A single clipped repeat shader, not thousands of bitmap primitives.
 // The material tile retains a fixed real-world size at every zoom level.
 return Primitive.Group(listOf(Primitive.Asset(b.min,b.width.coerceAtLeast(1.0),b.height.coerceAtLeast(1.0),
  "repeat:${tileMm.coerceAtLeast(20.0)}:$asset")),clip=poly)
}

fun materialStoneTextures(poly:List<Vec>,pattern:Pattern,assets:List<String>):Primitive {
 if(assets.isEmpty())return Primitive.Group(emptyList())
 val dx=(pattern.widthMm+pattern.jointMm).coerceAtLeast(1.0)
 val dy=(pattern.heightMm+pattern.jointMm).coerceAtLeast(1.0)
 val b=Bounds.of(poly.map{(it-pattern.origin).rotate(-pattern.angle)})
 val minX=floor(b.min.x/dx).toInt()-2;val maxX=ceil(b.max.x/dx).toInt()+2
 val minY=floor(b.min.y/dy).toInt()-2;val maxY=ceil(b.max.y/dy).toInt()+2
 // Never replace textured paving with a flat fill when its dimensions grow.
 // Large layouts still retain the original asset instead of silently dropping it.
 val tileCount=(maxX.toLong()-minX+1)*(maxY.toLong()-minY+1)
 if(tileCount>25000L){
  val min=Vec(poly.minOf{it.x},poly.minOf{it.y})
  val max=Vec(poly.maxOf{it.x},poly.maxOf{it.y})
  return Primitive.Group(listOf(Primitive.Asset(min,(max.x-min.x).coerceAtLeast(1.0),(max.y-min.y).coerceAtLeast(1.0),assets.first())),clip=poly)
 }
 val stones=mutableListOf<Primitive>()
 for(row in minY..maxY)for(col in minX..maxX){
  val offset=if(row%2==0)0.0 else pattern.offset*dx
  val at=Vec(col*dx+offset,row*dy)
  val width=pattern.widthMm.coerceAtLeast(1.0);val height=pattern.heightMm.coerceAtLeast(1.0)
  val idx=Math.floorMod(row*137+col*59,assets.size)
  stones.add(Primitive.Group(listOf(Primitive.Asset(at,width,height,assets[idx])),clip=rectangle(at,at+Vec(width,height))))
 }
 return Primitive.Group(listOf(Primitive.Group(stones,pattern.origin,angle=pattern.angle)),clip=poly)
}
fun dimensionTextPosition(a:Vec,b:Vec,aa:Vec,bb:Vec,label:String,textSize:Double,textDx:Double=0.0,textDy:Double=0.0):Vec {
 val mid=(aa+bb)*0.5
 val line=bb-aa
 val len=line.length()
 if(len<1e-9)return mid+Vec(textDx,textDy)
 val u=line*(1.0/len);val n=Vec(-u.y,u.x)
 val witnessMid=(a+b)*0.5;val side=mid-witnessMid
 val sign=if(side.x*n.x+side.y*n.y>=0)1.0 else -1.0
 val approxWidth=label.length*textSize*.62
 val vertical=kotlin.math.abs(line.y)>kotlin.math.abs(line.x)
 // Primitive.Text uses a start anchor. Compensate that here so the number is
 // actually centred on horizontal dimensions. Vertical dimension text stays
 // horizontal but sits close to the dimension line instead of half a label
 // width away from it.
 val auto=if(vertical){
  Vec(mid.x+n.x*(sign*textSize*.85),mid.y+textSize*.06)
 }else{
  Vec(mid.x-approxWidth/2,mid.y+n.y*(sign*textSize*.95))
 }
 return auto+Vec(textDx,textDy)
}

sealed interface Primitive {
 data class Path(val points:List<Vec>,val closed:Boolean=false,val style:Style=Style()):Primitive
 data class Circle(val center:Vec,val radius:Double,val style:Style=Style()):Primitive
 data class Text(val at:Vec,val value:String,val size:Double,val style:Style=Style(),val angle:Double=0.0):Primitive
 data class Asset(val at:Vec,val width:Double,val height:Double,val path:String,val opacity:Double=1.0,val angle:Double=0.0):Primitive
 data class Group(val nodes:List<Primitive>,val translate:Vec=Vec(),val scale:Double=1.0,val angle:Double=0.0,val clip:List<Vec>?=null,val mirrorY:Boolean=false):Primitive
}
/** Compact dimension arrowheads in paper units, not proportional to the measured span. */
fun dimensionArrows(a:Vec,b:Vec,s:Style,scale:Double):List<Primitive> {
 val v=b-a;val len=v.length();if(len<1e-8)return emptyList()
 val u=v*(1.0/len);val n=Vec(-u.y,u.x)
 val head=minOf(1.3*scale,len*.18)
 fun tip(p:Vec,dir:Vec)=Primitive.Path(listOf(p+dir*head+n*(head*.30),p,p+dir*head-n*(head*.30)),style=s)
 return listOf(Primitive.Path(listOf(a,b),style=s),tip(a,u),tip(b,u*(-1.0)))
}
object Scene {
 // The construction is painted in physically meaningful layers. Gravel is
 // behind foundations; bedding and paving are in front of them. Annotations
 // always remain legible on top, independent of insertion order.
 private fun physicalElevation(e:Entity):Double? = when {
  isPlanter(e) -> e.num("planterTopElevationMm",0.0)
  isLightwell(e) -> e.num("lightwellTopElevationMm",0.0)
  e.params.containsKey("topElevationMm") -> e.num("topElevationMm")
  e.params.containsKey("elevationMm") -> e.num("elevationMm")
  else -> null
 }
 private fun layerSortKey(e:Entity,index:Int,d:Drawing):Triple<Int,Double,Int> {
  val mode=e.str("layerOrderMode","auto")
  if(mode=="back")return Triple(-1,0.0,index)
  if(mode=="front")return Triple(99,0.0,index)
  val rank=paintRank(e)
  // Heights are only comparable within the same physical drawing stratum.
  // Objects with no reliable height keep their original insertion order.
  val height=if(d.viewMode()=="top")physicalElevation(e) else null
  return Triple(rank, height?:0.0,index)
 }
 private fun paintRank(e:Entity):Int = when {
  e.kind in setOf("dimension","text","leader","elevation","plan-height","slope") -> 50
  e.isParametricBuildUp() -> 10
  isFoundation(e) -> 20
  isPipe(e) -> 25
  else -> 30
 }
 fun drawing(d:Drawing,p:Project,printing:Boolean=false,skipUprightMarkers:Boolean=false):List<Primitive> {
  val visible=d.entities.filter { e -> (!skipUprightMarkers || e.kind !in setOf("elevation","plan-height")) && run { val layer=d.layers.find{it.id==e.layerId};layer?.visible!=false&&visibleIn(e,d)&&(!printing||layer?.printable!=false) } }
  val foundations=visible.filter(::isFoundation)
  val nodes=mutableListOf<Primitive>()
  // Draw foundations as one continuous concrete region. Aggregate is
  // underneath, and visible surfaces are restored above the concrete.
  // Split each construction into its actual physical strata. Only the lower
  // aggregate is behind concrete; bedding and paving cover the foundation.
  val stacks=visible.filter{it.isParametricBuildUp()&&d.viewMode()=="section"}.map{viewEntity(it,d)}
  stacks.forEach{stack->
   val entry=p.libraryEntries.find{it.id==stack.libraryId}
   val layers=stack.withBuildUpDefaults(entry).strata
   if(layers.isNotEmpty())nodes.addAll(entity(stack.withStr("renderStratum","${layers.lastIndex}").withStr("labelEnabled","false"),d,p))
  }
  visible.filter(::isFoundation).forEach{nodes.addAll(entity(it,d,p))}
  if(foundations.isNotEmpty())nodes.addAll(foundationEdges(d,p,printing))
  stacks.forEach{stack->
   val entry=p.libraryEntries.find{it.id==stack.libraryId}
   val layers=stack.withBuildUpDefaults(entry).strata
   if(layers.isNotEmpty()){
    (layers.lastIndex-1 downTo 0).forEach{i->nodes.addAll(entity(stack.withStr("renderStratum","$i").withStr("labelEnabled","false"),d,p))}
    // Add the object's annotation only once, after all physical strata.
    // The stack has already been rendered stratum by stratum; do not redraw it.
   }else nodes.addAll(entity(stack,d,p))
  }
  visible.withIndex().filter{!isFoundation(it.value)&&it.value !in stacks}
   .sortedWith(compareBy<IndexedValue<Entity>>({layerSortKey(it.value,it.index,d).first},{layerSortKey(it.value,it.index,d).second},{it.index}))
   .forEach{nodes.addAll(entity(it.value,d,p))}
  // Build-up labels must be emitted after every opaque material layer. Rendering
  // the layers with labelEnabled=false otherwise discards them completely.
  // Render the break marker once in the normal scene, above all opaque
  // strata. Rendering it inside the stack is insufficient: subsequent strata
  // paint over it, leaving it visible only in the selection preview.
  stacks.forEach { stack ->
   if(buildUpBroken(stack)) {
    val e=stack.withBuildUpDefaults(p.libraryEntries.find{it.id==stack.libraryId})
    val w=buildUpGraphicLengthMm(e)
    val cx=w*.5
    val total=e.strata.sumOf { it.thicknessMm }
    if(total>0.0 && w>0.0) {
     val top=buildUpSlopeDropMm(e,cx)
     val amp=(d.sheet.scale*2.0).coerceAtMost(w*.045)
     val zig=(0..8).map { i -> Vec(cx+(if(i%2==0)-amp else amp),top+total*i/8.0) }
     nodes.add(Primitive.Group(listOf(Primitive.Path(zig,false,e.style.copy(fill=null,widthMm=.35*d.sheet.scale))),e.points.firstOrNull()?:Vec(),angle=e.rotation))
    }
   }
  }
  stacks.forEach { stack ->
   if(kotlin.math.abs(buildUpSlopePercent(stack))>1e-8) {
    val slopeOnly=entity(stack.withStr("labelEnabled","false"),d,p)
    val noSlope=entity(stack.withStr("labelEnabled","false").withNum("buildUpSlopePct",0.0),d,p)
    if(slopeOnly.size>noSlope.size)nodes.addAll(slopeOnly.drop(noSlope.size))
   }
   val without=entity(stack.withStr("labelEnabled","false"),d,p)
   val with=entity(stack,d,p)
   if(with.size>without.size)nodes.addAll(with.drop(without.size))
  }
  return nodes
 }
 // Draw only the outer boundary of joined foundation bodies; individual
 // foundations remain separate editable entities.
 private fun foundationEdges(d:Drawing,p:Project,printing:Boolean):List<Primitive> {
  val found=d.entities.filter { e -> isFoundation(e)&&visibleIn(e,d)&&d.layers.find{it.id==e.layerId}?.let{it.visible&&(!printing||it.printable)}!=false }
  val polys=found.map{foundationOutline(it,d)}
  val stairContacts=if(d.viewMode()=="section")d.entities.filter{isStair(it)&&visibleIn(it,d)}.flatMap { stair ->
   stairSteps(stair,d,p).flatMap { step ->
    val outline=smartSnapOutline(step,d)
    if(outline.size<2)emptyList() else outline.indices.map{i->outline[i] to outline[(i+1)%outline.size]}
   }
  } else emptyList()
  val stairBodies=if(d.viewMode()=="section")d.entities.filter{isStair(it)&&visibleIn(it,d)}.flatMap{stair->
   stairVisibleSectionSegments(stair).chunked(4).filter{it.size==4}.map{block->block.map{assemblyPoint(stair,it.first,"section")}}
  }else emptyList()

  fun cross(a:Vec,b:Vec)=a.x*b.y-a.y*b.x
  fun inside(pt:Vec,poly:List<Vec>):Boolean {
   var hit=false
   for(i in poly.indices){val a=poly[i];val b=poly[(i+1)%poly.size]
    if((a.y>pt.y)!=(b.y>pt.y) && pt.x<(b.x-a.x)*(pt.y-a.y)/(b.y-a.y)+a.x)hit=!hit
   }
   return hit
  }
  val result=mutableListOf<Primitive>()
  polys.forEachIndexed{index,poly->if(poly.size>=3)poly.indices.forEach{i->
   val a=poly[i];val b=poly[(i+1)%poly.size];val dir=b-a;val len=dir.length()
   if(len>1e-7){
    val cuts=mutableListOf(0.0,1.0)
    polys.forEachIndexed{j,other->if(j!=index && other.size>=3)other.indices.forEach{k->
     val c=other[k];val v=other[(k+1)%other.size]-c;val den=cross(dir,v)
     if(abs(den)>1e-8){val t=cross(c-a,v)/den;val u=cross(c-a,dir)/den
      if(t>1e-7&&t<1-1e-7&&u>=-1e-7&&u<=1+1e-7)cuts.add(t)
     }else if(abs(cross(c-a,dir))<1e-5){
      val t1=(c-a).x*dir.x+(c-a).y*dir.y;val e=other[(k+1)%other.size];val t2=(e-a).x*dir.x+(e-a).y*dir.y
      cuts.add((t1/(len*len)).coerceIn(0.0,1.0));cuts.add((t2/(len*len)).coerceIn(0.0,1.0))
     }
    }}
    val ordered=cuts.sorted().distinctBy{(it*1000000).toInt()}
    ordered.zipWithNext().forEach{(lo,hi)->if(hi-lo>1e-7){
     val mid=a+dir*((lo+hi)*.5);val normal=Vec(-dir.y/len,dir.x/len)
     // Suppress only segments buried in another body; never change the bodies themselves.
     val buried=polys.indices.any{j->j!=index&&polys[j].size>=3&&inside(mid+normal*.1,polys[j])&&inside(mid-normal*.1,polys[j])}
     val shared=polys.indices.any{j->j<index&&polys[j].size>=3&&polys[j].indices.any{k->
      val c=polys[j][k];val e=polys[j][(k+1)%polys[j].size]
      abs(cross(dir,e-c))<1e-5&&closestOnSegment(mid,c,e).distance(mid)<.1
     }}
     // Hide the foundation boundary wherever it lies directly beneath a
     // rendered step, including sloped/rotated step undersides.
     val contact=stairBodies.any{body->inside(mid,body)} || stairContacts.any { (c,f) ->
      val edge=f-c
      edge.length()>1e-8 && closestOnSegment(mid,c,f).distance(mid)<2.0
     }
     if(!buried&&!shared&&!contact)result.add(Primitive.Path(listOf(a+dir*lo,a+dir*hi),style=found[index].style.copy(fill=null,widthMm=found[index].style.widthMm*d.sheet.scale)))
    }}
   }
  }}
  return result
 }
 fun entity(input:Entity,d:Drawing,p:Project):List<Primitive> {
  val entry=p.libraryEntries.find{it.id==input.libraryId}
  val sourceMaterial=input.materialSnapshot?.let{LibraryEntry(id="snapshot",type="material",name="",category="",appearance=it)}?:p.libraryEntries.find{it.id==input.materialId}
  val material=if(d.viewMode()=="top"&&input.str("fillMode","auto")=="vertical")null else sourceMaterial
  var e=viewEntity((if(material!=null&&closedContour(input))input.copy(style=materialStyle(material,d.viewMode()=="section"))else input).withBuildUpDefaults(entry),d)
  if(e.kind=="component"&&e.str("frozenTemplate")!="true"){
   val rawAsset=e.str("asset_"+d.viewMode()).ifBlank{entry?.views?.get(d.viewMode()).orEmpty()}
   val asset=if(d.viewMode()=="top"&&e.str("grassTopFallback")=="true")"" else rawAsset
   e=e.copy(asset=asset.ifBlank{if(e.view==d.viewMode()&&(d.viewMode()!="top"||e.str("libraryViews")!="true"))e.asset else null})
  }
  val pts=resolvedPoints(e,d);val a=pts.firstOrNull()?:Vec();val b=pts.getOrNull(1)?:a
  val cutOwner=if(input.str("pavingCutOwner").isNotBlank())d.entities.find{it.id==input.str("pavingCutOwner")}else null
  val cutWidth=if(cutOwner!=null){if(input.str("cutJointMode","auto")=="manual")input.num("cutJointWidthMm",cutOwner.pattern?.jointMm?:4.0) else cutOwner.pattern?.jointMm?:4.0}else null
  val cutColor=if(cutOwner!=null){if(input.str("cutColorMode","auto")=="manual")input.str("cutColor",cutOwner.style.stroke) else cutOwner.style.stroke}else null
  // Paving joints are rendered as outlines of adjacent individual stones.
  // Each shared seam therefore receives two coincident strokes, each capped
  // at 0.12 paper mm. A cut seam is a single path: match the *visible* width
  // of that pair rather than using the raw nominal joint size as one stroke.
  // This applies identically to inherited and manually entered joint widths.
  val visibleCutWidth= cutWidth?.let { 2.0 * min(it.coerceAtLeast(0.05),0.12*d.sheet.scale) }
  val s=e.style.copy(widthMm=visibleCutWidth?:e.style.widthMm*d.sheet.scale,stroke=cutColor?:e.style.stroke,align=if(cutWidth!=null)"cut-butt" else e.style.align,dashed=e.style.dashed||e.status=="Abbruch"||e.placement.hidden||(d.viewMode()=="top"&&isPipe(input)))
  val textSize=e.style.textPaperMm*d.sheet.scale
  fun text(at:Vec,value:String,size:Double=textSize)=Primitive.Text(at,value,size,s,e.rotation)
  fun textFlat(at:Vec,value:String,size:Double=textSize)=Primitive.Text(at,value,size,s,0.0)
  fun arrow(start:Vec,end:Vec):List<Primitive> {
   val delta=end-start;val dist=delta.length();if(dist<1e-6)return emptyList();val u=delta*(1/dist);val v=Vec(-u.y,u.x);val head=min(2.5*d.sheet.scale,dist/3)
   return listOf(Primitive.Path(listOf(start,end),style=s),Primitive.Path(listOf(end-u*head+v*(head/2),end,end-u*head-v*(head/2)),style=s))
  }
  // Unified construction-slope symbol for paving, steps and free slopes.
  // Geometry stays in model space; line weight, type size and text clearance
  // are specified once in paper units for screen and PDF alike.
  fun slopeSymbol(start:Vec,end:Vec,value:String,factor:Double=1.0):List<Primitive> {
   val f=factor.coerceIn(.01,2.5)
   val symbolStyle=s.copy(widthMm=.22*d.sheet.scale,fill=null)
   val delta=end-start;val len=delta.length()
   if(len<1e-6)return emptyList()
   val u=delta*(1.0/len);val n=Vec(-u.y,u.x)
   val head=2.3*d.sheet.scale*f
   val mid=(start+end)*.5
   val shortHalf=4.5*d.sheet.scale*f
   val shortStart=mid-u*shortHalf
   val shortEnd=mid+u*shortHalf
   val font=2.8*d.sheet.scale*f
   // Text anchors are left-aligned and baseline-based, not centered.
   val textWidth=value.length*font*.53
   val labelAt=mid+Vec(-textWidth*.5,-1.6*d.sheet.scale*f)
   return listOf(
    Primitive.Path(listOf(shortStart,shortEnd),style=symbolStyle),
    Primitive.Path(listOf(shortEnd-u*head+n*(head*.45),shortEnd,shortEnd-u*head-n*(head*.45)),style=symbolStyle),
    Primitive.Text(labelAt,value,font,symbolStyle,0.0)
   )
  }
  val rendered=when(if(e.isParametricBuildUp(entry)) "stack" else e.kind) {
   "assembly" -> {
    if(!isStair(e))return emptyList()
    // The assembly always renders the same real library-step instances that are
    // used when a step is inserted individually. The plan view only adds the
    // conventional flight annotation on top.
    val refs=stairReferencePoints(e,d.viewMode())
    // Keep the established library block-step appearance, including its
    // material/edge details. Only the parametric positions are corrected.
    val nodes=if(d.viewMode()=="section") stairSteps(e,d,p).flatMap{
     entity(it.withStr("labelEnabled","false").withStr("labelExplicit","true"),d,p)
    }.toMutableList() else mutableListOf<Primitive>()
    if(d.viewMode()!="section") {
     val width=e.num("widthMm",1200.0);val total=stairLength(e)
     // Plan convention: the complete flight is one continuous grey footprint.
     // Individual tread/front lines are drawn on top; no library-step top asset
     // may shift or leave half of the stair white.
     val footprint=rectangle(Vec(),Vec(total,width)).map{assemblyPoint(e,it,d.viewMode())}
     // Keep the actual stair footprint as the one authoritative outer edge.
     // Android strokes are centred on their paths and ROUND joins/caps can
     // otherwise protrude into neighbouring snapped drainage/paving objects.
     // Clip *all* construction strokes to the real footprint, including corners.
     // Keep the tread-edge primitives at the top level: selection and the
     // established stair geometry contract consume these individual paths.
     // Only the painted footprint/outline needs clipping.
     nodes.add(Primitive.Group(listOf(
      Primitive.Path(footprint,true,s.copy(fill="#D0CEC6")),
      Primitive.Path(footprint,true,s.copy(fill=null))
     ),clip=footprint))
     refs.chunked(2).filter{it.size==2}.forEach{
      nodes.add(Primitive.Path(it,style=s.copy(fill=null)))
     }
     val start=assemblyPoint(e,Vec(0.0,width/2),d.viewMode());val end=assemblyPoint(e,Vec(total,width/2),d.viewMode())
     nodes.addAll(arrow(start,end))
     val stairText=(textSize*.34).coerceAtLeast(d.sheet.scale*.85)
     val leftInset=maxOf(d.sheet.scale*1.2,stairText*.45)
     // Primitive.Text is left anchored. Reserve enough room for the four
     // letters of OBEN so the label can never protrude beyond the last tread.
     val rightInset=maxOf(d.sheet.scale*1.2,stairText*3.15)
     val labelY=width*.23
     nodes.add(text(assemblyPoint(e,Vec(leftInset,labelY),d.viewMode()),"UNTEN",stairText))
     nodes.add(text(assemblyPoint(e,Vec((total-rightInset).coerceAtLeast(leftInset),labelY),d.viewMode()),"OBEN",stairText))
    }
    nodes
   }
   "circle" -> listOf(Primitive.Circle(a,e.num("radiusMm",a.distance(b)),s))+materialHatch(e,material,d)
   "arc" -> {val r=e.num("radiusMm",500.0);val from=e.num("startAngle",0.0);val sweep=e.num("sweepAngle",90.0);listOf(Primitive.Path((0..96).map {val t=Math.toRadians(from+sweep*it/96);a+Vec(cos(t),sin(t))*r},style=s))}
   "polyline","area","rect","polygon","building" -> {
    if(!closedContour(e))return listOf(Primitive.Path(pts,style=s))
    if(e.str("plantingArea")=="true" || e.str("eavesStrip")=="true") {
     if(d.viewMode()=="top") {
      // The visible surface is the highest enabled stratum, not the vegetation type.
      // "Keine" has no thickness and exposes the next layer beneath it.
      val visible=e.strata.asReversed().firstOrNull { it.thicknessMm>0.0 && !it.materialId.equals("Keine",true) }
      val material=visible?.materialId.orEmpty().lowercase(java.util.Locale.ROOT)
      val surface=when {
       "rindenkompost" in material -> "#483225"
       "rindenmulch" in material -> "#785038"
       "lava" in material -> "#754C43"
       "anthrazit" in material -> "#505154"
       "weiß" in material || "weiss" in material -> "#E3E1D9"
       "beige" in material -> "#C6B69A"
       "rotbraun" in material -> "#985D48"
       "oberboden" in material || "erde" in material -> "#876A4D"
       "kies" in material || "schotter" in material -> "#B8AEA0"
       "rotlage" in material -> "#9C735E"
       else -> visible?.color ?: "#947B5B"
      }
      val ground=Primitive.Path(pts,true,s.copy(fill=surface))
      val marks=mutableListOf<Primitive>()
      val bounds=Bounds.of(pts)
      // Deterministic CAD surface symbols, clipped to the planting outline.
      val pitch=when {
       "rindenmulch" in material -> 75.0
       "rindenkompost" in material -> 42.0
       "lava" in material -> 45.0
       "16/32" in material -> 32.0
       "8/16" in material -> 20.0
       else -> 65.0
      }
      val nx=kotlin.math.ceil(bounds.width/pitch).toInt().coerceIn(0,130)
      val ny=kotlin.math.ceil(bounds.height/pitch).toInt().coerceIn(0,130)
      for(ix in 0..nx)for(iy in 0..ny) {
       val x=bounds.min.x+(ix+.5)*pitch
       val y=bounds.min.y+(iy+.5)*pitch
       val seed=(ix*73856093L xor iy*19349663L).and(0x7fffffff)
       val dx=(seed%17-8)*pitch/70.0
       val dy=((seed/17)%17-8)*pitch/70.0
       val p=Vec(x+dx,y+dy)
       when {
        "rindenmulch" in material -> marks.add(Primitive.Path(listOf(p+Vec(-pitch*.27,-pitch*.11),p+Vec(pitch*.23,pitch*.10)),false,s.copy(fill=null,stroke="#4C3022",widthMm=1.5)))
        "rindenkompost" in material -> marks.add(Primitive.Circle(p,pitch*.11,s.copy(fill="#2F211B",stroke="#2F211B")))
        "lava" in material -> marks.add(Primitive.Circle(p,pitch*.19,s.copy(fill=if(seed%2L==0L)"#4D3431" else "#9D6A58",stroke="#503631",widthMm=.5)))
        else -> marks.add(Primitive.Circle(p,pitch*.10,s.copy(fill="#655545",stroke="#655545")))
       }
      }
      return listOf(Primitive.Group(listOf(ground,Primitive.Group(marks,clip=pts),Primitive.Path(pts,true,s.copy(fill=null))),clip=pts))
     }
     val bounds=Bounds.of(pts)
     val width=bounds.width.coerceAtLeast(100.0)
     val x=bounds.min.x;val top=bounds.min.y
     val layers=if(e.strata.isEmpty())listOf(Stratum("Oberboden 0/20","Oberboden fein",150.0,"#A18A68","0/20"))else e.strata
     val result=mutableListOf<Primitive>()
     var y=top
     // Layers are stored bottom to top; draw from finished surface downwards.
     for(layer in layers.asReversed()) {
      val thickness=layer.thicknessMm.coerceAtLeast(0.0)
      if(thickness<=0.0)continue
      val shape=listOf(Vec(x,y),Vec(x+width,y),Vec(x+width,y+thickness),Vec(x,y+thickness))
      result.add(Primitive.Path(shape,true,s.copy(fill=layer.color,stroke="#625747",widthMm=.45)))
      val pitch=when{layer.grading.contains("35")->30.0;layer.grading.contains("32")->27.0;layer.grading.contains("20")->20.0;else->16.0}
      val dots=mutableListOf<Primitive>()
      val countX=kotlin.math.ceil(width/pitch).toInt().coerceIn(1,250)
      val countY=kotlin.math.ceil(thickness/pitch).toInt().coerceIn(1,50)
      for(ix in 0 until countX)for(iy in 0 until countY){
       val px=x+(ix+.5)*width/countX;val py=y+(iy+.5)*thickness/countY
       dots.add(Primitive.Circle(Vec(px,py),pitch*.11,s.copy(fill="#65594B",stroke="#65594B")))
      }
      result.add(Primitive.Group(dots,clip=shape))
      result.add(text(Vec(x+width*.02,y+thickness*.5),"${layer.name}: ${layer.materialId} · ${fmt(thickness)} mm"))
      y+=thickness
     }
     return result
    }
    if(e.str("grassObject")=="true") {
     val type=e.str("grassType","Gebrauchsrasen").let { if(it in setOf("Golfrasen","Zierrasen","Gebrauchsrasen","Sportrasen","Landschaftsrasen","Kräuterrasen","Blumenwiese","Kunstrasen"))it else "Gebrauchsrasen" }
     val bounds=Bounds.of(pts)
     if(d.viewMode()=="top") {
      val tiles=mutableListOf<Primitive>()
      val tile=1000.0
      val minX=kotlin.math.floor(bounds.min.x/tile).toInt();val maxX=kotlin.math.ceil(bounds.max.x/tile).toInt()
      val minY=kotlin.math.floor(bounds.min.y/tile).toInt();val maxY=kotlin.math.ceil(bounds.max.y/tile).toInt()
      // Bound tile count to keep very large plans responsive.
      val step=maxOf(1,kotlin.math.ceil(maxOf(maxX-minX,maxY-minY)/45.0).toInt())
      for(x in minX until maxX step step)for(y in minY until maxY step step) {
       val variant=(kotlin.math.abs((x.toLong()*73856093L xor y.toLong()*19349663L xor e.id.hashCode().toLong())%4L)+1).toInt()
       tiles.add(Primitive.Asset(Vec(x*tile,y*tile),tile*step,tile*step,"grass-textures/${if(type=="Kräuterrasen") "Kraeuterrasen" else type}-$variant.webp"))
      }
      val out=mutableListOf<Primitive>(Primitive.Group(listOf(Primitive.Path(pts,true,s.copy(fill="#92B779")),Primitive.Group(tiles,clip=pts),Primitive.Path(pts,true,s.copy(fill=null))),clip=pts))
      (e.params["grassHeights"] as? JsonArray)?.forEach { h ->
       val obj=h as? JsonObject?:return@forEach
       val x=(obj["x"] as? JsonPrimitive)?.doubleOrNull?:return@forEach
       val y=(obj["y"] as? JsonPrimitive)?.doubleOrNull?:return@forEach
       val z=(obj["z"] as? JsonPrimitive)?.doubleOrNull?:return@forEach
       out.add(Primitive.Circle(Vec(x,y),45.0,Style(stroke="#285D38",fill="#EAF5DE")))
       out.add(text(Vec(x+55.0,y-55.0),String.format(java.util.Locale.GERMANY,"%.2f",z/1000.0)))
      }
      return out
     }
     // The first point is the top-of-sod elevation reference; blades project above it.
     val grassGeometry=grassSectionGeometry(input)
     val sectionBounds=Bounds.of(grassGeometry.outline)
     val x=sectionBounds.min.x;val y=grassGeometry.vegetationTop.first.y;val width=sectionBounds.width.coerceAtLeast(100.0)
     val surfaceLeft=grassGeometry.vegetationTop.first;val surfaceRight=grassGeometry.vegetationTop.second
     fun grassY(atX:Double)=surfaceLeft.y+(surfaceRight.y-surfaceLeft.y)*((atX-surfaceLeft.x)/width).coerceIn(0.0,1.0)
     val layer1=e.num("grassLayer1Mm",50.0).coerceAtLeast(0.0)
     val layer2=e.num("grassLayer2Mm",150.0).coerceAtLeast(0.0)
     val blades=e.num("grassBladeMm",40.0).coerceAtLeast(0.0)
     val result=mutableListOf<Primitive>()
     // Native CAD vector vegetation: no photo assets, independent of soil thickness.
     // Deterministic density/shape by species, with bounded complexity for smooth gestures.
     val species=type.lowercase()
     val golf=species.contains("golf")
     val ornamental=species.contains("zier")
     val sport=species.contains("sport")
     val artificial=species.contains("kunst")
     val meadow=species.contains("landschaft")
     val herb=species.contains("kräuter") || species.contains("kraeuter")
     val flowers=species.contains("blumen")
     // Each species has its own recognisable silhouette, not just a label.
     val heightFactor=when{golf->.38;ornamental->.64;sport->.57;artificial->.53;meadow->1.40;herb->1.13;flowers->1.65;else->.91}
     val pitch=when{golf->4.5;ornamental->6.0;sport->4.8;artificial->6.5;meadow->12.0;herb->10.0;flowers->13.0;else->7.5}
     val count=kotlin.math.ceil(width/pitch).toInt().coerceIn(1,2200)
     val palette=when{artificial->listOf("#278653","#319D5C","#227D4C");golf->listOf("#438E36","#5BA642","#367D31");flowers->listOf("#679D3B","#82AB4D","#4E8734");else->listOf("#4A9635","#6CB13E","#37852F")}
     // A continuous sod base makes the grass visible even at 1:50.
     result.add(Primitive.Path(listOf(Vec(x,grassY(x)),Vec(x+width,grassY(x+width)),Vec(x+width,grassY(x+width)-3.5),Vec(x,grassY(x)-3.5)),true,s.copy(fill=palette[0],stroke=palette[0],widthMm=.6)))
     for(row in 0..2){
      for(i in 0..count){
       val seed=(i*47+row*31+19)%113
       val bx=x+width*(i+.17*row)/count
       val varied=if(artificial)1.0 else .70+seed/280.0
       val h=(blades*heightFactor*varied).coerceAtLeast(1.5)
       val lean=if(artificial)0.0 else ((i*17+row*7)%13-6)*h/(if(meadow||flowers)19.0 else 29.0)
       val thickness=when{golf->2.5;artificial->3.1;meadow||flowers->5.2;herb->5.5;else->4.2}*(if(row==0)1.0 else .77)
       val root=Vec(bx,grassY(bx)-1.5)
       val tip=Vec(bx+lean,y-h*(if(row==2).72 else 1.0))
       val shoulder=Vec(bx+lean*.40+thickness*.30,y-h*.54)
       val leaf=listOf(Vec(root.x-thickness*.55,root.y),shoulder,tip,Vec(root.x+thickness*.55,root.y))
       val green=palette[(i+row)%palette.size]
       result.add(Primitive.Path(leaf,true,s.copy(fill=green,stroke=green,widthMm=.45)))
       if((herb||flowers) && i%7==row%3){
        val stemX=bx+lean*.6
        val leafY=grassY(bx)-h*.54
        result.add(Primitive.Path(listOf(Vec(stemX-8.0,leafY+3),Vec(stemX-2.0,leafY-4),Vec(stemX,leafY+5)),true,s.copy(fill="#6D9B42",stroke="#6D9B42",widthMm=.6)))
        result.add(Primitive.Path(listOf(Vec(stemX,leafY+5),Vec(stemX+7.0,leafY-5),Vec(stemX+9.0,leafY+3)),true,s.copy(fill="#78A54C",stroke="#78A54C",widthMm=.6)))
       }
       if(flowers && i%11==2 && row==0){
        val c=Vec(bx+lean,grassY(bx)-h-4)
        val color=if(i%2==0)"#E5B744" else "#D9A2C9"
        result.add(Primitive.Circle(c,5.5,Style(stroke=color,fill=color,widthMm=.6)))
        result.add(Primitive.Circle(c,1.7,Style(stroke="#A47B29",fill="#A47B29",widthMm=.5)))
       }
      }
     }
     val colors=listOf("#806043","#AB9472")
     listOf(layer1,layer2).forEachIndexed { i,h ->
      if(h>0.0){val top=grassY(x)+(if(i==0)0.0 else layer1)
       val box=grassGeometry.strata[i]
       result.add(Primitive.Path(box,true,s.copy(fill=colors[i],stroke="#6D5948")))
       val name=e.str("grassLayer${i+1}Name","Oberboden");val grading=e.str("grassLayer${i+1}Grading",if(i==0)"0/15" else "0/25")
       result.add(text(Vec(x+50.0,top+h/2),"$name $grading · ${h.toInt()} mm",minOf(50.0,h*.28).coerceAtLeast(12.0)))
      }
     }
     result.add(Primitive.Path(listOf(surfaceLeft,surfaceRight),style=s.copy(fill=null,stroke="#376B35")))
     val reference=input.withNum("buildUpSectionLengthMm",width)
     if(buildUpBroken(reference)) {
      val cx=x+width*.5
      val total=layer1+layer2
      val amp=(d.sheet.scale*2.0).coerceAtMost(width*.045)
      val zig=(0..8).map{i->Vec(cx+(if(i%2==0)-amp else amp),grassY(cx)+total*i/8.0)}
      result.add(Primitive.Path(zig,false,s.copy(fill=null,stroke="#4E4539",widthMm=.35*d.sheet.scale)))
     }
     if(kotlin.math.abs(buildUpSlopePercent(input))>1e-8) {
      val factor=input.num("buildUpSlopeLabelScalePct",100.0).coerceIn(1.0,250.0)/100.0
      val centre=(surfaceLeft+surfaceRight)*.5+Vec(input.num("buildUpSlopeLabelDx"),-(width*.07).coerceIn(35.0,100.0)+input.num("buildUpSlopeLabelDy"))
      val half=4.5*d.sheet.scale*factor
      val direction=if(buildUpSlopePercent(input)>0)1.0 else -1.0
      result.addAll(slopeSymbol(centre+Vec(-direction*half,0.0),centre+Vec(direction*half,0.0),fmt(kotlin.math.abs(buildUpSlopePercent(input)))+" %",factor))
     }
     return result
    }
    val surface=mutableListOf<Primitive>(Primitive.Path(pts,true,s));e.pattern?.let {surface.add(pattern(pts,alignedPavingPattern(pts,it),s,d.sheet.scale))};surface.addAll(materialHatch(e.copy(points=pts),material,d));val out=mutableListOf<Primitive>(Primitive.Group(surface,clip=pts));if(e.str("grassObject")=="true"&&d.viewMode()=="top"){
     (e.params["grassHeights"] as? kotlinx.serialization.json.JsonArray)?.forEach{entry->
      val h=entry as? kotlinx.serialization.json.JsonObject ?:return@forEach
      val x=(h["x"] as? kotlinx.serialization.json.JsonPrimitive)?.doubleOrNull?:return@forEach
      val y=(h["y"] as? kotlinx.serialization.json.JsonPrimitive)?.doubleOrNull?:return@forEach
      val z=(h["z"] as? kotlinx.serialization.json.JsonPrimitive)?.doubleOrNull?:return@forEach
      val pos=Vec(x,y);out.add(Primitive.Circle(pos,45.0,Style(stroke="#285D38",fill="#EAF5DE")))
      out.add(text(pos+Vec(55.0,-55.0),String.format(java.util.Locale.GERMANY,"%.2f",z/1000.0)))
     }
    };out
   }
   "arrow","leader" -> arrow(a,b)+(if(e.text.isNotEmpty())listOf(text(a,interpolate(e.text,textVariables(e,d,p))))else emptyList())
   "text" -> listOf(text(a,interpolate(e.text,textVariables(e,d,p))))
   "plan-height" -> {
    // Same fixed, page-horizontal height-marker geometry as the proven section marker.
    // The point is the arrow TIP; the horizontal rule runs to the right and the
    // number sits immediately above it. Never rotate with a building or a view.
    val h:Double?=if(input.str("elevationRole","manual")=="relative") planRelativeHeightMm(input,d) else input.num("heightMm",d.elevationDatumMm)
    val decimals=input.num("heightDecimals",2.0).toInt().coerceIn(2,4)
    val value=if(h==null)"Höhe ?" else if(abs(h)<0.001)"±"+String.format(java.util.Locale.GERMANY,"%.${decimals}f",0.0) else (if(h>0)"+" else "")+String.format(java.util.Locale.GERMANY,"%.${decimals}f",h/1000.0)
    val scalePct=input.num("annotationScalePct",35.0).coerceIn(1.0,100.0)/100.0
    val r=2.5*50.0*scalePct
    val font=3.0*50.0*scalePct
    val tip=a
    val baseline=tip.y-r
    val triangle=Primitive.Path(listOf(tip,Vec(tip.x-r*.62,baseline),Vec(tip.x+r*.62,baseline)),true,s.copy(fill=s.stroke))
    val left=tip.x-r*.50
    val width=value.sumOf { ch -> when(ch) {
     '1','i','l','I','.',',',':',' ' -> .28
     '+','-','−','±' -> .55
     '0','2','3','4','5','6','7','8','9' -> .56
     else -> .57
    } }*font
    val rule=Primitive.Path(listOf(Vec(left,baseline),Vec(left+width,baseline)),style=s)
    listOf(triangle,rule,textFlat(Vec(left,baseline-font*.16),value,font))
   }
   "elevation" -> {
    val h=elevationValueMm(input,d);val label=if(abs(h)<0.001)"±0,00" else (if(h>0)"+" else "")+String.format(java.util.Locale.GERMANY,"%.2f",h/1000)
    val prefix=input.str("elevationPrefix").trim().let { if(it.isBlank()) "" else "$it " }
    val scalePct=input.num("annotationScalePct",35.0).coerceIn(1.0,100.0)/100.0
    val r=2.5*50.0*scalePct
    val font=3.0*50.0*scalePct
    // Entire compact level marker uses one scale, with the triangle tip at its measured anchor.
    val offset=elevationLabelOffset(input,d.viewMode())
    val tip=a+offset
    val baseline=tip.y-r
    val triangle=Primitive.Path(listOf(tip,Vec(tip.x-r*.62,baseline),Vec(tip.x+r*.62,baseline)),true,s.copy(fill=s.stroke))
    val value=prefix+label
    val left=tip.x-r*.50
    // Approximate proportional sans-serif glyph advances instead of counting
    // characters at one fixed width. Keep the rule directly below the text.
    val width=value.sumOf { ch -> when(ch) {
     '1','i','l','I','.',',',':',' ' -> .28
     '+','-','−','±' -> .55
     '0','2','3','4','5','6','7','8','9' -> .56
     else -> .57
    } }*font
    val line=Primitive.Path(listOf(Vec(left,baseline),Vec(left+width,baseline)),style=s)
    val labelAt=Vec(left,baseline-font*.16)
    // Top view markers are always page-horizontal, irrespective of plan rotation.
    listOf(triangle,line,textFlat(labelAt,value,font))

   }
   "foundation" -> {
    val outline=foundationOutline(input,d);val fill=s.fill?:"#C8C8C3"
    val b=if(outline.size>=3)Bounds.of(outline)else Bounds(Vec(),Vec())
    // Paint the body first; shared internal edges are suppressed in a second
    // outline pass, keeping separately editable foundation objects seamless.
    val concrete=s.copy(fill=fill,stroke=fill)
    val nodes=mutableListOf<Primitive>()
    if(outline.size>=3){nodes.add(Primitive.Path(outline,true,concrete));nodes.addAll(materialHatch(input.copy(kind="polygon",points=outline),material,d))}
    nodes
   }
   "slope" -> {
    // Keep the label above the complete arrow head even on an A3 PDF.
    // These offsets are in world millimetres; the paper viewport converts
    // them exactly once, including for drawings saved by older releases.
    slopeSymbol(a,b,slopeLabel(e,d),e.num("annotationScalePct",100.0)/100.0)
   }
   "dimension" -> {
    if(e.str("metric").isNotEmpty()){
     val source=d.entities.find{it.id==e.str("sourceId")};val witnesses=source?.let{metricWitnesses(it,e.str("metric"),d)}
     if(witnesses==null)return emptyList()
     if(e.str("metric")=="Stufengefälle") {
      val value=dimensionLabel(e,d);val shift=Vec(e.num("dimDx"),e.num("dimDy"));val start=witnesses[0]+shift;val end=witnesses[1]+shift
      // Point the slope arrow toward the lower/front side of the step.
      val downhillStart=if((source?.num("slope") ?: 0.0)>=0.0) end else start
      val downhillEnd=if((source?.num("slope") ?: 0.0)>=0.0) start else end
      return slopeSymbol(downhillStart,downhillEnd,value,e.num("annotationScalePct",50.0)/100.0)
     }
     val stairHeight=isStair(source?:e)&&e.str("metric") in setOf("Gesamthöhe","Stufenhöhe")
     val actualWitnesses=if(stairHeight && source!=null) {
      val right=e.num("dimDx")+a.x-e.num("metricOriginX",a.x) > (witnesses[0].x+witnesses[1].x)/2 - a.x
      stairHeightWitnesses(source,if(e.str("metric")=="Gesamthöhe")stairCount(source)-1 else 0,e.str("metric")=="Gesamthöhe",right)
     }else witnesses
     val annotation=e.copy(points=actualWitnesses,anchors=emptyList(),bindings=emptyList(),params=JsonObject(e.params-setOf("metric","sourceId"))).withStr("renderLabel",dimensionLabel(e,d)).withStr("shortWitness",if(false)"true" else "false").withNum("dimDx",e.num("dimDx")+a.x-e.num("metricOriginX",a.x)).withNum("dimDy",e.num("dimDy")+a.y-e.num("metricOriginY",a.y))
     return entity(annotation,d,p)
    }
    val mode=e.str("mode","aligned")
    if(mode=="chain") return pts.zipWithNext().flatMap { (start,end) -> entity(e.copy(points=listOf(start,end),anchors=emptyList()).withStr("mode","aligned"),d,p) }
    if(mode=="angle" && pts.size>=3) {
     val center=pts[1];val first=pts[0]-center;val last=pts[2]-center;val from=atan2(first.y,first.x);var sweep=atan2(last.y,last.x)-from
     while(sweep>PI)sweep-=2*PI;while(sweep< -PI)sweep+=2*PI
     val r=abs(e.num("offsetMm",8*d.sheet.scale)).coerceAtLeast(textSize*2)
     val arc=(0..64).map { val t=from+sweep*it/64;center+Vec(cos(t),sin(t))*r }
     return listOf(Primitive.Path(listOf(pts[0],center,pts[2]),style=s),Primitive.Path(arc,style=s),text(center+Vec(cos(from+sweep/2),sin(from+sweep/2))*(r+textSize),"${fmt(dimensionValue(e,d))}°"))
    }
    val rawDelta=b-a;val dist=rawDelta.length();val off=e.num("offsetMm",d.sheet.scale*8)
    val base=when(mode){"horizontal"->Vec(0.0,off);"vertical"->Vec(off,0.0);else->if(dist>0)Vec(-rawDelta.y/dist,rawDelta.x/dist)*off else Vec(0.0,off)}
    val shift=Vec(e.num("dimDx"),e.num("dimDy"));val aa=a+base+shift;val bb=when(mode){"horizontal"->Vec(b.x+shift.x,aa.y);"vertical"->Vec(aa.x,b.y+shift.y);else->b+base+shift}
    val label=e.str("renderLabel",dimensionLabel(e,d))
    val labelAt=dimensionTextPosition(a,b,aa,bb,label,textSize,e.num("textDx"),e.num("textDy"))
    run {
     val witnessGap=0.0
     fun trim(from:Vec,to:Vec):List<Vec> {val delta=to-from;val len=delta.length();return if(len<1e-9)emptyList() else listOf(from,to)}
     val guides=if(e.str("shortWitness")=="true") {
      val maxLen=textSize*4.0
      listOf(a to aa,b to bb).mapNotNull{(from,to)->val delta=to-from;val len=delta.length();if(len<1e-9)null else Primitive.Path(listOf(to-delta*(minOf(len,maxLen)/len),to),style=s)}
     }else listOf(trim(a,aa),trim(b,bb)).filter{it.size==2}.map{Primitive.Path(it,style=s)}
     guides+dimensionArrows(aa,bb,s,d.sheet.scale)+text(labelAt,label)
    }
   }
   "section" -> {
    val delta=b-a;val u=if(delta.length()>0)delta*(1/delta.length())else Vec(1.0,0.0);val v=Vec(-u.y,u.x)*(e.num("direction",1.0)*d.sheet.scale*7)
    listOf(Primitive.Path(listOf(a,b),style=s.copy(dashed=true)))+arrow(a,a+v)+arrow(b,b+v)+text(a+v*1.4,e.text.ifBlank {"A–A"})+text(b+v*1.4,e.text.ifBlank {"A–A"})
   }
   "tree" -> {
    val r=e.num("crownMm",2000.0)/2;val out=mutableListOf<Primitive>(Primitive.Circle(a,r,s),Primitive.Circle(a,e.num("trunkMm",120.0)/2,s.copy(fill=s.stroke)),Primitive.Path(listOf(a-Vec(r,0.0),a+Vec(r,0.0)),style=s),Primitive.Path(listOf(a-Vec(0.0,r),a+Vec(0.0,r)),style=s))
    if(e.num("rootMm")>0)out.add(Primitive.Circle(a,e.num("rootMm")/2,s.copy(fill=null,dashed=true)))
    if(e.num("pitMm")>0)out.add(Primitive.Path(rectangle(a-Vec(e.num("pitMm")/2,e.num("pitMm")/2),a+Vec(e.num("pitMm")/2,e.num("pitMm")/2)),true,s.copy(fill=null,dashed=true)))
    if(e.name.isNotEmpty())out.add(text(a+Vec(r*0.6,-r),e.name));out
   }
   "hedge" -> {
    val spacing=e.num("spacingMm",400.0).coerceAtLeast(1.0);val len=length(pts);val n=hedgeCount(len,spacing);val r=e.num("widthMm",600.0)/2
    val plant=e.str("hedgePlant", "").ifBlank { "Hecke" }
    val nodes=mutableListOf<Primitive>()
    if(d.viewMode()=="section") {
     val h=e.num("plantHeightMm",1500.0).coerceAtLeast(1.0)
     val end=Vec(a.x+len,a.y)
     nodes.add(Primitive.Path(listOf(a,end,end-Vec(0.0,h),a-Vec(0.0,h)),true,s.copy(fill=s.fill,opacity=0.35)))
     nodes.add(Primitive.Path(listOf(a-Vec(0.0,h),end-Vec(0.0,h)),style=s))
     nodes.add(text(a-Vec(0.0,h+textSize),"$plant · ${fmt(h/1000.0)} m · $n Stk"))
    } else {
     nodes.add(Primitive.Path(pts,style=s.copy(widthMm=r*2,opacity=0.25)))
     if(n<=1500)for(i in 0 until n)nodes.add(Primitive.Circle(pointAt(pts,if(n<=1)0.0 else len*i/(n-1)),r,s))
     nodes.add(text(a+Vec(0.0,-r-textSize),"$plant · $n Stk"))
    }
    nodes
   }
   "stack" -> {
    val w=if(d.viewMode()=="section")e.num("topDepthMm",e.num("widthMm",1500.0))else e.num("planGraphicWidthMm",e.num("widthMm",1500.0));val nodes=mutableListOf<Primitive>()
    // Every non-section view is a plan/top representation. This deliberately
    // avoids falling back to the layer section when an older drawing carries a
    // legacy plan-view token in extensions.
    if(d.viewMode()!="section"){
     val depth=e.num("topDepthMm",1000.0).coerceAtLeast(1.0);val poly=rectangle(Vec(),Vec(w,depth));val paving=e.strata.firstOrNull()
     val mat=paving?.materialId.orEmpty().ifBlank{paving?.name.orEmpty()}
     val lib=p.libraryEntries.find{it.id==mat || it.name==mat}
     val meta=lib?.extensions?.get("baudetailMaterial") as? JsonObject
     val textureType=(meta?.get("textureType") as? JsonPrimitive)?.contentOrNull.orEmpty()
     val visual=lib?.appearance?.top?.fill?:lib?.style?.fill?:pavingVisualColor(mat)
     // The visible boundary is exactly the construction polygon. A centered
     // outline stroke would extend beyond the measured/snap footprint.
     nodes.add(Primitive.Path(poly,true,s.copy(fill=visual,widthMm=0.0)))
     val defaultStone=if(meta!=null){
      val mw=(meta["nominalStoneWidthMm"] as? JsonPrimitive)?.doubleOrNull
      val mh=(meta["nominalStoneHeightMm"] as? JsonPrimitive)?.doubleOrNull
      (mw?:pavingStoneSize(lib?.name?:mat).first) to (mh?:pavingStoneSize(lib?.name?:mat).second)
     }else pavingStoneSize(mat)
     val pat=e.pattern?:Pattern(defaultStone.first,defaultStone.second,4.0,0.0,1.0/3.0)
     // Material-specific stone layout; keep user-edited patterns and dimensions.
     val sized=if(pat.widthMm==200.0&&pat.heightMm==100.0&&mat!="Betonpflaster")pat.copy(widthMm=defaultStone.first,heightMm=defaultStone.second) else pat
     // A surface owns its own joint phase and cut-edge alignment.
     // Never inherit the global world grid from distant paving objects.
     val chosen=alignedPavingPattern(poly,sized)
     val textureAssets=(lib?.extensions?.get("baudetailTextureAssets") as? JsonArray)?.mapNotNull{(it as? JsonPrimitive)?.contentOrNull}.orEmpty()
     val deckTexture=(lib?.extensions?.get("baudetailTextureTop") as? JsonPrimitive)?.contentOrNull.orEmpty().ifBlank{textureAssets.firstOrNull().orEmpty()}
     if(e.str("buildUpVariant")=="waterbound") {
      // Waterbound surfaces have no manufactured stone grid or cut edges.
      if(deckTexture.isNotBlank()) nodes.add(tiledMaterialSurface(poly,deckTexture))
      else nodes.add(pavingTexture(poly,lib?.name?:mat,w,depth,s,d.sheet.scale,textureType))
     } else if(textureAssets.isNotEmpty()) {
      // Raster images are clipped per stone, never used as geometric edges.
      // The CAD joint grid is drawn above the images and stays vector-accurate.
      nodes.add(materialStoneTextures(poly,chosen,textureAssets))
     } else nodes.add(pavingTexture(poly,lib?.name?:mat,w,depth,s,d.sheet.scale,textureType))
     if(e.str("buildUpVariant")!="waterbound")nodes.add(pattern(poly,chosen,s,d.sheet.scale))
     // Exact physical outer joint: four filled strips, never a centered
     // rounded stroke. Their OUTER edges coincide with the construction
     // footprint; a shared boundary joins two half-joints to one full joint.
     // In particular, nothing can protrude beyond a corner or change the
     // measured footprint as the viewport zoom changes.
     if(chosen.jointMm>0.0 && e.str("buildUpVariant")!="waterbound"){
      val half=(chosen.jointMm/2.0).coerceAtMost(min(w,depth)/2.0)
      val jointStyle=s.copy(fill=s.stroke,widthMm=0.0)
      val strips=listOf(
       rectangle(Vec(0.0,0.0),Vec(w,half)),
       rectangle(Vec(0.0,depth-half),Vec(w,depth)),
       rectangle(Vec(0.0,half),Vec(half,depth-half)),
       rectangle(Vec(w-half,half),Vec(w,depth-half))
      )
      nodes.addAll(strips.map{Primitive.Path(it,true,jointStyle)})
     }
    }else{
     var y=0.0
     e.strata.forEachIndexed{i,layer->
      val top=y;val bottom=y+layer.thicknessMm
      if(e.str("renderStratum").isNotBlank() && e.str("renderStratum").toIntOrNull()!=i){y=bottom;return@forEachIndexed}
      val lib=p.libraryEntries.find{it.id==layer.materialId || it.name==layer.materialId}
      val layerFill=if(i==0)(lib?.appearance?.section?.fill?:lib?.style?.fill?:pavingVisualColor(layer.materialId.ifBlank{layer.name}))else layer.color
      val layerPoly=listOf(Vec(0.0,top+buildUpSlopeDropMm(e,0.0)),Vec(w,top+buildUpSlopeDropMm(e,w)),Vec(w,bottom+buildUpSlopeDropMm(e,w)),Vec(0.0,bottom+buildUpSlopeDropMm(e,0.0)))
      nodes.add(Primitive.Path(layerPoly,true,s.copy(fill=layerFill)))
      val sectionAsset=(lib?.extensions?.get("baudetailTextureSection") as? JsonPrimitive)?.contentOrNull.orEmpty()
      if(e.str("buildUpVariant")=="waterbound" && sectionAsset.isNotBlank()) {
       nodes.add(Primitive.Group(listOf(Primitive.Asset(Vec(0.0,top+minOf(buildUpSlopeDropMm(e,0.0),buildUpSlopeDropMm(e,w))),w,(bottom-top+kotlin.math.abs(buildUpSlopeDropMm(e,w)-buildUpSlopeDropMm(e,0.0))).coerceAtLeast(1.0),sectionAsset)),clip=layerPoly))
      }
      if(i==0 && e.str("buildUpVariant")!="waterbound"){
       val stone=(e.pattern?.widthMm?:200.0).coerceAtLeast(20.0);var x=stone
       while(x<w){nodes.add(Primitive.Path(listOf(Vec(x,top+buildUpSlopeDropMm(e,x)),Vec(x,bottom+buildUpSlopeDropMm(e,x))),style=s.copy(fill=null,widthMm=.16*d.sheet.scale)));x+=stone}
      }else{
       val grading=layer.grading.ifBlank{if(layer.name.contains("Bett",true))"2/5" else if(layer.name.contains("Frost",true)||layer.name.contains("Trag",true))"0/32" else ""}
       val maxGrain=grading.substringAfter('/',"").replace(',','.').toDoubleOrNull()?:if(i==1)5.0 else 32.0
       val step=(maxGrain*2.2).coerceIn(18.0,85.0);var gy=top+step*.55;var row=0
       while(gy<bottom){var gx=step*.45+(row%2)*step*.4;while(gx<w){val r=(maxGrain*.22).coerceIn(1.2,7.0);nodes.add(Primitive.Circle(Vec(gx,gy+buildUpSlopeDropMm(e,gx)),r,s.copy(fill=null,widthMm=.10*d.sheet.scale)));gx+=step};gy+=step*.8;row++}
      }
      y=bottom
     }
    }
    if(d.viewMode()=="section" && e.str("renderStratum").isBlank() && buildUpBroken(e)) {
     // A full-height break mark explicitly declares that the section is not to scale.
     val cx=w*.5
     val total=e.strata.sumOf{it.thicknessMm}
     val top=buildUpSlopeDropMm(e,cx)
     val amp=(d.sheet.scale*2.0).coerceAtMost(w*.045)
     val zig=(0..8).map {i->Vec(cx+(if(i%2==0)-amp else amp),top+total*i/8.0)}
     nodes.add(Primitive.Path(zig,false,s.copy(fill=null,widthMm=.35*d.sheet.scale)))
    }
    val renderedStack=Primitive.Group(nodes,if(d.viewMode()=="section")a else buildUpPlanOrigin(e),angle=if(d.viewMode()=="section")e.rotation else buildUpPlanAngle(e))
    if(d.viewMode()=="section" && e.str("renderStratum").isBlank() && kotlin.math.abs(buildUpSlopePercent(e))>1e-8){
     val edge=buildUpSurfaceEdge(e)
     val centre=buildUpSlopeLabelCenter(e,d.sheet.scale)
     val span=(edge.second-edge.first).length().coerceAtLeast(1.0)
     val factor=e.num("buildUpSlopeLabelScalePct",100.0).coerceIn(1.0,250.0)/100.0
     // Limit annotation geometry in PAPER millimetres, not world millimetres.
     // At 1:20 the old 140 mm paper-wide arrow collided with nearby labels.
     val half=4.5*d.sheet.scale*factor
     val direction=if(buildUpSlopePercent(e)>0)1.0 else -1.0
     val start=centre+Vec(-direction*half,0.0)
     val end=centre+Vec(direction*half,0.0)
     val percent=kotlin.math.abs(buildUpSlopePercent(e))
     val value=fmt(percent)+" %"
     listOf(renderedStack)+slopeSymbol(start,end,value,factor)
    }else listOf(renderedStack)
   }
   "legend" -> {
    val base=legendItems(d,p.libraryEntries)
    fun order(item:LegendItem)=e.num("legendOrder:${item.key}",base.indexOf(item).toDouble())
    val items=base.filter{e.str("legendVisible:${it.key}","true")!="false"}.sortedBy(::order)
    val nodes=mutableListOf<Primitive>();var y=0.0
    if(e.text.isNotBlank()){nodes.add(Primitive.Text(Vec(0.0,y),e.text,textSize,s.copy(bold=true)));y+=textSize*1.7}
    items.forEach {item->
     val label=e.str("legendLabel:${item.key}").ifBlank{item.label}
     val fill=e.str("legendColor:${item.key}").ifBlank{item.style.fill?:"#D0D0D0"}
     nodes.add(Primitive.Path(rectangle(Vec(0.0,y-textSize),Vec(textSize*1.6,y)),true,s.copy(fill=fill)))
     nodes.add(Primitive.Text(Vec(textSize*2,y),label,textSize,s));y+=textSize*1.7
    }
    listOf(Primitive.Group(nodes,a))
   }
   "component" -> {
    when {
     isSteelEdge(e) -> {
      val len=e.num("edgeLengthMm",e.num("topWidthMm",1000.0)).coerceAtLeast(1.0)
      val thick=e.num("edgeThicknessMm",e.num("widthMm",8.0)).coerceAtLeast(1.0)
      val height=e.num("edgeHeightMm",e.num("sectionHeightMm",150.0)).coerceAtLeast(1.0)
      val bounds=if(d.viewMode()=="section")rectangle(Vec(0.0,0.0),Vec(thick,height))
                 else rectangle(Vec(0.0,0.0),Vec(len,thick))
      val parts=mutableListOf<Primitive>(Primitive.Path(bounds,true,s.copy(fill=e.style.fill)))
      if(d.viewMode()=="section"){
       if(e.str("steelFoundation")=="true"){
        val fw=e.num("steelFoundationWidthMm",200.0).coerceAtLeast(thick)
        val fh=e.num("steelFoundationHeightMm",200.0).coerceAtLeast(1.0)
        parts.add(0,Primitive.Path(rectangle(Vec(-(fw-thick)/2,height-fh/2),Vec((fw+thick)/2,height+fh/2)),true,s.copy(fill="#B7B6B0",stroke="#6C6D6B")))
       }
       if(e.str("steelBacking")=="true"){
        val bw=e.num("steelBackingWidthMm",100.0).coerceAtLeast(1.0)
        val bh=e.num("steelBackingHeightMm",100.0).coerceAtLeast(1.0)
        parts.add(0,Primitive.Path(listOf(Vec(thick,height),Vec(thick+bw,height),Vec(thick,height-bh)),true,s.copy(fill="#A6A5A0",stroke="#6C6D6B")))
       }
      }
      val pivot=if(d.viewMode()=="section")Vec(thick/2,height/2) else Vec(len/2,thick/2)
      // viewEntity() has already applied the view offset and rotation.
      // Applying smartViewOffset/Rotation again here moves the graphic away
      // from the selection/hit-test geometry after a drag or rotation.
      val angle=e.rotation
      val shift=pivot-pivot.rotate(angle)
      listOf(Primitive.Group(parts,a+shift,angle=angle))
     }
     e.smartFamily()=="curb" -> {
      // The chamfer is rendered visually here. Snap geometry intentionally remains
      // rectangular with two explicit height levels (OK and lower chamfer level).
      val outer=curbLocalOutline(e,d.viewMode())
      val w=if(d.viewMode()=="section")e.num("sectionWidthMm",e.num("widthMm",100.0)) else e.num("topWidthMm",e.num("widthMm",1000.0))
      val h=if(d.viewMode()=="section")e.num("sectionHeightMm",e.num("heightMm",200.0)) else e.num("topHeightMm",e.num("heightMm",100.0))
      val edge=(minOf(1.5,w*.025,h*.025)).coerceAtLeast(.35)
      val body=s.fill?:"#CFCFC8"
      val edgeStyle=s.copy(stroke=body,fill="#4B5652",widthMm=.01)
      val bodyStyle=s.copy(stroke=body,fill=body,widthMm=.01)
      val nodes=mutableListOf<Primitive>()
      nodes.add(Primitive.Path(outer,true,edgeStyle))
      if(w>edge*2&&h>edge*2){
       val inner=if(d.viewMode()=="section"&&curbHasChamfer(e)){
        val cw=curbChamferWidthMm(e).coerceAtMost(w);val cd=curbChamferDepthMm(e).coerceAtMost(h)
        listOf(Vec(edge,edge),Vec((w-cw-edge).coerceAtLeast(edge),edge),Vec(w-edge,(cd+edge).coerceAtMost(h-edge)),Vec(w-edge,h-edge),Vec(edge,h-edge))
       }else rectangle(Vec(edge,edge),Vec(w-edge,h-edge))
       nodes.add(Primitive.Path(inner,true,bodyStyle))
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isPlanter(e) -> {
      val shape=e.str("planterShape","Rechteckig")
      val round=shape=="Rund"
      val width=(if(round)e.num("planterDiameterMm",500.0) else e.num("planterWidthMm",1200.0)).coerceAtLeast(50.0)
      val depth=(if(round)width else e.num("planterDepthMm",500.0)).coerceAtLeast(50.0)
      val height=e.num("planterHeightMm",600.0).coerceAtLeast(50.0)
      val section=d.viewMode()=="section"
      val w=if(section)depth else width
      val h=if(section)height else depth
      val material=e.str("planterMaterial","Cortenstahl")
      val wall=(if(material=="Mauersteine")e.num("planterStoneDepthMm",200.0) else e.num("planterWallMm",5.0)).coerceIn(1.0,minOf(w,h)*.45)
      val finish=e.str("planterFinish","Naturrost")
      val metal=when{
       finish.contains("Anthrazit",true)->"#44484B"
       finish.contains("Schwarz",true)->"#292C2D"
       finish.contains("Weiß",true)->"#ECEBE5"
       finish.contains("Hellgrau",true)->"#C5C7C5"
       finish.contains("Grau",true)->"#92999B"
       finish.contains("Douglasie",true)->"#AC7951"
       finish.contains("Lärche",true)->"#C19562"
       finish.contains("Eiche",true)->"#9B7954"
       finish.contains("Braun",true)->"#765037"
       material=="Mauersteine"->when(e.str("planterStoneType","Betonmauerstein")){"Naturmauerstein"->"#B8AD98";"Klinker"->"#A76E5C";else->"#A9AAA6"}
       material=="Cortenstahl"->"#A45E3B"
       material=="Holz"->"#B78C60"
       material=="Beton"->"#B6B8B4"
       else->"#B1B9BD"
      }
      val planterTexture=if(material=="Mauersteine") (p.libraryEntries.find{it.id==e.str("planterManufacturerMaterialId")}
       ?.extensions?.get("baudetailTextureTop") as? JsonPrimitive)?.contentOrNull.orEmpty() else ""
      val edge=s.copy(stroke="#404948",fill=metal,widthMm=.24*d.sheet.scale)
      val soil=s.copy(stroke="#746D5A",fill="#A4987B",widthMm=.12*d.sheet.scale)
      val nodes=mutableListOf<Primitive>()
      if(!section && round){
       nodes.add(Primitive.Circle(Vec(w/2,h/2),w/2,edge))
       nodes.add(Primitive.Circle(Vec(w/2,h/2),(w/2-wall).coerceAtLeast(1.0),if(e.str("planterFill","true")=="true")soil else s.copy(stroke="#505755",fill=null,widthMm=.15*d.sheet.scale)))
      }else{
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(w,h)),true,edge))
       if(section){
        nodes.add(Primitive.Path(rectangle(Vec(wall,wall),Vec(w-wall,h-wall)),true,if(e.str("planterFill","true")=="true")soil else s.copy(stroke="#505755",fill="#F4F4F0",widthMm=.15*d.sheet.scale)))
        // Opening at the top: only sidewalls and base remain.
        nodes.add(Primitive.Path(listOf(Vec(wall,0.0),Vec(wall,h-wall),Vec(w-wall,h-wall),Vec(w-wall,0.0)),false,s.copy(stroke="#414947",fill=null,widthMm=.18*d.sheet.scale)))
       }else nodes.add(Primitive.Path(rectangle(Vec(wall,wall),Vec(w-wall,h-wall)),true,if(e.str("planterFill","true")=="true")soil else s.copy(stroke="#505755",fill=null,widthMm=.15*d.sheet.scale)))
       if(material=="Holz")for(i in 1..3){val y=h*i/4;nodes.add(Primitive.Path(listOf(Vec(0.0,y),Vec(if(section)wall else w,y)),style=s.copy(stroke="#71563C",fill=null,widthMm=.11*d.sheet.scale)))}
      }
      // Manufacturer color samples are not dimensionally calibrated stone textures.
      // Clip the original sample to the visible wall regions; keep mortar geometry vector based.
      if(planterTexture.isNotBlank()){
       if(section){
        nodes.add(Primitive.Group(listOf(Primitive.Asset(Vec(0.0,0.0),wall,h,planterTexture)),clip=rectangle(Vec(0.0,0.0),Vec(wall,h))))
        nodes.add(Primitive.Group(listOf(Primitive.Asset(Vec(w-wall,0.0),wall,h,planterTexture)),clip=rectangle(Vec(w-wall,0.0),Vec(w,h))))
       }else if(!round){
        val frame=rectangle(Vec(),Vec(w,h))
        nodes.add(Primitive.Group(listOf(Primitive.Asset(Vec(),w,h,planterTexture)),clip=frame))
        nodes.add(Primitive.Path(rectangle(Vec(wall,wall),Vec(w-wall,h-wall)),true,if(e.str("planterFill","true")=="true")soil else s.copy(stroke="#505755",fill="#F4F4F0",widthMm=.15*d.sheet.scale)))
       }
      }
      if(material=="Mauersteine" && !round){
       val stoneL=e.num("planterStoneLengthMm",400.0).coerceAtLeast(20.0)
       val stoneH=e.num("planterStoneHeightMm",200.0).coerceAtLeast(20.0)
       val stoneD=e.num("planterStoneDepthMm",200.0).coerceAtLeast(20.0)
       val mortar=s.copy(stroke="#65625D",fill=null,widthMm=.10*d.sheet.scale)
       if(section){
        // Brick courses across the section; heights are clipped to the shell.
        var y=stoneH
        while(y<h && y/stoneH<150){nodes.add(Primitive.Path(listOf(Vec(0.0,y),Vec(wall,y)),style=mortar));nodes.add(Primitive.Path(listOf(Vec(w-wall,y),Vec(w,y)),style=mortar));y+=stoneH}
       }else{
        // Long walls use longitudinal stones, short return walls use
        // perpendicular stones. All masonry stays inside the outer footprint.
        val thickness=wall.coerceAtMost(minOf(w,h)*.45)
        fun horizontalCourse(y0:Double){var x=thickness;while(x<w-thickness){val nx=(x+stoneL).coerceAtMost(w-thickness);nodes.add(Primitive.Path(listOf(Vec(nx,y0),Vec(nx,y0+thickness)),style=mortar));x=nx}}
        horizontalCourse(0.0);horizontalCourse(h-thickness)
        // The corner returns rotate the stone layout by 90 degrees.
        fun endCourse(x0:Double){var y=thickness;while(y<h-thickness){val ny=(y+stoneL).coerceAtMost(h-thickness);nodes.add(Primitive.Path(listOf(Vec(x0,y),Vec(x0+thickness,y)),style=mortar));y=ny}}
        endCourse(0.0);endCourse(w-thickness)
        // Stone depth is the wall build-up in the masonry variant.
        if(stoneD>0.0) { /* preserve explicit stone depth for editing */ }
       }
      }
      if(e.str("planterPlanting","true")=="true") {
       // Deterministic botanical linework: foliage rosettes in plan, branching
       // grasses and leafy stems in section. Geometry follows the planter size.
       val green=s.copy(stroke="#527449",fill=null,widthMm=.16*d.sheet.scale)
       val light=s.copy(stroke="#769364",fill=null,widthMm=.12*d.sheet.scale)
       val dark=s.copy(stroke="#3E6240",fill=null,widthMm=.20*d.sheet.scale)
       if(section){
        val soilLine=if(e.str("planterFill","true")=="true")wall else wall*.85
        val ground=soilLine.coerceAtLeast(3.0)
        val count=(w/145.0).toInt().coerceIn(3,11)
        for(i in 0 until count){
         val x=wall+(w-2*wall)*(i+.5)/count
         val tall=height*(.18+.10*((i*7)%5)/4.0)
         val tip=ground-tall
         nodes.add(Primitive.Path(listOf(Vec(x,ground),Vec(x+((i%3)-1)*tall*.09,tip)),style=dark))
         for(j in 1..4){
          val y=ground-tall*j/5.0
          val spread=tall*(.10+.035*(j%2))
          val side=if((i+j)%2==0)1.0 else -1.0
          nodes.add(Primitive.Path(listOf(Vec(x,y+spread*.20),Vec(x+side*spread*.55,y-spread*.4),Vec(x+side*spread,y-spread*.65)),style=green))
          nodes.add(Primitive.Path(listOf(Vec(x,y),Vec(x-side*spread*.45,y-spread*.55),Vec(x-side*spread*.8,y-spread*.45)),style=light))
         }
         // Slender blades make the planting read as vegetation, not arrows.
         nodes.add(Primitive.Path(listOf(Vec(x-tall*.12,ground),Vec(x-tall*.19,ground-tall*.53),Vec(x-tall*.24,ground-tall*.7)),style=light))
         nodes.add(Primitive.Path(listOf(Vec(x+tall*.10,ground),Vec(x+tall*.20,ground-tall*.43),Vec(x+tall*.27,ground-tall*.6)),style=green))
        }
       }else{
        val radius=minOf(w,h)*.15
        val count=if(round)7 else (w/180.0).toInt().coerceIn(4,13)
        for(i in 0 until count){
         val theta=i*2.399963229728653
         val fraction=sqrt((i+.5)/count.toDouble())*.72
         val x=if(round)w*.5+cos(theta)*(w*.5-wall-radius*.7)*fraction else wall+radius+(w-2*wall-2*radius)*(i+.5)/count
         val y=if(round)h*.5+sin(theta)*(h*.5-wall-radius*.7)*fraction else h*.5+sin(i*2.1)*(h*.5-wall-radius)*.46
         val r=radius*(.65+.13*(i%4))
         for(j in 0..7){
          val t=j*Math.PI/4+i*.31
          val v=Vec(cos(t),sin(t))
          val side=Vec(-v.y,v.x)
          nodes.add(Primitive.Path(listOf(Vec(x,y),Vec(x+v.x*r*.55+side.x*r*.16,y+v.y*r*.55+side.y*r*.16),Vec(x+v.x*r,y+v.y*r),Vec(x+v.x*r*.55-side.x*r*.16,y+v.y*r*.55-side.y*r*.16)),true,if(j%2==0)green else light))
         }
         nodes.add(Primitive.Circle(Vec(x,y),r*.12,dark))
        }
       }
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isLightwell(e) -> {
      val w=e.num("lightwellWidthMm",1000.0).coerceAtLeast(100.0)
      val depth=e.num("lightwellDepthMm",500.0).coerceAtLeast(100.0)
      val height=e.num("lightwellHeightMm",1000.0).coerceAtLeast(100.0)
      val wall=e.num("lightwellWallMm",80.0).coerceIn(5.0,minOf(w,depth,height)*.40)
      val cover=e.str("lightwellCover","Gitterrost")
      val color=e.str("lightwellColor","Silber")
      val metal=when(color){"Edelstahl silber","Silber"->"#ADB8C0";"Cortenstahl"->"#A35A36";"Anthrazit"->"#454B4E";"Grau"->"#858C90";"Schwarz"->"#24282B";else->"#ADB8C0"}
      val edge=s.copy(stroke="#49565B",fill="#BFC3C2",widthMm=.24*d.sheet.scale)
      val grate=s.copy(stroke=metal,fill=null,widthMm=.23*d.sheet.scale)
      val nodes=mutableListOf<Primitive>()
      if(d.viewMode()=="top"){
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(w,depth)),true,edge))
       val left=wall;val right=w-wall;val top=wall;val bottom=depth-wall
       nodes.add(Primitive.Path(rectangle(Vec(left,top),Vec(right,bottom)),true,s.copy(stroke="#49565B",fill="#4C5558",widthMm=.2*d.sheet.scale)))
       val inset=wall+minOf(6.0,wall*.12);val x1=inset;val x2=w-inset;val y1=inset;val y2=depth-inset
       if(x2>x1&&y2>y1){
        val fine=cover.contains("Insektenschutz",true)
        val longitudinal=cover.contains("Längs",true)
        val step=if(fine)12.0 else 38.0
        val countX=((x2-x1)/step).toInt().coerceIn(2,110)
        val countY=((y2-y1)/step).toInt().coerceIn(2,75)
        if(!longitudinal)for(i in 1 until countX){val x=x1+(x2-x1)*i/countX;nodes.add(Primitive.Path(listOf(Vec(x,y1),Vec(x,y2)),style=grate.copy(widthMm=if(fine).10*d.sheet.scale else .27*d.sheet.scale)))}
        val count=if(longitudinal)minOf(22,countY) else countY
        for(i in 1 until count){val y=y1+(y2-y1)*i/count;nodes.add(Primitive.Path(listOf(Vec(x1,y),Vec(x2,y)),style=grate.copy(widthMm=if(fine).10*d.sheet.scale else .27*d.sheet.scale)))}
        nodes.add(Primitive.Path(rectangle(Vec(x1,y1),Vec(x2,y2)),true,grate))
       }
      }else{
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(depth,height)),true,edge))
       nodes.add(Primitive.Path(rectangle(Vec(wall,wall),Vec(depth-wall,height-wall)),true,s.copy(stroke="#49565B",fill="#EFF0EE",widthMm=.18*d.sheet.scale)))
       nodes.add(Primitive.Path(rectangle(Vec(0.0,0.0),Vec(depth,wall.coerceAtMost(35.0))),true,s.copy(stroke=metal,fill=metal,widthMm=.15*d.sheet.scale)))
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isChannelBox(e) -> {
      val bw=e.num("boxWidthMm",185.0);val bh=e.num("boxHeightMm",610.0);val bl=e.num("boxLengthMm",500.0);val nw=e.num("channelNominalWidthMm",150.0);val dn=e.num("pipeDnMm",160.0);val axis=e.num("pipeAxisFromTopMm",500.0);val side=e.str("pipeOutlet","none")
      val channelType=e.str("channelType","box")
      val loadClass=e.str("loadClass","B 125")
      val grateType=e.str("grateType",when(channelType){"slot"->"Schlitz";"facade"->"Längsstab";else->"Gitterrost"})
      // The parametric dimensions are the single source of truth. Decorative
      // strokes are drawn *inside* those millimetre bounds so screen graphics,
      // hit box, dimensions and print/PDF all describe the same real geometry.
      val outlineW=0.25*d.sheet.scale
      val detailW=0.22*d.sheet.scale
      val halfOutline=outlineW/2.0
      val bodyFill=s.copy(stroke="#D9C27C",fill=s.fill?:"#D9C27C",widthMm=0.01*d.sheet.scale)
      val outline=s.copy(stroke="#6A603F",fill=null,widthMm=outlineW)
      val dark=s.copy(stroke="#42484A",fill="#596164",widthMm=detailW)
      val metal=s.copy(stroke="#50575A",fill="#AAB0B2",widthMm=detailW)
      val nodes=mutableListOf<Primitive>()
      if(d.viewMode()=="top"){
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(bl,bw)),true,bodyFill))
       nodes.add(Primitive.Path(rectangle(Vec(halfOutline,halfOutline),Vec(bl-halfOutline,bw-halfOutline)),true,outline))
       val grateW=nw.coerceAtMost(bw);val y0=(bw-grateW)/2
       val inset=(detailW/2).coerceAtMost(grateW/8)
       if(channelType=="slot"||grateType=="Schlitz"){
        val slotW=minOf(grateW*.16,30.0).coerceAtLeast(12.0);val sx=bl/2-slotW/2
        nodes.add(Primitive.Path(rectangle(Vec(sx,y0+inset),Vec(sx+slotW,y0+grateW-inset)),true,dark.copy(fill="#596164",widthMm=0.01*d.sheet.scale)))
       }else{
        nodes.add(Primitive.Path(rectangle(Vec(inset,y0+inset),Vec(bl-inset,y0+grateW-inset)),true,metal))
        when(grateType){
         "Längsstäbe","Längsstab"->{for(i in 1..7){val y=y0+grateW*i/8;nodes.add(Primitive.Path(listOf(Vec(inset,y),Vec(bl-inset,y)),style=dark.copy(fill=null)))}}
         "Stegrost"->{for(i in 1..10){val x=bl*i/11;nodes.add(Primitive.Path(listOf(Vec(x,y0+inset),Vec(x,y0+grateW-inset)),style=dark.copy(fill=null,widthMm=.38*d.sheet.scale)))}}
         "Stabgitter"->{for(i in 1..16){val x=bl*i/17;nodes.add(Primitive.Path(listOf(Vec(x,y0+inset),Vec(x,y0+grateW-inset)),style=dark.copy(fill=null)))};for(i in 1..3){val y=y0+grateW*i/4;nodes.add(Primitive.Path(listOf(Vec(inset,y),Vec(bl-inset,y)),style=dark.copy(fill=null,widthMm=.32*d.sheet.scale)))}}
         else->{for(i in 1..12){val x=bl*i/13;nodes.add(Primitive.Path(listOf(Vec(x,y0+inset),Vec(x,y0+grateW-inset)),style=dark.copy(fill=null)))};for(i in 1..5){val y=y0+grateW*i/6;nodes.add(Primitive.Path(listOf(Vec(inset,y),Vec(bl-inset,y)),style=dark.copy(fill=null)))}}
        }
       }
       if(e.str("leafBasket","true")=="true"&&channelType!="slot")nodes.add(Primitive.Path(rectangle(Vec(bl*.25,y0+grateW*.15),Vec(bl*.75,y0+grateW*.85)),true,dark.copy(fill=null,dashed=true)))
      } else {
       nodes.add(Primitive.Path(rectangle(Vec(),Vec(bw,bh)),true,bodyFill))
       nodes.add(Primitive.Path(rectangle(Vec(halfOutline,halfOutline),Vec(bw-halfOutline,bh-halfOutline)),true,outline))
       val cx=bw/2;val cutW=nw.coerceAtMost(bw);val cutD=minOf(150.0,bh*.26)
       val frameH=if(e.str("grateVisible","true")=="true")minOf(24.0,bh*.04) else 0.0
       when(channelType){
        "slot"->{
         val slotW=minOf(cutW*.16,24.0).coerceAtLeast(10.0)
         nodes.add(Primitive.Path(rectangle(Vec(cx-slotW/2,0.0),Vec(cx+slotW/2,frameH.coerceAtLeast(18.0))),true,dark.copy(widthMm=0.01*d.sheet.scale)))
        }
        "facade"->{
         val sideW=(cutW*.28).coerceAtLeast(24.0)
         nodes.add(Primitive.Path(rectangle(Vec((bw-cutW)/2,0.0),Vec((bw-cutW)/2+sideW,frameH.coerceAtLeast(20.0))),true,dark.copy(widthMm=0.01*d.sheet.scale)))
        }
        else->{
         if(e.str("grateVisible","true")=="true")nodes.add(Primitive.Path(rectangle(Vec((bw-cutW)/2,0.0),Vec((bw+cutW)/2,frameH)),true,dark.copy(widthMm=0.01*d.sheet.scale)))
        }
       }
       val topY=frameH
       nodes.add(Primitive.Path(listOf(Vec(cx-cutW/2,topY),Vec(cx-cutW/2,topY+cutD*.35),Vec(cx,topY+cutD*.88),Vec(cx+cutW/2,topY+cutD*.35),Vec(cx+cutW/2,topY)),style=dark.copy(fill=null)))
       if(e.str("leafBasket","true")=="true"&&channelType!="slot")nodes.add(Primitive.Path(rectangle(Vec(cx-cutW*.32,topY+cutD+20),Vec(cx+cutW*.32,(topY+cutD+170).coerceAtMost(bh-halfOutline))),true,metal.copy(fill=null,dashed=true)))
       if(side!="none"){
        val y=if(side=="bottom")bh else axis.coerceIn(dn/2,bh-dn/2);val x=when(side){"left"->0.0;"right"->bw;else->bw/2.0}
        val outletStroke=0.22*d.sheet.scale
        val outletRadius=(dn/2-outletStroke/2).coerceAtLeast(dn*.40)
        nodes.add(Primitive.Circle(Vec(x,y),outletRadius,dark.copy(fill="#5B6D78",widthMm=outletStroke)))
       }
      }
      listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     isRetainingWall(e) -> {
      if(d.viewMode()=="section") listOf(Primitive.Group(listOf(Primitive.Path(retainingWallSection(e),true,s.copy(fill=s.fill?:"#D0CEC6"))),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      else {val (wall,foot)=retainingWallTop(e);listOf(Primitive.Group(listOf(Primitive.Path(foot,true,s.copy(fill=null,dashed=true)),Primitive.Path(wall,true,s.copy(fill=s.fill?:"#D0CEC6"))),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))}
     }
     isPipe(e) -> {
      val dn=e.num("dnMm",e.num("sectionHeightMm",160.0)).coerceAtLeast(1.0);val vertical=e.str("orientation","horizontal")=="vertical";val dir=if(e.str("verticalDirection","down")=="up")-1.0 else 1.0;val len=e.num("pipeLengthMm",e.num("verticalLengthMm",1000.0)).coerceAtLeast(dn)
      if(isKg2000(e)&&!vertical){
       val green=s.copy(stroke="#0B5F34",fill="#149447",widthMm=0.5*d.sheet.scale);val dark=s.copy(stroke="#063E23",fill="#0C6E3B",widthMm=0.45*d.sheet.scale);val type=e.str("fittingType","pipe");val nodes=mutableListOf<Primitive>()
       when(type){
        "bend"->{val g=kg2000BendGeometry(e,d.viewMode());val socketLen=minOf(g.path.getOrElse(1){Vec(dn*.4,0.0)}.x.coerceAtLeast(dn*.25),dn*.55);nodes.add(Primitive.Path(g.path,style=green.copy(fill=null,widthMm=dn)));nodes.add(Primitive.Path(listOf(Vec(),Vec(socketLen,0.0)),style=dark.copy(fill=null,widthMm=dn*1.12)));nodes.add(Primitive.Path(listOf(Vec(socketLen*.18,0.0),Vec(socketLen,0.0)),style=green.copy(fill=null,widthMm=dn)));}
        "y"->{val branch=e.num("branchDnMm",dn);nodes.add(Primitive.Path(listOf(Vec(),Vec(len,0.0)),style=green.copy(fill=null,widthMm=dn)));nodes.add(Primitive.Path(listOf(Vec(len*.52,0.0),Vec(len*.88,len*.36)),style=green.copy(fill=null,widthMm=branch)));nodes.add(Primitive.Circle(Vec(),dn*.62,dark))}
        "reducer"->{val big=e.num("inletDnMm",dn);val small=e.num("outletDnMm",dn);val actualLen=kg2000ReducerLengthMm(big.toInt(),small.toInt())?:len;val sy=(big-small)/2.0;nodes.add(Primitive.Path(listOf(Vec(0.0,-big/2),Vec(actualLen,sy-small/2),Vec(actualLen,sy+small/2),Vec(0.0,big/2)),true,green));val od=kg2000SocketOuterDnMm(small);val socketLen=minOf(kg2000SocketProjectionMm(small),actualLen*.45);nodes.add(Primitive.Path(rectangle(Vec(actualLen-socketLen,sy-od/2),Vec(actualLen,sy+od/2)),true,dark))}
        "double_spigot"->{nodes.add(Primitive.Path(rectangle(Vec(),Vec(len,dn)),true,green))}
        else->{nodes.add(Primitive.Path(rectangle(Vec(),Vec(len,dn)),true,green));val od=kg2000SocketOuterDnMm(dn);val socketLen=minOf(kg2000SocketProjectionMm(dn),len*.45);nodes.add(Primitive.Path(rectangle(Vec(0.0,(dn-od)/2),Vec(socketLen,(dn+od)/2)),true,dark))}
       }
       if(e.str("flowArrow","true")=="true"){if(type=="bend"){val path=kg2000BendGeometry(e,d.viewMode()).path;val a=path[(path.size*.35).toInt().coerceIn(0,path.lastIndex)];val b=path[(path.size*.65).toInt().coerceIn(0,path.lastIndex)];val reverse=e.str("flowDirection","forward")=="reverse";nodes.addAll(arrow(if(reverse)b else a,if(reverse)a else b))}else{val cy=if(type in setOf("pipe","double_spigot"))dn*.5 else 0.0;val from=if(e.str("flowDirection","forward")=="reverse")Vec(len*.65,cy)else Vec(len*.35,cy);val to=if(e.str("flowDirection","forward")=="reverse")Vec(len*.35,cy)else Vec(len*.65,cy);nodes.addAll(arrow(from,to))}}
       listOf(Primitive.Group(nodes,a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      } else {
       val node=if(d.viewMode()=="section") {if(vertical)Primitive.Path(rectangle(Vec(-dn/2,0.0),Vec(dn/2,dir*len)),true,s.copy(fill=s.fill)) else Primitive.Circle(Vec(),dn/2,s.copy(fill=s.fill))} else {if(vertical)Primitive.Circle(Vec(),dn/2,s.copy(fill=s.fill)) else Primitive.Path(rectangle(Vec(),Vec(e.num("topWidthMm",len),dn)),true,s.copy(fill=s.fill))}
       listOf(Primitive.Group(listOf(node),a,angle=e.rotation,mirrorY=e.num("mirrored")==1.0))
      }
     }
     e.smartFamily()=="grass" && d.viewMode()=="section" && e.asset==null -> {
      val w=e.num("sectionWidthMm",1000.0);val h=e.num("sectionHeightMm",150.0);val grassStyle=s.copy(fill=s.fill?:"#B79B72");val blades=(0..(w/35).toInt().coerceAtMost(200)).map{i->val x=i*35.0;Primitive.Path(listOf(Vec(x,0.0),Vec(x+7,-20.0),Vec(x+13,0.0)),style=s.copy(stroke="#6F9B55"))};listOf(Primitive.Group(listOf(Primitive.Path(rectangle(Vec(),Vec(w,h)),true,grassStyle))+blades,a,angle=e.rotation))
     }
     e.children.isNotEmpty()&&(e.str("frozenTemplate")=="true"||(e.asset==null&&e.view==d.viewMode()&&(e.str("libraryViews")!="true"||d.viewMode()=="section"))) -> {
      val bounds=Bounds.of(e.children.flatMap {it.points});val base=e.num("baseWidthMm",bounds.width.coerceAtLeast(1.0));val scale=if(e.str("frozenTemplate")=="true")e.num("templateScale",1.0)else e.num("widthMm",base)/base
      listOf(Primitive.Group(e.children.flatMap {entity(it,d,p)},a,scale,e.rotation,mirrorY=e.num("mirrored")==1.0))
     }
     e.asset!=null -> listOf(Primitive.Group(listOf(Primitive.Asset(Vec(),e.num("widthMm",500.0),e.num("heightMm",500.0),e.asset,s.opacity)),a,angle=e.rotation+(if(d.viewMode()=="section")-Math.toDegrees(atan(e.num("slope")/100))else 0.0),mirrorY=e.num("mirrored")==1.0))
     else -> listOf(Primitive.Group(listOf(Primitive.Path(rectangle(Vec(),Vec(e.num("widthMm",500.0),e.num("heightMm",500.0))),true,s)),a,angle=e.rotation+(if(d.viewMode()=="section")-Math.toDegrees(atan(e.num("slope")/100))else 0.0),mirrorY=e.num("mirrored")==1.0))
    }
   }
   "image" -> if(e.asset!=null)listOf(Primitive.Asset(a,e.num("widthMm",1000.0),e.num("heightMm",1000.0),e.asset,s.opacity,e.rotation))else listOf(text(a,"Ressource fehlt"))
   else -> listOf(Primitive.Path(pts,style=s))
  }
  if(labelActive(e,d)) {
   val atLabel=objectLabelPosition(input,d)
   val target=objectLabelTarget(input,d,atLabel)
   val value=if(input.str("labelMode","auto")=="manual"&&input.str("labelText").isNotBlank())input.str("labelText") else {
    when {
     isChannelBox(input) && input.name.contains("Einlaufkasten",ignoreCase=true) -> "Einlaufkasten"
     input.isParametricBuildUp(entry) -> buildUpLabel(input)
     isStair(input) -> "Blockstufenanlage"
     else -> input.name.ifBlank{input.kind}
    }
   }
   val lines=value.split("\n")
   val labelSize=input.style.textPaperMm*50.0*(input.num("annotationScalePct",100.0).coerceIn(1.0,100.0)/100.0)
   val lineHeight=labelSize*1.4
   val maxWidth=(lines.maxOfOrNull{it.length}?:0)*labelSize*.57
   // Text origin is a baseline; leader connects to the nearest outer edge of its bounding box.
   val labelLeft=atLabel.x-maxWidth/2.0;val labelRight=atLabel.x+maxWidth/2.0
   val labelTop=atLabel.y-labelSize;val labelBottom=atLabel.y+(lines.size-1)*lineHeight+labelSize*.3
   val attach=Vec(target.x.coerceIn(labelLeft,labelRight),target.y.coerceIn(labelTop,labelBottom))
   val left=Vec(labelLeft,target.y.coerceIn(labelTop,labelBottom));val right=Vec(labelRight,target.y.coerceIn(labelTop,labelBottom))
   val top=Vec(target.x.coerceIn(labelLeft,labelRight),labelTop);val bottom=Vec(target.x.coerceIn(labelLeft,labelRight),labelBottom)
   // Connect to the nearest outside boundary, never across any text line.
   val options=listOf(left,right,top,bottom)
   val boundary=options.minByOrNull{it.distance(target)}?:right
   return rendered+arrow(boundary,target)+lines.flatMapIndexed{i,line->listOf(Primitive.Text(atLabel+Vec(0.0,i*lineHeight),line,labelSize,s.copy(stroke="#687373",align="center"),0.0))}
  }
  return rendered
 }
 fun materialHatch(e:Entity,entry:LibraryEntry?,d:Drawing):List<Primitive>{
  if(entry==null||d.viewMode()!="section")return emptyList()
  val asset=entry.appearance?.sectionPattern?:entry.views["section"]?:return emptyList()
  val polygon=contour(e);if(polygon.size<3)return emptyList();val b=Bounds.of(polygon)
  val gravel=(entry.name+" "+entry.category).lowercase().let{it.contains("kies")||it.contains("schotter")||it.contains("schütt")||it.contains("frostschutz")||it.contains("rc ")}
  if(gravel){
   val step=38.0;val dots=mutableListOf<Primitive>();var y=b.min.y+step*.45;var row=0
   while(y<b.max.y){var x=b.min.x+step*.4+(row%2)*step*.35;while(x<b.max.x){dots.add(Primitive.Circle(Vec(x,y),4.0,style=Style(stroke=e.style.stroke,fill=null,widthMm=.10*d.sheet.scale)));x+=step};y+=step*.72;row++}
   return listOf(Primitive.Group(dots,clip=polygon))
  }
  val w=(entry.appearance?.tileWidthMm?:entry.attribute("pattern_width_mm",200.0)).coerceAtLeast(1.0);val h=(entry.appearance?.tileHeightMm?:entry.attribute("pattern_height_mm",200.0)).coerceAtLeast(1.0)
  val cols=ceil(b.width/w).toInt().coerceAtLeast(1);val rows=ceil(b.height/h).toInt().coerceAtLeast(1)
  if(cols.toLong()*rows>10000)return listOf(Primitive.Text(b.min,"Schraffur: Fläche teilen (mehr als 10.000 Kacheln)",3*d.sheet.scale))
  return listOf(Primitive.Group((0 until rows).flatMap{y->(0 until cols).map{x->Primitive.Asset(b.min+Vec(x*w,y*h),w,h,asset)}},clip=polygon))
 }
 fun pattern(poly:List<Vec>,p:Pattern,style:Style,scale:Double):Primitive {
  val dx=(p.widthMm+p.jointMm).coerceAtLeast(1.0);val dy=(p.heightMm+p.jointMm).coerceAtLeast(1.0)
  val bounds=Bounds.of(poly.map {(it-p.origin).rotate(-p.angle)})
  val minX=floor(bounds.min.x/dx).toInt()-2;val maxX=ceil(bounds.max.x/dx).toInt()+2;val minY=floor(bounds.min.y/dy).toInt()-2;val maxY=ceil(bounds.max.y/dy).toInt()+2
  val nodes=mutableListOf<Primitive>();val count=(maxX.toLong()-minX+1)*(maxY.toLong()-minY+1)
  if(count<=40000)for(row in minY..maxY)for(col in minX..maxX){val offset=if(row%2==0)0.0 else p.offset*dx;val a=Vec(col*dx+offset,row*dy);nodes.add(Primitive.Path(rectangle(a,a+Vec(p.widthMm,p.heightMm)),true,style.copy(fill=null,widthMm=min(p.jointMm.coerceAtLeast(0.05),0.12*scale))))}
  return Primitive.Group(listOf(Primitive.Group(nodes,p.origin,angle=p.angle)),clip=poly)
 }
 /** Two independent scale-preserving viewports on one physical sheet. */
 fun paperDual(d:Drawing,p:Project,sectionPos:Vec,topPos:Vec,sectionScale:Double,topScale:Double,sectionOrigin:Vec,topOrigin:Vec):List<Primitive> {
  val sh=d.sheet
  val margin=10.0
  val bottom=sh.heightMm-32.0
  val frame=Style(stroke="#69756F",widthMm=0.18)
  fun pane(view:String,pos:Vec,scale:Double,origin:Vec):List<Primitive> {
   val v=d.copy(extensions=JsonObject(d.extensions.toMutableMap().apply{put("viewMode",JsonPrimitive(view))}))
   val nodes=drawing(v,p,true)
   val items=v.entities.filter { e -> val layer=v.layers.find{it.id==e.layerId};visibleIn(e,v)&&layer?.visible!=false&&layer?.printable!=false }
   val bounds=if(items.isEmpty())Bounds(Vec(),Vec()) else Bounds.of(items.flatMap{listOf(viewBounds(it,v).min,viewBounds(it,v).max)})
   // The window follows the actual geometry, not a giant fixed half-page rectangle.
   val paneW=((bounds.max.x-bounds.min.x)/scale+6.0).coerceAtLeast(10.0)
   val paneH=((bounds.max.y-bounds.min.y)/scale+12.0).coerceAtLeast(16.0)
   val group=Primitive.Group(nodes,Vec(pos.x-origin.x/scale,pos.y-origin.y/scale+8.0),1/scale)
   val caption=Primitive.Text(pos+Vec(2.0,5.0),if(view=="section")"Schnitt · 1:${scale.toInt()}" else "Draufsicht · 1:${scale.toInt()}",2.8,frame)
   return listOf(group,caption)
  }
  val title=Primitive.Path(rectangle(Vec(margin,bottom+2.0),Vec(sh.widthMm-margin,sh.heightMm-margin)),true,frame)
  val titleText=Primitive.Text(Vec(margin+3,bottom+9),"${p.name} · Schnitt und Draufsicht",3.0,frame)
  return pane("section",sectionPos,sectionScale,sectionOrigin)+pane("top",topPos,topScale,topOrigin)+listOf(title,titleText)
 }
 fun paper(d:Drawing,p:Project):List<Primitive> {
  val sh=d.sheet;val margin=10.0;val bottom=sh.heightMm-32.0
  val printableW=(sh.widthMm-2*margin).coerceAtLeast(1.0)*sh.scale
  val printableH=(bottom-margin).coerceAtLeast(1.0)*sh.scale
  val visible=d.entities.filter { e ->
   val l=d.layers.find{it.id==e.layerId};l?.visible!=false&&l?.printable!=false&&visibleIn(e,d)
  }
  // sheet.origin is the fixed lower-left world anchor of the printable area.
  // Changing A4/A3/A2 therefore grows/shrinks the sheet to the right and upward
  // without moving the drawing. Only translation changes placement; scale stays exact.
  val exportOrigin=sh.origin
  val angle=if(d.viewMode()=="top")d.topViewAngle() else 0.0
  // Rotate around a stable world origin, never around the movable paper viewport.
  // Otherwise moving the sheet changes the rotation pivot and swaps drag axes.
  val center=Vec(0.0,0.0)
  val contentNodes=if(kotlin.math.abs(angle)<0.00001)drawing(d,p,true) else listOf(Primitive.Group(
   listOf(Primitive.Group(drawing(d,p,true),translate=Vec(-center.x,-center.y))),
   translate=center,angle=angle))
  val content=Primitive.Group(contentNodes,Vec(margin-exportOrigin.x/sh.scale,bottom-exportOrigin.y/sh.scale),1/sh.scale)
  val style=Style(widthMm=0.2)
  // Upgrade the legacy standard title fields without changing custom title templates.
  val titleTemplate=sh.titleTemplate
   .replace("{projekt} | {zeichnung}","{bauvorhaben} | {zeichnung}")
   .replace("Nr. {projektnummer}","BV {projektnummer}")
  val titleLines=interpolate(titleTemplate,variables(p,d)).lines().map{it.trimEnd()}.filter{it.isNotBlank()}
  val titleSize=2.6
  val frameTop=bottom+2
  val head=mutableListOf<Primitive>(
   Primitive.Group(listOf(content),clip=rectangle(Vec(margin,margin),Vec(sh.widthMm-margin,bottom))),
   Primitive.Path(rectangle(Vec(margin,frameTop),Vec(sh.widthMm-margin,sh.heightMm-margin)),true,style)
  )
  titleLines.take(4).forEachIndexed{i,line->head.add(Primitive.Text(Vec(margin+3,frameTop+5+i*4.7),line,titleSize,style))}
  val barLeft=sh.widthMm-115
  val barRight=sh.widthMm-15
  val barY=sh.heightMm-15
  // Exactly 100 mm on paper; end ticks make measurement unambiguous.
  head.add(Primitive.Path(listOf(Vec(barLeft,barY),Vec(barRight,barY)),style=style))
  head.add(Primitive.Path(listOf(Vec(barLeft,barY-1.5),Vec(barLeft,barY+1.5)),style=style))
  head.add(Primitive.Path(listOf(Vec(barRight,barY-1.5),Vec(barRight,barY+1.5)),style=style))
  val actualCm=100.0*sh.scale/10.0
  val actualLabel=if(kotlin.math.abs(actualCm-kotlin.math.round(actualCm))<0.000001)
   kotlin.math.round(actualCm).toLong().toString() else fmt(actualCm,2)
  head.add(Primitive.Text(Vec(barLeft,sh.heightMm-17),"Kontrollmaß 100 mm ≙ $actualLabel cm",2.2,style))
  return head
 }
}
