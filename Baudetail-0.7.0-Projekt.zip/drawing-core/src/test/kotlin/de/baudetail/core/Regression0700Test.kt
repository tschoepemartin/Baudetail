package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.*
import kotlin.test.*

class Regression0700Test {
 private fun libraryBuildUp(name:String="Pflasteraufbau begehbar")=LibraryEntry(
  id="future-build-up",type="component",name=name,category="Baugruppen/Standard-Schichtaufbauten",
  attributes=buildJsonObject{put("Schichten","Pflaster 8 cm | Bettung 4 cm | Frostschutz 25 cm");put("width_mm",1200.0);put("height_mm",370.0)},
  views=mapOf("top" to "legacy-section.svg","section" to "legacy-section.svg")
 )
 @Test fun libraryMetadataMakesBuildUpGeneric(){
  val entry=libraryBuildUp();assertTrue(entry.isParametricBuildUp())
  val e=componentInstance(entry,Vec());assertEquals("stack",e.kind);assertEquals(3,e.strata.size);assertEquals(80.0,e.strata[0].thicknessMm,0.0)
 }
 @Test fun oldPlacedComponentIsMigratedFromItsLibraryEntry(){
  val entry=libraryBuildUp();val old=Entity(kind="component",libraryId=entry.id,name=entry.name,points=listOf(Vec()))
  val migrated=old.withBuildUpDefaults(entry);assertTrue(migrated.isParametricBuildUp(entry));assertEquals(3,migrated.strata.size);assertNotNull(migrated.pattern)
 }
 @Test fun futureNamedBuildUpNeedsNoHardcodedName(){
  val entry=libraryBuildUp("Neue Bibliothek Konstruktion 2030");assertTrue(entry.isParametricBuildUp());assertEquals("Aufbau anpassen",entry.buildUpEditorTitle())
 }
 @Test fun planRenderingOfLegacyBuildUpDoesNotUseLibrarySectionAsset(){
  val entry=libraryBuildUp();val old=Entity(kind="component",libraryId=entry.id,name=entry.name,points=listOf(Vec()))
  val p=Project(libraryEntries=listOf(entry));val d=Drawing(entities=listOf(old)).withViewMode("top")
  val nodes=Scene.drawing(d,p)
  fun assets(x:Primitive):Int=when(x){is Primitive.Asset->1;is Primitive.Group->x.nodes.sumOf(::assets);else->0}
  assertEquals(0,nodes.sumOf(::assets))
 }
}
