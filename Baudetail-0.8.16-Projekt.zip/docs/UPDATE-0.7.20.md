# Baudetail 0.7.20

## Geändert
- Der mobile Eigenschaften-Dialog ist nun ein transparentes ModalBottomSheet; seine Hintergrundfläche wird nur gezeichnet, solange kein Größenregler aktiv ist.
- Während der Größenänderung werden die anderen Inspector-Elemente transparent, ohne aus dem Layout entfernt zu werden. Regler und Prozentangabe behalten ihre Position; auch die große Bottom-Sheet-Fläche und die Verdunkelung verschwinden, sodass die Zeichnung dahinter sichtbar bleibt.
- Nach dem Loslassen wird der Eigenschaften-Dialog wieder eingeblendet.
- Die Linie unter Höhenkoten endet nun bei der geschätzten tatsächlichen Textbreite statt um eine feste Zusatzlänge weiter rechts. Zahlen, Vorzeichen und Komma erhalten unterschiedliche Zeichenbreiten.
- VersionCode 62 / VersionName 0.7.20.

## Hinweis
- Die Glyphenbreite wird in der Zeichen-Engine angenähert, nicht über die Android-Fontmetriken pixelgenau gemessen.
- Android- und Gerätetest noch ausstehend. Höhenkotenberechnung/Snapping nicht geändert.
