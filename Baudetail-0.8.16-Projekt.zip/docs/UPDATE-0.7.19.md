# Baudetail 0.7.19
- Beschriftungsregler behält beim Ziehen seinen Platz: restliches Menü bleibt im Layout, wird aber transparent.
- Größe wird unmittelbar in die Zeichnung übernommen; Menü erscheint nach dem Loslassen.
- Relative Höhenkoten ohne Referenzmarker aus Bezugshöhe und geometrischer Y-Position.
- Höhenkoten können auch an Segmenten einfacher Zeichnungsobjekte verankert werden.
- Dynamische Anker werden bei Geometrieänderungen erneut ausgewertet.
- Noch nicht auf Android gebaut oder auf Gerät getestet.
