# Baudetail 0.7.16
- PDF-Druckvorschau nutzt dieselbe Mindestschriftgrößen-Normalisierung wie der PDF-Export.
- Automatische Objektbeschriftungen werden näher am Bauteil platziert; manuelle Positionsversätze bleiben erhalten.
- Höhenkoten: Eingabe in Metern einschließlich negativer Werte, interne Speicherung in Millimetern.
- Bezugshöhen ohne automatisches REF; gefülltes nach unten gerichtetes Dreieck, Schrift-/Pfeilgröße separat in Papier-mm.
- VersionCode 58. Gradle-/Gerätetest noch ausstehend.
