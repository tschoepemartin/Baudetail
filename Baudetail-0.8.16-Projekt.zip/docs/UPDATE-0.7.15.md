# 0.7.15 – PDF-Schriftgröße

PDF-Texte werden vor der Umrechnung in PDF-Punkte in der **effektiven Blattgröße** auf mindestens 3,0 mm gebracht. Das berücksichtigt verschachtelte Gruppen und Planansichten mit eigenen Maßstäben. Die Koordinaten, Maßlinien, Bemaßungswerte, Objektgeometrie und Plangröße bleiben unverändert.

Die Änderung gilt für PDF, nicht für die Bildschirmdarstellung oder SVG/PNG. Ein Android-Gerätetest der tatsächlichen Lesbarkeit ist weiterhin erforderlich.
