# Baudetail 0.7.17
- Kompakte Höhenkote: Zahl links über kurzer Linie, gefülltes nach unten gerichtetes Dreieck; gemeinsamer Maßstab.
- Beschriftungsgrößenregler 1–100 % im Inspector; während des Ziehens nur Regler und Prozentwert.
- Höhenkoten über den sichtbaren Marker auswählbar; Ziehen behält den ursprünglichen Finger-/Textversatz bei.
- Objektbeschriftungen in einheitlichem Grauton; Texte mit gemeinsamem Größenfaktor.
- Automatische Objektbeschriftungen und Höhenkoten skalieren im PDF proportional zur Geometrie, ohne PDF-Mindestschriftgrößen-Korrektur.
- Bestehende Maßgeometrie und automatische Maße nicht geändert.
- Gradle- und Gerätetest ausstehend.
