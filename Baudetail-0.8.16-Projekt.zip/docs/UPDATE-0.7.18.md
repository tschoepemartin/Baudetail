# Baudetail 0.7.18 – Höhenkoten an Bauteiloberkanten
- Beim Ziehen einer Höhenkote wird die gemessene Dreiecksspitze an die nächste passende Bauteiloberkante gefangen, nicht der Text-Anker.
- Oberkanten von Blockstufen, Komponenten und parametrischen Schichtaufbauten; keine Maße oder Texte als Snap-Ziele.
- Persistente Kantenanker mit Segmentindex und relativem Abstand, die auf Bauteiländerungen reagieren.
- Höhenwert im relativen Modus aus der verknüpften geometrischen Y-Höhe, Bezugshöhe und manuellem Offset.
- Beim Verschieben bleibt der Fingerabstand zur Spitze erhalten, ohne Positionssprung.
- Manuelle Höhenwerte bleiben fix und werden nicht automatisch überschrieben.
- Tests für Geometrieanker und Ausschluss von Texten ergänzt.
- Noch nicht durch Android-Gradle-Build oder Gerätetest verifiziert.
