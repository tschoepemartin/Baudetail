package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Assert.*
import org.junit.Test

class BuildUpRealLength089Test {
 @Test fun brokenSlopeHasDifferentDrawnAndRealHeights() {
  val e=Entity(kind="stack",points=listOf(Vec())).withNum("topDepthMm",1000.0)
   .withNum("buildUpSlopePct",-2.0).withStr("buildUpSlopeFixedSide","right")
   .withStr("buildUpRealLengthEnabled","true").withNum("buildUpRealLengthMm",6000.0)
  assertTrue(buildUpBroken(e))
  assertEquals(6000.0,buildUpRealLengthMm(e),0.001)
  assertEquals(20.0,buildUpSlopeDropMm(e,0.0),0.001)
  assertEquals(120.0,buildUpRealDropMm(e,0.0),0.001)
  assertEquals(0.0,buildUpRealDropMm(e,1000.0),0.001)
  assertEquals(6000.0,metricValue(e,"Weglänge"),0.001)
 }
 @Test fun disabledRealLengthKeepsLegacyBehavior() {
  val e=Entity(kind="stack").withNum("topDepthMm",1000.0).withNum("buildUpSlopePct",2.0)
  assertFalse(buildUpBroken(e))
  assertEquals(buildUpSlopeDropMm(e,1000.0),buildUpRealDropMm(e,1000.0),0.001)
 }
}
