package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Assert.*
import org.junit.Test

class Regression0718Test {
 @Test fun levelMarkerSnapsToConstructionSurfaceAndKeepsItsAnchor() {
  val stair=Entity(kind="assembly",points=listOf(Vec(0.0,0.0)))
   .withStr("assemblyType","stair").withNum("stepCount",3.0)
   .withNum("riseMm",145.0).withNum("goingMm",350.0)
   .withNum("slope",0.0)
  val d=Drawing(entities=listOf(stair)).withViewMode("section")
  val surfaces=smartSnapSegments(stair,d).filter{(a,b)->kotlin.math.abs(a.y-b.y)<1e-5}
  assertTrue(surfaces.isNotEmpty())
  val top=surfaces.minByOrNull{it.first.y}!!
  val probe=(top.first+top.second)*0.5
  val result=elevationSurfaceSnap(probe,d,10.0)
  assertNotNull(result)
  assertEquals("Oberkante",result!!.reason)
  val marker=Entity(kind="elevation",points=listOf(result.point),anchors=listOf(result.anchor!!))
   .withStr("elevationRole","relative")
  val original=resolvedPoints(marker,d).first()
  assertEquals(result.point.y,original.y,0.001)
  val shifted=stair.copy(points=listOf(Vec(0.0,-100.0)))
  val updated=resolvedPoints(marker,d.copy(entities=listOf(shifted))).first()
  assertEquals(original.y-100.0,updated.y,0.001)
 }
 @Test fun markerDoesNotSnapToAnnotations() {
  val label=Entity(kind="text",points=listOf(Vec(0.0,0.0)),text="Hello")
  val d=Drawing(entities=listOf(label)).withViewMode("section")
  assertNull(elevationSurfaceSnap(Vec(0.0,0.0),d,100.0))
 }
}
