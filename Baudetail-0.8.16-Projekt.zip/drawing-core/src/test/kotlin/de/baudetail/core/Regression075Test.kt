package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.*
import org.junit.Test

class Regression075Test {
 @Test fun planPoseDoesNotChangeSectionBounds(){
  val e=Entity(kind="stack",points=listOf(Vec(100.0,200.0)),params=buildJsonObject{
   put("widthMm",2000.0);put("topDepthMm",1000.0);put("buildUpTopRotationDelta",90.0)
   put("buildUpTopWidthOffsetMm",-500.0);put("buildUpTopDxMm",350.0);put("buildUpTopDyMm",900.0)
  },strata=listOf(Stratum(thicknessMm=80.0),Stratum(thicknessMm=40.0),Stratum(thicknessMm=300.0)))
  val section=viewBounds(e,Drawing().withViewMode("section"))
  assertEquals(100.0,section.min.x,0.001)
  assertEquals(200.0,section.min.y,0.001)
  assertEquals(420.0,section.height,0.001)
  assertEquals(90.0,buildUpPlanAngle(e),0.001)
  val plan=viewBounds(e,Drawing().withViewMode("top"))
  assertEquals(1000.0,plan.width,0.001)
  assertEquals(2000.0,plan.height,0.001)
 }
 @Test fun planWidthIsSymmetricAroundCenterline(){
  val a=Entity(kind="stack",points=listOf(Vec()),params=buildJsonObject{put("topDepthMm",1200.0);put("widthMm",2000.0);put("buildUpTopRotationDelta",90.0);put("buildUpTopWidthOffsetMm",-600.0)})
  val b=a.withNum("topDepthMm",1000.0).withNum("buildUpTopWidthOffsetMm",-500.0)
  val d=Drawing().withViewMode("top")
  assertEquals(viewBounds(a,Drawing().withViewMode("section")).max.x,viewBounds(a,d).max.x,0.001)
  assertEquals(viewBounds(b,Drawing().withViewMode("section")).max.x,viewBounds(b,d).max.x,0.001)
  assertEquals(viewBounds(a,d).center.y,viewBounds(b,d).center.y,0.001)
 }
}
