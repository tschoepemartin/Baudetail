package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue

class BuildUpSlopeTest {
 @Test fun oneMetreAtTwoPercentDropsTwentyMillimetres() {
  val e=Entity(kind="stack",points=listOf(Vec(100.0,200.0))).withNum("topDepthMm",1000.0).withNum("buildUpSlopePct",2.0)
  val (start,end)=buildUpSurfaceEdge(e)
  assertEquals(100.0,start.x,0.0001)
  assertEquals(1100.0,end.x,0.0001)
  assertEquals(20.0,end.y-start.y,0.0001)
 }
 @Test fun reverseDirectionRaisesRightEnd() {
  val e=Entity(kind="stack",points=listOf(Vec())).withNum("topDepthMm",1000.0).withNum("buildUpSlopePct",-2.0)
  assertEquals(-20.0,buildUpSurfaceEdge(e).second.y,0.0001)
 }
}
