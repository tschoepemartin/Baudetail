# BauDetail 0.9.84

Universelles X/Y-Snapping beim Verschieben gewöhnlicher Planobjekte neu konsolidiert: tatsächliche Eckpunkte, Segmentprojektion für schräge Kanten, kombinierbarer X-/Y-Fang aus unterschiedlichen Objekten und Ebenen. Keine Änderungen an der funktionierenden Drehgeometrie. Komponentenspezifisches Verschieben behält vorerst seinen separaten Pfad.
