# BauDetail 0.9.87

- Grundbibliothek: 21 Mauerscheiben-Varianten auf einen parametrierbaren Eintrag „Mauerscheibe“ reduziert.
- Vorhandener Dialog für Höhe, Fußtiefe, Wandstärke, Fußstärke, Elementlänge und Fußrichtung über „Mauerscheibe anpassen“ benannt.
- Bestehende Zeichnungsobjekte und deren gespeicherte Parameter bleiben unverändert.
- Keine Änderung am universellen X-/Y-Snapping oder an der Leistenstein-Geometrie.
