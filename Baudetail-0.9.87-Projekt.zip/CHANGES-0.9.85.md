# BauDetail 0.9.85 – Universeller X/Y-Doppelsnap

- X- und Y-Achsen können unabhängig an unterschiedlichen Objekten/Kanten einrasten.
- Auch gedrehte Smart-Objekte und Grundstückskanten als Quellen und Ziele.
- Zwei Achsen haben Vorrang vor einzelnem Kanten-/Eckfang.
- Vorhandene Smart-Objekt-Kantenlogik bleibt für Ein-Achsen-Fälle erhalten.
- Spezialanschlüsse KG2000 unverändert.
- Build und Gerätetest noch ausstehend.
