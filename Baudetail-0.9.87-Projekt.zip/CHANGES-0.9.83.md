# BauDetail 0.9.83 – Leistenstein-Kontur neu aufgebaut

- Einheitliche vierpunktige Kontur für Darstellung, Snapping und Bearbeitung.
- Vier unabhängig ziehbare Eckpunkte statt zwei Unterkanten-Griffe.
- Keine zweite rechteckige Innenfüllung, die über Schrägschnitte hinausragt.
- Stoßfugen enden exakt an den interpolierten Außenkanten.
- Numerische Schrägschnitt-Einstellungen aktualisieren alle vier Eckpunkte.
- Drehung, Längen- und Stückzahlberechnung unverändert.

Nicht auf einem Android-Gerät getestet; Build über GitHub Actions erforderlich.
