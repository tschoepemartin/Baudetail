# BauDetail 0.9.86

- Leistenstein-Stoßfugen bleiben beim Anpassen schräger Endzuschnitte senkrecht zur lokalen Längsachse.
- Innenfugen werden anhand fester x-Positionen berechnet und an den tatsächlichen Längskanten begrenzt, nicht zwischen schrägen Stirnkanten interpoliert.
- Keine Änderung an der universellen X/Y-Fanglogik.
