# BauDetail 0.9.57 – experimentelle RenderNode-Optimierung

- Unveränderte Szene wird in einem Android-Hardware-Display-List-Cache aufgezeichnet.
- Beim Verschieben innerhalb des Overscan-Bereichs werden vorhandene Vektor-Zeichenbefehle wiederverwendet.
- Bei Zoom, Drehung, Dokumentänderung oder Überschreiten des Bereichs erfolgt eine Neuaufzeichnung.
- Interaktions-Overlays, Snapping, PDF-Export und Geometrie bleiben auf dem bisherigen Renderweg.
- Bei aktivierter Performance-Diagnose wird der ursprüngliche Renderweg verwendet.

**Status:** experimentell; Geräteperformance und Darstellung müssen verglichen werden.
