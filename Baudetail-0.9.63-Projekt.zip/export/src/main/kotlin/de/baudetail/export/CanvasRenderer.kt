package de.baudetail.export

import android.graphics.*
import com.caverock.androidsvg.SVG
import de.baudetail.core.*
import de.baudetail.geometry.*
import java.io.File

class CanvasRenderer(private val asset:(String)->File, private val interactive:Boolean=false) {
 private val bitmaps=object:android.util.LruCache<String,Bitmap>(if(interactive) 64*1024*1024 else 32*1024*1024){override fun sizeOf(key:String,value:Bitmap)=value.allocationByteCount}
 private val vectors=android.util.LruCache<String,SVG>(64)
 // Cached reduced resolutions prevent aliasing and moire at distant zooms.
 private val mipmaps=object:android.util.LruCache<String,Bitmap>(16*1024*1024){override fun sizeOf(key:String,value:Bitmap)=value.allocationByteCount}
 private fun color(s:String)=runCatching{Color.parseColor(s)}.getOrDefault(Color.DKGRAY)
 // Screen-only caches: PDF/print continues through the uncached reference path.
 // Keys contain every input; stored point keys are snapshots, so even a caller
 // mutating a List cannot make an old native Path masquerade as new geometry.
 // Identity fast path: Scene primitives are immutable between drawing revisions.
 // Avoid hashing every vertex on every frame for the same retained point list.
 private class IdentityPathKey(val points:List<Vec>,val closed:Boolean) {
  override fun hashCode():Int=31*System.identityHashCode(points)+if(closed)1 else 0
  override fun equals(other:Any?):Boolean=other is IdentityPathKey && points===other.points && closed==other.closed
 }
 private val identityPaths=object:android.util.LruCache<IdentityPathKey,PreparedPath>(131072) {
  override fun sizeOf(key:IdentityPathKey,value:PreparedPath)=key.points.size+24
 }
 private data class PreparedPath(val geometry:Path,val bounds:RectF)
 // Interactive scene geometry is retained by Scene.drawing. Identity lookup is O(1)
 // and avoids repeatedly hashing/comparing every vertex on camera-only redraws.
 // Export continues to create independent paths through the noninteractive branch.
 // Repeated textures previously allocated a BitmapShader, Matrix and Paint on EVERY frame.
 private data class TileKey(val source:String,val sample:Int,val tile:Float,val x:Float,val y:Float,val alpha:Int)
 private val tiles=android.util.LruCache<TileKey,Paint>(256)
 private data class PaintKey(val style:Style,val fill:Boolean)
 private val paints=android.util.LruCache<PaintKey,Paint>(512)
 private data class TextKey(val value:String,val size:Double,val style:Style)
 private data class PreparedText(val pen:Paint,val lines:List<String>,val width:Float)
 private val texts=object:android.util.LruCache<TextKey,PreparedText>(262144) {
  override fun sizeOf(key:TextKey,value:PreparedText)=key.value.length+128
 }
 // Cached pens are read-only. Text setup must use its own pen.
 private fun paint(style:Style,fill:Boolean=false):Paint {
  if(!interactive)return newPaint(style,fill)
  val key=PaintKey(style,fill)
  return paints[key]?:newPaint(style,fill).also{paints.put(key,it)}
 }
 private fun newPaint(style:Style,fill:Boolean=false)=Paint(Paint.ANTI_ALIAS_FLAG).apply {
  this.style=if(fill) Paint.Style.FILL else Paint.Style.STROKE
  color=color(if(fill)style.fill?:style.stroke else style.stroke);alpha=(style.opacity*255).toInt();strokeWidth=style.widthMm.toFloat();strokeJoin=Paint.Join.ROUND;strokeCap=if(style.align=="cut-butt")Paint.Cap.BUTT else Paint.Cap.ROUND
  if(style.dashed&&!fill)pathEffect=DashPathEffect(floatArrayOf(strokeWidth*7,strokeWidth*5),0f)
 }
 private fun preparedPath(points:List<Vec>,closed:Boolean):PreparedPath {
  if(!interactive)return createPreparedPath(points,closed)
  val key=IdentityPathKey(points,closed)
  return identityPaths[key]?:createPreparedPath(points,closed).also { prepared ->
   if(points.size<=131048)identityPaths.put(key,prepared)
  }
 }
 private fun createPreparedPath(points:List<Vec>,closed:Boolean):PreparedPath {
  val geometry=newPath(points,closed)
  val bounds=RectF()
  geometry.computeBounds(bounds,true)
  return PreparedPath(geometry,bounds)
 }
 private fun path(points:List<Vec>,closed:Boolean)=preparedPath(points,closed).geometry
 private fun newPath(points:List<Vec>,closed:Boolean)=Path().apply {
  points.firstOrNull()?.let{moveTo(it.x.toFloat(),it.y.toFloat())}
  for(i in 1 until points.size){val point=points[i];lineTo(point.x.toFloat(),point.y.toFloat())}
  if(closed)close()
 }
 private fun prepareText(n:Primitive.Text):PreparedText {
  val key=TextKey(n.value,n.size,n.style)
  if(interactive)texts[key]?.let{return it}
  val pen=newPaint(n.style,true).apply {color=color(n.style.stroke);textSize=n.size.toFloat();typeface=Typeface.create(Typeface.SANS_SERIF,if(n.style.bold&&n.style.italic)Typeface.BOLD_ITALIC else if(n.style.bold)Typeface.BOLD else if(n.style.italic)Typeface.ITALIC else Typeface.NORMAL);textAlign=when(n.style.align){"center"->Paint.Align.CENTER;"right"->Paint.Align.RIGHT;else->Paint.Align.LEFT}}
  val lines=n.value.lines()
  return PreparedText(pen,lines,lines.maxOfOrNull{pen.measureText(it)}?:0f).also{if(interactive && n.value.length<=262016)texts.put(key,it)}
 }
 fun draw(canvas:Canvas,nodes:List<Primitive>,uprightAngle:Float=0f, measure:((String,Long)->Unit)?=null) {nodes.forEach {n->
  val started=if(measure!=null)System.nanoTime() else 0L
  when(n) {
  is Primitive.Group -> {
   // A group clip is in parent coordinates. Reject its entire subtree before
   // descending into thousands of stones/paths when the area is off screen.
   val clip=n.clip
   if(interactive && clip!=null && clip.isNotEmpty() && canvas.quickReject(preparedPath(clip,true).bounds)) {
    // No canvas state has been changed, so there is nothing to restore.
   } else {
    canvas.save()
    clip?.let {canvas.clipPath(path(it,true))}
    canvas.translate(n.translate.x.toFloat(),n.translate.y.toFloat())
    canvas.rotate(n.angle.toFloat())
    canvas.scale(n.scale.toFloat(),n.scale.toFloat()*(if(n.mirrorY)-1f else 1f))
    draw(canvas,n.nodes,uprightAngle,measure)
    canvas.restore()
   }
  }
  is Primitive.Path -> {
   val prepared=preparedPath(n.points,n.closed);val p=prepared.geometry
   // Reject geometry completely outside the current screen clip. This keeps
   // full-quality drawing and the exact same geometry for visible objects.
   val bounds=RectF(prepared.bounds)
   val margin=n.style.widthMm.toFloat().coerceAtLeast(1f)*0.5f+1f
   bounds.inset(-margin,-margin)
   if(!interactive || !canvas.quickReject(bounds)) {
    if(n.closed&&n.style.fill!=null)canvas.drawPath(p,paint(n.style,true))
    canvas.drawPath(p,paint(n.style))
   }
  }
  is Primitive.Circle -> {
   val x=n.center.x.toFloat();val y=n.center.y.toFloat();val radius=n.radius.toFloat()
   val margin=n.style.widthMm.toFloat().coerceAtLeast(1f)*0.5f+1f
   if(!interactive || !canvas.quickReject(RectF(x-radius-margin,y-radius-margin,x+radius+margin,y+radius+margin))) {
    if(n.style.fill!=null)canvas.drawCircle(x,y,radius,paint(n.style,true))
    canvas.drawCircle(x,y,radius,paint(n.style))
   }
  }
  is Primitive.Text -> {
   // Conservative pre-cull before measuring glyphs, creating paints or rotating the canvas.
   // Covers rotated labels as well; only far-offscreen text is rejected.
   if(interactive) {
    val x=n.at.x.toFloat();val y=n.at.y.toFloat()
    val extent=(n.size.toFloat().coerceAtLeast(1f)*(n.value.length.coerceAtLeast(1)+n.value.count{it=='\n'}+4)).coerceAtMost(1e8f)
    if(canvas.quickReject(RectF(x-extent,y-extent,x+extent,y+extent)))return@forEach
   }
   val prepared=prepareText(n);val pen=prepared.pen
   canvas.save();canvas.rotate(n.angle.toFloat()-uprightAngle,n.at.x.toFloat(),n.at.y.toFloat());val lines=prepared.lines;val w=prepared.width
   val x=n.at.x.toFloat();val y=n.at.y.toFloat();val left=x-when(pen.textAlign){Paint.Align.CENTER->w/2;Paint.Align.RIGHT->w;else->0f}
   val box=RectF(left-n.size.toFloat()/3,y-n.size.toFloat(),left+w+n.size.toFloat()/3,y+(lines.size-1)*n.size.toFloat()*1.35f+n.size.toFloat()/3)
   if(!interactive || !canvas.quickReject(box)){
    n.style.background?.let {canvas.drawRect(box,Paint().apply{color=color(it)})};if(n.style.frame)canvas.drawRect(box,paint(n.style))
    lines.forEachIndexed {i,line->canvas.drawText(line,x,y+i*n.size.toFloat()*1.35f,pen)}
   };canvas.restore()
  }
  is Primitive.Asset -> {
   canvas.save();canvas.translate(n.at.x.toFloat(),n.at.y.toFloat());canvas.rotate(n.angle.toFloat());val rect=RectF(0f,0f,n.width.toFloat(),n.height.toFloat())
   // Skip off-screen tiles before disk access or decoding. Canvas carries the viewport clip.
   if(interactive && canvas.quickReject(rect)) { canvas.restore();return@forEach }
   runCatching {
    val repeated=n.path.startsWith("repeat:")
    val repeatSpec=if(repeated)n.path.removePrefix("repeat:").split(":",limit=2)else emptyList()
    val tileMm=if(repeated)repeatSpec.firstOrNull()?.toFloatOrNull()?.coerceAtLeast(20f)?:350f else 0f
    val sourcePath=if(repeated)repeatSpec.getOrNull(1)?:"" else n.path
    val cachedVector=if(!repeated)vectors[n.path] else null
    val cachedBitmap=bitmaps[sourcePath]
    val f=if(cachedVector==null && cachedBitmap==null)asset(sourcePath) else null
    if(f!=null)require(f.isFile){"Datei fehlt"}
    if(!repeated && (cachedVector!=null || (f?.extension?.lowercase()=="svg"))) {
     val svg=cachedVector?:SVG.getFromString(sanitizeSvg(requireNotNull(f).readText())).also{vectors.put(n.path,it)}
     val layer=canvas.saveLayerAlpha(rect,(n.opacity*255).toInt());svg.renderToCanvas(canvas,rect);canvas.restoreToCount(layer)
    } else {
     val bmp=cachedBitmap?:run {
      // Screen preview needs fewer source pixels than print/PDF. Decode once,
      // retain in an LRU; never decode full-res tiles during every gesture.
      val opts=BitmapFactory.Options().apply {
       inPreferredConfig=Bitmap.Config.RGB_565
       if(interactive && n.path.startsWith("grass-textures/")) inSampleSize=2
      }
      BitmapFactory.decodeFile(requireNotNull(f).path,opts)?.also{bitmaps.put(sourcePath,it)}
     }?:error("Bild nicht lesbar")
     if(repeated){
      // One draw call irrespective of area size. Filtered mip levels are
      // reused while pinch-zooming; no bitmap creation in the hot path.
      val matrix=Matrix();canvas.getMatrix(matrix)
      val values=FloatArray(9);matrix.getValues(values)
      val pxPerMm=kotlin.math.hypot(values[Matrix.MSCALE_X].toDouble(),values[Matrix.MSKEW_Y].toDouble()).coerceAtLeast(0.00001)
      val desired=(tileMm*pxPerMm).toInt().coerceAtLeast(1)
      val downsample=if(!interactive)1 else {
       var sample=1
       while(bmp.width/sample>desired*2 && sample<64)sample*=2
       sample
      }
      val image=if(downsample==1)bmp else {
       val key="$sourcePath#$downsample"
       mipmaps[key]?:Bitmap.createScaledBitmap(bmp,(bmp.width/downsample).coerceAtLeast(1),(bmp.height/downsample).coerceAtLeast(1),true).also{mipmaps.put(key,it)}
      }
      val alpha=(n.opacity*255).toInt()
      val key=TileKey(sourcePath,downsample,tileMm,n.at.x.toFloat(),n.at.y.toFloat(),alpha)
      val tilePaint=if(interactive)tiles[key] else null
      val pen=tilePaint?:run {
       val shader=BitmapShader(image,Shader.TileMode.REPEAT,Shader.TileMode.REPEAT)
       val transform=Matrix().apply{setScale(tileMm/image.width,tileMm/image.height);postTranslate(-n.at.x.toFloat(),-n.at.y.toFloat())}
       shader.setLocalMatrix(transform)
       Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply{this.alpha=alpha;this.shader=shader}.also{if(interactive)tiles.put(key,it)}
      }
      canvas.drawRect(rect,pen)
     }else canvas.drawBitmap(bmp,null,rect,Paint(Paint.ANTI_ALIAS_FLAG).apply{alpha=(n.opacity*255).toInt();isFilterBitmap=true})
    }
   }.onFailure {canvas.drawRect(rect,Paint().apply{color=Color.LTGRAY});canvas.drawText("Ressource fehlt / ungültig",8f,24f,Paint().apply{color=Color.RED;textSize=16f})}
   canvas.restore()
  }
  }
  if(measure!=null){
   val category=when(n){
    is Primitive.Path->"path";is Primitive.Circle->"circle";is Primitive.Text->"text"
    is Primitive.Asset->"asset";is Primitive.Group->"group";else->"other"
   }
   measure(category,System.nanoTime()-started)
  }
 }}
}
/** Declarative SVG only: block active content and external resources before AndroidSVG/XML parsing. */
fun sanitizeSvg(source:String):String {
 require(source.length<=8*1024*1024){"SVG zu groß"}
 require(!Regex("<!DOCTYPE|<!ENTITY|<script|<foreignObject|<image|\\son[a-z]+\\s*=|@import|url\\(\\s*['\"]?(?!#)",RegexOption.IGNORE_CASE).containsMatchIn(source)){"SVG enthält nicht unterstützte aktive oder externe Inhalte"}
 require(!Regex("(?:href|src)\\s*=\\s*['\"](?!#)",RegexOption.IGNORE_CASE).containsMatchIn(source)){"Externe SVG-Verweise sind nicht erlaubt"}
 require(source.contains("<svg",true)){"Keine SVG-Datei"};return source
}
