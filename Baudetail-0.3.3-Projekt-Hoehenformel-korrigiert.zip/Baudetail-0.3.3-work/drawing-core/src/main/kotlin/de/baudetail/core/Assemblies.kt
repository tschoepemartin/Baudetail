package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

fun Drawing.viewMode()=(extensions["viewMode"] as? JsonPrimitive)?.contentOrNull ?: if(type=="Schnitt")"section"else"top"
fun Drawing.withViewMode(mode:String)=copy(extensions=JsonObject(extensions+("viewMode" to JsonPrimitive(mode))+(if(mode=="top"&&profile()=="Schnitt")mapOf("viewProfile" to JsonPrimitive("Oberflächenplan"))else emptyMap())))
fun LibraryEntry.isStairStep():Boolean = (attributes["assembly_role"] as? JsonPrimitive)?.contentOrNull=="stair_step" || (type in setOf("component","step") && (category+"/"+name).lowercase().let{"stuf" in it||"step" in it})
fun isStair(e:Entity)=e.kind=="assembly"&&e.str("assemblyType")=="stair"
fun stairCount(e:Entity)=e.num("stepCount",5.0).toInt().coerceIn(1,100)
fun stairRise(e:Entity)=if(e.str("heightMode")=="total") {
 val count=stairCount(e); val drop=stairSlopeDrop(e)
 // Hgesamt = (Stufenhoehe + Auftritt * Gefaelle/100) * Anzahl
 // => Stufenhoehe = Hgesamt/Anzahl - Gefaelleanteil je Stufe
 e.num("totalHeightMm",750.0)/count-drop
} else e.num("riseMm",150.0)
fun stairGoing(e:Entity)=if(e.str("lengthMode")=="total")if(stairCount(e)>1)(e.num("totalLengthMm",1800.0)-stairDepth(e))/(stairCount(e)-1)else stairDepth(e)else e.num("goingMm",350.0)
fun stairSlopeDrop(e:Entity)=stairGoing(e)*e.num("slope")/100.0
fun stairEffectiveRise(e:Entity)=stairRise(e)+stairSlopeDrop(e)
fun stairTotalHeight(e:Entity):Double {
 val count=stairCount(e)
 // Reale Treppenhoehe: pro Stufe kommt zur Stufenhoehe der Hoehenanteil
 // aus dem Laengsgefaelle des Auftritts hinzu.
 return count*(stairRise(e)+stairSlopeDrop(e))
}
fun stairLocalPoints(e:Entity,view:String):List<Vec> {
 val count=stairCount(e);val rise=stairRise(e);val going=stairGoing(e);val width=e.num("widthMm",1200.0);val effectiveRise=stairEffectiveRise(e);val drop=stairSlopeDrop(e)
 return if(view=="section") (0 until count).flatMap{i->val baseY=-i*effectiveRise;listOf(Vec(i*going,baseY),Vec(i*going,baseY-rise),Vec((i+1)*going,baseY-rise-drop))}
 else ((0 until count).map{it*going}+stairLength(e)).flatMap{x->listOf(Vec(x,0.0),Vec(x,width))}
}
fun assemblyPoint(e:Entity,point:Vec):Vec {
 val local=Vec(point.x,if(e.num("mirrored")==1.0)-point.y else point.y)
 return local.rotate(e.rotation)+(e.points.firstOrNull()?:Vec())
}
fun stairReferencePoints(e:Entity,view:String)=stairLocalPoints(e,view).map{assemblyPoint(e,it)}
fun stairSteps(e:Entity,d:Drawing,p:Project):List<Entity> {
 val base=e.children.firstOrNull()?:p.libraryEntries.find{it.id==e.libraryId}?.let{componentInstance(it,Vec())}?:return emptyList()
 val rise=stairRise(e);val effectiveRise=stairEffectiveRise(e);val going=stairGoing(e);val depth=stairDepth(e)
 require(going>0&&going<=depth){"Auftritt muss positiv und höchstens so groß wie die Stufentiefe sein"}
 return (0 until stairCount(e)).map{i->
  val local=if(d.viewMode()=="section")Vec(i*going,-(i+1)*effectiveRise+e.num("widthMm",1000.0)*e.num("crossSlope")/200)else Vec(i*going,0.0)
  base.copy(id="${e.id}-step-$i",points=listOf(assemblyPoint(e,local)),layerId=e.layerId,placement=e.placement,rotation=e.rotation)
   .withNum("depthMm",depth).withNum("widthMm",depth).withNum("stairWidthMm",e.num("widthMm",1000.0))
   .withNum("mirrored",e.num("mirrored")).withNum("slope",e.num("slope")).withNum("crossSlope",e.num("crossSlope"))
 }
}

/** Associates an already snapped point with its source geometry. */
fun anchorAt(point:Vec,d:Drawing):Anchor? {
 for(e in d.entities.filter{visibleIn(it,d)}){
  if(isStair(e)&&assemblyPoint(e,Vec(stairLength(e),0.0)).distance(point)<1e-5)return Anchor(e.id,reference="stairEnd",view=d.viewMode())
  if(e.kind=="component"){val i=componentReferencePoints(e,d).indexOfFirst{it.distance(point)<1e-5};if(i>=0)return Anchor(e.id,i,"component",d.viewMode())}
  if(e.kind=="circle"){val v=point-(e.points.firstOrNull()?:Vec());if(abs(v.length()-e.num("radiusMm"))<1e-5)return Anchor(e.id,reference="circleEdge",fraction=atan2(v.y,v.x))}

  val pts=if(isStair(e))stairReferencePoints(e,d.viewMode())else resolvedPoints(e,d)
  val i=pts.indexOfFirst{it.distance(point)<1e-5}
  if(i>=0)return Anchor(e.id,i,if(isStair(e))"stair"else"",d.viewMode())
 }
 val edges=mutableListOf<Anchor>()
 for(e in d.entities.filter{it.kind in setOf("line","polyline","polygon","rect","building","area")}){
  val pts=e.points;val count=if(e.kind in setOf("polygon","rect","building","area"))pts.size else (pts.size-1).coerceAtLeast(0)
  for(i in 0 until count){val a=pts[i];val b=pts[(i+1)%pts.size];val len=a.distance(b)
   if(len>1e-9 && closestOnSegment(point,a,b).distance(point)<1e-5)edges.add(Anchor(e.id,i,"edge",fraction=a.distance(point)/len))
  }
 }
 val first=edges.firstOrNull()?:return null
 val second=edges.drop(1).firstOrNull{it.entityId!=first.entityId}
 return if(second!=null)first.copy(reference="intersection",otherEntityId=second.entityId,otherVertex=second.vertex)else first
}
