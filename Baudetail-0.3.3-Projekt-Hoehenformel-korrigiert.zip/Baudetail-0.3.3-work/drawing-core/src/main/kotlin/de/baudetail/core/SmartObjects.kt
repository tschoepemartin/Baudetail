package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*

/** Shared semantic family used for intelligent component replacement/rendering. */
fun LibraryEntry.smartFamily():String {
 val explicit=(attributes["component_family"] as? JsonPrimitive)?.contentOrNull.orEmpty()
 if(explicit.isNotBlank()) return explicit
 val key=(category+"/"+name).lowercase()
 return when {
  "rohre/" in key || "rohr" in key || "leitung" in key -> "pipe"
  "mauerbau" in key && ("l-stein" in key || "winkel" in key || "mauerscheib" in key) -> "retaining_wall"
  "einfassungen/borde" in key || "bord " in key -> "curb"
  "rinne" in key -> "channel"
  "rasen" in key -> "grass"
  else -> "component"
 }
}

fun Entity.smartFamily():String = str("componentFamily").ifBlank {
 when {
  isStair(this) -> "stair"
  else -> "component"
 }
}

fun LibraryEntry.attrNumber(vararg keys:String, default:Double=0.0):Double {
 for(key in keys) {
  val p=attributes[key] as? JsonPrimitive ?: continue
  p.doubleOrNull?.let { if(it.isFinite()) return it }
 }
 return default
}

fun LibraryEntry.variantGroup():String = (attributes["variant_group"] as? JsonPrimitive)?.contentOrNull
 ?: when(smartFamily()) {
  "pipe" -> category
  "curb" -> category
  "retaining_wall" -> "Mauerbau/Mauerscheiben"
  "channel" -> category
  "grass" -> category
  else -> category
 }

/** Swap a placed smart component to another compatible library entry while preserving its anchor/OK and editing state. */
fun replaceComponentVariant(old:Entity,entry:LibraryEntry):Entity {
 require(old.kind=="component") { "Nur Bauteile können typgleich ersetzt werden" }
 require(old.smartFamily()==entry.smartFamily() || old.smartFamily()=="component") { "Bauteil gehört zu einer anderen Kategorie" }
 val at=old.points.firstOrNull()?:Vec()
 val fresh=componentInstance(entry,at)
 val keepKeys=setOf("orientation","verticalDirection","verticalLengthMm","labelEnabled","labelMode","labelText","labelDx","labelDy","fillMode","fillTop","fillSection")
 val merged=fresh.params.toMutableMap()
 old.params.forEach { (k,v) -> if(k in keepKeys) merged[k]=v }
 return fresh.copy(
  id=old.id, layerId=old.layerId, status=old.status, rotation=old.rotation,
  locked=old.locked, groupId=old.groupId, placement=old.placement,
  style=old.style, materialId=old.materialId, materialSnapshot=old.materialSnapshot,
  quantityUnit=old.quantityUnit, extensions=old.extensions,
  params=JsonObject(merged)
 )
}

fun smartPivot(e:Entity):Vec = if((e.kind=="component" || isStair(e)) && e.points.isNotEmpty()) e.points.first() else entityBounds(e).center

fun retainingWallSection(e:Entity):List<Vec> {
 val h=e.num("wallHeightMm",e.num("sectionHeightMm",800.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("sectionWidthMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val slab=e.num("footThicknessMm",100.0).coerceIn(1.0,h)
 val side=e.str("footSide","right")
 val pts=if(side=="left") listOf(Vec(foot,0.0),Vec(foot-wall,0.0),Vec(foot-wall,h-slab),Vec(0.0,h-slab),Vec(0.0,h),Vec(foot,h))
 else listOf(Vec(0.0,0.0),Vec(wall,0.0),Vec(wall,h-slab),Vec(foot,h-slab),Vec(foot,h),Vec(0.0,h))
 return pts
}

fun retainingWallTop(e:Entity):Pair<List<Vec>,List<Vec>> {
 val length=e.num("elementLengthMm",e.num("topWidthMm",1000.0)).coerceAtLeast(1.0)
 val foot=e.num("footDepthMm",e.num("topHeightMm",400.0)).coerceAtLeast(1.0)
 val wall=e.num("wallThicknessMm",70.0).coerceIn(1.0,foot)
 val wallRect=rectangle(Vec(),Vec(length,wall))
 val footRect=rectangle(Vec(),Vec(length,foot))
 return wallRect to footRect
}

fun isPipe(e:Entity)=e.kind=="component"&&e.smartFamily()=="pipe"
fun isRetainingWall(e:Entity)=e.kind=="component"&&e.smartFamily()=="retaining_wall"
