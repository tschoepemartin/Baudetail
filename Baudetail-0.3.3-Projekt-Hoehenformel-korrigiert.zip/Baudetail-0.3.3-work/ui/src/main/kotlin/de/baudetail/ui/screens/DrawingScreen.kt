package de.baudetail.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import de.baudetail.ui.drawing.*
import de.baudetail.ui.panels.*
import de.baudetail.ui.toolbars.*
import kotlinx.serialization.json.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DrawingScreen(vm:BaudetailViewModel,onBack:()->Unit,onLibrary:()->Unit,onExport:()->Unit,onBackground:()->Unit){
 val d=vm.drawing;val project=vm.project
 if(d==null||project==null){Page("Zeichnung",onBack){Text("Keine Zeichnung geöffnet.")};return}
 var points by remember(d.id){mutableStateOf<List<Vec>>(emptyList())}
 val input=d.input();val grid=input.gridVisible;val snapOn=input.snapEnabled;val ortho=input.ortho;val angleStep=input.angleStep
 var penMode by remember{mutableStateOf(false)}
 var topMenu by remember{mutableStateOf(false)}
 var toolPanel by remember{mutableStateOf(true)};var propertyPanel by remember{mutableStateOf(false)};var dialog by remember{mutableStateOf("")};var coordinate by remember{mutableStateOf(Vec())};var zoom by remember{mutableDoubleStateOf(.06)};var fit by remember{mutableIntStateOf(0)};var measurePoints by remember{mutableStateOf<List<Vec>>(emptyList())};var calibrating by remember{mutableStateOf<String?>(null)};var multi by remember{mutableStateOf(false)}
 val shapeTools=setOf("polygon","area","building","polyline","hedge","dimension-chain","measure-area")
 fun complete(ps:List<Vec> = points){
  val tool=vm.tool
  if(ps.isEmpty())return
  fun params(vararg pairs:Pair<String,Double>)=buildJsonObject{pairs.forEach{put(it.first,it.second)}}
  val a=ps.first();val b=ps.getOrElse(1){a+Vec(1000.0,500.0)}
  val e=when(tool){
   "rect"->Entity(kind="rect",points=rectangle(a,b))
   "circle"->Entity(kind="circle",points=listOf(a,b),params=params("radiusMm" to a.distance(b)))
   "arc"->Entity(kind="arc",points=listOf(a,b),params=params("radiusMm" to a.distance(b),"startAngle" to Math.toDegrees(atan2(b.y-a.y,b.x-a.x)),"sweepAngle" to 90.0))
   "area"->Entity(kind="area",points=ps,style=Style(fill="#DCE8C9"),name="Pflanzfläche",quantityUnit="m²",params=buildJsonObject{put("plantName","");put("spacingMm",300);put("depthMm",200)})
   "building"->Entity(kind="building",points=ps,style=Style(fill="#DFE1DD",widthMm=.5),name="Gebäudeumriss")
   "slope"->Entity(kind="slope",points=ps,params=buildJsonObject{put("mode","manual");put("percent",2.0);put("startHeightMm",0);put("endHeightMm",-100);put("unit","%")})
   "dimension","dimension-chain","dimension-angle"->{val anchors=ps.mapNotNull{point->anchorAt(point,d)};Entity(kind="dimension",points=ps,anchors=if(anchors.size==ps.size)anchors else emptyList(),params=buildJsonObject{put("mode",when(tool){"dimension-chain"->"chain";"dimension-angle"->"angle";else->"aligned"});put("unit","cm");put("offsetMm",8*d.sheet.scale)})}
   "hedge"->Entity(kind="hedge",points=ps,name="Hecke",quantityUnit="Stk",params=params("spacingMm" to 400.0,"widthMm" to 600.0,"plantHeightMm" to 1500.0),style=Style(stroke="#47774A",fill="#BBD2AD"))
   "guide"->Entity(kind="guide",points=ps,layerId=d.layers.find{it.name=="Hilfslinien"}?.id?:"planning",style=Style(stroke="#A9B6C0",dashed=true))
   "leader"->Entity(kind="leader",points=ps,text="Hinweis")
   else->Entity(kind=tool,points=ps)
  }
  if(tool=="section")vm.addSection(ps,('A'.code+d.entities.count{it.kind=="section"}).toChar().let{"$it–$it"})
  else if(tool=="measure"||tool=="measure-area"){measurePoints=ps;dialog="measure"}
  else vm.add(e)
  points=emptyList()
 }
 fun tap(raw:Vec,long:Boolean=false,exact:Boolean=false){
  coordinate=raw
  if(calibrating!=null){points=points+raw;if(points.size==2)dialog="calibrate";return}
  if(vm.tool=="select"){
   val hit=d.entities.lastOrNull{e->d.layers.find{it.id==e.layerId}?.visible!=false&&visibleIn(e,d)&&hitTest(raw,e,d,18/zoom)}
   if(hit!=null){val target=hit.targetDrawingId;if(hit.kind=="section"&&target!=null&&!long&&!multi){vm.openDrawing(target);return};val ids=if(hit.groupId!=null)d.entities.filter{it.groupId==hit.groupId}.map{it.id}.toSet()else setOf(hit.id);vm.selected=if(long||multi){if(hit.id in vm.selected)vm.selected-ids else vm.selected+ids}else ids}
   else if(!multi)vm.selected=emptySet()
   return
  }
  val point=if(exact)raw else snap(raw,d,input.options(18/zoom),points.lastOrNull()).point
  when(vm.tool){
   "library"->vm.placeEntry(point)
   "origin"->vm.edit(d.copy(origin=point))
   "text"->{points=listOf(point);dialog="text"}
   "elevation"->{vm.add(Entity(kind="elevation",points=listOf(point),params=buildJsonObject{put("heightMm",0);put("mode","relative")}));propertyPanel=true}
   "tree"->vm.add(Entity(kind="tree",points=listOf(point),name="Baum",quantityUnit="Stk",style=Style(stroke="#476A48",fill="#D0DFBB"),params=buildJsonObject{put("crownMm",2500);put("trunkMm",120);put("rootMm",0);put("pitMm",0);put("plantHeightMm",4000);put("trunkCircumferenceMm",180);put("rootBallMm",600);put("plantName","")}))
   "stack"->vm.add(Entity(kind="stack",points=listOf(point),name="Belagsaufbau",params=buildJsonObject{put("widthMm",1500)},strata=listOf(Stratum("paving","Pflaster",80.0,"#B6BBB7"),Stratum("grit","Bettung",40.0,"#E4DBC4"),Stratum("frost","Frostschutz",250.0,"#CBC3B4"))))
   "legend"->vm.add(Entity(kind="legend",points=listOf(point)))
   else->{if(vm.tool=="polyline"&&points.size>=3&&point.distance(points.first())<=18/zoom){complete(points+points.first());return};points=points+point;if(vm.tool !in shapeTools && points.size>=if(vm.tool=="dimension-angle")3 else 2)complete(points)}
  }
 }
 BackHandler(points.isNotEmpty()||calibrating!=null){points=emptyList();calibrating=null}
 Scaffold(topBar={TopAppBar(title={Column{Text(d.name,maxLines=1,style=MaterialTheme.typography.titleMedium);Text("${project.name} · ${if(vm.saving)"Speichert …"else"Lokal"}",maxLines=1,style=MaterialTheme.typography.labelSmall)}},navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Projektakte")}},actions={IconButton(onClick=vm::undo,enabled=vm.canUndo){Icon(Icons.Default.Undo,"Rückgängig")};IconButton(onClick=vm::redo,enabled=vm.canRedo){Icon(Icons.Default.Redo,"Wiederholen")};IconButton(onClick={propertyPanel=!propertyPanel}){Icon(Icons.Default.Tune,"Eigenschaften")};Box{IconButton(onClick={topMenu=true}){Icon(Icons.Default.MoreVert,"Zeichnungsmenü")};DropdownMenu(expanded=topMenu,onDismissRequest={topMenu=false}){DropdownMenuItem(text={Text("Speichern")},leadingIcon={Icon(Icons.Default.Save,null)},onClick={topMenu=false;vm.persist()});DropdownMenuItem(text={Text("Exportieren / Teilen")},leadingIcon={Icon(Icons.Default.IosShare,null)},onClick={topMenu=false;onExport()})}}})},bottomBar={Surface(tonalElevation=3.dp){Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(2.dp)){
  TextButton(onClick={dialog="sheet"}){Text("1:${fmt(d.sheet.scale)}")};FilterChip(grid,{dialog="grid"},label={Text("Raster ${if(grid)fmt(d.gridMm)+" mm"else"aus"}")});FilterChip(snapOn,{dialog="snap"},label={Text("Fang ${if(snapOn)fmt(input.snapMm)+" mm"else"aus"}")});FilterChip(ortho,{vm.edit(d.withInput(input.copy(ortho=!ortho)))},label={Text("Ortho")});TextButton(onClick={dialog="angle"}){Text("${fmt(angleStep)}°")};Text("mm · X ${fmt(coordinate.x-d.origin.x)} / Y ${fmt(coordinate.y-d.origin.y)}",Modifier.padding(12.dp));TextButton(onClick={fit++}){Text("Einpassen")}
 }}}){padding->BoxWithConstraints(Modifier.padding(padding).fillMaxSize()){
  val wide=maxWidth>=1000.dp
  Column {
   Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){
    IconButton(onClick={toolPanel=!toolPanel}){Icon(Icons.Default.Menu,"Werkzeuge")}
    TextButton(onClick=onLibrary){Text("Bibliothek")};TextButton(onClick={dialog="assemblies"}){Text("Bauwerke")};FilterChip(d.viewMode()=="section",{vm.edit(d.withViewMode(if(d.viewMode()=="section")"top"else"section"))},label={Text(if(d.viewMode()=="section")"Schnitt"else"Draufsicht")});TextButton(onClick={dialog="profile"}){Text(d.profile())};TextButton(onClick={dialog="layers"}){Text("Layer")};TextButton(onClick=onBackground){Text("Hintergrund")};TextButton(onClick={dialog="quantity"}){Text("Mengen")};TextButton(onClick={dialog="backups"}){Text("Sicherungen")};TextButton(onClick={dialog="objects"}){Text("Objekte")};TextButton(onClick={dialog="variant"}){Text("Variante")};TextButton(onClick={dialog="variables"}){Text("Variablen")};TextButton(onClick={dialog=if(vm.tool in dragShapeTools)"shapeNumeric"else"numeric"}){Text("Maße eingeben")};FilterChip(penMode,{penMode=!penMode},label={Text("Finger navigiert")});FilterChip(multi,{multi=!multi},label={Text("Mehrfachauswahl")});TextButton(onClick={vm.linkedSnap=!vm.linkedSnap}){Text(if(vm.linkedSnap)"Verknüpft fangen ✓"else"Verknüpft fangen")}
   }
   d.sourceDrawingId?.let{source->TextButton(onClick={vm.openDrawing(source)}){Text("← Zum Ausgangsplan")}}
   if(points.isNotEmpty()||calibrating!=null)Row(Modifier.padding(horizontal=8.dp)){
    Text(if(calibrating!=null)"Kalibrieren: zwei Punkte wählen"else"${points.size} Punkte · ${drawTools.find{it.id==vm.tool}?.label.orEmpty()}",Modifier.weight(1f).padding(top=12.dp))
    if(vm.tool in shapeTools)TextButton(onClick={complete()},enabled=points.size>=if(vm.tool in setOf("area","polygon","building","measure-area"))3 else 2){Text("Abschließen")};TextButton(onClick={points=emptyList();calibrating=null}){Text("Abbrechen")}
   }
   Row(Modifier.weight(1f)){
    if(toolPanel)Surface(Modifier.width(if(wide)112.dp else 80.dp),tonalElevation=1.dp){LazyColumn{items(drawTools.size){i->val t=drawTools[i];FilledTonalButton(onClick={points=emptyList();calibrating=null;vm.tool=t.id},modifier=Modifier.fillMaxWidth().padding(2.dp),contentPadding=PaddingValues(4.dp),colors=if(vm.tool==t.id)ButtonDefaults.filledTonalButtonColors(containerColor=MaterialTheme.colorScheme.primaryContainer)else ButtonDefaults.filledTonalButtonColors(containerColor=MaterialTheme.colorScheme.surface)){Column(horizontalAlignment=androidx.compose.ui.Alignment.CenterHorizontally){Icon(t.icon,t.label);Text(t.label,style=MaterialTheme.typography.labelSmall,maxLines=1)}}}}}
    DrawingCanvas(d,project,vm.store::assetFile,vm.tool,vm.selected,points,grid,penMode,fit,Modifier.weight(1f).fillMaxHeight(),onTap={v,long->tap(v,long)},onFreehand={vm.add(Entity(kind="polyline",points=it))},onMove={delta->vm.modifySelected{transform(it,translation=delta)}},onDeleteRequested={dialog="confirmDelete"},onCoordinates={point,z->coordinate=point;zoom=z},onCreate={vm.add(it);points=emptyList()},onChange=vm::update)
    if(wide&&propertyPanel)Surface(Modifier.width(310.dp).fillMaxHeight(),tonalElevation=2.dp){Inspector(vm){calibrating=vm.selected.firstOrNull();points=emptyList();propertyPanel=false}}
   }
  }
  if(!wide&&propertyPanel)ModalBottomSheet(onDismissRequest={propertyPanel=false}){Inspector(vm){calibrating=vm.selected.firstOrNull();points=emptyList();propertyPanel=false}}
 }}
 when(dialog){
  "confirmDelete"->AlertDialog(onDismissRequest={dialog=""},title={Text("Löschen?")},text={Text(if(vm.selected.size==1)"Ausgewähltes Objekt löschen?"else"${vm.selected.size} ausgewählte Objekte löschen?")},confirmButton={TextButton(onClick={vm.removeSelected();dialog=""}){Text("Löschen")}},dismissButton={TextButton(onClick={dialog=""}){Text("Abbrechen")}})
  "assemblies"->ChoiceDialog("Bauwerke",listOf("Treppe","Eigene Bauwerke"),{dialog=""}){dialog=if(it==0)"stair"else"ownAssemblies"}
  "ownAssemblies"->{val entries=vm.catalog.entries().filter{it.type=="assembly-template"};ChoiceDialog("Eigene Bauwerke",entries.map{it.name},{dialog=""}){vm.attachEntry(entries[it])}}
  "profile"->ChoiceDialog("Ansichtsprofil",viewProfiles,{dialog=""}){vm.edit(d.withProfile(viewProfiles[it]))}
  "stair"->StairDialog(vm.catalog.entries()+project.libraryEntries,Entity(kind="assembly",points=listOf(coordinate)),{dialog=""},vm::saveStair)
 "text"->FormDialog("Text platzieren",listOf(Field("text","Text / Variablen z. B. {projekt}")),{dialog="";points=emptyList()}){vm.add(Entity(kind="text",points=listOf(points.firstOrNull()?:coordinate),text=it["text"].orEmpty()))}
 "shapeNumeric"->{val circle=vm.tool in setOf("circle","arc");val line=vm.tool=="line"
 val fields=listOf(Field("x","Start X mm",fmt(points.firstOrNull()?.x?:coordinate.x),true),Field("y","Start Y mm",fmt(points.firstOrNull()?.y?:coordinate.y),true),Field("width",if(circle)"Radius mm"else if(line)"Länge mm"else"Breite mm","1000",true,true))+if(circle)emptyList()else if(line)listOf(Field("angle","Winkel Grad","0",true))else listOf(Field("height","Höhe / Tiefe mm","1000",true,true))
 FormDialog("${drawTools.find{it.id==vm.tool}?.label.orEmpty()} · genaue Maße",fields,{dialog=""}){v->val a=Vec(parseNumber(v.getValue("x"))!!,parseNumber(v.getValue("y"))!!);val w=parseNumber(v.getValue("width"))!!;val delta=if(circle)Vec(w,0.0)else if(line)Vec(w,0.0).rotate(parseNumber(v.getValue("angle"))!!)else Vec(w,parseNumber(v.getValue("height"))!!);vm.add(shapeFromDrag(vm.tool,a,a+delta));points=emptyList()}}
 "numeric"->FormDialog("Numerisch zeichnen",listOf(Field("x","X mm (relativ zum Nullpunkt)",fmt(coordinate.x-d.origin.x),true),Field("y","Y mm (relativ zum Nullpunkt)",fmt(coordinate.y-d.origin.y),true),Field("length","Länge ab letztem Punkt (0 = X/Y)","0",true),Field("angle","Winkel ab letztem Punkt in Grad","0",true)),{dialog=""}){v->val len=parseNumber(v["length"]!!)!!;val a=Math.toRadians(parseNumber(v["angle"]!!)!!);val point=if(len!=0.0&&points.isNotEmpty())points.last()+Vec(cos(a),sin(a))*len else Vec(parseNumber(v["x"]!!)!!,parseNumber(v["y"]!!)!!)+d.origin;tap(point,exact=true)}
 "sheet"->FormDialog("Papier und Maßstab",listOf(Field("scale","Maßstab 1:x",fmt(d.sheet.scale),true,true),Field("width","Papierbreite mm (A4 210/297, A3 297/420, A2 420/594)",fmt(d.sheet.widthMm),true,true),Field("height","Papierhöhe mm",fmt(d.sheet.heightMm),true,true),Field("x","Papierausschnitt Ursprung X mm",fmt(d.sheet.origin.x),true),Field("y","Papierausschnitt Ursprung Y mm",fmt(d.sheet.origin.y),true),Field("paper","Papierbereich anzeigen: ja / nein",if(d.sheet.showPaper)"ja"else"nein"),Field("grid","Rasterweite mm",fmt(d.gridMm),true,true),Field("datum","Bezugshöhe mm",fmt(d.elevationDatumMm),true),Field("template","Plankopfvorlage",d.sheet.titleTemplate)),{dialog=""}){v->fun n(k:String):Double { return parseNumber(v.getValue(k))!! }
vm.edit(d.copy(sheet=d.sheet.copy(scale=n("scale"),widthMm=n("width"),heightMm=n("height"),origin=Vec(n("x"),n("y")),showPaper=v["paper"]=="ja",titleTemplate=v["template"].orEmpty()),gridMm=n("grid"),elevationDatumMm=n("datum")))}
 "grid","snap"->SnapDialog(d,dialog=="grid",{dialog=""},vm::edit)
 "angle"->FormDialog("Winkelfang",listOf(Field("step","Schritt in Grad (0 = aus; z. B. 15, 30, 45)",fmt(angleStep),true)),{dialog=""}){val step=parseNumber(it.getValue("step"))!!;require(step in 0.0..180.0);vm.edit(d.withInput(input.copy(angleStep=step)))}
 "layers"->LayerDialog(vm){dialog=""}
 "objects"->ChoiceDialog("Objekt auswählen",d.entities.map{"${it.name.ifBlank{it.kind}} · ${it.id.take(6)}"},{dialog=""}){vm.selected=setOf(d.entities[it].id);propertyPanel=true}
 "quantity"->AlertDialog(onDismissRequest={dialog=""},title={Text("Mengen der Zeichnung")},text={Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState())){val rows=quantities(d,project.libraryEntries);if(rows.isEmpty())Text("Flächen, Hecken, Bäume und Bauteile platzieren oder Objekten eine Mengeneinheit zuweisen.");rows.forEach{Text("${it.label}: ${fmt(it.value)} ${it.unit}")}}},confirmButton={TextButton(onClick={dialog=""}){Text("Schließen")}})
 "backups"->ChoiceDialog("Automatische Sicherungen (${vm.backups().size}/10)",vm.backups().mapIndexed{i,b->"Sicherung ${i+1} · ${b.entities.size} Objekte"},{dialog=""}){vm.restoreBackup(it)}
 "variant"->FormDialog("Variante der Zeichnung",listOf(Field("name","Name",d.name+" · Variante B")),{dialog=""}){vm.addDrawing(it.getValue("name"),d.type,true)}
 "variables"->FormDialog("Freie Textvariable",listOf(Field("key","Variablenname ohne Klammern"),Field("value","Wert")),{dialog=""}){require(it["key"].orEmpty().isNotBlank());vm.edit(d.copy(variables=d.variables+(it.getValue("key") to it.getValue("value"))))}
 "calibrate"->FormDialog("Hintergrund kalibrieren",listOf(Field("distance","Reale Strecke mm","1000",true,true)),{dialog="";points=emptyList();calibrating=null}){v->val e=d.entities.find{it.id==calibrating}?:error("Hintergrund fehlt");vm.update(calibrate(e,points[0],points[1],parseNumber(v["distance"]!!)!!));fit++}
 "measure"->AlertDialog(onDismissRequest={dialog=""},title={Text("Temporäre Messung")},text={val a=measurePoints.firstOrNull()?:Vec();val b=measurePoints.lastOrNull()?:a;Text("Fläche: ${fmt(area(measurePoints)/1e6)} m²\nLänge: ${fmt(length(measurePoints))} mm\nHorizontal: ${fmt(abs(b.x-a.x))} mm\nVertikal: ${fmt(abs(b.y-a.y))} mm\nWinkel: ${fmt(Math.toDegrees(atan2(b.y-a.y,b.x-a.x)))}°")},confirmButton={TextButton(onClick={vm.add(Entity(kind="dimension",points=measurePoints));dialog=""}){Text("Als Bemaßung")}},dismissButton={TextButton(onClick={dialog=""}){Text("Schließen")}})
 }
}
@Composable fun LayerDialog(vm:BaudetailViewModel,onDismiss:()->Unit){val d=vm.drawing?:return;var new by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Layer")},text={Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())){d.layers.forEach{layer->Column{Text(layer.name);Row{Checkbox(layer.visible,{v->vm.edit(d.copy(layers=d.layers.map{if(it.id==layer.id)it.copy(visible=v)else it}))});Text("Sichtbar");Checkbox(layer.locked,{v->vm.edit(d.copy(layers=d.layers.map{if(it.id==layer.id)it.copy(locked=v)else it}))});Text("Gesperrt")};Row{Checkbox(layer.printable,{v->vm.edit(d.copy(layers=d.layers.map{if(it.id==layer.id)it.copy(printable=v)else it}))});Text("Drucken")};HorizontalDivider()}};OutlinedTextField(new,{new=it},label={Text("Neuer Layer")});TextButton(onClick={if(new.isNotBlank()){vm.edit(d.copy(layers=d.layers+Layer(name=new)));new=""}}){Text("Hinzufügen")}}},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})}
