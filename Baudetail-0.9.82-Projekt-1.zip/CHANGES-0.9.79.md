# BauDetail 0.9.79
- Objekt Winkel: kontinuierliche Fingerdrehung ohne Fang-Quantisierung, Anker bleibt fest.
- Numerisches Gradfeld im unteren Werkzeugbereich, positive/negative Dezimalwinkel, Drehung um gewählten Anker.
- Snap-Priorität: tatsächliche End- und Schnittpunkte vor freien Kantenpunkten innerhalb der Fangtoleranz.
- Android-Build noch nicht ausgeführt; GitHub Actions erforderlich.
