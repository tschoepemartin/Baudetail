# BauDetail 0.9.71
- Neues Werkzeug Objekt Winkel unter Objekt drehen.
- Fixierbare Anker links/rechts/oben/unten in der unteren Werkzeugleiste.
- Leistenstein-/Bordsteinreihen: Eckpunkte vertikal verziehen; fixierte Seiten bleiben unverändert.
- Die Schrägstellung wird als tatsächliche Geometrie einschließlich Steinfugen gerendert.
- Fangpunkte und Fangsegmente basieren auf der veränderten Kontur.
- Funktion derzeit nur für aktive Bordstein-Reihen in Draufsicht.
- Noch kein bestätigter Android-Build oder Gerätetest.
