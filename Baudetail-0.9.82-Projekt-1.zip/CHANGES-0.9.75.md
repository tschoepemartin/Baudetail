# 0.9.75

- Objekt Winkel: statt vertikaler Eckpunktverschiebung wird die gesamte Leistenstein-Reihe starr um den gewählten Endanker gedreht. Die echte Reihenlänge bleibt erhalten.
- Position und Winkel werden als Draufsicht-Transformation gespeichert; Darstellung, Stoßfugen, Hitbox und Snapkontur nutzen dieselbe Transformation.
- Schrägschnitte an den Enden bleiben eigenständige Konturänderungen.
- Hinweis: Bisher mit alter Winkelbearbeitung verformte Reihen können vor dem erneuten Ausrichten zurückgesetzt werden müssen.
- Android-Build nicht lokal ausgeführt.
