# BauDetail 0.9.78

- Compilerfehler in Operations.kt behoben: snapEdges ist jetzt im gesamten snap()-Funktionsbereich sichtbar.
- Keine beabsichtigten Funktionsänderungen gegenüber 0.9.77.
