# BauDetail 0.9.77
- Snap-Ergebnisse auf Kanten bekommen einen echten Edge-Anker; zuvor wurden diese beim Ziehen von Komponenten verworfen.
- Die rein achsorientierte Verschiebefunktion übersteuert nicht mehr die Komponenten-Snaplogik.
- Bei Polygonen können echte Eckpunkte auf beliebige schräge Segmente einrasten.
- Pflasterkanten werden in der Kantenprüfung aus ihrer tatsächlichen Kontur gewonnen.
- Leistenstein-Stoßfugen kontrastreicher gezeichnet.
- Stückzahl und Länge des letzten Passstücks live im Leistenstein-Menü.
- Android-Build und Gerätepraxistest ausstehend.
