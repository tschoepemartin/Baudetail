# 0.9.74
- Steinfugen nach dem Füllkörper rendern, damit sie nicht überdeckt werden.
- Snap-Kandidaten nach tatsächlicher Distanz priorisieren statt weiter entfernte Eckpunkte pauschal vorzuziehen.
- Längenbezug in der Reihen-Eingabe erläutert (mm, entlang Reihenachse).
