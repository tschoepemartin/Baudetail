# BauDetail 0.9.76

- Fangpunkte an Polygon-Ecken und Schnittpunkten innerhalb der Fangtoleranz priorisiert.
- Pflaster-Kontur als einheitliche Geometrie fuer Fanganker und gebundene Punkte.
- Grundstuecksgrenzen verwenden weiterhin ihre echten Polygonsegmente im zentralen Snap.

Nicht lokal kompiliert oder auf Android getestet.
