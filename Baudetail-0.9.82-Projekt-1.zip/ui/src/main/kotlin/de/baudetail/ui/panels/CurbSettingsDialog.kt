package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.parseNumber
import de.baudetail.ui.*
import kotlin.math.ceil

/** Separate curb editor: does not add bytecode to the main Inspector method. */
@Composable
internal fun CurbSettingsDialog(e:Entity,onDismiss:()->Unit,onSave:(Entity)->Unit){
 val row=e.str("curbRowEnabled","false")=="true"
 var enabled by remember(e.id){mutableStateOf(row)}
 var kind by remember(e.id){mutableStateOf(e.str("curbType",e.name))}
 var material by remember(e.id){mutableStateOf(e.str("curbMaterial","Beton"))}
 var length by remember(e.id){mutableStateOf(fmt(e.num("curbSingleLengthMm",if(row)e.num("topWidthMm",1000.0).coerceAtMost(1000.0) else e.num("topWidthMm",1000.0))))}
 var width by remember(e.id){mutableStateOf(fmt(e.num("topHeightMm",e.num("heightMm",100.0))))}
 var thickness by remember(e.id){mutableStateOf(fmt(e.num("sectionHeightMm",e.num("heightMm",200.0))))}
 var sectionWidth by remember(e.id){mutableStateOf(fmt(e.num("sectionWidthMm",e.num("widthMm",100.0))))}
 var chamfer by remember(e.id){mutableStateOf(e.str("withoutChamfer","false")!="true")}
 var chamferW by remember(e.id){mutableStateOf(fmt(e.num("chamferWidthMm",3.0)))}
 var chamferD by remember(e.id){mutableStateOf(fmt(e.num("chamferDepthMm",4.0)))}
 var total by remember(e.id){mutableStateOf(fmt(e.num("curbRowLengthMm",e.num("topWidthMm",1000.0))))}
 var startCut by remember(e.id){mutableStateOf(fmt(e.num("curbStartCutMm",0.0)))}
 var endCut by remember(e.id){mutableStateOf(fmt(e.num("curbEndCutMm",0.0)))}
 var startFixed by remember(e.id){mutableStateOf(e.str("curbStartFixedEdge","top"))}
 var endFixed by remember(e.id){mutableStateOf(e.str("curbEndFixedEdge","top"))}
 fun positive(v:String)=parseNumber(v)?.takeIf{it.isFinite()&&it>0.0}
 val valid=positive(length)!=null&&positive(width)!=null&&positive(thickness)!=null&&positive(sectionWidth)!=null&&(!enabled||((positive(total)?:0.0)>=(positive(length)?:Double.MAX_VALUE)))
 AlertDialog(onDismissRequest=onDismiss,title={Text("Bordstein / Leistenstein anpassen")},text={
  Column(Modifier.fillMaxWidth().heightIn(max=580.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
   OutlinedTextField(kind,{kind=it},label={Text("Steinart / Sorte")},singleLine=true)
   OutlinedTextField(material,{material=it},label={Text("Material")},singleLine=true)
   OutlinedTextField(length,{length=it},label={Text("Steinlänge (mm)")},singleLine=true)
   OutlinedTextField(width,{width=it},label={Text("Breite Draufsicht (mm)")},singleLine=true)
   OutlinedTextField(sectionWidth,{sectionWidth=it},label={Text("Breite Schnitt (mm)")},singleLine=true)
   OutlinedTextField(thickness,{thickness=it},label={Text("Höhe / Dicke Schnitt (mm)")},singleLine=true)
   Row{Checkbox(chamfer,{chamfer=it});Text("Mit Phase",Modifier.padding(top=12.dp))}
   OutlinedTextField(chamferW,{chamferW=it},label={Text("Fasenbreite (mm)")},enabled=chamfer,singleLine=true)
   OutlinedTextField(chamferD,{chamferD=it},label={Text("Fasentiefe (mm)")},enabled=chamfer,singleLine=true)
   HorizontalDivider()
   Row{Checkbox(enabled,{enabled=it});Text("Reihe aktivieren",Modifier.padding(top=12.dp))}
   OutlinedTextField(total,{total=it},label={Text("Gesamtlänge Reihe (mm)")},enabled=enabled,singleLine=true)
   if(enabled){
    val rowLength=positive(total)
    val stoneLength=positive(length)
    val count=if(rowLength!=null && stoneLength!=null)ceil(rowLength/stoneLength).toInt().coerceAtLeast(1) else 0
    Text("Stückzahl: ${if(count>0) "$count Stk." else "–"}")
    if(count>0 && rowLength!=null && stoneLength!=null){
     val last=rowLength-(count-1)*stoneLength
     Text("Letzter Stein: ${fmt(last)} mm")
    }
   }
   OutlinedTextField(startCut,{startCut=it},label={Text("Schrägschnitt Anfang (mm)")},enabled=enabled,singleLine=true)
   OutlinedTextField(endCut,{endCut=it},label={Text("Schrägschnitt Ende (mm)")},enabled=enabled,singleLine=true)
   Text("Anfang: fixierte Kante")
   Row { RadioButton(selected=startFixed=="top",onClick={startFixed="top"});Text("Oben",Modifier.padding(top=12.dp));Spacer(Modifier.width(12.dp));RadioButton(selected=startFixed=="bottom",onClick={startFixed="bottom"});Text("Unten",Modifier.padding(top=12.dp)) }
   Text("Ende: fixierte Kante")
   Row { RadioButton(selected=endFixed=="top",onClick={endFixed="top"});Text("Oben",Modifier.padding(top=12.dp));Spacer(Modifier.width(12.dp));RadioButton(selected=endFixed=="bottom",onClick={endFixed="bottom"});Text("Unten",Modifier.padding(top=12.dp)) }
   Text("Gesamtlänge ist die Länge entlang der Reihenachse (in mm). Einzelsteine werden bis zur Gesamtlänge wiederholt; der letzte wird gekürzt.")
   Text("Schrägschnitte: Versatz der äußeren Ecke in Längsrichtung. Endkanten lassen sich auch mit Bearbeiten verschieben.")
  }
 },confirmButton={TextButton(onClick={
  val l=positive(length)?:return@TextButton
  val t=if(enabled)positive(total)?:return@TextButton else l
  var out=e.withStr("curbType",kind).withStr("curbMaterial",material).withStr("withoutChamfer",(!chamfer).toString())
   .withStr("curbRowEnabled",enabled.toString()).withNum("curbSingleLengthMm",l)
   .withNum("curbRowLengthMm",t).withNum("topWidthMm",t).withNum("topHeightMm",positive(width)?:100.0)
   .withNum("sectionWidthMm",positive(sectionWidth)?:100.0).withNum("sectionHeightMm",positive(thickness)?:200.0)
   .withNum("chamferWidthMm",(parseNumber(chamferW)?:3.0).coerceAtLeast(0.0))
   .withNum("chamferDepthMm",(parseNumber(chamferD)?:4.0).coerceAtLeast(0.0))
   .withNum("curbStartCutMm",if(enabled)parseNumber(startCut)?:0.0 else 0.0)
   .withNum("curbEndCutMm",if(enabled)parseNumber(endCut)?:0.0 else 0.0)
   .withStr("curbStartFixedEdge",startFixed).withStr("curbEndFixedEdge",endFixed)
  onSave(out)
 },enabled=valid){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
