# BauDetail 0.9.72

- Kotlin-Syntaxfehler in Scene.kt (Steinfugen bei aktivierter Bordstein-Reihe) behoben.
- Keine beabsichtigte Funktionsaenderung gegenueber 0.9.71.
- Build noch nicht bestaetigt.
