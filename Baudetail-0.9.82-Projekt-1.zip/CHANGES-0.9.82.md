# BauDetail 0.9.82

- Objekt Winkel: Button „Parallel zur nächsten Grundstückskante“ berechnet Kantenwinkel der tatsächlichen Grundstückskontur und richtet die Bordstein-Reihe mit festem Anker aus. Die Richtung mit der geringsten Drehung wird gewählt.
- Bearbeiten: Bordstein-Reihen bieten im Werkzeug „Bearbeiten“ die beiden Schrägschnitt-Griffe, die zuvor ausschließlich im Auswahlmodus mit aktiviertem editMode erreichbar waren.
- Funktionierende Finger- und numerische Drehung von 0.9.80/0.9.81 unverändert.

Nicht als getestet ausgeben: Android-Build, Gerätetest, Performance, allgemeine Bearbeitung sämtlicher Objektklassen.
