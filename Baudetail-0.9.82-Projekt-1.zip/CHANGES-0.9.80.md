# BauDetail 0.9.80 — Winkel-Geometrie neu vereinheitlicht

- Ursache: Die Gradwerte der Zeichenengine wurden im numerischen Werkzeug und beim Finger-Drehen fälschlich in Radiant umgerechnet. `Vec.rotate()` erwartet Grad.
- Gemeinsame Funktion `rotateCurbAroundAnchor` für direkte Eingabe und Fingersteuerung; Drehung um tatsächlichen Bordstein-Eckpunkt mit unveränderter Geometrie.
- Grundstücks-Snapping verwendet die aktuelle Kontur. Eckpunkte haben in unmittelbarer Nähe Vorrang, Kanten bleiben sonst frei fangbar.
- Andere Werkzeuge und Ebenenreihenfolge unverändert.

Status: Quellcode-Patch; Android-Kompilierung und Gerätetest stehen aus.
