# 0.9.88

- Bereinigt beim App-Start alte, bereits lokal gespeicherte Mauerscheiben-Formatvarianten (z.B. 105/55/49).
- Die einzige allgemeine Mauerscheibe aus der Grundbibliothek bleibt erhalten.
- Bereits platzierte Projektobjekte bleiben unverändert.
- Die Druckvorschau und der Zoom-Ruecksprung sind noch nicht in dieser Version korrigiert.
