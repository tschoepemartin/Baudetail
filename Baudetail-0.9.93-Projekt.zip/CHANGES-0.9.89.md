# 0.9.89
- Druckvorschau: vereinfachte Primitive statt Asset-Texturen, begrenzte Anzahl von Zeichenelementen; PDF-Export unverändert.
- Zeichenansicht: Fit-Effekt nicht mehr an Größenänderungen der Zeichenfläche gekoppelt; Zoom/Offset bleiben bei Objektmenüs erhalten.
- Mauerscheibe: Anpassen als primärer Button im Objekt-Inspector. Bestehender Dialog in GeometryAndPavingDialogs bleibt zuständig.

Hinweis: Die Druckszene wird beim Verschieben weiterhin neu erstellt; vollständiges Scene-Caching ist eine separate Optimierung.
