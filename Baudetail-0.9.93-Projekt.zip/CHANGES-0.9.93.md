# 0.9.93

- Stationäre Fangkantengeometrie für Smart-Objektverschiebung wird bei Dokument-/Auswahländerung zwischengespeichert statt bei jeder Fingerbewegung neu aufgebaut.
- Mauerscheiben-Innenkante aus 0.9.92 als Fangsegment erhalten.
- Universelles X/Y-Snapping und PDF-Export unverändert.
- Android-Build und Gerätetest ausstehend.
