# 0.9.92

- Mauerscheiben: Innenkante des aufrechten Schenkels als echte Fanglinie in Draufsicht und Schnitt, auch bei Drehung/Spiegelung.
- Ruckeln beim Verschieben weiterhin zu untersuchen; keine unbelegte Performancekorrektur behauptet.
