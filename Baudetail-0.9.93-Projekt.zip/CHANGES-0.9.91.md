# 0.9.91

- Kotlin-Kompilierfehler in ProjectScreens.kt behoben: fehlender Import de.baudetail.geometry.Vec.
- Vorschau-Optimierung aus 0.9.90 beibehalten.
