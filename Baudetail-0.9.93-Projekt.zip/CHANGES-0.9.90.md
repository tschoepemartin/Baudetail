# BauDetail 0.9.90 – gecachte Exportvorschau

- Die vereinfachte Druckszene wird unabhängig von der Blattverschiebung gecacht.
- Einzelformat: Nur die Transformationsposition der Zeichnung innerhalb des Papier-Clips wird aktualisiert.
- Doppelformat: Beide Ansichten werden bei Referenzposition (0,0) erzeugt und anschließend als Gruppe verschoben.
- Der eigentliche PDF-Export bleibt unverändert.
- Noch nicht durch Android-Build oder Gerätetest verifiziert.
