package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

private data class GodelmannVariant(val id:String,val product:String,val color:String,val surface:String,val image:String)
private fun loadGodelmannVariants(vm:BaudetailViewModel):List<GodelmannVariant> =
 (vm.catalog.entries()+vm.project?.libraryEntries.orEmpty()).distinctBy{it.id}.mapNotNull { entry ->
  val meta=entry.extensions["baudetailManufacturer"] as? JsonObject ?: return@mapNotNull null
  fun field(key:String)=(meta[key] as? JsonPrimitive)?.contentOrNull.orEmpty()
  if(!field("manufacturer").equals("Godelmann",true))return@mapNotNull null
  val asset=(entry.extensions["baudetailTextureTop"] as? JsonPrimitive)?.contentOrNull.orEmpty()
  if(asset.isBlank())return@mapNotNull null
  GodelmannVariant(entry.id,field("product"),field("color"),field("surface"),asset)
 }.distinctBy{it.id}.sortedWith(compareBy({it.product},{it.color},{it.surface}))

/** Identical dimension/slope controls for paving and grass construction sections. */
internal fun buildUpMeasureFields(e:Entity,grass:Boolean=false):List<Field> {
 val section=e.num("buildUpSectionLengthMm",if(grass)e.num("grassSectionLengthMm",Bounds.of(e.points).width) else e.num("topDepthMm",1000.0))
 return listOf(
  Field("sectionWidth","Grafische Breite Schnitt mm (Querschnitt)",fmt(e.num("buildUpSectionWidthMm",if(grass)Bounds.of(e.points).height else e.num("widthMm",1500.0))),true,true),
  Field("realWidth","Tatsächliche Breite mm",fmt(e.num("buildUpRealWidthMm",if(grass)Bounds.of(e.points).height else e.num("widthMm",1500.0))),true,true),
  Field("sectionLength","Grafische Länge Schnitt mm",fmt(section),true,true),
  Field("realLengthEnabled","Realmaß abweichend",if(e.str("buildUpRealLengthEnabled","false")=="true")"ja" else "nein",checkbox=true),
  Field("realLength","Tatsächliche Länge mm",fmt(buildUpRealLengthMm(e.withNum("buildUpSectionLengthMm",section))),true,true),
  Field("slopePct","Gefälle % (0 = eben)",fmt(kotlin.math.abs(buildUpSlopePercent(e))),true),
  Field("slopeDirection","Gefällerichtung im Schnitt",if(buildUpSlopePercent(e)<0)"Nach links fallend" else "Nach rechts fallend",choices=listOf("Nach links fallend","Nach rechts fallend")),
  Field("slopeFixedSide",if(grass)"Fixpunkt der Rasenoberkante" else "Fixpunkt der Pflasteroberkante",if(e.str("buildUpSlopeFixedSide","left")=="right")"Rechts" else "Links",choices=listOf("Links","Rechts")),
  Field("slopeLabelDx","Gefällepfeil verschieben X mm",fmt(e.num("buildUpSlopeLabelDx")),true),
  Field("slopeLabelDy","Gefällepfeil verschieben Y mm",fmt(e.num("buildUpSlopeLabelDy")),true)
 )
}

@Composable fun Inspector(vm:BaudetailViewModel,onCalibrate:()->Unit,onResizeChange:(Boolean)->Unit={},onAddCut:(String)->Unit={}){val d=vm.drawing?:return;val e=d.entities.find{it.id in vm.selected}
 val godelmannVariants=remember(vm.libraryVersion){loadGodelmannVariants(vm)};var dialog by remember{mutableStateOf("")};var resizing by remember{mutableStateOf(false)};val selectedCount=vm.selected.size
 val libraryEntry=e?.libraryId?.let{id->(vm.catalog.entries()+vm.project!!.libraryEntries).distinctBy{it.id}.find{it.id==id}}
 val buildUp=e?.withBuildUpDefaults(libraryEntry)
 // Keep the slider in its original layout slot throughout the gesture.
 // Hiding other controls with alpha (rather than removing their layout) prevents
 // the slider from jumping underneath the user's thumb.
 Column(Modifier.fillMaxWidth().background(if(resizing)Color.Transparent else MaterialTheme.colorScheme.surfaceContainerLow).heightIn(max=650.dp).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
 if(e!=null&&!e.locked&&(e.kind in setOf("elevation","text","leader","dimension","slope")||labelActive(e,d)||e.isParametricBuildUp())){
  val slopeLabelMode=((e.isParametricBuildUp() || e.str("grassObject")=="true") && d.viewMode()=="section" && kotlin.math.abs(buildUpSlopePercent(e))>1e-8) || (e.kind=="dimension" && e.str("metric")=="Stufengefälle") || e.kind=="slope"
  val sizeKey=if((e.isParametricBuildUp() || e.str("grassObject")=="true") && slopeLabelMode)"buildUpSlopeLabelScalePct" else "annotationScalePct"
  val pct=e.num(sizeKey,if(e.kind=="elevation")35.0 else if(e.kind=="dimension"&&e.str("metric")=="Stufengefälle")50.0 else 100.0).toFloat().coerceIn(1f,100f)
  Text("${if(slopeLabelMode)"Gefällepfeilgröße" else "Beschriftungsgröße"}: ${pct.toInt()} %")
  Slider(value=pct,onValueChange={if(!resizing){resizing=true;onResizeChange(true)};vm.update(e.withNum(sizeKey,it.toDouble()))},onValueChangeFinished={resizing=false;onResizeChange(false)},valueRange=1f..100f)
 }
 Column(Modifier.alpha(if(resizing)0f else 1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Text(if(e==null)"Eigenschaften"else"${e.name.ifBlank{e.kind}} · $selectedCount gewählt",style=MaterialTheme.typography.titleLarge)
 if(e!=null && !e.locked && e.kind=="component" &&
    (e.name.contains("Großbaum",true)||e.name.contains("Grossbaum",true)||
     e.name.contains("Strauch",true)||e.name.contains("Kleinbaum",true)) &&
    (libraryEntry?.category?.contains("Vegetation",true)==true)){
  Button(onClick={
   val shrub=e.name.contains("Strauch",true)
   val base=componentInstance(libraryEntry!!,e.points.firstOrNull()?:Vec())
   vm.update(base.copy(id=e.id,points=e.points.take(1),layerId=e.layerId,locked=e.locked,
    rotation=e.rotation,placement=e.placement,groupId=e.groupId))
  },modifier=Modifier.fillMaxWidth()){Text("In bearbeitbare Pflanzung umwandeln")}
 }
 if(e!=null && !e.locked && e.kind=="tree")Button(onClick={dialog="plantSettings"},modifier=Modifier.fillMaxWidth()){Text("Pflanzung anpassen")}
 if(e!=null && !e.locked && e.kind=="hedge")Button(onClick={dialog="hedgeSettings"},modifier=Modifier.fillMaxWidth()){Text("Hecke anpassen")}

 if(e==null){Text("Tippe ein Objekt an. Lange tippen erweitert die Auswahl.");return@Column}
 Row{Checkbox(e.locked,{vm.update(e.copy(locked=it))});Text("Objekt sperren",Modifier.padding(top=12.dp))}
 Row{Checkbox(e.placement.visibleSection,{vm.update(e.copy(placement=e.placement.copy(visibleSection=it)))});Text("Im Schnitt anzeigen",Modifier.padding(top=12.dp))}
 Row{Checkbox(e.placement.visibleTop,{vm.update(e.copy(placement=e.placement.copy(visibleTop=it)))});Text("In Draufsicht anzeigen",Modifier.padding(top=12.dp))}
 if(e.kind=="component"||isStair(e)||isFoundation(e)){Row{Checkbox(e.str("editMode","false")=="true",{vm.update(e.withStr("editMode",it.toString()))});Text("Bearbeiten · Geometriegriffe",Modifier.padding(top=12.dp))}}
 if(e.smartFamily()=="curb" && !e.locked)Button(onClick={dialog="curbSettings"},modifier=Modifier.fillMaxWidth()){Text("Bordstein / Leistenstein anpassen")}

 if(e.kind in setOf("area","polygon","rect","building","property"))Text("Fläche ${fmt(area(e.points)/1e6)} m² · Umfang ${fmt(length(e.points,true)/1000)} m")
 if(e.kind=="property" && !e.locked)Button(onClick={dialog="propertySettings"},modifier=Modifier.fillMaxWidth()){Text("Grundstück bearbeiten · Maße und Winkel")}
 if(e.kind=="hedge")Text("${hedgeCount(length(e.points),e.num("spacingMm",400.0))} Pflanzen · ${fmt(length(e.points)/1000)} m")
 if(e.kind=="dimension")Text("Maß: ${fmt(dimensionValue(e,d))}")
 if(e.kind=="slope")Text("Gefälle: ${slopeLabel(e,d)}")
 if(e.kind=="section")e.targetDrawingId?.let{target->Button(onClick={vm.openDrawing(target)}){Text("Verknüpften Schnitt öffnen")}}
 if(!e.locked && d.viewMode()=="top" && planFootprint(e,d).size>=3 && e.kind !in setOf("plan-height","elevation")) {
  HorizontalDivider()
  Text("Höhen Draufsicht",style=MaterialTheme.typography.titleMedium)
  val cornerKeys=listOf("planZTopLeftMm","planZTopRightMm","planZBottomLeftMm","planZBottomRightMm")
  val cornerLabels=listOf("Höhe oben links (m)","Höhe oben rechts (m)","Höhe unten links (m)","Höhe unten rechts (m)")
  var all by remember(e.id){mutableStateOf(e.str("planZOverallEnabled","false")=="true")}
  var overall by remember(e.id){mutableStateOf(fmt(e.num("planZOverallMm",e.num("planHeightMm",0.0))/1000.0))}
  var corners by remember(e.id){mutableStateOf(cornerKeys.map{key->fmt(e.num(key,e.num("planHeightMm",0.0))/1000.0)})}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
   Checkbox(checked=all,onCheckedChange={checked->all=checked;if(checked)corners=List(4){overall}})
   Text("Gesamt – einheitliche Höhe")
  }
  OutlinedTextField(value=overall,onValueChange={value->overall=value;if(all)corners=List(4){value}},label={Text("Gesamthöhe (m)")},enabled=all,singleLine=true,modifier=Modifier.fillMaxWidth())
  cornerLabels.forEachIndexed{index,label->
   OutlinedTextField(value=corners[index],onValueChange={value->corners=corners.toMutableList().also{it[index]=value}},label={Text(label)},enabled=!all,singleLine=true,modifier=Modifier.fillMaxWidth())
  }
  Button(onClick={
   val numbers=if(all)List(4){parseNumber(overall)}else corners.map{parseNumber(it)}
   if(numbers.all{it!=null}){
    var updated=e.withStr("planZOverallEnabled",all.toString())
    if(all)updated=updated.withNum("planZOverallMm",numbers[0]!!*1000.0)
    cornerKeys.forEachIndexed{index,key->updated=updated.withNum(key,numbers[index]!!*1000.0)}
    vm.update(updated)
   }
  },modifier=Modifier.fillMaxWidth()){Text("Höhen übernehmen")}
 }
 if(!e.locked){
  OutlinedButton(onClick={dialog="level"}){Text("Ebene / Höhen / Sichtbarkeit")}
  if(closedContour(e)){Text("${fmt(surfaceArea(e)/1e6)} m² · ${fmt(perimeter(e)/1000)} m");OutlinedButton(onClick={vm.update(asArea(e))}){Text("In Fläche umwandeln")}}
  OutlinedButton(onClick={dialog="autoMeasuresSection"}){Text("Automatische Maße – Schnitt")}
  OutlinedButton(onClick={dialog="autoMeasuresTop"}){Text("Automatische Maße – Draufsicht")}
  if(e.kind=="dimension"){OutlinedButton(onClick={dialog="measureFormat"}){Text("Maßtext und Maßlinie bearbeiten")};OutlinedButton(onClick={dialog="dimensionRotation"}){Text("Drehmodus / Winkelsnap")}}

  
  if(e.kind=="legend")OutlinedButton(onClick={dialog="legendEdit"},modifier=Modifier.fillMaxWidth()){Text("Legende bearbeiten")}
  if(isFoundation(e))Text(if(e.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil")
  if(e.bindings.isNotEmpty())OutlinedButton(onClick={vm.detachConnections(e)}){Text("Dauerhafte Anschlüsse lösen")}
  OutlinedButton(onClick={dialog="saveAssembly"}){Text("Als Bauwerk speichern")}
  if(d.extensions["editingTemplateId"]!=null)OutlinedButton(onClick={dialog="updateAssembly"}){Text("Globale Vorlage aktualisieren")}

  if(isStair(e))OutlinedButton(onClick={vm.dissolveStair(e)}){Text("Baugruppe auflösen")}
  if(isFrozenTemplate(e))OutlinedButton(onClick={vm.dissolveTemplate(e)},modifier=Modifier.fillMaxWidth()){Text("Bauwerk auflösen")}

  if(e.kind=="component")OutlinedButton(onClick={dialog="variant"},modifier=Modifier.fillMaxWidth()){Text("Bauteiltyp / Variante ändern")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(if(isStair(e)&&e.str("labelExplicit")!="true")true else e.str("labelEnabled")=="true",{vm.update(e.withStr("labelEnabled",it.toString()).withStr("labelExplicit","true"))});Text("Beschriftung aktiv")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(e.str("labelVisibleSection","true")=="true",{vm.update(e.withStr("labelVisibleSection",it.toString()))});Text("Beschriftung im Schnitt")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(e.str("labelVisibleTop",if(e.isParametricBuildUp()||isStair(e))"false" else "true")=="true",{vm.update(e.withStr("labelVisibleTop",it.toString()))});Text("Beschriftung in Draufsicht")}
  OutlinedButton(onClick={dialog="label"},modifier=Modifier.fillMaxWidth()){Text("Beschriftung bearbeiten / positionieren")}
  if(e.kind=="component"||isStair(e))OutlinedButton(onClick={dialog="snapPriority"},modifier=Modifier.fillMaxWidth()){Text("Snap-Priorität / Referenz")}
  if(supportsFoundation(e)){
   val foundation=foundationFor(e,d);Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(foundation!=null,{vm.setUnderfoundation(e,it)});Text("Unterfundament C20/25")}

  }
  if(closedContour(e))OutlinedButton(onClick={dialog="fillMaterial"},modifier=Modifier.fillMaxWidth()){Text("Füllung / Material zuordnen")}
  if(closedContour(e))OutlinedButton(onClick={dialog="fillSettings"},modifier=Modifier.fillMaxWidth()){Text("Füllungsdarstellung in Ansichten")}
  if(isPipe(e))OutlinedButton(onClick={dialog="pipe"},modifier=Modifier.fillMaxWidth()){Text("Rohr-/Leitungsorientierung")}
  if(isKg2000(e))OutlinedButton(onClick={dialog="kg2000"},modifier=Modifier.fillMaxWidth()){Text("KG 2000 · DN / Formstück / Gefälle")}
  if(isRetainingWall(e))Button(onClick={dialog="retaining"},modifier=Modifier.fillMaxWidth()){Text("Mauerscheibe anpassen")}
  if(e.kind in setOf("text","leader","arrow","legend","section")||e.text.isNotBlank())OutlinedButton(onClick={dialog="textEdit"},modifier=Modifier.fillMaxWidth()){Text("Text bearbeiten")}
  if(e.kind in setOf("rect","building","circle","line")&&(e.kind!="building"||e.points.size==4))Button(onClick={dialog="geometry"},modifier=Modifier.fillMaxWidth()){Text("Geometrie: Maße und Position")}
  Button(onClick={dialog="properties"},modifier=Modifier.fillMaxWidth()){Text("Maße, Position und Attribute")}
  OutlinedButton(onClick={dialog="points"},modifier=Modifier.fillMaxWidth()){Text("Eckpunkte numerisch bearbeiten")}
  OutlinedButton(onClick={dialog="style"},modifier=Modifier.fillMaxWidth()){Text("Darstellung und Text")}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={dialog="layer"}){Text("Layer")};OutlinedButton(onClick={dialog="transform"}){Text("Transformieren")}}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=vm::duplicateSelected){Text("Duplizieren")};OutlinedButton(onClick=vm::removeSelected){Text("Löschen")}}
  Text("Ebenenreihenfolge")
  Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
   TextButton(onClick={vm.modifySelected{it.withStr("layerOrderMode","auto")}}){Text("Automatisch")}
   TextButton(onClick={vm.modifySelected{it.withStr("layerOrderMode","back")};vm.orderSelected(false)}){Text("Nach hinten")}
   TextButton(onClick={vm.modifySelected{it.withStr("layerOrderMode","front")};vm.orderSelected(true)}){Text("Nach vorne")}
  }
  Text("Aktuell: "+when(e.str("layerOrderMode","auto")){"front"->"Nach vorne";"back"->"Nach hinten";else->"Automatisch"})
  Row{TextButton(onClick={val id=uid();vm.modifySelected{it.copy(groupId=id)}}){Text("Gruppieren")};TextButton(onClick={vm.modifySelected{it.copy(groupId=null)}}){Text("Gruppe lösen")}}
  if(isSteelEdge(e))Button(onClick={dialog="steelEdgeSettings"},modifier=Modifier.fillMaxWidth()){Text("Stahlkante anpassen")}
  if(e.str("masonryWall")=="true")Button(onClick={dialog="masonryWallSettings"},modifier=Modifier.fillMaxWidth()){Text("Mauer anpassen")}
  if(e.kind=="tree"){
   Button(onClick={dialog="plantSettings"},modifier=Modifier.fillMaxWidth()){Text("Pflanzung anpassen")}
   OutlinedButton(onClick={dialog="plantBrunsPicker"},modifier=Modifier.fillMaxWidth()){Text("Pflanzenart aus Bruns-Katalog wählen")}
  }
  if(e.kind=="hedge"){
   Button(onClick={dialog="hedgeSettings"},modifier=Modifier.fillMaxWidth()){Text("Hecke anpassen")}
   Button(onClick={dialog="brunsPicker"},modifier=Modifier.fillMaxWidth()){Text("Pflanzenart aus Bruns-Katalog wählen")}
  }
  if(e.str("plantingArea")=="true")Button(onClick={dialog="plantingSettings"},modifier=Modifier.fillMaxWidth()){Text("Pflanzfläche · Schichtaufbau bearbeiten")}
  if(e.str("eavesStrip")=="true")Button(onClick={dialog="eavesSettings"},modifier=Modifier.fillMaxWidth()){Text("Traufe · Kiesstreifen und Schichten bearbeiten")}
  if(e.str("grassObject")=="true")Button(onClick={dialog="grassSettings"},modifier=Modifier.fillMaxWidth()){Text("Rasen bearbeiten")}
  if(e.kind=="elevation")Button(onClick={dialog="elevationEdit"},modifier=Modifier.fillMaxWidth()){Text("Höhenkote bearbeiten")}
  OutlinedButton(onClick={dialog="symbol"}){Text("Als Bauteil speichern")}
  if(e.kind=="text")OutlinedButton(onClick={dialog="textLink"}){Text("Text an Objekt koppeln")}
  if(e.kind=="image")OutlinedButton(onClick=onCalibrate){Text("Kalibrieren: 2 Punkte")}
  if(e.kind in setOf("area","rect","polygon"))OutlinedButton(onClick={dialog="pattern"}){Text("Verlegemuster")}
  if(isStair(e))Button(onClick={dialog="stair"},modifier=Modifier.fillMaxWidth()){Text("Treppe anpassen")}
  if(isFoundation(e))Button(onClick={dialog="foundationObjectSettings"},modifier=Modifier.fillMaxWidth()){Text("Unterfundament anpassen")}
  if(supportsFoundation(e)&&foundationFor(e,d)!=null)Button(onClick={dialog="foundationSettings"},modifier=Modifier.fillMaxWidth()){Text("Unterfundament einstellen")}
  if(isPlanter(e))Button(onClick={dialog="planter"},modifier=Modifier.fillMaxWidth()){Text("Pflanztrog einstellen")}
  if(isLightwell(e))Button(onClick={dialog="lightwell"},modifier=Modifier.fillMaxWidth()){Text("Lichtschacht einstellen")}
  if(isChannelBox(e))Button(onClick={dialog="channelBox"},modifier=Modifier.fillMaxWidth()){Text(if(e.str("channelType","box")=="facade" || e.name.contains("Fassadenrinne",true))"Rinne einstellen" else "Einlauf-/Sinkkasten einstellen")}
  if(buildUp?.isParametricBuildUp(libraryEntry)==true)Button(onClick={dialog="stackEdit"},modifier=Modifier.fillMaxWidth()){Text(libraryEntry?.buildUpEditorTitle()?:e.str("buildUpEditorTitle","Aufbau anpassen"))}
  if(e.str("pavingCutOwner").isNotBlank())Button(onClick={dialog="cutSettings"},modifier=Modifier.fillMaxWidth()){Text("Schnittkante anpassen")}
 }
 }
 }
 if(e==null)return

 VegetationAndWallDialogs(dialog,e,vm,{dialog=it},onAddCut)
 StairAndSurfaceDialogs(dialog,e,vm,{dialog=it},onAddCut)
 InfrastructureDialogs(dialog,e,vm,{dialog=it},onAddCut)
 GeometryAndPavingDialogs(dialog,e,buildUp,vm,{dialog=it},onAddCut)
 if(dialog=="curbSettings")CurbSettingsDialog(e,{dialog=""}){vm.update(it);dialog=""}
}

@Composable
internal fun PropertySettingsDialog(e:Entity,vm:BaudetailViewModel,onDismiss:()->Unit){
 PropertyEditorDialog(e,onDismiss){vm.update(it);onDismiss()}
}

@Composable
internal fun PlantSettingsDialog(e:Entity,vm:BaudetailViewModel,onDismiss:()->Unit){
  FormDialog("Pflanzung anpassen",listOf(
   Field("plantName","Pflanzenname",e.str("plantName",e.name)),
   Field("crown","Kronendurchmesser im Plan (mm)",fmt(e.num("crownMm",2000.0)),true,true),
   Field("form","Wuchsform",e.str("plantForm","Hochstamm"),choices=listOf("Hochstamm","Stammbusch","Mehrstämmig","Heister","Strauch")),
   Field("foliage","Gehölzart",e.str("plantFoliage","Laubgehölz"),choices=listOf("Laubgehölz","Nadelgehölz")),
   Field("existing","Bestand",e.str("plantExisting","false"),checkbox=true),
   Field("opacity","Sichtbarkeit der Pflanze (%) – 100 = deckend, 0 = unsichtbar",fmt(e.num("plantOpacityPercent",100.0)),true,true),
   Field("circumference","Stammumfang (cm)",e.str("plantCircumferenceCm","18–20")),
   Field("transplanted","Verpflanzung",e.str("plantTransplanted","3× verpflanzt"),choices=listOf("2× verpflanzt","3× verpflanzt","4× verpflanzt","5× verpflanzt")),
   Field("height","Pflanzenhöhe (cm)",e.str("plantHeightCm","300–350")),
   Field("stems","Stammzahl (bei mehrstämmigen Gehölzen)",e.str("plantStemCount","3"))
  ),{onDismiss()}){v->
   val crown=parseNumber(v["crown"].orEmpty())?:e.num("crownMm",2000.0)
   require(crown>0.0){"Kronendurchmesser muss positiv sein"}
   val plant=v["plantName"].orEmpty()
   val opacity=(parseNumber(v["opacity"].orEmpty())?:100.0).coerceIn(0.0,100.0)
   vm.update(e.copy(name=plant).withNum("crownMm",crown).withStr("plantName",plant)
    .withStr("plantForm",v["form"].orEmpty()).withStr("plantFoliage",v["foliage"].orEmpty()).withStr("plantExisting",v["existing"].orEmpty()).withStr("plantCircumferenceCm",v["circumference"].orEmpty())
    .withStr("plantTransplanted",v["transplanted"].orEmpty()).withStr("plantHeightCm",v["height"].orEmpty())
    .withStr("plantStemCount",v["stems"].orEmpty()).withNum("plantOpacityPercent",opacity))
  }
}

fun paramLabel(key:String)=mapOf("radiusMm" to "Radius mm","widthMm" to "Breite mm","heightMm" to "Höhe mm / Kote mm","crownMm" to "Kronendurchmesser mm","rootMm" to "Wurzelschutzdurchmesser mm (0 = aus)","pitMm" to "Baumgrube mm (0 = aus)","trunkMm" to "Stammdurchmesser mm","spacingMm" to "Pflanzabstand mm","percent" to "Manuelles Gefälle %","mode" to "Modus","unit" to "Anzeige: % / cm/m / 1:x","startHeightMm" to "Starthöhe mm","endHeightMm" to "Endhöhe mm","offsetMm" to "Maßlinienabstand mm","startAngle" to "Startwinkel Grad","sweepAngle" to "Bogenwinkel Grad","direction" to "Blickrichtung: 1 / -1","depthMm" to "Tiefe mm","plantName" to "Pflanzenname","plantHeightMm" to "Pflanzenhöhe mm","trunkCircumferenceMm" to "Stammumfang mm","rootBallMm" to "Ballengröße mm","count" to "Stückzahl")[key]?:key

