package de.baudetail.ui.drawing

import android.view.MotionEvent
import de.baudetail.ui.diagnostics.PerformanceTrace
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.background
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.export.CanvasRenderer
import java.io.File
import kotlin.math.*

@OptIn(ExperimentalComposeUiApi::class)
@Composable fun DrawingCanvas(
 d:Drawing,p:Project,asset:(String)->File,tool:String,selected:Set<String>,preview:List<Vec>,grid:Boolean,penMode:Boolean,fit:Int,
 modifier:Modifier=Modifier,onTap:(Vec,Boolean)->Unit,onFreehand:(List<Vec>)->Unit,onMove:(Vec,SnapResult?,Vec?,Double,String?)->Unit,onDeleteRequested:()->Unit={},onCoordinates:(Vec,Double)->Unit,onCreate:(Entity)->Unit,onChange:(Entity)->Unit
){
 var zoom by rememberSaveable(d.id,d.viewMode()){mutableDoubleStateOf(0.06)};var ox by rememberSaveable(d.id,d.viewMode()){mutableDoubleStateOf(60.0)};var oy by rememberSaveable(d.id,d.viewMode()){mutableDoubleStateOf(60.0)}
 var width by remember{mutableIntStateOf(1)};var height by remember{mutableIntStateOf(1)}
 val renderer=remember{CanvasRenderer(asset,interactive=true)}
 val density=LocalDensity.current
 val touchPx=24f*density.density
 val labelPx=14f*density.density*density.fontScale
 val gripPx=7f*density.density
 val rotationOffset=36f*density.density
 val input=d.input()
 var live by remember(d.id,tool){mutableStateOf<Entity?>(null)}
 var snapMark by remember(d.id,tool){mutableStateOf<SnapResult?>(null)}
 var angleHint by remember(d.id,tool){mutableStateOf<String?>(null)}
 var angleHintAt by remember(d.id,tool){mutableStateOf(Vec())}
 var handle by remember{mutableStateOf("")};var lockedDragId by remember{mutableStateOf<String?>(null)}
 var original by remember{mutableStateOf<Entity?>(null)}
 var contourGrip by remember{mutableIntStateOf(-1)}
 var contourEdge by remember{mutableStateOf(false)}
 var contourVertexAxis by remember{mutableIntStateOf(-1)}
 var contourMeasure by remember(d.id){mutableStateOf<Pair<Vec,Vec>?>(null)}
 var activeContour by remember(d.id){mutableStateOf<Pair<String,Int>?>(null)}
 var measureDialog by remember(d.id,tool){mutableStateOf(false)}
 var measureInput by remember(d.id,tool){mutableStateOf("")}
 // Refresh the retained measurement after an undo, redraw, or numeric edit.
 LaunchedEffect(d,activeContour,tool){
  val active=activeContour
  contourMeasure=if(active!=null && active.first in selected){
   d.entities.find{it.id==active.first}?.let{oppositeContourMeasure(resolvedPoints(it,d),active.second)}
  }else null
 }


 var inlineLegendId by remember{mutableStateOf<String?>(null)}
 var inlineLegendKey by remember{mutableStateOf<String?>(null)}
 var inlineLegendText by remember{mutableStateOf("")}
 var inlineLegendScreen by remember{mutableStateOf(Vec())}
 val inlineFocus=remember{FocusRequester()}
 fun caught(v:Vec,previous:Vec?=null,exclude:Set<String> = emptySet()):Vec {val result=snap(v,d.copy(entities=d.entities.filterNot{it.id in exclude}),input.options(touchPx/zoom),previous);snapMark=result.takeIf{it.reason.isNotEmpty()};return result.point}
 var down by remember{mutableStateOf(Vec())};var last by remember{mutableStateOf(Vec())};var downWorld by remember{mutableStateOf(Vec())};var moved by remember{mutableStateOf(false)};var pinch by remember{mutableStateOf(false)};var panMode by remember{mutableStateOf(false)};var dragSnap by remember{mutableStateOf<SnapResult?>(null)};var dragSourceOffset by remember{mutableStateOf<Vec?>(null)}
 // Remember both axis locks for the duration of one drag. A slightly wider
 // release threshold prevents jitter when the finger moves around a snap line.
 var lockedAxisX by remember{mutableStateOf<Pair<Vec,Vec>?>(null)}
 var lockedAxisY by remember{mutableStateOf<Pair<Vec,Vec>?>(null)}
 var previousDistance by remember{mutableDoubleStateOf(1.0)};var previousCenter by remember{mutableStateOf(Vec())};var downTime by remember{mutableLongStateOf(0)};var stroke by remember{mutableStateOf<List<Vec>>(emptyList())};var dragDelta by remember{mutableStateOf(Vec())};var dragRotationDelta by remember{mutableDoubleStateOf(0.0)};var dragging by remember{mutableStateOf(false)}
 val scene=remember(d,p){Scene.drawing(d,p,skipUprightMarkers=true)}
 // Reuse target geometry while the finger moves; only rebuild after a document/selection change.
 val snapTargets=remember(d,selected){d.copy(entities=d.entities.filterNot{it.id in selected})}
 val axisTargetPoints=remember(d,selected){
  if(d.viewMode()=="section") emptyList() else snapTargets.entities.filter{visibleIn(it,snapTargets)}.flatMap{target->
   val outline=if(target.isParametricBuildUp()){
    val base=buildUpPlanOrigin(target);val angle=buildUpPlanAngle(target)
    rectangle(Vec(),Vec(target.num("planGraphicWidthMm",target.num("widthMm",1500.0)),target.num("topDepthMm",1000.0))).map{base+it.rotate(angle)}
   }else resolvedPoints(target,snapTargets)
   outline+if(outline.size>=2)outline.indices.map{i->(outline[i]+outline[(i+1)%outline.size])*.5}else emptyList()
  }
 }
 // Build actual edge segments once per drawing revision, not for every touch event.
 val planMoveEdges=remember(d){
  d.entities.associate{entity->
   val segments:List<Pair<Vec,Vec>> = when {
    entity.isParametricBuildUp() -> {
     val origin=buildUpPlanOrigin(entity);val angle=buildUpPlanAngle(entity)
     val outline=rectangle(Vec(),Vec(entity.num("planGraphicWidthMm",entity.num("widthMm",1500.0)),entity.num("topDepthMm",1000.0))).map{origin+it.rotate(angle)}
     outline.indices.map{i->outline[i] to outline[(i+1)%outline.size]}
    }
    entity.kind=="component" || isStair(entity) -> smartDragSnapSegments(entity,d).ifEmpty{
     val outline=smartSnapOutline(entity,d)
     if(outline.size<2) emptyList() else outline.indices.map{i->outline[i] to outline[(i+1)%outline.size]}
    }
    else -> {
     val points=resolvedPoints(entity,d)
     val outline=if(points.size>=2)points else emptyList()
     val closed=entity.kind !in setOf("line","polyline","leader","arrow","guide")
     if(outline.size<2) emptyList() else (0 until if(closed && outline.size>2)outline.size else outline.size-1).map{i->outline[i] to outline[(i+1)%outline.size]}
    }
   }
   entity.id to segments.filter{(a,b)->a.distance(b)>0.1}
  }
 }
 val planStationaryEdges=remember(planMoveEdges,d,selected){
  d.entities.filter{it.id !in selected && visibleIn(it,d) && !it.locked}.flatMap{entity->planMoveEdges[entity.id].orEmpty()}
 }
 // Rebuild the stationary background only when the drawing or dragged object changes.
 // Pointer movement must not regenerate thousands of texture primitives.
 val dragBackgrounds=remember(d,p,selected){mutableMapOf<String,List<Primitive>>()}
 val viewAngle=if(d.viewMode()=="top")d.topViewAngle() else 0.0
 fun viewport():PlanViewport=PlanViewport(zoom,Vec(ox,oy),viewAngle,Vec(width/2.0,height/2.0))
 fun world(v:Vec):Vec=viewport().toWorld(v)
 LaunchedEffect(d.id,d.viewMode(),fit,width>1&&height>1){if(width>1&&height>1){val pts=d.entities.filter{visibleIn(it,d)}.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)};val b=if(pts.isEmpty())Bounds(Vec(),Vec(10000.0,7000.0))else Bounds.of(pts);val radians=Math.toRadians(viewAngle);val rotatedWidth=abs(b.width*cos(radians))+abs(b.height*sin(radians));val rotatedHeight=abs(b.width*sin(radians))+abs(b.height*cos(radians));zoom=min((width-100).coerceAtLeast(100)/rotatedWidth.coerceAtLeast(200.0),(height-100).coerceAtLeast(100)/rotatedHeight.coerceAtLeast(200.0)).coerceIn(0.001,20.0);ox=width/2.0-b.center.x*zoom;oy=height/2.0-b.center.y*zoom}}
 LaunchedEffect(inlineLegendId,inlineLegendKey){if(inlineLegendId!=null)runCatching{inlineFocus.requestFocus()}}
 Box(modifier){
 Canvas(Modifier.fillMaxSize().testTag("drawing-canvas").clipToBounds().background(Color.White).onSizeChanged{width=it.width;height=it.height}.pointerInteropFilter{event->
  val traceMove=PerformanceTrace.enabled && event.actionMasked==MotionEvent.ACTION_MOVE
  val traceStart=if(traceMove)System.nanoTime() else 0L
  val pos=Vec(event.x.toDouble(),event.y.toDouble())
  val consumed=when(event.actionMasked){
   MotionEvent.ACTION_DOWN->{
    down=pos;last=pos;downWorld=world(pos);moved=false;pinch=false;downTime=event.eventTime
    panMode=tool=="pan"||(penMode&&event.getToolType(0)!=MotionEvent.TOOL_TYPE_STYLUS)
    stroke=if(tool=="freehand"&&!panMode)listOf(downWorld)else emptyList();dragDelta=Vec();dragRotationDelta=0.0;dragSnap=null;dragSourceOffset=null;lockedAxisX=null;lockedAxisY=null;live=null;angleHint=null;handle="";original=null;lockedDragId=null
    if(tool=="contour-edit" && !panMode){
     val oldMeasure=contourMeasure
     val oldLabel=oldMeasure?.let{(a,b)->(a+b)*.5+Vec(-(b.y-a.y),b.x-a.x)*(18.0/zoom/(a.distance(b).coerceAtLeast(1.0)))}
     if(oldLabel!=null && world(pos).distance(oldLabel)<touchPx*1.5/zoom && activeContour!=null){
      measureInput=fmt(oldMeasure.first.distance(oldMeasure.second),0)
      measureDialog=true
     }else{
     // Keep the last edited edge until a different edge/object is selected.
     val target=d.entities.firstOrNull{it.id in selected && (it.kind in setOf("area","polygon","rect","property") || (it.kind=="hedge" && it.str("hedgeRectangle")=="true") || (it.isParametricBuildUp() && d.viewMode()!="section")) && !it.locked && visibleIn(it,d)}
     if(target!=null){
      val outline=contourOutline(target,d)
      val near=outline.indices.minByOrNull{downWorld.distance(outline[it])}
      if(near!=null && downWorld.distance(outline[near])<touchPx*1.5/zoom){original=target;contourGrip=near;contourEdge=false;contourVertexAxis=-1;dragging=true
       if(activeContour?.first!=target.id){activeContour=target.id to near;contourMeasure=oppositeContourMeasure(outline,near)}
      }
      else {
       val edge=outline.indices.minByOrNull{closestOnSegment(downWorld,outline[it],outline[(it+1)%outline.size]).distance(downWorld)}
       if(edge!=null && closestOnSegment(downWorld,outline[edge],outline[(edge+1)%outline.size]).distance(downWorld)<touchPx/zoom){original=target;contourGrip=edge;contourEdge=true;dragging=true;activeContour=target.id to edge;contourMeasure=oppositeContourMeasure(outline,edge)}
       else if(activeContour?.first!=target.id){activeContour=null;contourMeasure=null}
      }
     }
     }
    }
    val priority=d.entities.asReversed().firstOrNull{it.isParametricBuildUp()&&d.viewMode()=="section"&&visibleIn(it,d)&&!it.locked&&buildUpSlopeLabelHit(it,downWorld,d.sheet.scale,18*density.density/zoom)}
     ?:d.entities.asReversed().firstOrNull{it.kind in setOf("elevation","plan-height")&&visibleIn(it,d)&&!it.locked&&hitTest(downWorld,it,d,10*density.density/zoom)}
     ?:d.entities.asReversed().firstOrNull{it.kind=="dimension"&&visibleIn(it,d)&&!it.locked&&hitTest(downWorld,it,d,10*density.density/zoom)}
     ?:d.entities.asReversed().firstOrNull{!it.locked&&visibleIn(it,d)&&labelTextBounds(it,d)?.contains(downWorld,12*density.density/zoom)==true}
    if(tool=="select"&&!panMode&&priority!=null&&priority.id !in selected)onTap(downWorld,false)
    val e=priority?:d.entities.singleOrNull{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true}
    if(tool=="select"&&!panMode&&e!=null){lockedDragId=e.id;val b=viewBounds(e,d);original=e
     val editing=e.str("editMode","false")=="true"
     val dimensionHandle=if(e.kind=="dimension" && e.points.size>=2 && e.num("auto")!=1.0){
      resolvedPoints(e,d).take(2).indexOfFirst{downWorld.distance(it)<touchPx*1.5/zoom}.takeIf{it>=0}?.let{"dimensionAnchor$it"}
     }else null
     val cutHandle=if(e.str("pavingCutOwner").isNotBlank() && e.points.size>=2){
      e.points.indexOfFirst{downWorld.distance(it)<touchPx*1.5/zoom}.takeIf{it>=0}?.let{"cutAnchor$it"}
     }else null
     val foundationHandle=if(editing&&isFoundation(e))foundationEditHandles(e,d).entries.minByOrNull{downWorld.distance(it.value)}?.takeIf{downWorld.distance(it.value)<touchPx*1.5/zoom}?.key else null
     handle=dimensionHandle?:cutHandle?:foundationHandle?:when{e.isParametricBuildUp()&&d.viewMode()=="section"&&buildUpSlopeLabelHit(e,downWorld,d.sheet.scale,18*density.density/zoom)->"buildUpSlopeLabel";e.kind in setOf("elevation","plan-height")->"elevationLabel";labelTextBounds(e,d)?.contains(downWorld,12*density.density/zoom)==true->"label";editing&&downWorld.distance(Vec(b.center.x,b.min.y-rotationOffset/zoom))<touchPx/zoom->"rotate";editing&&downWorld.distance(b.max)<touchPx/zoom->"scale";else->""}

    }
    dragging=dragging || tool=="select"&&!panMode&&(priority!=null||handle.isNotEmpty()||d.entities.any{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true&&visibleIn(it,d)&&hitTest(downWorld,it,d,touchPx/zoom)})
    if(tool in dragShapeTools&&!panMode)downWorld=caught(downWorld)
    true
   }
   MotionEvent.ACTION_POINTER_DOWN->{pinch=true;dragging=false;live=null;stroke=emptyList();snapMark=null;if(event.pointerCount>=2){previousDistance=hypot((event.getX(1)-event.getX(0)).toDouble(),(event.getY(1)-event.getY(0)).toDouble());previousCenter=Vec((event.getX(0)+event.getX(1))/2.0,(event.getY(0)+event.getY(1))/2.0)};true}
   MotionEvent.ACTION_MOVE->{
    if(event.pointerCount>=2){val center=Vec((event.getX(0)+event.getX(1))/2.0,(event.getY(0)+event.getY(1))/2.0);val dist=hypot((event.getX(1)-event.getX(0)).toDouble(),(event.getY(1)-event.getY(0)).toDouble());val anchor=world(previousCenter);zoom=(zoom*(dist/previousDistance.coerceAtLeast(1.0)).coerceIn(0.75,1.35)).coerceIn(0.0005,50.0);val nextOffset=viewport().offsetForAnchor(anchor,center,zoom);ox=nextOffset.x;oy=nextOffset.y;previousCenter=center;previousDistance=dist;pinch=true}
    else if(!pinch){if(pos.distance(down)>8*density.density)moved=true;if(panMode){val delta=viewport().panDelta(pos-last);ox+=delta.x;oy+=delta.y}else if(tool=="freehand"&&pos.distance(last)>2){stroke=stroke+world(pos)}else if(tool=="contour-edit" && dragging && original!=null && contourGrip>=0){
      val e=original!!;val old=contourOutline(e,d)
      val rawDelta=world(pos)-downWorld
      val changed=old.toMutableList()
      if(contourEdge){
       val a=old[contourGrip];val b=old[(contourGrip+1)%old.size]
       // Always constrain a complete edge to its perpendicular axis, independent of snap/ortho.
       val horizontal=abs(b.x-a.x)>=abs(b.y-a.y)
       val proposed=if(horizontal)Vec(a.x,a.y+rawDelta.y) else Vec(a.x+rawDelta.x,a.y)
       val snapped=if(input.snapEnabled) caught(proposed,exclude=setOf(e.id)) else proposed
       val axisDelta=if(horizontal)Vec(0.0,snapped.y-a.y) else Vec(snapped.x-a.x,0.0)
       changed[contourGrip]=a+axisDelta
       val next=(contourGrip+1)%old.size;changed[next]=b+axisDelta
       contourMeasure=oppositeContourMeasure(changed,contourGrip)
      }else{
       // A vertex slides only along one of its two adjoining edges.
       // Pick the direction on first movement and keep it locked until release.
       val origin=old[contourGrip]
       val prev=old[(contourGrip-1+old.size)%old.size]-origin
       val next=old[(contourGrip+1)%old.size]-origin
       if(contourVertexAxis<0) {
        val prevProjection=kotlin.math.abs(rawDelta.x*prev.x+rawDelta.y*prev.y)/prev.distance(Vec()).coerceAtLeast(1e-6)
        val nextProjection=kotlin.math.abs(rawDelta.x*next.x+rawDelta.y*next.y)/next.distance(Vec()).coerceAtLeast(1e-6)
        contourVertexAxis=if(prevProjection>nextProjection)0 else 1
       }
       val direction=if(contourVertexAxis==0)prev else next
       val unit=direction*(1.0/direction.distance(Vec()).coerceAtLeast(1e-6))
       val projected=origin+unit*(rawDelta.x*unit.x+rawDelta.y*unit.y)
       val candidate=if(input.snapEnabled)caught(projected,exclude=setOf(e.id))else projected
       changed[contourGrip]=origin+unit*((candidate.x-origin.x)*unit.x+(candidate.y-origin.y)*unit.y)
       // A vertex edit does not select a new edge. Keep the last edge measure
       // attached to the updated contour when one was previously selected.
       contourMeasure=activeContour?.takeIf{it.first==e.id}?.let{
        oppositeContourMeasure(changed,it.second)
       }
      }
      live=updateContour(e,d,changed)
      angleHint=null
     }else if(dragging){
      val e=original
      if(e!=null&&handle.isNotEmpty()) {val bounds=viewBounds(e,d);val target=world(pos)
       live=when(handle){
        "dimensionAnchor0","dimensionAnchor1"->{
         val index=handle.last().digitToInt()
         val others=d.copy(entities=d.entities.filterNot{it.id==e.id})
         val result=snap(target,others,input.options(touchPx*1.5/zoom),resolvedPoints(e,d).getOrNull(1-index))
         snapMark=result.takeIf{it.reason.isNotEmpty()}
         val changed=e.points.toMutableList().apply{set(index,result.point)}
         val newAnchors=MutableList<Anchor?>(changed.size){i->e.bindings.find{it.vertex==i}?.anchor ?: e.anchors.getOrNull(i)}
         newAnchors[index]=result.anchor
         // Anchors are positional: mixed anchored/free endpoints must be kept
         // as point bindings rather than a shortened, misindexed anchor list.
         e.copy(points=changed,anchors=if(newAnchors.take(2).all{it!=null})newAnchors.take(2).filterNotNull() else emptyList(),
          bindings=if(newAnchors.take(2).all{it!=null})emptyList() else newAnchors.take(2).mapIndexedNotNull{i,a->a?.let{PointBinding(i,it)}})
        }
        "cutAnchor0","cutAnchor1"->{
         val index=handle.last().digitToInt()
         val owner=d.entities.find{it.id==e.str("pavingCutOwner")}
         val snapped=caught(target,e.points[1-index],setOf(e.id))
         val outline=owner?.let{planFootprint(it,d)}.orEmpty()
         val bounded=if(outline.size>=3){
          val closest=outline.indices.map{j->closestOnSegment(snapped,outline[j],outline[(j+1)%outline.size])}.minByOrNull{it.distance(snapped)}
          // Free interior endpoints are allowed. Exterior drags stop at the contour.
          if(outline.isNotEmpty() && !pointInsidePolygonForCut(snapped,outline))closest?:snapped else snapped
         }else snapped
         e.copy(points=e.points.toMutableList().apply{set(index,bounded)})
        }
        "foundationWidthLeft","foundationWidthRight"->{val source=d.entities.find{it.id==e.str("sourceId")};if(source==null)e else {val c=viewBounds(source,d).center.x;val w=(abs(target.x-c)*2).coerceAtLeast(viewBounds(source,d).width);angleHint="Breite ${fmt(w/10.0,1)} cm";angleHintAt=target;e.withNum("foundationWidthMm",w)}}
        "foundationThickness"->{val source=d.entities.find{it.id==e.str("sourceId")};if(source==null)e else {val top=viewBounds(source,d).max.y;val t=(target.y-top).coerceAtLeast(10.0);angleHint="Dicke ${fmt(t/10.0,1)} cm";angleHintAt=target;e.withNum("thicknessMm",t)}}
        "foundationEmbed"->{val source=d.entities.find{it.id==e.str("sourceId")};if(source==null)e else {val b=viewBounds(source,d);val em=(b.max.y-target.y).coerceIn(0.0,b.height);angleHint="Einbindung ${fmt(em/10.0,1)} cm";angleHintAt=target;e.withStr("embedMode","manual").withNum("embedMm",em)}}
        "elevationLabel"->{
         // Drag the measured tip, not the text insertion point. Preserve the
         // finger-to-tip offset so the marker never jumps under the thumb.
         val start=resolvedPoints(e,d).firstOrNull()?:e.points.firstOrNull()?:Vec()
         val proposed=start+(target-downWorld)
         val others=d.copy(entities=d.entities.filterNot{it.id==e.id})
         val snapped=if(!input.snapEnabled) null else if(d.viewMode()=="top")planHeightEdgeSnap(proposed,others,24*density.density/zoom) else elevationExistingSurfaceSnap(proposed,e,others,24*density.density/zoom)
          ?:elevationSurfaceSnap(proposed,others,24*density.density/zoom)
         val tip=snapped?.point?:proposed
         snapMark=snapped
         e.copy(points=listOf(tip),anchors=if(e.str("elevationRole","relative")=="manual")emptyList() else if(d.viewMode()=="top")planElevationAnchor(tip,others)?.let{listOf(it)}?:emptyList() else snapped?.anchor?.let{listOf(it)}?:emptyList())
        }
        "buildUpSlopeLabel"->e.withNum("buildUpSlopeLabelDx",e.num("buildUpSlopeLabelDx")+target.x-downWorld.x).withNum("buildUpSlopeLabelDy",e.num("buildUpSlopeLabelDy")+target.y-downWorld.y)
        "label"->{val center=bounds.center;if(d.viewMode()=="section")e.withNum("labelSectionDx",e.num("labelSectionDx",objectLabelPosition(e,d).x-center.x)+target.x-downWorld.x).withNum("labelSectionDy",e.num("labelSectionDy",objectLabelPosition(e,d).y-center.y)+target.y-downWorld.y) else e.withNum("labelTopDx",e.num("labelTopDx",objectLabelPosition(e,d).x-center.x)+target.x-downWorld.x).withNum("labelTopDy",e.num("labelTopDy",objectLabelPosition(e,d).y-center.y)+target.y-downWorld.y)}
        "rotate"->{val snapped=caught(target,exclude=selected);val center=smartPivot(e,d);val a=atan2(downWorld.y-center.y,downWorld.x-center.x);val b=atan2(snapped.y-center.y,snapped.x-center.x);val step=when{e.kind=="dimension"&&e.str("rotationMode","snap")=="free"->0.0;e.kind=="dimension"->e.num("angleSnapStep",15.0);e.kind=="component"||isStair(e)->15.0;input.ortho->90.0;else->input.angleStep};val degrees=Math.toDegrees(b-a);val delta=if(step>0)round(degrees/step)*step else degrees;angleHint="${fmt(((smartViewRotation(e,d.viewMode())+delta)%360+360)%360,1)}°";angleHintAt=target+Vec(60/zoom,-80/zoom);if(e.kind=="component"||isStair(e))rotateSmartInView(e,d.viewMode(),delta)else transform(e,angle=delta,center=center)}
        else->{val snapped=caught(target,exclude=selected);val anchor=bounds.min;val factor=(snapped.distance(anchor)/bounds.max.distance(anchor).coerceAtLeast(1e-9)).coerceIn(0.001,1000.0);transform(e,factor=factor,center=anchor)}
       }
      } else {
       val moving=d.entities.singleOrNull{it.id in selected};val raw=world(pos)-downWorld;val others=snapTargets
       // Unified plan move snap for every drawable entity. Keep specialized
       // pipe connector snapping and section construction-surface snapping.
       if(d.viewMode()=="top" && moving!=null && !isKg2000(moving) && moving.kind!="dimension"){
        val tol=touchPx/zoom
        val own=d.entities.filter{it.id in selected}.flatMap{planMoveEdges[it.id].orEmpty()}
        var bestX:Double?=null;var bestY:Double?=null
        var scoreX=tol;var scoreY=tol
        if(input.snapEnabled && "Kante" in input.modes){
         for((a,b) in own){
          val sa=a+raw;val sb=b+raw
          val vertical=abs(sa.x-sb.x)<0.01 && abs(sa.y-sb.y)>0.01
          val horizontal=abs(sa.y-sb.y)<0.01 && abs(sa.x-sb.x)>0.01
          if(!vertical && !horizontal)continue
          for((ta,tb) in planStationaryEdges){
           if(vertical && abs(ta.x-tb.x)<0.01 && abs(ta.y-tb.y)>0.01){
            val overlap=min(max(sa.y,sb.y),max(ta.y,tb.y))-max(min(sa.y,sb.y),min(ta.y,tb.y))
            val dx=ta.x-sa.x
            if(overlap>=-tol*0.1 && abs(dx)<scoreX){scoreX=abs(dx);bestX=dx}
           }
           if(horizontal && abs(ta.y-tb.y)<0.01 && abs(ta.x-tb.x)>0.01){
            val overlap=min(max(sa.x,sb.x),max(ta.x,tb.x))-max(min(sa.x,sb.x),min(ta.x,tb.x))
            val dy=ta.y-sa.y
            if(overlap>=-tol*0.1 && abs(dy)<scoreY){scoreY=abs(dy);bestY=dy}
           }
          }
         }
        }
        dragDelta=raw+Vec(bestX?:0.0,bestY?:0.0)
        dragSnap=null;dragSourceOffset=Vec();dragRotationDelta=0.0
        snapMark=if(bestX!=null||bestY!=null)SnapResult(downWorld+dragDelta,if(bestX!=null&&bestY!=null)"X/Y Kantenfang" else "Kantenfang") else null
       } else if(moving!=null&&(moving.kind=="component"||isStair(moving))){
        val origin=smartViewOrigin(moving,d.viewMode())
        if(isKg2000(moving)){
         data class KgChoice(val source:PipeConnector,val target:PipeConnector,val targetEntity:Entity,val dist:Double,val rotation:Double,val rotatedSource:Vec)
         fun norm180(v:Double):Double{var x=(v+180.0)%360.0;if(x<0)x+=360.0;return x-180.0}
         val sourceCons=kg2000Connectors(moving,d);val targetCons=others.entities.filter{isKg2000(it)||isChannelBox(it)}.flatMap{te->(if(isKg2000(te))kg2000Connectors(te,others)else channelBoxPipeConnectors(te,others)).mapIndexed{index,tc->Triple(te,index,tc)}}
         val candidates=sourceCons.flatMap{sc->targetCons.mapNotNull{(te,index,tc)->if(kg2000Compatible(sc,tc)&&!kg2000ConnectorOccupied(tc,te.id,others,selected)){val rot=norm180(tc.direction+180.0-sc.direction);val rotatedSource=origin+(sc.at-origin).rotate(rot);val dist=(rotatedSource+raw).distance(tc.at);if(dist<=touchPx/zoom*2.5)KgChoice(sc,tc,te,dist,rot,rotatedSource)else null}else null}}
         // Nearest free compatible connector wins. Rotation is only the tie breaker; otherwise a distant straight connector could steal the snap from a nearby bend outlet.
         val best=candidates.minWithOrNull(compareBy<KgChoice>{it.dist}.thenBy{kotlin.math.abs(it.rotation)});if(best!=null){dragRotationDelta=best.rotation;dragDelta=raw+(best.target.at-(best.rotatedSource+raw));val idx=(if(isKg2000(best.targetEntity))kg2000Connectors(best.targetEntity,others)else channelBoxPipeConnectors(best.targetEntity,others)).indexOfFirst{it.at.distance(best.target.at)<1e-4};dragSnap=SnapResult(best.target.at,"KG2000 Anschluss",Anchor(best.targetEntity.id,idx.coerceAtLeast(0),"kg2000",d.viewMode()),best.targetEntity.str("snapPriority","normal"));dragSourceOffset=best.rotatedSource-origin;snapMark=dragSnap}
         else {dragRotationDelta=0.0;val r=snap(origin+raw,others,input.options(touchPx/zoom),origin);dragDelta=r.point-origin;dragSnap=r.takeIf{it.anchor!=null};dragSourceOffset=Vec();snapMark=r.takeIf{it.reason.isNotEmpty()}}
        } else {
        val refs=smartDragSnapReferencePoints(moving,d)
        val sourceSegments=smartDragSnapSegments(moving,d)
        // Curbs are deliberately more magnetic than ordinary smart objects.
        // Their installation edges are small on screen and should lock firmly
        // once they are close enough to another construction edge.
        val smartSnapTolerance=touchPx/zoom
        data class Choice(val result:SnapResult,val sourceAt:Vec,val offset:Vec,val correction:Double,val rank:Int,val sourceRank:Int,val curbBias:Int)
        fun targetIsCurb(r:SnapResult)=r.anchor?.entityId?.let{id->others.entities.find{it.id==id}}?.smartFamily()=="curb"
        val criticalSource=if(moving.smartFamily()=="curb")curbCriticalSnapPoints(moving,d)else emptyList()
        val pointChoices=refs.mapNotNull{ref->
         val tol=smartSnapTolerance*(if(criticalSource.any{it.distance(ref)<1e-5})2.4 else 1.0)
         val at=ref+raw;val r=snap(at,others,input.options(tol))
         if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else Choice(r,at,ref-origin,r.point.distance(at),when(r.priority){"high"->0;"low"->2;else->1},1,if(targetIsCurb(r)||moving.smartFamily()=="curb")1 else 0)
        }
        // Also snap the actual visible source edges. The point on the source edge
        // nearest the finger is used, so endpoint/phase targets correct only the
        // normal distance and do not drag the whole component along its edge.
        val pointer=world(pos)
        val edgeChoices=sourceSegments.mapNotNull{(a,b)->
         val aa=a+raw;val bb=b+raw;val at=closestOnSegment(pointer,aa,bb);val r=snap(at,others,input.options(smartSnapTolerance))
         if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else Choice(r,at,(at-raw)-origin,r.point.distance(at),when(r.priority){"high"->0;"low"->2;else->1},0,if(targetIsCurb(r)||moving.smartFamily()=="curb")0 else 0)
        }
        // Full segment-to-segment alignment: not just midpoints or corners.
        // Only nearly parallel construction edges participate. The normal
        // displacement is independent of the along-edge step quantization.
        data class EdgeLock(val delta:Vec,val result:SnapResult,val score:Double)
        val edgeLocks=if(input.snapEnabled && "Kante" in input.modes && d.viewMode()!="section") {
         val targets=others.entities.filter{visibleIn(it,others)}.flatMap{target->
          val outline=when {
           target.isParametricBuildUp()->{
            val base=buildUpPlanOrigin(target);val angle=buildUpPlanAngle(target)
            rectangle(Vec(),Vec(target.num("planGraphicWidthMm",target.num("widthMm",1500.0)),target.num("topDepthMm",1000.0))).map{base+it.rotate(angle)}
           }
           target.kind=="component"||isStair(target)->smartSnapOutline(target,others)
           else->resolvedPoints(target,others)
          }
          if(outline.size<2) emptyList() else outline.indices.mapNotNull{i->
           if(i==outline.lastIndex && target.kind !in setOf("rect","area","polygon","building","property","component")&&!target.isParametricBuildUp()&&!isStair(target))null
           else Triple(outline[i],outline[(i+1)%outline.size],target)
          }
         }
         sourceSegments.flatMap{(sa,sb)->targets.mapNotNull{(ta,tb,target)->
          val sv=sb-sa;val tv=tb-ta;val sl=sv.length();val tl=tv.length()
          if(sl<1e-5||tl<1e-5||abs(cross(sv,tv))/(sl*tl)>0.025) null else {
           val u=tv*(1.0/tl);val normal=Vec(-u.y,u.x)
           val movedA=sa+raw;val movedB=sb+raw
           val separation=(ta-movedA).x*normal.x+(ta-movedA).y*normal.y
           val amin=(movedA-ta).x*u.x+(movedA-ta).y*u.y
           val bmin=(movedB-ta).x*u.x+(movedB-ta).y*u.y
           val lo=min(amin,bmin);val hi=max(amin,bmin)
           val overlap=min(hi,tl)-max(lo,0.0)
           if(abs(separation)>smartSnapTolerance || overlap < -smartSnapTolerance) null else {
            val step=input.edgeStepMm
            // Align the source edge's first projected endpoint to the
            // nearest interval from the target edge's first endpoint.
            val lateral=if(step>0) round(amin/step)*step-amin else 0.0
            val shift=normal*separation+u*lateral
            val projected=movedA+shift
            val marker=SnapResult(projected,if(step>0)"Kante · ${fmt(step/10)} cm" else "Kante",Anchor(target.id,0,"edge",d.viewMode()),target.str("snapPriority","normal"))
            EdgeLock(raw+shift,marker,abs(separation)+abs(lateral)*0.15)
           }
          }
         }}
        } else emptyList()
        val edgeLock=edgeLocks.minByOrNull{it.score}
        val best=(edgeChoices+pointChoices).minWithOrNull(compareBy<Choice>{it.rank}.thenBy{it.curbBias}.thenBy{it.correction}.thenBy{it.sourceRank})
        if(edgeLock!=null && (best==null || best.correction>smartSnapTolerance*0.2)){
         dragDelta=edgeLock.delta;dragSnap=edgeLock.result;dragSourceOffset=Vec();snapMark=edgeLock.result
        }else if(best!=null){dragDelta=raw+(best.result.point-best.sourceAt);dragSnap=best.result;dragSourceOffset=best.offset;snapMark=best.result}
        else {val r=snap(origin+raw,others,input.options(touchPx/zoom),origin);dragDelta=r.point-origin;dragSnap=r.takeIf{it.anchor!=null};dragSourceOffset=Vec();snapMark=r.takeIf{it.reason.isNotEmpty()}}
        }
       } else {
        val movingEntity=d.entities.firstOrNull{it.id==lockedDragId}?:d.entities.firstOrNull{it.id in selected}
        if(movingEntity?.kind=="dimension"){
         // Dimension placement has deliberately only two magnetic directions:
         // horizontal and vertical. No grid/angle/object snap is applied here.
         // The constrained preview is used during the drag, not just on release.
         val len=raw.length()
         dragDelta=if(len<1e-9)raw else {
          val a=((Math.toDegrees(kotlin.math.atan2(raw.y,raw.x))%180)+180)%180
          when{
           kotlin.math.min(a,kotlin.math.abs(180-a))<=8.0 -> Vec(raw.x,0.0)
           kotlin.math.abs(a-90.0)<=8.0 -> Vec(0.0,raw.y)
           else -> raw
          }
         }
         dragSnap=null;dragSourceOffset=Vec();snapMark=null
        } else if(selected.size>1){
         // Groups are a selection concept (shared groupId), not a synthetic
         // bounding-box entity.  Therefore keep the real snap geometry of all
         // children when the group is moved.  This also makes grouped curbs,
         // channel boxes, pipes, stairs, etc. snap exactly like their members.
         data class GroupChoice(val result:SnapResult,val correction:Double)
         fun pavingEdgeRefs(entity:Entity):List<Vec> {
          val corners=if(entity.isParametricBuildUp()&&d.viewMode()!="section") {
           val origin=buildUpPlanOrigin(entity);val angle=buildUpPlanAngle(entity)
           rectangle(Vec(),Vec(entity.num("planGraphicWidthMm",entity.num("widthMm",1500.0)),entity.num("topDepthMm",1000.0))).map{origin+it.rotate(angle)}
          } else emptyList()
          return if(corners.size==4) corners+corners.indices.map{i->(corners[i]+corners[(i+1)%4])*.5} else emptyList()
         }
         fun sourceRefs(entity:Entity):List<Vec> = when {
          entity.str("grassObject")=="true" && d.viewMode()=="section" -> grassSectionDragRefs(entity)
          entity.isParametricBuildUp() && d.viewMode()!="section" -> pavingEdgeRefs(entity)
          entity.kind=="component" || isStair(entity) -> smartDragSnapReferencePoints(entity,d)
          else -> {
           val pts=resolvedPoints(entity,d)
           if(pts.isNotEmpty()) pts else { val b=viewBounds(entity,d);rectangle(b.min,b.max) }
          }
         }
         val movingMembers=d.entities.filter{it.id in selected && visibleIn(it,d) && it.kind!="dimension"}
         val refs=movingMembers.flatMap(::sourceRefs).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
         val choices=refs.mapNotNull{ref->
          val r=snap(ref+raw,others,input.options(touchPx/zoom))
          if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else GroupChoice(r,r.point.distance(ref+raw))
         }
         val best=choices.minByOrNull{it.correction}
         if(best!=null){
          // All members receive one common correction, preserving the group.
          val source=refs.minByOrNull{(it+raw).distance(best.result.point)}?:downWorld
          dragDelta=raw+(best.result.point-(source+raw));dragSnap=best.result;dragSourceOffset=source-downWorld;snapMark=best.result
         }else{
          dragDelta=raw;dragSnap=null;dragSourceOffset=Vec();snapMark=null
         }
        } else {
         val moving=movingEntity
         // Section paving: only the actual OK-Belag endpoints are valid join
         // targets. Generic snap() also offers bottom/layer corners and could
         // therefore attach an upper surface to the wrong construction level.
         val surfaceJoin=if(d.viewMode()=="section" && (moving?.isParametricBuildUp()==true || moving?.str("grassObject")=="true") && input.snapEnabled)
          buildUpSurfaceJoin(moving,others.entities.filter{visibleIn(it,others)},raw,touchPx/zoom)
         else null
         if(surfaceJoin!=null){
          dragDelta=surfaceJoin.delta
          val target=others.entities.first{it.id==surfaceJoin.targetId}
          val edge=constructionSurfaceEdge(target)
          val p=if(surfaceJoin.targetEnd==0)edge.first else edge.second
          dragSnap=SnapResult(p,"OK Bauteil",Anchor(target.id,surfaceJoin.targetEnd,"constructionSurfaceJoin",d.viewMode()),target.str("snapPriority","normal"))
          dragSourceOffset=Vec();snapMark=dragSnap
         }else {
         val edgeGuide=if(d.viewMode()=="section" && moving!=null && input.snapEnabled && "Kante" in input.modes)
          constructionSectionEdgeGuide(moving,others.entities.filter{visibleIn(it,others)},raw,touchPx/zoom)
         else null
         if(edgeGuide!=null){
          dragDelta=edgeGuide.delta;dragSnap=null;dragSourceOffset=Vec();snapMark=null
         }else {
         // Other view modes retain their dedicated construction geometry.
         dragDelta=raw;dragSnap=null;dragSourceOffset=Vec();snapMark=null
         }
         }
        }
       }
      }
     }else if(tool in dragShapeTools){val target=caught(world(pos),if(tool in setOf("rect","building","property","area"))null else downWorld);if(target.distance(downWorld)>1e-9&&(tool !in setOf("rect","building","property","area")||(abs(target.x-downWorld.x)>1e-9&&abs(target.y-downWorld.y)>1e-9)))live=shapeFromDrag(tool,downWorld,target)else live=null};last=pos}
    onCoordinates(world(pos),zoom);true
   }
   MotionEvent.ACTION_UP->{if(!pinch){if(!panMode){val deleteDrop=tool=="select"&&dragging&&moved&&(handle.isEmpty()||handle=="elevationLabel")&&pos.x>width-110*density.density&&pos.y<125*density.density;if(deleteDrop){lockedDragId?.let{ id -> if(id !in selected) onTap(downWorld,false) };onDeleteRequested()}else if(tool=="freehand"&&stroke.size>1)onFreehand(stroke)else if(moved&&live!=null){if(dragging)onChange(live!!)else onCreate(live!!)}else if(dragging&&moved)onMove(dragDelta,dragSnap,dragSourceOffset,dragRotationDelta,lockedDragId)else if(!moved && tool=="contour-edit"){Unit}else if(!moved){val wp=world(pos);val legend=d.entities.lastOrNull{it.kind=="legend"&&visibleIn(it,d)&&hitTest(wp,it,d,touchPx/zoom)};if(legend!=null){val base=legendItems(d,p.libraryEntries);val textSize=legend.style.textPaperMm*d.sheet.scale;val localY=wp.y-(legend.points.firstOrNull()?.y?:0.0);val titleRows=if(legend.text.isNotBlank())1 else 0;val row=kotlin.math.floor(localY/(textSize*1.7)).toInt()-titleRows;inlineLegendId=legend.id;inlineLegendKey=if(titleRows==1&&localY<textSize*1.7)"__title" else base.filter{legend.str("legendVisible:${it.key}","true")!="false"}.sortedBy{legend.num("legendOrder:${it.key}",base.indexOf(it).toDouble())}.getOrNull(row)?.key;if(inlineLegendKey!=null){inlineLegendText=if(inlineLegendKey=="__title")legend.text else {val item=base.find{it.key==inlineLegendKey};legend.str("legendLabel:${inlineLegendKey}").ifBlank{item?.label.orEmpty()}};inlineLegendScreen=pos}else onTap(wp,event.eventTime-downTime>500)}else if(!(dragging&&event.eventTime-downTime>500))onTap(wp,false)}} };dragging=false;dragDelta=Vec();dragRotationDelta=0.0;stroke=emptyList();live=null;snapMark=null;angleHint=null;handle="";lockedDragId=null;contourGrip=-1;contourEdge=false;contourVertexAxis=-1;lockedAxisX=null;lockedAxisY=null;pinch=false;true}
   MotionEvent.ACTION_CANCEL->{dragging=false;dragDelta=Vec();dragRotationDelta=0.0;stroke=emptyList();live=null;snapMark=null;angleHint=null;handle="";lockedDragId=null;contourGrip=-1;contourEdge=false;contourVertexAxis=-1;contourMeasure=null;pinch=false;true}
   else->true
  }
  if(traceMove)PerformanceTrace.sample("touch_move",System.nanoTime()-traceStart,d.entities.size)
  consumed
 }){
  val traceDraw=PerformanceTrace.frameStart()
  val canvas=drawContext.canvas.nativeCanvas;canvas.save();canvas.clipRect(0f,0f,size.width,size.height)
  // The sheet and all model entities share the same camera transformation.
  canvas.save();canvas.rotate(viewAngle.toFloat(),size.width/2f,size.height/2f);canvas.translate(ox.toFloat(),oy.toFloat());canvas.scale(zoom.toFloat(),zoom.toFloat())
  if(d.sheet.showPaper){val a=d.sheet.origin;val rect=android.graphics.RectF(a.x.toFloat(),a.y.toFloat(),(a.x+(d.sheet.widthMm-20)*d.sheet.scale).toFloat(),(a.y+(d.sheet.heightMm-42)*d.sheet.scale).toFloat());canvas.drawRect(rect,android.graphics.Paint().apply{color=android.graphics.Color.rgb(245,248,244)});canvas.drawRect(rect,android.graphics.Paint().apply{color=android.graphics.Color.LTGRAY;style=android.graphics.Paint.Style.STROKE;strokeWidth=(1/zoom).toFloat()})}
  canvas.restore()
  canvas.rotate(viewAngle.toFloat(),size.width/2f,size.height/2f);canvas.translate(ox.toFloat(),oy.toFloat());canvas.scale(zoom.toFloat(),zoom.toFloat())

  if(grid){var spacing=d.gridMm;while(spacing*zoom<14)spacing*=5;val corners=listOf(world(Vec()),world(Vec(width.toDouble(),0.0)),world(Vec(0.0,height.toDouble())),world(Vec(width.toDouble(),height.toDouble())));val min=Vec(corners.minOf{it.x},corners.minOf{it.y});val max=Vec(corners.maxOf{it.x},corners.maxOf{it.y});val pen=android.graphics.Paint().apply{color=android.graphics.Color.rgb(217,226,222);strokeWidth=(1/zoom).toFloat()};var x=floor((min.x-d.origin.x)/spacing)*spacing+d.origin.x;var count=0;while(x<max.x&&count++<500){canvas.drawLine(x.toFloat(),min.y.toFloat(),x.toFloat(),max.y.toFloat(),pen);x+=spacing};var y=floor((min.y-d.origin.y)/spacing)*spacing+d.origin.y;count=0;while(y<max.y&&count++<500){canvas.drawLine(min.x.toFloat(),y.toFloat(),max.x.toFloat(),y.toFloat(),pen);y+=spacing}}
  // While dragging, draw the moved preview instead of also drawing its old instance.
  val dragId=if(dragging&&handle.isEmpty())lockedDragId else null
  val visibleScene=if(dragId==null)scene else dragBackgrounds.getOrPut(dragId){Scene.drawing(d.copy(entities=d.entities.filterNot{it.id==dragId}),p,skipUprightMarkers=true)}
  val traceParts=PerformanceTrace.enabled
  val renderParts=if(traceParts)HashMap<String,Long>() else null
  val partObserver:((String,Long)->Unit)?=if(renderParts!=null) { kind,nanos -> renderParts[kind]=(renderParts[kind]?:0L)+nanos } else null
  renderer.draw(canvas,visibleScene,viewAngle.toFloat(),partObserver)
  if(renderParts!=null){
   renderParts.forEach{(kind,nanos)->PerformanceTrace.sample("render_"+kind,nanos,d.entities.size)}
   PerformanceTrace.sample("zoom_factor",(zoom*1_000_000.0).toLong(),d.entities.size)
  }
  val selectionStyle=Style(stroke="#D0802E",widthMm=2/zoom)
  selected.forEach{id->d.entities.find{it.id==id&&visibleIn(it,d)}?.let{e->val b=viewBounds(e,d);val contour=if(d.viewMode()=="top" && (e.kind in setOf("area","polygon","rect","property") || (e.kind=="hedge" && e.str("hedgeRectangle")=="true") || (e.isParametricBuildUp() && d.viewMode()!="section")) && e.points.size>=3)contourOutline(e,d) else rectangle(b.min,b.max);renderer.draw(canvas,listOf(Primitive.Path(contour,true,selectionStyle)));if(tool=="select"&&selected.size==1&&!e.locked&&d.layers.find{it.id==e.layerId}?.locked!=true){
    val rotation=Vec(b.center.x,b.min.y-rotationOffset/zoom)
    val editing=e.str("editMode","false")=="true"
    val grips=mutableListOf<Primitive>();if(editing){grips.add(Primitive.Path(listOf(Vec(b.center.x,b.min.y),rotation),style=selectionStyle));grips.add(Primitive.Circle(b.max,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")));grips.add(Primitive.Circle(rotation,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))}
    if(e.kind=="dimension" && e.num("auto")!=1.0)resolvedPoints(e,d).take(2).forEach{grips.add(Primitive.Circle(it,gripPx/zoom,selectionStyle.copy(stroke="#2787A5",fill="#FFFFFF")))}
    if(e.str("pavingCutOwner").isNotBlank())e.points.take(2).forEach{grips.add(Primitive.Circle(it,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))}
    if(labelActive(e,d))grips.add(Primitive.Circle(objectLabelPosition(e,d),gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))
    if(editing&&isFoundation(e))foundationEditHandles(e,d).values.forEach{grips.add(Primitive.Circle(it,gripPx/zoom,selectionStyle.copy(stroke="#2787A5",fill="#FFFFFF")))}
    renderer.draw(canvas,grips)
    if(editing&&(e.kind=="component"||isStair(e))){renderer.draw(canvas,smartSnapReferencePoints(e,d).map{Primitive.Circle(it,gripPx*.55/zoom,selectionStyle.copy(stroke="#2787A5",fill="#FFFFFF"))});val targetId=e.str("followTargetId");val target=d.entities.find{it.id==targetId};if(target!=null)renderer.draw(canvas,listOf(Primitive.Path(listOf(viewBounds(e,d).center,viewBounds(target,d).center),style=selectionStyle.copy(stroke="#2787A5",dashed=true))))}
   };if(dragging&&handle.isEmpty()&&e.kind !in setOf("elevation","plan-height"))renderer.draw(canvas,Scene.entity(when{e.kind=="component"||isStair(e)->{val r=if(kotlin.math.abs(dragRotationDelta)>1e-9)rotateSmartInView(e,d.viewMode(),dragRotationDelta)else e;moveSmartInView(r,d.viewMode(),dragDelta)};e.kind=="elevation"->moveAnnotationInView(e,d.viewMode(),dragDelta);e.str("grassObject")=="true"&&d.viewMode()=="section"->e.withNum("grassSectionDxMm",e.num("grassSectionDxMm")+dragDelta.x).withNum("grassSectionDyMm",e.num("grassSectionDyMm")+dragDelta.y);else->transform(e,translation=dragDelta)},d,p))}}
  if(tool=="contour-edit")selected.forEach{id->d.entities.find{it.id==id && (it.kind in setOf("area","polygon","rect","property") || (it.kind=="hedge" && it.str("hedgeRectangle")=="true") || (it.isParametricBuildUp() && d.viewMode()!="section")) && visibleIn(it,d)}?.let{e->
   val pts=contourOutline(if(live?.id==e.id)live!! else e,d)
   renderer.draw(canvas,listOf(Primitive.Path(pts,true,selectionStyle)))
   renderer.draw(canvas,pts.map{Primitive.Circle(it,gripPx*.65/zoom,selectionStyle.copy(fill="#FFFFFF"))})
  }}
  renderer.draw(canvas,listOf(Primitive.Path(preview+stroke,style=Style(stroke="#1879A2",widthMm=2/zoom))))
  live?.let{e->
   renderer.draw(canvas,Scene.entity(e.copy(style=e.style.copy(stroke="#1879A2",opacity=.7)),d,p))
   val b=viewBounds(e,d);val font=labelPx/zoom
   val labelStyle=Style(stroke="#12516A",background="#FFFFFF",align="center")
   val labels=if(tool=="contour-edit") emptyList() else if(e.kind in setOf("rect","building","property","area")&&e.points.size==4) {
    listOf(Primitive.Text(Vec(b.center.x,b.min.y-font*.7),"${fmt(e.points[0].distance(e.points[1]))} mm",font,labelStyle),Primitive.Text(Vec(b.max.x+font*.8,b.center.y),"${fmt(e.points[0].distance(e.points[3]))} mm",font,labelStyle.copy(align="left")))
   } else listOf(Primitive.Text(b.min-Vec(0.0,font*.7),if(e.kind in setOf("circle","arc"))"R ${fmt(e.num("radiusMm"))} mm"else "${fmt(length(e.points))} mm",font,labelStyle.copy(align="left")))
   renderer.draw(canvas,labels)
  }
  if(tool=="contour-edit")contourMeasure?.let{(from,to)->
   val distance=from.distance(to)
   if(distance>0.01){
    val direction=(to-from)*(1.0/distance)
    val wing=Vec(-direction.y,direction.x)
    val arrow=11.0/zoom
    val measureStyle=Style(stroke="#137A6B",widthMm=1.5/zoom)
    val mid=(from+to)*0.5
    renderer.draw(canvas,listOf(
     Primitive.Path(listOf(from,to),style=measureStyle),
     Primitive.Path(listOf(from+direction*arrow+wing*(arrow*.4),from,from+direction*arrow-wing*(arrow*.4)),style=measureStyle),
     Primitive.Path(listOf(to-direction*arrow+wing*(arrow*.4),to,to-direction*arrow-wing*(arrow*.4)),style=measureStyle),
     Primitive.Text(mid+wing*(18.0/zoom),"${fmt(distance,0)} mm",labelPx/zoom,Style(stroke="#137A6B",background="#FFFFFF",align="center",bold=true))
    ))
   }
  }
  snapMark?.let{mark->renderer.draw(canvas,listOf(Primitive.Circle(mark.point,gripPx/zoom,selectionStyle.copy(stroke="#B63586")),Primitive.Text(mark.point+Vec(labelPx/zoom,-labelPx/zoom),mark.reason,labelPx/zoom,Style(stroke="#B63586",background="#FFFFFF"))))}
  angleHint?.let{renderer.draw(canvas,listOf(Primitive.Text(angleHintAt+Vec(labelPx/zoom,-labelPx/zoom),it,labelPx/zoom,Style(stroke="#12516A",background="#FFFFFF",bold=true))))}
  preview.forEach{renderer.draw(canvas,listOf(Primitive.Circle(it,4/zoom,selectionStyle.copy(fill="#D0802E"))))}
  renderer.draw(canvas,listOf(Primitive.Path(listOf(d.origin-Vec(60/zoom,0.0),d.origin+Vec(60/zoom,0.0)),style=Style(stroke="#B0BDB8",widthMm=1/zoom)),Primitive.Path(listOf(d.origin-Vec(0.0,60/zoom),d.origin+Vec(0.0,60/zoom)),style=Style(stroke="#B0BDB8",widthMm=1/zoom))))
  canvas.restore()
  // Draw height annotations in SCREEN axes. Their anchors follow the rotated
  // world, but their triangles, rules and labels must never inherit viewAngle.
  // Both independent height systems share only this final presentation pass.
  d.entities.filter { it.kind in setOf("elevation","plan-height") && visibleIn(it,d) && d.layers.find { layer -> layer.id==it.layerId }?.visible!=false }.forEach { marker ->
   val shown=if(dragging&&original?.id==marker.id&&live?.id==marker.id) live!! else if(dragging&&marker.id in selected) transform(marker,translation=dragDelta) else marker
   val anchor=resolvedPoints(shown,d).firstOrNull() ?: shown.points.firstOrNull()
   if(anchor!=null) {
    val screenPoint=viewport().toScreen(anchor)
    val screenX=screenPoint.x;val screenY=screenPoint.y
    canvas.save()
    canvas.translate(screenX.toFloat(),screenY.toFloat())
    canvas.scale(zoom.toFloat(),zoom.toFloat())
    canvas.translate(-anchor.x.toFloat(),-anchor.y.toFloat())
    renderer.draw(canvas,Scene.entity(shown.copy(rotation=0.0),d,p))
    canvas.restore()
   }
  }
  if(dragging&&(handle.isEmpty()||handle=="elevationLabel")&&(selected.isNotEmpty()||original?.kind=="elevation")){
   val r=android.graphics.RectF(size.width-94*density.density,18*density.density,size.width-18*density.density,94*density.density)
   val over=last.x>size.width-110*density.density&&last.y<125*density.density
   val fill=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=if(over)android.graphics.Color.rgb(210,70,60)else android.graphics.Color.rgb(245,225,222);style=android.graphics.Paint.Style.FILL}
   val strokePaint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(150,45,40);style=android.graphics.Paint.Style.STROKE;strokeWidth=2*density.density}
   canvas.drawRoundRect(r,14*density.density,14*density.density,fill);canvas.drawRoundRect(r,14*density.density,14*density.density,strokePaint)
   val cx=r.centerX();val cy=r.centerY();canvas.drawRect(cx-14*density.density,cy-10*density.density,cx+14*density.density,cy+18*density.density,strokePaint);canvas.drawLine(cx-18*density.density,cy-16*density.density,cx+18*density.density,cy-16*density.density,strokePaint);canvas.drawLine(cx-7*density.density,cy-21*density.density,cx+7*density.density,cy-21*density.density,strokePaint)
  }
  if(traceDraw!=0L)PerformanceTrace.sample("canvas_draw",System.nanoTime()-traceDraw,d.entities.size)
 }
 // Fixed screen-space measure control for long edges (whose midpoint is off-screen).
 if(tool=="contour-edit" && activeContour!=null && contourMeasure!=null){
  val value=contourMeasure!!.first.distance(contourMeasure!!.second)
  if(value.isFinite() && value>0.01){
   Surface(modifier=Modifier.align(androidx.compose.ui.Alignment.BottomCenter).padding(bottom=8.dp),
    shape=androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    color=MaterialTheme.colorScheme.surfaceVariant,tonalElevation=3.dp){
    Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically,modifier=Modifier.padding(horizontal=10.dp)){
     Text("Kantenabstand: ${fmt(value,0)} mm",style=MaterialTheme.typography.labelMedium)
     Spacer(Modifier.width(8.dp))
     TextButton(onClick={measureInput=fmt(value,0);measureDialog=true}){Text("Ändern")}
    }
   }
  }
 }
 if(measureDialog && activeContour!=null){
  AlertDialog(onDismissRequest={measureDialog=false},title={Row{Text("Kantenabstand",Modifier.weight(1f));TextButton(onClick={measureDialog=false}){Text("×")}}},
   text={Column{Text("Abstand zur gegenüberliegenden Kante (mm)");OutlinedTextField(value=measureInput,onValueChange={measureInput=it},singleLine=true)}},
   confirmButton={TextButton(onClick={
    val active=activeContour
    val wanted=measureInput.replace(',','.').toDoubleOrNull()
    if(active!=null && wanted!=null && wanted>0.0 && wanted.isFinite()){
     val entity=d.entities.find{it.id==active.first}
     if(entity!=null){val pts=contourOutline(entity,d);val measure=oppositeContourMeasure(pts,active.second)
      if(measure!=null){val current=measure.first.distance(measure.second);val dir=(measure.second-measure.first)*(1.0/current)
       val delta=dir*(current-wanted);val changed=pts.toMutableList();val i=active.second
       changed[i]=changed[i]+delta;changed[(i+1)%changed.size]=changed[(i+1)%changed.size]+delta
       if(validContour(changed)){onChange(updateContour(entity,d,changed));contourMeasure=oppositeContourMeasure(changed,i);measureDialog=false}
      }
     }
    }
   }){Text("OK")}},dismissButton={TextButton(onClick={measureDialog=false}){Text("Abbrechen")}})
 }
 inlineLegendId?.let{id->inlineLegendKey?.let{key->
  BasicTextField(value=inlineLegendText,onValueChange={value->inlineLegendText=value;d.entities.find{it.id==id}?.let{legend->onChange(if(key=="__title")legend.copy(text=value)else legend.withStr("legendLabel:$key",value))}},singleLine=true,modifier=Modifier.offset{IntOffset(inlineLegendScreen.x.toInt(),inlineLegendScreen.y.toInt())}.width(220.dp).background(Color.White).focusRequester(inlineFocus))
 }}
 }
}

/** Real section snap handles, deliberately independent of plan geometry. */
private fun grassSectionDragRefs(e:Entity):List<Vec> {
 val c=grassSectionGeometry(e).points
 val b=grassSectionBounds(e)
 return (c+listOf(Vec((b.min.x+b.max.x)/2,b.min.y),Vec((b.min.x+b.max.x)/2,b.max.y),Vec(b.min.x,(b.min.y+b.max.y)/2),Vec(b.max.x,(b.min.y+b.max.y)/2))).distinct()
}

private fun pointInsidePolygonForCut(p:Vec,poly:List<Vec>):Boolean {
 var inside=false
 for(i in poly.indices){val a=poly[i];val b=poly[(i+1)%poly.size]
  if((a.y>p.y)!=(b.y>p.y) && p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside
 }
 return inside
}

/** Measures from the edited edge midpoint to the first *other* polygon boundary
 * along the edge normal. No bounding-box approximation. */
private fun oppositeContourMeasure(points:List<Vec>,edge:Int):Pair<Vec,Vec>? {
 if(points.size<3||edge !in points.indices)return null
 val a=points[edge];val b=points[(edge+1)%points.size]
 val horizontal=abs(b.x-a.x)>=abs(b.y-a.y)
 val start=(a+b)*.5
 val directions=if(horizontal)listOf(Vec(0.0,1.0),Vec(0.0,-1.0)) else listOf(Vec(1.0,0.0),Vec(-1.0,0.0))
 fun intersection(dir:Vec):Double? {
  var closest=Double.POSITIVE_INFINITY
  for(i in points.indices){
   if(i==edge)continue
   val c=points[i];val d=points[(i+1)%points.size]
   val t=if(horizontal){
    if(abs(d.x-c.x)<1e-9 || start.x<min(c.x,d.x)-1e-7 || start.x>max(c.x,d.x)+1e-7) null
    else {val u=(start.x-c.x)/(d.x-c.x);val y=c.y+u*(d.y-c.y);(y-start.y)*dir.y}
   }else{
    if(abs(d.y-c.y)<1e-9 || start.y<min(c.y,d.y)-1e-7 || start.y>max(c.y,d.y)+1e-7) null
    else {val u=(start.y-c.y)/(d.y-c.y);val x=c.x+u*(d.x-c.x);(x-start.x)*dir.x}
   }
   if(t!=null && t>1e-6 && t<closest)closest=t
  }
  return closest.takeIf{it.isFinite()}
 }
 // Prefer the ray facing the polygon interior (even/odd point-in-polygon).
 fun inside(p:Vec):Boolean {
  var hit=false
  for(i in points.indices){val a0=points[i];val b0=points[(i+1)%points.size]
   if((a0.y>p.y)!=(b0.y>p.y) && p.x<(b0.x-a0.x)*(p.y-a0.y)/(b0.y-a0.y)+a0.x)hit=!hit
  }
  return hit
 }
 val options=directions.mapNotNull{dir->intersection(dir)?.let{Triple(dir,it,inside(start+dir*min(it*.25,1.0)))}}
 val chosen=options.filter{it.third}.minByOrNull{it.second}?:options.minByOrNull{it.second}?:return null
 return start to start+chosen.first*chosen.second
}

private fun validContour(points:List<Vec>):Boolean {
 if(points.size<3)return false
 val area=points.indices.sumOf{i->val a=points[i];val b=points[(i+1)%points.size];a.x*b.y-b.x*a.y}
 if(abs(area)<1e-4)return false
 fun cross(a:Vec,b:Vec,c:Vec)=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)
 for(i in points.indices)for(j in i+1 until points.size){
  if(j==i+1 || (i==0 && j==points.lastIndex))continue
  val a=points[i];val b=points[(i+1)%points.size];val c=points[j];val d=points[(j+1)%points.size]
  val x=cross(a,b,c);val y=cross(a,b,d);val z=cross(c,d,a);val w=cross(c,d,b)
  if(x*y<0 && z*w<0)return false
 }
 return true
}
