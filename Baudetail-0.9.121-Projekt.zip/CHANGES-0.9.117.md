# BauDetail 0.9.117

- Automatische Bibliotheks-Synchronisierung zeigt keine modale Erfolgsmeldung mehr. Fehlerhinweise und manueller Import bleiben unverändert.
- KG2000-Bogen: gefüllte, winkelgetreue Rohrkontur statt breiter Linienstriche; Muffe mit derselben Maß- und Farbdefinition wie das gerade Rohr. Anschlusspunkte, Bogenwinkel, Drehung und Flussrichtung bleiben unverändert.
