# BauDetail 0.9.115 — Schnitt-Objektfang

- Wiederherstellung des geometrischen Objektfangs beim Verschieben von parametrischen Pflasteraufbauten und Rasen-Schnittaufbauten an andere Schnittbauteile (insbesondere Rinnen/Komponenten).
- Bestehender OK-Belag-zu-OK-Belag-Fang und vertikaler Schnittkantenfang behalten Vorrang.
- Als bewegte Referenz dienen nur die tatsächlichen Oberflächenendpunkte, nicht Unterkanten der Schichten.
- Draufsicht-Snapping, X/Y-Doppelfang und sonstige Bearbeitungspfade bleiben unverändert.
- Build und Smartphone-Darstellung noch nicht verifiziert.
