# BauDetail 0.9.116

- Beschriftung: interne `bd-material-*`-Materialkennungen werden bei automatischen Pflasteraufbau-Beschriftungen in lesbare Namen aufgelöst. Bestehende Objekte bleiben unverändert gespeichert.
- Schnitt-Zeichenreihenfolge: ausdrücklich nach hinten verschobene Objekte werden vor Unterfundamenten gezeichnet, damit Fundamente darüber sichtbar bleiben. Die bestehende Aufteilung der Pflasterschichten (Frostschutz hinter Fundament, Bettung/Belag davor) bleibt erhalten.
- Version auf 0.9.116 aktualisiert.

Nicht auf Android visuell getestet.
