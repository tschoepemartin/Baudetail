## 0.8.37 – Höhenkote an gemeinsamem Belagsanschluss

Beim Fang einer relativen Höhenkote am gemeinsamen OK-Belag-Anschluss wird bei praktisch gleich nahen Oberkanten (≤ 1 mm Abstandsdifferenz) die Oberfläche mit maßgeblicher tatsächlicher Länge bevorzugt. Damit bleibt die Höhenkorrektur bei grafisch verkürztem Schnitt erhalten, statt die Kote durch den benachbarten Aufbau falsch zu berechnen. Keine Änderungen an Gefälle, Zeichnungsgeometrie oder Datenformat.

## BauDetail 0.8.36 – OK-Belag-Schnittfang

Im Schnitt werden beim Verschieben parametrischer Pflasteraufbauten die tatsächlichen sichtbaren OK-Belag-Endpunkte statt generischer Schicht- oder Umrisspunkte zum Fangen verwendet. Das verhindert, dass eine Belagsoberkante an einer Unterkante oder Schichtgrenze einrastet. Bestehende Gefälle- und Höhenparameter bleiben unverändert.

Hinweis: Die absolute Höhenreferenz bei grafisch verkürzten Schnitten erfordert weiterhin die Prüfung der tatsächlichen Höhenkoten; die Fangkorrektur verbindet die sichtbaren OK-Belag-Endpunkte.

## 0.8.35 – Draufsicht-Kantenfang

Behebt die bisher nur punktbasierte Verschiebung parametrisierter Pflasteraufbauten: echte vollständige Segment-zu-Segment-Ausrichtung mit separat einstellbaren seitlichen Rasterintervallen (Standard 100 mm), inklusive gedrehter Flächen. Die bestehende Schnittgeometrie bleibt unverändert.

# Baudetail 0.8.21

Pflastergefälle, Stufengefälle und freie Gefälle verwenden nun dieselbe Zeichenfunktion für Pfeil, Pfeilspitze, Linienstärke, Schriftgröße und Textabstand. Der Maßstab wird einheitlich in Papiermillimetern berücksichtigt. Bestehende Zeichnungen benötigen keine Datenmigration.

## 0.8.20
- Gefälle-Beschriftungen: Antippen/Auswählen oder Gedrückthalten/Ziehen öffnet nicht mehr automatisch das Objektmenü. Das Menü wird ausschließlich über die obere Schaltfläche „Objektmenü“ geöffnet.
- Lang gedrückt halten ohne Bewegung auf einem bereits ausgewählten Objekt löst keine erneute Auswahl aus.
- Gilt auch für bestehende Zeichnungen; keine Änderung am PDF-Export, Maßstab oder Druck.

## 0.8.19
Gefällepfeile von Pflasteraufbauten: Ankerposition relativ zur Bauteiloberfläche in Modellkoordinaten statt maßstabsabhängigem Papierabstand. Bestehende Zeichnungen übernehmen die Korrektur ohne Datenmigration.

# Baudetail

Aktueller Entwicklungsstand: 0.6.2

Update auf Basis des vorhandenen 0.2.0-Projekts. [Änderungen, Bedienung und Grenzen](docs/UPDATE-0.3.0.md). Aktueller Build-/Testnachweis: `reports/0.3.0/Pruefbericht.md`. Historische Berichte gelten nur für ihre jeweilige Version.

App-ID `de.baudetail`, versionCode 25, bestehender Debug-Schlüssel. APK über 0.2.0 installieren; nicht deinstallieren.


Native Android-Anwendung für maßhaltige 2D-Außenanlagen- und Detailplanung. Kotlin, Jetpack Compose, lokale Projektakten, Millimetergeometrie und externe versionierte Bibliothekspakete.

**Historischer Stand 0.1.1:** Debug- und Release-Build erfolgreich; Debug-Signatur geprüft; 48 Kerntests bestanden. Touch-/Raster-/Layoutänderungen enthalten. Der ursprüngliche Geräte-Crash und der vollständige Android-Ablauf sind noch nicht abschließend bestätigt. Aktueller [Prüfbericht](reports/0.1.1/Pruefbericht.md) und [Änderungen](docs/UX-KORREKTUREN.md).

- **Direkt installieren:** `apks/Baudetail-debug.apk`
- **Release zum selbst Signieren:** `apks/Baudetail-release-unsigned.apk`
- **Schritt für Schritt lokal bauen:** [APK-Bauanleitung](docs/APK-LOKAL-BAUEN.md)
- **Downloads beim ersten Build:** [Abhängigkeiten](docs/ABHAENGIGKEITEN.md)

Der frühere Maven-Abbruch war auf die Proxy-/JDK-Konfiguration der Ausführungsumgebung zurückzuführen. Diese Einstellungen wurden außerhalb des Projekts korrigiert; im Lieferpaket sind keine containerspezifischen Proxy-, SDK- oder JDK-Pfade eingetragen.

## In Android Studio öffnen

1. Das ZIP entpacken und den Ordner `Baudetail` über **Open** öffnen.
2. Android Studio Meerkat 2024.3.1 oder eine neuere stabile Version mit Unterstützung für AGP 8.9 verwenden.
3. Gradle JDK auf **JDK 17** stellen. Android SDK Platform 35 und Build Tools 35.0.0 installieren.
4. Gradle-Synchronisierung ausführen. Beim ersten Build werden die festgelegten Abhängigkeiten aus Google Maven und Maven Central benötigt.
5. Ein Gerät ab Android 8.0 / API 26 auswählen. Modul `app` starten.

Es müssen keine Kotlin-Dateien einzeln kopiert werden. `local.properties` wird von Android Studio mit dem lokalen SDK-Pfad erstellt und gehört nicht ins Lieferpaket.

Die Kombination AGP 8.9, Gradle 8.11.1, SDK 35 und JDK 17 folgt der [offiziellen AGP-Kompatibilitätstabelle](https://developer.android.com/build/releases/agp-8-9-0-release-notes). Kotlin und Compose-Compiler sind im Version Catalog gemeinsam auf 2.1.10 festgelegt, entsprechend der [Compose-Plugin-Konfiguration](https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler).

## Build und Tests

Windows PowerShell:

```powershell
.\gradlew.bat :geometry:test :drawing-core:test :file-format:test :libraries:test :projects:test :app:assembleDebug
.\gradlew.bat :app:assembleRelease
```

Linux / macOS:

```bash
./gradlew :geometry:test :drawing-core:test :file-format:test :libraries:test :projects:test :app:assembleDebug
./gradlew :app:assembleRelease
```

Erwartete Ausgaben nach einem **erfolgreichen** Build:

- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release, zunächst unsigniert: `app/build/outputs/apk/release/app-release-unsigned.apk`
- AAB: `./gradlew :app:bundleRelease`

Für eine verteilbare Release-Version den eigenen Signaturschlüssel über Android Studio „Generate Signed Bundle / APK“ konfigurieren. Ein öffentlicher Entwicklungsschlüssel für Debug ist unter `debug-signing/` enthalten; kein Release-Schlüssel wird mitgeliefert.

Android-PDF-Maßtest auf angeschlossenem Gerät/Emulator:

```bash
./gradlew :export:connectedDebugAndroidTest
```

Der offizielle Gradle Wrapper samt JAR und Prüfsumme für Gradle 8.11.1 ist enthalten. Die aktuelle Dokumentation unter `reports/0.1.1/` enthält den erfolgreichen Gradle-Gesamtbuild, die Kerntests, APK-Prüfungen und die noch offenen Geräteprüfungen.

## Erster Start und Bedienung

- Im Setup optional das Beispielprojekt installieren. Es wird keine Demo-Bibliothek automatisch angelegt. Externe .bdlib importieren.
- Einen externen Bibliotheksordner optional auswählen; er kann später in den Einstellungen geändert werden.
- Projektakte öffnen, Gartenplan oder Schnitt wählen.
- Rechteck, Kreis, Linie, Gebäudegrundform und rechteckige Fläche durch Drücken und Ziehen aufziehen. Andere Werkzeuge verwenden Punkteingabe. Polygone, Hecken und Polylinien mit **Abschließen** beenden.
- Mit zwei Fingern verschieben und zoomen. „Finger navigiert“ reserviert Finger für Navigation und Stift für Zeichnen.
- Bereits ausgewählte Objekte ziehen. Lange tippen oder „Mehrfachauswahl“ verwenden, um eine Auswahl zu erweitern.
- Über „Eigenschaften“ Positionen, Eckpunkte, Maße und Parameter numerisch bearbeiten. Dezimalkomma wird akzeptiert.
- Schnittmarken öffnen ihre verknüpfte Zeichnung; dort führt „Zum Ausgangsplan“ zurück.
- „1:x“ öffnet Maßstab, Papiermaße, Raster, Bezugshöhe und Plankopf. „Einpassen“ verändert ausschließlich die Ansicht.
- Hintergründe importieren; danach über die Eigenschaften zwei bekannte Punkte kalibrieren.
- Export bietet PDF, PNG, SVG, `.bdetail`, `.bproject` und `.bdlib`. Für Gerätetransfer „Vollständig paketieren“ aktivieren.
- PDF mit **100 % / tatsächlicher Größe** drucken und das Kontrollmaß prüfen.

## Projektstruktur

Siehe [Architektur](docs/ARCHITECTURE.md), [Bestandsprüfung](docs/Bestandspruefung.md) und [Dateiinventar](reports/Dateiinventar.txt).

## Eigene Bibliotheken und Dateiformate

- [Offene Dateiformate](docs/DATEIFORMATE.md)
- [Bibliotheken, Symbole und Planköpfe erstellen](docs/BIBLIOTHEKEN.md)
- [Bibliothekseintrag: JSON-Schema](schemas/library-entry.schema.json)
- `examples/sample-library.bdlib`, `examples/sample-project.bproject`, `examples/Schnitt-A-A.bdetail`

## Bekannte Grenzen

[Bestandsprüfung](docs/Bestandspruefung.md) und [Prüfbericht](reports/Pruefbericht.md) sind verbindlich für den erreichten Stand. Insbesondere fehlen noch Gerätetests, grafische Planköpfe mit Logo, speichersparende Varianten und weitere in der Gesamtspezifikation beschriebene Komfortfunktionen. PDF-Hintergründe werden pro gewählter Seite als Rasterreferenz eingebunden; das Original bleibt für den vollständigen Projekttransfer erhalten. Automatische Schnittgeometrie und DXF sind noch nicht umgesetzt.



### 0.8.30 – getrennte Plan-/Schnittlängen
- Abschnittslänge für Schnittgeometrie, Bemaßungs-Endpunkte und Höhenkorrektur einheitlich `buildUpSectionLengthMm`.
- Echte Länge `buildUpRealLengthMm` bleibt Grundlage für Maßzahl und tatsächliche Gefälle-Höhendifferenz.
- Materiallagen und Aussparungsbezug verwenden wieder die kurze Schnittgeometrie; keine Änderungen an der Bibliothek oder am Build-Workflow.
- Regressionstest für 6500 mm real / 1000 mm Schnitt / rechten Fixpunkt / 1,65 %.

### 0.8.32 – grafische Breiten und Stirnkantenfang
- Im Pflasteraufbau-Dialog werden tatsächliche Breite, grafische Breite der Draufsicht und grafische Breite für einen künftigen Querschnitt getrennt gespeichert. Im vorhandenen Längsschnitt ist die Breite senkrecht zur Schnittebene nicht sichtbar; dessen horizontale Ausdehnung bleibt durch „Grafische Länge Schnitt“ gesteuert.
- Beim Verschieben werden in der Draufsicht die vier echten Eckpunkte und die Mittelpunkte **aller vier** Außenkanten des Pflasteraufbaus als Quell-Fangpunkte berücksichtigt (auch bei Drehung und geänderter Größe). Die Ziel-Fanglinien umfassen bereits alle vier Seiten.
- Bei gleicher Fangpriorität gewinnt der räumlich nähere Fangpunkt statt eines entfernteren Schnittpunkts.

## 0.8.35
- Getrennte Zuschnittseiten links/rechts/beidseitig und oben/unten/beidseitig im Verlegemuster.
- Fugen und Einzelstein-Texturen benutzen denselben maßhaltigen Rasterursprung, inkl. Fugenbreite.
- Die Zuschnittseiten werden im Projektmuster persistent gespeichert.


## 0.8.44 Rendering-Optimierung
- Sichtbarkeitsprüfung für Textur-Kacheln vor dem Laden/Zeichnen im interaktiven Canvas.
- Bildschirmdarstellung dekodiert Rasentexturen in halber Auflösung und RGB_565, Cache 64 MiB.
- PDF-/Export-Renderer bleibt bei voller Bildauflösung und ARGB_8888.
- Keine Änderung der Schicht- oder Höhengeometrie.


## 0.8.45 – Rasen-Schnitt
- Grundriss- und Schnittverschiebung getrennt (`grassSectionDxMm/DyMm`).
- Schnitt-Auswahlkontur entspricht der tatsächlichen Summe der Oberbodenschichten, nicht dem Grundriss-Rechteck.
- Geometrische Fangpunkte an OK Grasnarbe, Schichtgrenze, Unterkante und seitlichen Ecken/Kanten.
- Wiederholte statt auf volle Breite gestreckte Vegetationstextur. OK Grasnarbe bleibt unverändert.
- Render-Cache und hochauflösender PDF-Export aus 0.8.44 bleiben erhalten.


## 0.8.48
- CAD-Vektorvegetation im Rasenschnitt ohne fotografische Schnitttexturen.
- Gemeinsame OK-Kanten-Verbindung für Rasen und Pflaster beim Verschieben im Schnitt.
- Draufsicht und Textur-Cache unverändert.
