# BauDetail 0.9.118

- Mauern mit Oberflächenkennzeichnung `kugelgestrahlt` zeigen in der Draufsicht eine deterministische feinkörnige Vektortextur statt der bisher gestreckten Hersteller-Produktaufnahme.
- Materialfarbgrundlage, Fugen, Maße und Positionen bleiben bestehen; Schnittdarstellung bleibt unverändert.
- Bestehende Mauerobjekte werden anhand ihrer gespeicherten Oberflächenvariante erkannt.
- Hinweis: Die Vektortextur ist eine technische Annäherung, kein echtes Herstellerfoto der kugelgestrahlten Oberseite.
- Android-Build und visuelle Geräteprüfung noch ausstehend.
