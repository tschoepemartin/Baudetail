package de.baudetail.ui.toolbars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

data class DrawTool(val id:String,val label:String,val icon:ImageVector)
val drawTools=listOf(
 DrawTool("select","Auswahl",Icons.Default.NearMe),DrawTool("rotate-view","Seite drehen",Icons.Default.RotateRight),DrawTool("rotate-object","Objekt drehen",Icons.Default.Rotate90DegreesCw),DrawTool("object-angle","Objekt Winkel",Icons.Default.Tune),DrawTool("pan","Verschieben",Icons.Default.PanTool),DrawTool("merge","Zusammenführen",Icons.Default.CallMerge),DrawTool("contour-edit","Bearbeiten",Icons.Default.Edit),
 DrawTool("line","Linie",Icons.Default.Remove),DrawTool("polyline","Polylinie",Icons.Default.Timeline),
 DrawTool("rect","Rechteck",Icons.Default.CropSquare),DrawTool("circle","Kreis",Icons.Default.RadioButtonUnchecked),
 DrawTool("arc","Bogen",Icons.Default.RotateRight),DrawTool("polygon","Polygon",Icons.Default.ChangeHistory),
 DrawTool("area","Fläche",Icons.Default.Landscape),DrawTool("building","Gebäude",Icons.Default.Home),DrawTool("property","Grundstück",Icons.Default.CropFree),
 DrawTool("freehand","Freie Kontur",Icons.Default.Gesture),DrawTool("arrow","Pfeil",Icons.Default.ArrowForward),
 DrawTool("leader","Führung",Icons.Default.CallMade),DrawTool("guide","Hilfslinie",Icons.Default.MoreHoriz),
 DrawTool("text","Text",Icons.Default.TextFields),DrawTool("dimension","Bemaßung",Icons.Default.Straighten),
 DrawTool("dimension-chain","Kettenmaß",Icons.Default.Straighten),DrawTool("dimension-angle","Winkelmaß",Icons.Default.RotateRight),DrawTool("measure-area","Fläche messen",Icons.Default.SquareFoot),
 DrawTool("slope","Gefälle",Icons.Default.TrendingDown),DrawTool("elevation","Höhe Schnitt",Icons.Default.Height),DrawTool("assign-height","Höhe Draufsicht",Icons.Default.Terrain),DrawTool("grass","Rasen",Icons.Default.Grass),
 DrawTool("section","Schnitt",Icons.Default.CallSplit),DrawTool("stack","Schichten",Icons.Default.Layers),
 DrawTool("legend","Legende",Icons.Default.List),DrawTool("measure","Messen",Icons.Default.SquareFoot),
 DrawTool("origin","Nullpunkt",Icons.Default.MyLocation)
)
