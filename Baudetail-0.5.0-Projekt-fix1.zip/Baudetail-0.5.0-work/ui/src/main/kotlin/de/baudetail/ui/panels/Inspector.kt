package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

@Composable fun Inspector(vm:BaudetailViewModel,onCalibrate:()->Unit){val d=vm.drawing?:return;val e=d.entities.find{it.id in vm.selected}
 var dialog by remember{mutableStateOf("")};val selectedCount=vm.selected.size
 Column(Modifier.fillMaxWidth().heightIn(max=650.dp).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Text(if(e==null)"Eigenschaften"else"${e.name.ifBlank{e.kind}} · $selectedCount gewählt",style=MaterialTheme.typography.titleLarge)
 if(e==null){Text("Tippe ein Objekt an. Lange tippen erweitert die Auswahl.");return@Column}
 Row{Checkbox(e.locked,{vm.update(e.copy(locked=it))});Text("Objekt sperren",Modifier.padding(top=12.dp))}
 if(e.kind=="component"||isStair(e)||isFoundation(e)){Row{Checkbox(e.str("editMode","false")=="true",{vm.update(e.withStr("editMode",it.toString()))});Text("Bearbeiten · Geometriegriffe",Modifier.padding(top=12.dp))}}
 if(e.kind in setOf("area","polygon","rect","building"))Text("Fläche ${fmt(area(e.points)/1e6)} m² · Umfang ${fmt(length(e.points,true)/1000)} m")
 if(e.kind=="hedge")Text("${hedgeCount(length(e.points),e.num("spacingMm",400.0))} Pflanzen · ${fmt(length(e.points)/1000)} m")
 if(e.kind=="dimension")Text("Maß: ${fmt(dimensionValue(e,d))}")
 if(e.kind=="slope")Text("Gefälle: ${slopeLabel(e,d)}")
 if(e.kind=="section")e.targetDrawingId?.let{target->Button(onClick={vm.openDrawing(target)}){Text("Verknüpften Schnitt öffnen")}}
 if(!e.locked){
  OutlinedButton(onClick={dialog="level"}){Text("Ebene / Höhen / Sichtbarkeit")}
  if(closedContour(e)){Text("${fmt(surfaceArea(e)/1e6)} m² · ${fmt(perimeter(e)/1000)} m");OutlinedButton(onClick={vm.update(asArea(e))}){Text("In Fläche umwandeln")}}
  OutlinedButton(onClick={dialog="autoMeasures"}){Text("Automatische Maße")}
  if(e.kind=="dimension"){OutlinedButton(onClick={dialog="measureFormat"}){Text("Maßtext und Maßlinie bearbeiten")};OutlinedButton(onClick={dialog="dimensionRotation"}){Text("Drehmodus / Winkelsnap")}}
  if(e.kind=="elevation")OutlinedButton(onClick={dialog="elevationEdit"}){Text("Höhenkote bearbeiten")}
  if(isFoundation(e)){Text(if(e.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil");OutlinedButton(onClick={dialog="foundationObjectSettings"}){Text("Unterfundament bearbeiten")}}
  if(e.bindings.isNotEmpty())OutlinedButton(onClick={vm.detachConnections(e)}){Text("Dauerhafte Anschlüsse lösen")}
  OutlinedButton(onClick={dialog="saveAssembly"}){Text("Als Bauwerk speichern")}
  if(d.extensions["editingTemplateId"]!=null)OutlinedButton(onClick={dialog="updateAssembly"}){Text("Globale Vorlage aktualisieren")}

  if(isStair(e)){Button(onClick={dialog="stair"}){Text("Treppenparameter")};OutlinedButton(onClick={vm.dissolveStair(e)}){Text("Baugruppe auflösen")}}
  if(e.kind=="component")OutlinedButton(onClick={dialog="variant"},modifier=Modifier.fillMaxWidth()){Text("Bauteiltyp / Variante ändern")}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(e.str("labelEnabled")=="true",{vm.update(e.withStr("labelEnabled",it.toString()))});Text("Beschriftung anzeigen")}
  OutlinedButton(onClick={dialog="label"},modifier=Modifier.fillMaxWidth()){Text("Beschriftung bearbeiten / positionieren")}
  if(e.kind=="component"||isStair(e))OutlinedButton(onClick={dialog="snapPriority"},modifier=Modifier.fillMaxWidth()){Text("Snap-Priorität / Referenz")}
  if(supportsFoundation(e)){
   val foundation=foundationFor(e,d);Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(foundation!=null,{vm.setUnderfoundation(e,it)});Text("Unterfundament C20/25")}
   if(foundation!=null)OutlinedButton(onClick={dialog="foundationSettings"},modifier=Modifier.fillMaxWidth()){Text(if(foundation.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil · Maße" else "Fundament ohne Keil · Maße") }
  }
  if(closedContour(e))OutlinedButton(onClick={dialog="fillMaterial"},modifier=Modifier.fillMaxWidth()){Text("Füllung / Material zuordnen")}
  if(closedContour(e))OutlinedButton(onClick={dialog="fillSettings"},modifier=Modifier.fillMaxWidth()){Text("Füllungsdarstellung in Ansichten")}
  if(isPipe(e))OutlinedButton(onClick={dialog="pipe"},modifier=Modifier.fillMaxWidth()){Text("Rohr-/Leitungsorientierung")}
  if(isKg2000(e))OutlinedButton(onClick={dialog="kg2000"},modifier=Modifier.fillMaxWidth()){Text("KG 2000 · DN / Formstück / Gefälle")}
  if(isRetainingWall(e))OutlinedButton(onClick={dialog="retaining"},modifier=Modifier.fillMaxWidth()){Text("Mauerscheiben-Abmessungen")}
  if(isChannelBox(e))OutlinedButton(onClick={dialog="channelBox"},modifier=Modifier.fillMaxWidth()){Text("Einlauf-/Sinkkasten einstellen")}
  if(e.kind in setOf("text","leader","arrow","legend","section")||e.text.isNotBlank())OutlinedButton(onClick={dialog="textEdit"},modifier=Modifier.fillMaxWidth()){Text("Text bearbeiten")}
  if(e.kind in setOf("rect","building","circle","line")&&(e.kind!="building"||e.points.size==4))Button(onClick={dialog="geometry"},modifier=Modifier.fillMaxWidth()){Text("Geometrie: Maße und Position")}
  Button(onClick={dialog="properties"},modifier=Modifier.fillMaxWidth()){Text("Maße, Position und Attribute")}
  OutlinedButton(onClick={dialog="points"},modifier=Modifier.fillMaxWidth()){Text("Eckpunkte numerisch bearbeiten")}
  OutlinedButton(onClick={dialog="style"},modifier=Modifier.fillMaxWidth()){Text("Darstellung und Text")}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={dialog="layer"}){Text("Layer")};OutlinedButton(onClick={dialog="transform"}){Text("Transformieren")}}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=vm::duplicateSelected){Text("Duplizieren")};OutlinedButton(onClick=vm::removeSelected){Text("Löschen")}}
  Row{TextButton(onClick={vm.orderSelected(false)}){Text("Nach hinten")};TextButton(onClick={vm.orderSelected(true)}){Text("Nach vorne")}}
  Row{TextButton(onClick={val id=uid();vm.modifySelected{it.copy(groupId=id)}}){Text("Gruppieren")};TextButton(onClick={vm.modifySelected{it.copy(groupId=null)}}){Text("Gruppe lösen")}}
  OutlinedButton(onClick={dialog="symbol"}){Text("Als Bauteil speichern")}
  if(e.kind=="text")OutlinedButton(onClick={dialog="textLink"}){Text("Text an Objekt koppeln")}
  if(e.kind=="image")OutlinedButton(onClick=onCalibrate){Text("Kalibrieren: 2 Punkte")}
  if(e.kind in setOf("area","rect","polygon"))OutlinedButton(onClick={dialog="pattern"}){Text("Verlegemuster")}
  if(e.kind=="stack")OutlinedButton(onClick={dialog="strata"}){Text("Schichtdicken bearbeiten")}
 }
 }
 if(e==null)return
 when(dialog){
 "level"->LevelDialog(e,{dialog=""},vm::update)
 "measureFormat"->MeasureDialog(e,{dialog=""},vm::update)
 "autoMeasures"->ChoiceDialog("Maßprofil",measureProfiles,{dialog=""},selectedIndex=measureProfiles.indexOf(e.str("autoMeasureProfile")).takeIf{it>=0}){vm.setAutoMeasures(e,measureProfiles[it])}
 "saveAssembly","updateAssembly"->FormDialog("Bauwerksvorlage",listOf(Field("name","Name",e.name.ifBlank{"Eigenes Bauwerk"}),Field("category","Kategorie","Eigene Bauwerke")),{dialog=""}){v->vm.saveAssembly(v.getValue("name"),v.getValue("category"),if(dialog=="updateAssembly")(d.extensions["editingTemplateId"] as? JsonPrimitive)?.contentOrNull else null)}

 "stair"->if(e!=null)StairDialog(vm.catalog.entries()+vm.project!!.libraryEntries,e,{dialog=""},vm::saveStair)
 "variant"->{
  val all=(vm.catalog.entries()+vm.project!!.libraryEntries).distinctBy{it.id};val source=all.find{it.id==e.libraryId};val family=if(e.smartFamily()!="component")e.smartFamily() else source?.smartFamily() ?: "component";val group=e.str("variantGroup").ifBlank{source?.variantGroup().orEmpty()}
  val options=all.filter{it.type=="component"&&it.smartFamily()==family&&(group.isBlank()||it.variantGroup()==group)}.sortedBy{it.name}
  if(options.isEmpty())AlertDialog(onDismissRequest={dialog=""},text={Text("Keine kompatiblen Varianten in der geladenen Bibliothek.")},confirmButton={TextButton(onClick={dialog=""}){Text("OK")}})
  else ChoiceDialog("Bauteiltyp ändern · Bezugspunkt bleibt erhalten",options.map{it.name},{dialog=""}){i->val base=if(e.smartFamily()=="component")e.withStr("componentFamily",family).withStr("variantGroup",group)else e;val changed=replaceComponentVariant(base,options[i]);vm.project?.let{p->vm.update(changed);if(p.libraryEntries.none{it.id==options[i].id})vm.attachLibraryForPlacedVariant(options[i])}}
 }
 "label"->{val b=viewBounds(e,d);val defaultDy=-(b.height/2+d.sheet.scale*8.0);FormDialog("Objektbeschriftung",listOf(Field("mode","Textmodus",e.str("labelMode","auto"),choices=listOf("auto","manuell")),Field("text","Manueller Text",e.str("labelText")),Field("dx","Textabstand X mm",fmt(e.num("labelDx",0.0)),true),Field("dy","Textabstand Y mm",fmt(e.num("labelDy",defaultDy)),true)),{dialog=""}){v->vm.update(e.withStr("labelMode",v["mode"].orEmpty()).withStr("labelText",v["text"].orEmpty()).withNum("labelDx",parseNumber(v["dx"]!!)!!).withNum("labelDy",parseNumber(v["dy"]!!)!!))}}
 "snapPriority"->ChoiceDialog("Snap-Priorität · Führende Bauteile werden beim Fangen bevorzugt",listOf("Führend","Normal","Folgend"),{dialog=""},selectedIndex=when(e.str("snapPriority","normal")){"high"->0;"low"->2;else->1}){i->vm.update(e.withStr("snapPriority",listOf("high","normal","low")[i]))}
 "dimensionRotation"->{val labels=listOf("Winkelsnap 15°","Winkelsnap 30°","Winkelsnap 45°","Winkelsnap 90°","Frei drehbar");val idx=if(e.str("rotationMode","snap")=="free")4 else when(e.num("angleSnapStep",15.0).toInt()){30->1;45->2;90->3;else->0};ChoiceDialog("Drehmodus · aktueller Modus ist markiert",labels,{dialog=""},selectedIndex=idx){i->vm.update(if(i==4)e.withStr("rotationMode","free") else e.withStr("rotationMode","snap").withNum("angleSnapStep",listOf(15.0,30.0,45.0,90.0)[i]))}}
 "elevationEdit"->ElevationDialog("Höhenkote bearbeiten",e.str("elevationRole","manual"),fmt(if(e.str("elevationRole")=="relative")e.num("heightOffsetMm") else e.num("heightMm")),e.str("elevationPrefix"),{dialog=""}){role,value,prefix->var n=e.withStr("elevationRole",role).withStr("elevationPrefix",prefix);n=if(role=="relative")n.withNum("heightOffsetMm",value)else n.withNum("heightMm",value);vm.update(n)}
 "foundationSettings"->{val f=foundationFor(e,d);if(f!=null){val sb=viewBounds(e,d);val fields=mutableListOf(Field("type","Ausführung",if(f.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil",choices=listOf("Fundament mit Keil","Fundament ohne Keil")),Field("width","Breite cm",fmt(f.num("foundationWidthMm",sb.width+200.0)/10.0),true,true),Field("thickness",if(isStair(e))"Dicke unter VK Stufe cm" else "Dicke ab Unterkante cm",fmt(f.num("thicknessMm",200.0)/10.0),true,true),Field("embedMode","Einbindung",if(f.str("embedMode","auto")=="manual")"manuell" else "automatisch 1/3",choices=listOf("automatisch 1/3","manuell")),Field("embed","Einbindung cm (bei manuell)",fmt(f.num("embedMm",sb.height/3.0)/10.0),true),Field("side","Keilseite",when(f.str("wedgeSide","both")){"left"->"links";"right"->"rechts";else->"beidseitig"},choices=listOf("beidseitig","links","rechts")));if(isStair(e))fields.add(1,Field("stairExecution","Treppenfundament",if(f.str("stairFoundationExecution","sloped")=="sloped")"schräg" else "getrennt",choices=listOf("schräg","getrennt")));FormDialog("Unterfundament",fields,{dialog=""}){v->val type=if(v["type"].orEmpty().contains("mit Keil"))"with_wedge" else "without_wedge";val mode=if(v["embedMode"]=="manuell")"manual" else "auto";val side=when(v["side"]){"links"->"left";"rechts"->"right";else->"both"};val stairExecution=if(v["stairExecution"]=="getrennt")"separate" else "sloped";vm.updateFoundation(e,parseNumber(v["thickness"]!!)!!*10.0,parseNumber(v["width"]!!)!!*10.0,type,mode,parseNumber(v["embed"]!!)!!*10.0,side,stairExecution)}}}
 "foundationObjectSettings"->{val source=d.entities.find{it.id==e.str("sourceId")};val sb=source?.let{viewBounds(it,d)}?:viewBounds(e,d);val fields=mutableListOf(Field("type","Ausführung",if(e.str("foundationType","without_wedge")=="with_wedge")"Fundament mit Keil" else "Fundament ohne Keil",choices=listOf("Fundament mit Keil","Fundament ohne Keil")),Field("width","Breite cm",fmt(e.num("foundationWidthMm",sb.width+200.0)/10.0),true,true),Field("thickness",if(source?.let(::isStair)==true)"Dicke unter VK Stufe cm" else "Dicke ab Unterkante cm",fmt(e.num("thicknessMm",200.0)/10.0),true,true),Field("embedMode","Einbindung",if(e.str("embedMode","auto")=="manual")"manuell" else "automatisch 1/3",choices=listOf("automatisch 1/3","manuell")),Field("embed","Einbindung cm (bei manuell)",fmt(e.num("embedMm",sb.height/3.0)/10.0),true),Field("side","Keilseite",when(e.str("wedgeSide","both")){"left"->"links";"right"->"rechts";else->"beidseitig"},choices=listOf("beidseitig","links","rechts")));if(source?.let(::isStair)==true)fields.add(1,Field("stairExecution","Treppenfundament",if(e.str("stairFoundationExecution","sloped")=="sloped")"schräg" else "getrennt",choices=listOf("schräg","getrennt")));FormDialog("Unterfundament",fields,{dialog=""}){v->val type=if(v["type"].orEmpty().contains("mit Keil"))"with_wedge" else "without_wedge";val mode=if(v["embedMode"]=="manuell")"manual" else "auto";val side=when(v["side"]){"links"->"left";"rechts"->"right";else->"both"};val stairExecution=if(v["stairExecution"]=="getrennt")"separate" else "sloped";vm.update(e.withNum("thicknessMm",parseNumber(v["thickness"]!!)!!*10.0).withNum("foundationWidthMm",parseNumber(v["width"]!!)!!*10.0).withStr("foundationType",type).withStr("wedgeEnabled",(type=="with_wedge").toString()).withStr("embedMode",mode).withNum("embedMm",parseNumber(v["embed"]!!)!!*10.0).withStr("wedgeSide",side).withStr("stairFoundationExecution",stairExecution))}}
 "textEdit"->FormDialog("Text bearbeiten",listOf(Field("text","Text",e.text)),{dialog=""}){v->vm.update(e.copy(text=v["text"].orEmpty()))}
 "fillMaterial"->{val materials=(vm.catalog.entries()+vm.project!!.libraryEntries).filter{it.type=="material"}.distinctBy{it.id}.sortedBy{it.name};val labels=listOf("Keine Füllung")+materials.map{it.name};val selected=if(e.materialId==null)0 else materials.indexOfFirst{it.id==e.materialId}.let{if(it<0)null else it+1};ChoiceDialog("Füllung / Material",labels,{dialog=""},selectedIndex=selected){i->if(i==0)vm.update(e.copy(materialId=null,materialSnapshot=null))else{val m=materials[i-1];vm.attachLibraryForPlacedVariant(m);vm.update(e.copy(materialId=m.id,materialSnapshot=null,quantityUnit=e.quantityUnit?:"m²"))}}}
 "fillSettings"->FormDialog("Füllungsdarstellung",listOf(Field("mode","Draufsicht",when(e.str("fillMode","auto")){"area"->"flächig";"vertical"->"senkrecht";else->"auto"},choices=listOf("auto","flächig","senkrecht")),Field("top","In Draufsicht sichtbar",if(e.placement.visibleTop)"ja"else"nein",checkbox=true),Field("section","Im Schnitt sichtbar",if(e.placement.visibleSection)"ja"else"nein",checkbox=true)),{dialog=""}){v->val mode=when(v["mode"].orEmpty().lowercase()){"flächig","flaechig","area"->"area";"senkrecht","vertical"->"vertical";else->"auto"};vm.update(e.withStr("fillMode",mode).copy(placement=e.placement.copy(visibleTop=v["top"]!="nein",visibleSection=v["section"]!="nein")))}
 "pipe"->FormDialog("Rohr-/Leitungsorientierung",listOf(Field("orientation","Orientierung",if(e.str("orientation","horizontal")=="vertical")"vertikal"else"horizontal",choices=listOf("horizontal","vertikal")),Field("direction","Bei vertikal",if(e.str("verticalDirection","down")=="up")"oben"else"unten",choices=listOf("unten","oben")),Field("length","Vertikale dargestellte Länge mm",fmt(e.num("verticalLengthMm",1000.0)),true,true)),{dialog=""}){v->vm.update(e.withStr("orientation",if(v["orientation"].orEmpty().startsWith("v",true))"vertical"else"horizontal").withStr("verticalDirection",if(v["direction"].orEmpty().startsWith("o",true))"up"else"down").withNum("verticalLengthMm",parseNumber(v["length"]!!)!!))}
 "channelBox"->FormDialog("Einlauf-/Sinkkasten",listOf(
  Field("width","Kastenbreite cm",fmt(e.num("boxWidthMm",185.0)/10.0),true,true),
  Field("height","Kastenhöhe cm",fmt(e.num("boxHeightMm",610.0)/10.0),true,true),
  Field("length","Kastenlänge cm",fmt(e.num("boxLengthMm",500.0)/10.0),true,true),
  Field("nw","Rinnen-Nennweite cm",fmt(e.num("channelNominalWidthMm",150.0)/10.0),true,true),
  Field("outlet","Rohranschluss",when(e.str("pipeOutlet","left")){"left"->"links";"none"->"keiner";else->"rechts"},choices=listOf("keiner","links","rechts")),
  Field("dn","Rohranschluss DN",("DN "+e.num("pipeDnMm",160.0).toInt()),choices=listOf("DN 110","DN 125","DN 160","DN 200","DN 250","DN 315","DN 400","DN 500","DN 630")),
  Field("axis","Rohrachse ab OK cm",fmt(e.num("pipeAxisFromTopMm",310.0)/10.0),true,true),
  Field("basket","Laubfangkorb",if(e.str("leafBasket","true")=="true")"ja"else"nein",checkbox=true),
  Field("grate","Rost sichtbar",if(e.str("grateVisible","true")=="true")"ja"else"nein",checkbox=true)
 ),{dialog=""}){v->vm.update(e.withNum("boxWidthMm",parseNumber(v["width"]!!)!!*10).withNum("boxHeightMm",parseNumber(v["height"]!!)!!*10).withNum("boxLengthMm",parseNumber(v["length"]!!)!!*10).withNum("channelNominalWidthMm",parseNumber(v["nw"]!!)!!*10).withStr("pipeOutlet",when(v["outlet"]){"links"->"left";"keiner"->"none";else->"right"}).withNum("pipeDnMm",v["dn"].orEmpty().filter{it.isDigit()}.toDoubleOrNull()?:160.0).withNum("pipeAxisFromTopMm",parseNumber(v["axis"]!!)!!*10).withStr("leafBasket",(v["basket"]!="nein").toString()).withStr("grateVisible",(v["grate"]!="nein").toString()))}
 "kg2000"->{
  val dns=listOf("DN 110","DN 125","DN 160","DN 200","DN 250","DN 315","DN 400","DN 500","DN 630")
  val type=e.str("fittingType","pipe")
  val fields=mutableListOf(
   Field("dn","DN","DN "+e.num("dnMm",160.0).toInt(),choices=dns),
   Field("length","Länge cm",fmt(e.num("pipeLengthMm",1000.0)/10.0),true,true),
   Field("slope","Gefälle %",fmt(e.num("slope",0.0)),true),
   Field("flow","Fließrichtung anzeigen",if(e.str("flowArrow","true")=="true")"ja"else"nein",checkbox=true)
  )
  if(type=="bend")fields.add(Field("angle","Bogenwinkel",fmt(e.num("bendAngle",45.0))+"°",choices=listOf("15°","30°","45°","67°","87,5°")))
  if(type=="y")fields.add(Field("branch","Abzweig DN","DN "+e.num("branchDnMm",e.num("dnMm",160.0)).toInt(),choices=dns))
  if(type=="reducer"){
   fields.add(Field("inlet","Eingang DN","DN "+e.num("inletDnMm",160.0).toInt(),choices=dns))
   fields.add(Field("outlet","Ausgang DN","DN "+e.num("outletDnMm",110.0).toInt(),choices=dns))
  }
  FormDialog("KG 2000",fields,{dialog=""}){v->
   fun selectedDn(key:String,def:Double):Double=v[key].orEmpty().filter{ch->ch.isDigit()}.toDoubleOrNull()?:def
   var r=e.withNum("dnMm",selectedDn("dn",160.0)).withNum("pipeLengthMm",parseNumber(v["length"]!!)!!*10).withNum("slope",parseNumber(v["slope"]!!)!!).withStr("flowArrow",(v["flow"]!="nein").toString())
   if(type=="bend")r=r.withNum("bendAngle",v["angle"].orEmpty().replace(",",".").filter{ch->ch.isDigit()||ch=='.'}.toDoubleOrNull()?:45.0)
   if(type=="y")r=r.withNum("branchDnMm",selectedDn("branch",r.num("dnMm")))
   if(type=="reducer")r=r.withNum("inletDnMm",selectedDn("inlet",160.0)).withNum("outletDnMm",selectedDn("outlet",110.0))
   vm.update(r)
  }
 }
 "retaining"->FormDialog("Mauerscheibe / Winkelstützelement",listOf(Field("height","Höhe mm",fmt(e.num("wallHeightMm",800.0)),true,true),Field("foot","Fußtiefe mm",fmt(e.num("footDepthMm",400.0)),true,true),Field("wall","Wandstärke mm",fmt(e.num("wallThicknessMm",70.0)),true,true),Field("slab","Fußstärke mm",fmt(e.num("footThicknessMm",100.0)),true,true),Field("length","Elementlänge mm",fmt(e.num("elementLengthMm",1000.0)),true,true),Field("side","Fußseite",if(e.str("footSide","right")=="left")"links"else"rechts",choices=listOf("rechts","links"))),{dialog=""}){v->val h=parseNumber(v["height"]!!)!!;val f=parseNumber(v["foot"]!!)!!;val w=parseNumber(v["wall"]!!)!!;val slab=parseNumber(v["slab"]!!)!!;val len=parseNumber(v["length"]!!)!!;require(w<=f&&slab<=h){"Wand-/Fußstärke darf Gesamtmaß nicht überschreiten"};vm.update(e.withNum("wallHeightMm",h).withNum("sectionHeightMm",h).withNum("footDepthMm",f).withNum("sectionWidthMm",f).withNum("wallThicknessMm",w).withNum("footThicknessMm",slab).withNum("elementLengthMm",len).withNum("topWidthMm",len).withNum("topHeightMm",f).withStr("footSide",if(v["side"].orEmpty().startsWith("l",true))"left"else"right"))}
 "geometry"->{val origin=e.points.firstOrNull()?:Vec();val circle=e.kind=="circle";val line=e.kind=="line"
 val fields=listOf(Field("x",if(circle)"Mittelpunkt X mm"else"Position X mm",fmt(origin.x),true),Field("y",if(circle)"Mittelpunkt Y mm"else"Position Y mm",fmt(origin.y),true))+if(circle)listOf(Field("radius","Radius mm",fmt(e.num("radiusMm")),true,true))else listOf(Field("width",if(line)"Länge mm"else"Breite mm",fmt(e.points.getOrElse(1){origin}.distance(origin)),true,true),Field("angle","Drehwinkel Grad",fmt(rectangleAngle(e)),true))+(if(line)emptyList()else listOf(Field("height","Höhe / Tiefe mm",fmt(e.points.getOrElse(3){origin}.distance(origin)),true,true)))
 FormDialog("Geometrie bearbeiten",fields,{dialog=""}){v->fun n(k:String)=parseNumber(v.getValue(k))!!
 val at=Vec(n("x"),n("y"));vm.update(if(circle)resizeCircle(e,n("radius"),at)else if(line)resizeLine(e,n("width"),n("angle"),at)else resizeRectangle(e,n("width"),n("height"),at,n("angle")))}}
 "properties"->{val fields=mutableListOf(Field("name","Bezeichnung",e.name),Field("x","X in mm",fmt(e.points.firstOrNull()?.x?:0.0),true),Field("y","Y in mm",fmt(e.points.firstOrNull()?.y?:0.0),true),Field("status","Status",e.status,choices=listOf("Bestand","Planung","Abbruch")),Field("quantity","Mengeneinheit",e.quantityUnit.orEmpty(),choices=listOf("","m²","m","Stk","m³")))
 e.params.forEach{(k,v)->fields.add(Field(k,paramLabel(k),(v as? JsonPrimitive)?.content?:v.toString(),v is JsonPrimitive&&v.doubleOrNull!=null))}
 if(e.kind=="text"||e.kind=="leader"||e.kind=="dimension"||e.kind=="section"||e.kind=="legend")fields.add(Field("text","Text / manuelle Überschreibung",e.text))
 FormDialog("Objekteigenschaften",fields,{dialog=""}){v->var result=transform(e,translation=Vec(parseNumber(v.getValue("x"))!!,parseNumber(v.getValue("y"))!!)-(e.points.firstOrNull()?:Vec())).copy(name=v["name"].orEmpty(),status=v["status"].orEmpty(),quantityUnit=v["quantity"]?.takeIf{it.isNotBlank()},text=v["text"]?:e.text)
 e.params.forEach{(k,value)->result=if(value is JsonPrimitive&&value.doubleOrNull!=null)result.withNum(k,parseNumber(v.getValue(k))!!)else result.withStr(k,v[k].orEmpty())}
 require(listOf("widthMm","heightMm","radiusMm","spacingMm","crownMm").all{!result.params.containsKey(it)||(it=="heightMm"&&result.kind=="elevation")||result.num(it)>0}){"Maße und Pflanzabstände müssen positiv sein"};vm.update(result)
 }}
 "points"->FormDialog("Eckpunkte (mm)",e.points.flatMapIndexed{i,p->listOf(Field("x$i","Punkt ${i+1}: X",fmt(p.x),true),Field("y$i","Punkt ${i+1}: Y",fmt(p.y),true))},{dialog=""}){v->vm.update(e.copy(points=e.points.indices.map{i->Vec(parseNumber(v.getValue("x$i"))!!,parseNumber(v.getValue("y$i"))!!)}))}
 "style"->FormDialog("Linien und Texte",listOf(Field("stroke","Linienfarbe (#RRGGBB)",e.style.stroke),Field("fill","Füllfarbe (#RRGGBB, leer = keine)",e.style.fill.orEmpty()),Field("width","Linienstärke Papier in mm",fmt(e.style.widthMm),true,true),Field("opacity","Deckkraft 0–1",fmt(e.style.opacity),true),Field("textSize","Texthöhe Papier in mm",fmt(e.style.textPaperMm),true,true),Field("rotation","Drehung in Grad",fmt(e.rotation),true),Field("align","Textausrichtung",e.style.align,choices=listOf("left","center","right")),Field("font","Schrift",if(e.style.bold&&e.style.italic)"bolditalic"else if(e.style.bold)"bold"else if(e.style.italic)"italic"else"normal",choices=listOf("normal","bold","italic","bolditalic")),Field("frame","Rahmen",if(e.style.frame)"ja"else"nein",checkbox=true),Field("background","Texthintergrund (#RRGGBB, optional)",e.style.background.orEmpty())),{dialog=""}){v->listOf("stroke","fill","background").forEach{require(v[it].isNullOrBlank()||Regex("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?").matches(v[it]!!)){"Ungültige Farbe"}};require(parseNumber(v["opacity"]!!)!! in 0.0..1.0);vm.update(transform(e,angle=parseNumber(v.getValue("rotation"))!!-e.rotation,center=e.points.firstOrNull()?:Vec()).copy(style=e.style.copy(stroke=v.getValue("stroke"),fill=v["fill"]?.takeIf{it.isNotBlank()},widthMm=parseNumber(v.getValue("width"))!!,opacity=parseNumber(v.getValue("opacity"))!!,textPaperMm=parseNumber(v.getValue("textSize"))!!,align=v.getValue("align"),bold=v["font"].orEmpty().contains("bold"),italic=v["font"].orEmpty().contains("italic"),frame=v["frame"]=="ja",background=v["background"]?.takeIf{it.isNotBlank()})))}
 "textLink"->ChoiceDialog("Textquelle ({name}, {widthMm}, {flaeche_m2}, {dicke_mm})",d.entities.filter{it.id!=e.id}.map{it.name.ifBlank{it.kind}},{dialog=""}){i->vm.update(e.withStr("sourceId",d.entities.filter{it.id!=e.id}[i].id))}
 "layer"->ChoiceDialog("Layer",d.layers.map{it.name},{dialog=""},selectedIndex=d.layers.indexOfFirst{it.id==e.layerId}.takeIf{it>=0}){i->vm.modifySelected{it.copy(layerId=d.layers[i].id)}}
 "transform"->FormDialog("Auswahl transformieren",listOf(Field("dx","Verschieben X (mm)","0",true),Field("dy","Verschieben Y (mm)","0",true),Field("angle","Drehen (Grad)","0",true),Field("scale","Skalierungsfaktor","1",true,true),Field("mirror","Spiegeln an vertikaler Achse","nein",checkbox=true)),{dialog=""}){v->val chosen=d.entities.filter{it.id in vm.selected};val groupCenter=Bounds.of(chosen.flatMap{it.points}).center;vm.modifySelected{obj->val center=if(chosen.size==1)smartPivot(obj)else groupCenter;transform(obj,Vec(parseNumber(v["dx"]!!)!!,parseNumber(v["dy"]!!)!!),parseNumber(v["angle"]!!)!!,parseNumber(v["scale"]!!)!!,v["mirror"]=="ja",center)}}
 "symbol"->FormDialog("Als Bauteil speichern",listOf(Field("name","Bauteilname",e.name.ifBlank{"Eigenes Bauteil"})),{dialog=""}){vm.saveSymbol(it.getValue("name"))}
 "pattern"->{val pattern=e.pattern?:Pattern();FormDialog("Verlegemuster",listOf(Field("width","Plattenlänge mm",fmt(pattern.widthMm),true,true),Field("height","Plattenbreite mm",fmt(pattern.heightMm),true,true),Field("joint","Fuge mm",fmt(pattern.jointMm),true),Field("angle","Winkel: 45 = diagonal",fmt(pattern.angle),true),Field("offset","Versatz: 0 = Kreuzfuge, 0,5 = Läufer",fmt(pattern.offset),true),Field("x","Ursprung X mm",fmt(pattern.origin.x),true),Field("y","Ursprung Y mm",fmt(pattern.origin.y),true)),{dialog=""}){v->fun n(k:String):Double { return parseNumber(v.getValue(k))!! }
require(n("joint")>=0);vm.update(e.copy(pattern=Pattern(n("width"),n("height"),n("joint"),n("angle"),n("offset"),Vec(n("x"),n("y")))))}}
 "strata"->FormDialog("Schichtaufbau",e.strata.flatMapIndexed{i,s->listOf(Field("name$i","Schicht ${i+1}: Material",s.name),Field("thickness$i","Dicke mm",fmt(s.thicknessMm),true,true))},{dialog=""}){v->vm.update(e.copy(strata=e.strata.mapIndexed{i,s->s.copy(name=v.getValue("name$i"),thicknessMm=parseNumber(v.getValue("thickness$i"))!!)}))}
 }
}
fun paramLabel(key:String)=mapOf("radiusMm" to "Radius mm","widthMm" to "Breite mm","heightMm" to "Höhe mm / Kote mm","crownMm" to "Kronendurchmesser mm","rootMm" to "Wurzelschutzdurchmesser mm (0 = aus)","pitMm" to "Baumgrube mm (0 = aus)","trunkMm" to "Stammdurchmesser mm","spacingMm" to "Pflanzabstand mm","percent" to "Manuelles Gefälle %","mode" to "Modus","unit" to "Anzeige: % / cm/m / 1:x","startHeightMm" to "Starthöhe mm","endHeightMm" to "Endhöhe mm","offsetMm" to "Maßlinienabstand mm","startAngle" to "Startwinkel Grad","sweepAngle" to "Bogenwinkel Grad","direction" to "Blickrichtung: 1 / -1","depthMm" to "Tiefe mm","plantName" to "Pflanzenname","plantHeightMm" to "Pflanzenhöhe mm","trunkCircumferenceMm" to "Stammumfang mm","rootBallMm" to "Ballengröße mm","count" to "Stückzahl")[key]?:key
