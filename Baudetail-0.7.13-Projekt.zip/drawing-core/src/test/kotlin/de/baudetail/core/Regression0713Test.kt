package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Assert.*
import org.junit.Test

class Regression0713Test {
 @Test fun verticalDimensionTextIsSelectableAcrossItsPrintedWidth() {
  val d=Drawing()
  val e=Entity(kind="dimension",points=listOf(Vec(0.0,0.0),Vec(0.0,600.0)))
   .withStr("mode","vertical").withStr("unit","cm").withNum("offsetMm",100.0)
  val label=dimensionLabel(e,d)
  val size=e.style.textPaperMm*d.sheet.scale
  val textAt=dimensionTextPosition(e.points[0],e.points[1],Vec(100.0,0.0),Vec(100.0,600.0),label,size)
  assertTrue(hitTest(textAt+Vec(label.length*size*.45,-size*.4),e,d,5.0))
 }
 @Test fun dimensionTextDoesNotHaveHugeInvisibleHitbox() {
  val d=Drawing()
  val e=Entity(kind="dimension",points=listOf(Vec(0.0,0.0),Vec(0.0,600.0)))
   .withStr("mode","vertical").withStr("unit","cm").withNum("offsetMm",100.0)
  assertFalse(hitTest(Vec(500.0,300.0),e,d,5.0))
 }
}
