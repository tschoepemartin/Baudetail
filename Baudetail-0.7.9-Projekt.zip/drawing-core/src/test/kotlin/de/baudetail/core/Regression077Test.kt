package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.*
import org.junit.Test

class Regression077Test {
 @Test fun planEndsAtSameEdgeAsSectionWithoutChangingElevation() {
  val e=Entity(kind="stack",points=listOf(Vec(150.0,230.0)),params=buildJsonObject {
   put("widthMm",1200.0);put("topDepthMm",1800.0);put("buildUpTopRotationDelta",90.0)
  },strata=listOf(Stratum(thicknessMm=80.0),Stratum(thicknessMm=40.0)))
  val section=Drawing().withViewMode("section")
  val plan=Drawing().withViewMode("top")
  assertEquals(viewBounds(e,section).max.x,viewBounds(e,plan).max.x,.001)
  val resized=e.withNum("widthMm",1000.0).withNum("buildUpTopLengthOffsetMm",100.0)
  assertEquals(viewBounds(e,section).max.x,viewBounds(resized,section).max.x,.001)
  assertEquals(viewBounds(e,section).min.y,viewBounds(resized,section).min.y,.001)
  assertEquals(viewBounds(e,plan).center.y,viewBounds(resized,plan).center.y,.001)
 }
 @Test fun labelIsNotInteractiveWhenHiddenInPlan() {
  val e=Entity(kind="stack",points=listOf(Vec()),params=buildJsonObject {
   put("widthMm",1000.0);put("topDepthMm",1500.0);put("labelEnabled","true");put("labelVisibleSection","true");put("labelVisibleTop","false")
  })
  assertTrue(labelActive(e,Drawing().withViewMode("section")))
  assertFalse(labelActive(e,Drawing().withViewMode("top")))
 }
 @Test fun dualPdfSheetContainsTwoIndependentViewports() {
  val d=Drawing()
  val nodes=Scene.paperDual(d,Project(drawings=listOf(d)),Vec(10.0,10.0),Vec(153.5,10.0),20.0,50.0,Vec(),Vec())
  assertTrue(nodes.filterIsInstance<Primitive.Text>().any{it.value.contains("Schnitt")})
  assertTrue(nodes.filterIsInstance<Primitive.Text>().any{it.value.contains("Draufsicht")})
  assertEquals(2,nodes.filterIsInstance<Primitive.Group>().size)
 }
 @Test fun oldStairCanDisplayPlainLabel() {
  val e=Entity(kind="assembly",name="Blockstufenanlage",params=buildJsonObject {put("assemblyType","stair");put("labelEnabled","false")})
  assertTrue(labelActive(e,Drawing().withViewMode("section")))
  assertFalse(labelActive(e,Drawing().withViewMode("top")))
 }
}
