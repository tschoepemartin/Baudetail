# Baudetail 0.8.22

- Stufengefälle, freie Gefälle und Pflastergefälle benutzen denselben Zeichner und denselben Beschriftungsabstand (1,6 Papier-mm bei 100 %).
- Der Größenregler steuert jetzt auch beim automatisch erzeugten Stufengefälle den tatsächlich gezeichneten Pfeil und die Prozentzahl.
- Der Regler ist für alle Gefällearten als Gefällepfeilgröße beschriftet.
- Gespeicherte Maßobjekte werden beim Rendern mit den neuen Regeln angezeigt; keine Neuanlage erforderlich.
- Druckmaßstab und Exportgeometrie bleiben unangetastet.
