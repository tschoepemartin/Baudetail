package de.baudetail.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject

/** Offline search of the original Bruns 2026/2027 plant names bundled with BauDetail. */
private data class BrunsPlant(val botanical:String,val german:String,val number:String)

@Composable
fun BrunsPlantPicker(onDismiss:()->Unit,onSelect:(String)->Unit) {
 val context=LocalContext.current
 val plants=remember {
  runCatching {
   val source=context.assets.open("bruns-pflanzen-2026-2027.json").bufferedReader().use{it.readText()}
   val entries=JSONObject(source).getJSONArray("pflanzen")
   (0 until entries.length()).map { index ->
    val entry=entries.getJSONObject(index)
    BrunsPlant(entry.optString("botanisch"),entry.optString("deutsch"),entry.optString("pflanzenNummer"))
   }
  }.getOrDefault(emptyList())
 }
 var query by remember { mutableStateOf("") }
 val matches=remember(plants,query) {
  if(query.isBlank()) plants.take(80)
  else plants.asSequence().filter {
   it.botanical.contains(query,true)||it.german.contains(query,true)||it.number.contains(query,true)
  }.take(100).toList()
 }
 AlertDialog(onDismissRequest=onDismiss,title={Text("Bruns-Pflanzenkatalog 2026/2027")},
  text={Column(Modifier.fillMaxWidth().heightIn(max=490.dp)) {
   OutlinedTextField(value=query,onValueChange={query=it},label={Text("Pflanzenname oder Artikelnummer")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Text("${matches.size} Treffer angezeigt · ${plants.size} Einträge offline",style=MaterialTheme.typography.bodySmall)
   LazyColumn(Modifier.weight(1f)) {
    items(matches,key={it.number+it.botanical}) { plant ->
     TextButton(onClick={onSelect(plant.botanical.ifBlank { plant.german })},modifier=Modifier.fillMaxWidth()) {
      Column(Modifier.fillMaxWidth()) {
       Text(plant.botanical)
       if(plant.german.isNotBlank())Text(plant.german,style=MaterialTheme.typography.bodySmall)
       Text("Bruns-Nr. ${plant.number}",style=MaterialTheme.typography.labelSmall)
      }
     }
    }
   }
  }},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})
}
