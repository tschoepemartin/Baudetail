# Baudetail 0.6.9

Gezielter Korrekturstand auf Basis 0.6.8.

- Bord-Snap: normale Eck-/Mittelpunkt-Sensitivität wiederhergestellt; OK Bord und unterer Phasenpunkt als gezielt magnetische Snap-Punkte. Die schräge Phase bleibt ohne Snap-Segment.
- Draufsicht: section-basierte Smart-Beziehungen werden als echte Installationskette behandelt; Bord/Kasten/Bord bleibt vor der Treppe in Reihenfolge.
- KG2000: Abgang aus dem Mittelpunkt des Einlauf-/Sinkkastens nach links; Folgeteile bleiben über Connectoren in Reihenfolge.
- Belastungsklassen (A15/B125/...) sind reine Eigenschaften und werden nicht auf dem Gitterrost gezeichnet.
- Treppe: UNTEN/OBEN kleiner und vollständig innerhalb der Treppengeometrie.
- Legende: eigenes Bearbeitungsmenü für Sichtbarkeit, Text, Farbe und Reihenfolge; KG2000 DN wird aufgenommen.
- Nach dem Platzieren eines Objekts springt die Bedienung automatisch auf Auswahl zurück.
- Höhenkoten: Bezugsspitze liegt exakt auf dem Referenzpunkt; relative Höhenkoten können nach dem Setzen verschoben und an der neuen Position neu an die Oberfläche gebunden werden.
- versionCode 33, versionName 0.6.9.
