package de.baudetail.core

import de.baudetail.geometry.*
import kotlinx.serialization.json.*
import kotlin.math.*

/** 2.5D surface attached to the actual plan footprint, never to the section Y axis. */
data class PlanSurface(val source:Entity,val polygon:List<Vec>)

/** A common 2D footprint for library components. Recognition does not imply a
 * known elevation: an object without an explicit datum remains unmeasured. */
private fun libraryPlanFootprint(e:Entity,d:Drawing):List<Vec> {
 if(e.kind!="component")return emptyList()
 val top=d.withViewMode("top")
 // Prefer the semantic outside contour; a channel's connector/reference
 // points may be collinear and therefore cannot describe a surface.
 val outline=smartSnapOutline(e,top)
 if(outline.size>=3 && abs(polygonSignedArea(outline))>1.0)return outline
 // Use real component edges as a fallback, never decorative hatch lines.
 val edgePoints=smartSnapSegments(e,top).flatMap { listOf(it.first,it.second) }
 if(edgePoints.size<3)return emptyList()
 return convexFootprint(edgePoints)
}
/** Convex construction footprint from actual segment endpoints. Unlike an
 * axis-aligned bounds rectangle, this does not inflate rotated drains. */
private fun convexFootprint(points:List<Vec>):List<Vec> {
 val sorted=points.distinctBy { Pair(round(it.x*1000),round(it.y*1000)) }
  .sortedWith(compareBy<Vec> { it.x }.thenBy { it.y })
 if(sorted.size<3)return emptyList()
 fun cross(a:Vec,b:Vec,c:Vec)=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)
 val lower=mutableListOf<Vec>()
 for(p in sorted){while(lower.size>=2 && cross(lower[lower.size-2],lower.last(),p)<=0)lower.removeAt(lower.lastIndex);lower.add(p)}
 val upper=mutableListOf<Vec>()
 for(p in sorted.asReversed()){while(upper.size>=2 && cross(upper[upper.size-2],upper.last(),p)<=0)upper.removeAt(upper.lastIndex);upper.add(p)}
 val hull=lower.dropLast(1)+upper.dropLast(1)
 return hull.takeIf { it.size>=3 && abs(polygonSignedArea(it))>1.0 }?:emptyList()
}

private fun polygonSignedArea(vertices:List<Vec>):Double = vertices.indices.sumOf { i ->
 val a=vertices[i];val b=vertices[(i+1)%vertices.size];a.x*b.y-b.x*a.y
}/2.0


fun planFootprint(e:Entity,d:Drawing):List<Vec> = when {
 isStair(e) -> smartSnapOutline(e,d.withViewMode("top"))
 e.isParametricBuildUp() -> rectangle(Vec(),Vec(e.num("planGraphicWidthMm",e.num("widthMm",1500.0)),e.num("topDepthMm",1000.0))).map{buildUpPlanOrigin(e)+it.rotate(buildUpPlanAngle(e))}
 e.str("grassObject")=="true" -> resolvedPoints(e,d.withViewMode("top"))
 e.kind=="component" -> libraryPlanFootprint(e,d)
 e.kind in setOf("area","polygon","rect","paving","path") -> resolvedPoints(e,d.withViewMode("top"))
 else -> emptyList()
}

private fun insidePolygon(p:Vec,polygon:List<Vec>):Boolean {
 if(polygon.size<3)return false
 var inside=false
 for(i in polygon.indices){val a=polygon[i];val b=polygon[(i+1)%polygon.size]
  if(closestOnSegment(p,a,b).distance(p)<0.01)return true
  if((a.y>p.y)!=(b.y>p.y) && p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside
 }
 return inside
}

fun planSurfaceAt(point:Vec,d:Drawing):PlanSurface? {
 val hits=d.entities.asReversed().mapNotNull{e->
  if(!visibleIn(e,d)||e.kind in setOf("elevation","plan-height"))null
  else planFootprint(e,d).takeIf{insidePolygon(point,it)}?.let{PlanSurface(e,it)}
 }
 // A narrow drain or step should not disappear under an overlapping paving
 // polygon. Prefer the smallest actual construction footprint at the point.
 return hits.minByOrNull{kotlin.math.abs(polygonSignedArea(it.polygon))}
}

/** Local coordinates travel with the construction when moved or rotated. */
/** Describes the actual construction under a marker, including individual treads. */
fun planSurfaceDescription(point:Vec,d:Drawing):String {
 val surface=planSurfaceAt(point,d)?:return "Keine Oberfläche erkannt"
 val source=surface.source
 if(isStair(source)) {
  val local=stairPlanLocalPoint(source,point)
  val index=kotlin.math.floor((local.x/stairGoing(source).coerceAtLeast(1.0)).coerceAtLeast(0.0)).toInt().coerceIn(0,stairCount(source)-1)
  return "Blockstufenanlage · Stufe ${index+1} von ${stairCount(source)}"
 }
 val name=source.name.ifBlank { when {source.isParametricBuildUp()->"Pflasteraufbau";source.str("grassObject")=="true"->"Rasenfläche";else->source.kind} }
 return if(source.kind=="component") when(source.smartFamily()) {
  "channel" -> "$name · Oberkante Rost/Abdeckung"
  "channel_box" -> "$name · Oberkante Abdeckung"
  "pipe" -> "$name · Rohrbauteil (Höhenbezug prüfen)"
  "curb" -> "$name · Oberkante"
  else -> name
 } else name
}

fun planLocalPoint(source:Entity,world:Vec):Vec {
 val origin=if(source.isParametricBuildUp())buildUpPlanOrigin(source) else if(source.kind=="component")smartViewOrigin(source,"top") else source.points.firstOrNull()?:Vec()
 val angle=if(source.isParametricBuildUp())buildUpPlanAngle(source) else if(source.kind=="component")smartViewRotation(source,"top") else source.rotation
 return (world-origin).rotate(-angle)
}
fun planWorldPoint(source:Entity,local:Vec):Vec {
 val origin=if(source.isParametricBuildUp())buildUpPlanOrigin(source) else if(source.kind=="component")smartViewOrigin(source,"top") else source.points.firstOrNull()?:Vec()
 val angle=if(source.isParametricBuildUp())buildUpPlanAngle(source) else if(source.kind=="component")smartViewRotation(source,"top") else source.rotation
 return origin+local.rotate(angle)
}

/** Plan Z in mm. A defined datum and longitudinal slope describe a plane.
 * Optional measured grass points override that plane using exact matches and
 * inverse-distance interpolation, pending a future triangulated terrain model. */
/** Explicit four-corner plan height geometry (millimetres), rotated with its object.
 * The corners are ordered in local plan coordinates, not screen coordinates. */
private fun cornerPlanHeightMm(source:Entity,world:Vec,d:Drawing):Double? {
 val keys=listOf("planZTopLeftMm","planZTopRightMm","planZBottomLeftMm","planZBottomRightMm")
 val heights=keys.map { (source.params[it] as? JsonPrimitive)?.doubleOrNull }
 if(heights.any{it==null})return null
 val polygon=planFootprint(source,d)
 if(polygon.size<3)return null
 val localPolygon=polygon.map{planLocalPoint(source,it)}
 val bounds=Bounds.of(localPolygon)
 if(bounds.width<0.001||bounds.height<0.001)return null
 val p=planLocalPoint(source,world)
 val x=((p.x-bounds.min.x)/bounds.width).coerceIn(0.0,1.0)
 val y=((p.y-bounds.min.y)/bounds.height).coerceIn(0.0,1.0)
 val top=heights[0]!!*(1-x)+heights[1]!!*x
 val bottom=heights[2]!!*(1-x)+heights[3]!!*x
 return top*(1-y)+bottom*y
}

fun planSurfaceHeightMm(source:Entity,world:Vec,d:Drawing):Double? {
 cornerPlanHeightMm(source,world,d)?.let{return it}
 if(isStair(source))return source.params["planHeightMm"]?.let{(it as? JsonPrimitive)?.doubleOrNull}?.plus(stairPlanRelativeZMm(source,world))
 // Generic library components are identifiable, but cannot inherit an arbitrary
 // paving slope. Only an explicit surface datum and optional component slope
 // permit a numerical Z. Never synthesize a height from the drawing origin.
 if(source.kind=="component") {
  // Placement heights are authoritative for all library families, not only
  // paving. A component without any declared datum must remain unknown.
  val base=(source.params["planHeightMm"] as? JsonPrimitive)?.doubleOrNull
   ?: (source.params["surfaceHeightMm"] as? JsonPrimitive)?.doubleOrNull
   ?: source.placement.topMm
   ?: source.placement.zMm
   ?: return null
  val local=(world-smartViewOrigin(source,"top")).rotate(-smartViewRotation(source,"top"))
  return base-local.x*source.num("surfaceSlopePct",0.0)/100.0
   -local.y*source.num("surfaceCrossSlopePct",0.0)/100.0
 }
 val local=planLocalPoint(source,world)
 val slope=buildUpSlopePercent(source)
 val fixedRight=source.str("buildUpSlopeFixedSide","left")=="right"
 val length=if(source.str("grassObject")=="true")source.num("grassRealLengthMm",source.num("grassSectionLengthMm",1000.0)) else buildUpRealLengthMm(source)
 val footprintLength=if(source.isParametricBuildUp())source.num("planGraphicWidthMm",source.num("widthMm",1500.0)).coerceAtLeast(1.0) else Bounds.of(planFootprint(source,d.withViewMode("top"))).width.coerceAtLeast(1.0)
 val longitudinalDepth=if(source.isParametricBuildUp())source.num("topDepthMm",1000.0).coerceAtLeast(1.0) else footprintLength
 val normalized=(if(source.isParametricBuildUp())local.y/longitudinalDepth else local.x/footprintLength).coerceIn(0.0,1.0)
 val fixedFraction=source.num("planFixedFraction",if(fixedRight)1.0 else 0.0).coerceIn(0.0,1.0)
 // Independent local axes: longitudinal slope follows local X, crossfall local Y.
 // Zero crossfall guarantees an equal elevation across each transverse edge.
 val depth=source.num("topDepthMm",source.num("planGraphicDepthMm",1000.0)).coerceAtLeast(1.0)
 val crossSlope=source.num("planCrossSlopePct",0.0).coerceIn(-100.0,100.0)
 val crossFixed=source.num("planCrossFixedFraction",0.0).coerceIn(0.0,1.0)
 val drop=(normalized-fixedFraction)*length*slope/100.0 +
   ((if(source.isParametricBuildUp())local.x/footprintLength else local.y/depth).coerceIn(0.0,1.0)-crossFixed)*(if(source.isParametricBuildUp())footprintLength else depth)*crossSlope/100.0
 val base=source.params["planHeightMm"]?.let { (it as? JsonPrimitive)?.doubleOrNull }
 val points=(source.params["grassHeights"] as? JsonArray)?.mapNotNull{v->
  val o=v as? JsonObject?:return@mapNotNull null
  val x=(o["x"] as? JsonPrimitive)?.doubleOrNull?:return@mapNotNull null
  val y=(o["y"] as? JsonPrimitive)?.doubleOrNull?:return@mapNotNull null
  val z=(o["z"] as? JsonPrimitive)?.doubleOrNull?:return@mapNotNull null
  Vec(x,y) to z
 }.orEmpty()
 if(points.isEmpty())return base?.minus(drop)
 val exact=points.firstOrNull{it.first.distance(world)<0.01}
 if(exact!=null)return exact.second
 var weight=0.0;var sum=0.0
 for((p,z) in points){val w=1.0/(p.distance(world).coerceAtLeast(1.0).let{it*it});weight+=w;sum+=w*z}
 return if(weight>0.0)sum/weight else base?.minus(drop)
}

fun planElevationAnchor(point:Vec,d:Drawing):Anchor? {
 val surface=planSurfaceAt(point,d)?:return null
 val local=if(isStair(surface.source)) stairPlanLocalPoint(surface.source,point) else planLocalPoint(surface.source,point)
 return Anchor(surface.source.id,reference="planSurface",view="top",offset=local)
}
fun planElevationPoint(e:Entity,d:Drawing):Vec? {
 val a=e.anchors.firstOrNull{it.reference=="planSurface"}?:return null
 val source=d.entities.find{it.id==a.entityId}?:return null
 return if(isStair(source))assemblyPoint(source,a.offset,"top") else planWorldPoint(source,a.offset)
}
fun planElevationHeight(e:Entity,d:Drawing):Double? {
 val a=e.anchors.firstOrNull{it.reference=="planSurface"}?:return null
 val source=d.entities.find{it.id==a.entityId}?:return null
 return planSurfaceHeightMm(source,e.points.firstOrNull()?:return null,d)
}

/** Project a section surface marker to the corresponding plan construction edge.
 * Only geometrically anchored markers can be projected; free section coordinates
 * are deliberately not guessed. Section distances use normalized real station. */
fun sectionElevationPlanPoint(e:Entity,d:Drawing):Vec? {
 if(e.kind!="elevation" || e.str("elevationCreatedView", "section")!="section")return null
 val a=e.anchors.firstOrNull{it.reference=="elevationSurface" && it.view=="section"}?:return null
 val source=d.entities.find{it.id==a.entityId}?:return null
 val fraction=a.fraction.coerceIn(0.0,1.0)
 if(source.isParametricBuildUp()) {
  val x=source.num("planGraphicWidthMm",source.num("widthMm",1500.0))*fraction
  val y=source.num("topDepthMm",1000.0)
  return planWorldPoint(source,Vec(x,y))
 }
 if(source.str("grassObject")=="true") {
  val footprint=planFootprint(source,d.withViewMode("top"))
  if(footprint.size<3)return null
  val edges=footprint.indices.map{i->footprint[i] to footprint[(i+1)%footprint.size]}
  val edge=edges.maxByOrNull{(u,v)->(u.x+v.x)/2.0}?:return null
  return edge.first+(edge.second-edge.first)*fraction
 }
 return null
}

/** Relative level on the same physical paving surface, independent of viewport. */
fun planSlopeDifferenceMm(source:Entity,from:Vec,to:Vec,d:Drawing):Double {
 val explicitFrom=cornerPlanHeightMm(source,from,d)
 val explicitTo=cornerPlanHeightMm(source,to,d)
 if(explicitFrom!=null&&explicitTo!=null)return explicitTo-explicitFrom
 if(isStair(source))return stairPlanRelativeZMm(source,to)-stairPlanRelativeZMm(source,from)
 if(source.kind=="component") {
  val a=planLocalPoint(source,from);val b=planLocalPoint(source,to)
  return -(b.x-a.x)*source.num("surfaceSlopePct",0.0)/100.0
   -(b.y-a.y)*source.num("surfaceCrossSlopePct",0.0)/100.0
 }
 val a=planLocalPoint(source,from);val b=planLocalPoint(source,to)
 val graphic=if(source.isParametricBuildUp())source.num("planGraphicWidthMm",source.num("widthMm",1500.0)).coerceAtLeast(1.0) else Bounds.of(planFootprint(source,d.withViewMode("top"))).width.coerceAtLeast(1.0)
 val real=if(source.str("grassObject")=="true")source.num("grassRealLengthMm",source.num("grassSectionLengthMm",1000.0)) else buildUpRealLengthMm(source)
 return if(source.isParametricBuildUp()) {
  val depth=source.num("topDepthMm",1000.0).coerceAtLeast(1.0)
  -(b.y-a.y)*real/depth*buildUpSlopePercent(source)/100.0-(b.x-a.x)*source.num("planCrossSlopePct",0.0)/100.0
 } else -(b.x-a.x)*real/graphic*buildUpSlopePercent(source)/100.0-(b.y-a.y)*source.num("planCrossSlopePct",0.0)/100.0
}
/** A shared construction edge is an elevation constraint, not merely a visual snap.
 * The contact point is identical in world coordinates on both surfaces. */
private data class SurfaceContact(val a:Vec,val b:Vec,val gap:Double)
private fun sharedSurfaceContact(first:List<Vec>,second:List<Vec>):SurfaceContact? {
 if(first.size<3||second.size<3)return null
 var best:SurfaceContact?=null
 fun examine(p:Vec,polygon:List<Vec>,reverse:Boolean) {
  for(i in polygon.indices){
   val q=closestOnSegment(p,polygon[i],polygon[(i+1)%polygon.size]);val gap=p.distance(q)
   if(best==null||gap<best!!.gap)best=if(reverse)SurfaceContact(q,p,gap) else SurfaceContact(p,q,gap)
  }
 }
 for(p in first)examine(p,second,false)
 for(p in second)examine(p,first,true)
 // Also detect partial overlaps whose endpoints do not coincide.
 for(i in first.indices)for(j in second.indices){
  val a=first[i];val b=first[(i+1)%first.size];val c=second[j];val d=second[(j+1)%second.size]
  val mid=(a+b)*0.5;val near=closestOnSegment(mid,c,d)
  val gap=mid.distance(near)
  if(best==null||gap<best!!.gap)best=SurfaceContact(mid,near,gap)
 }
 return best?.takeIf{it.gap<=2.0}
}
private fun declaredSurfaceHeight(source:Entity,at:Vec,d:Drawing):Double? = planSurfaceHeightMm(source,at,d)
private fun connectionOffset(source:Entity):Double=source.num("connectionHeightOffsetMm",0.0)
/** Resolve height from a known datum through snapped construction edges.
 * A directly declared datum takes precedence; explicit connection offsets permit
 * a deliberate step between otherwise coincident edges. */
fun connectedSurfaceHeightMm(source:Entity,at:Vec,d:Drawing):Double? {
 declaredSurfaceHeight(source,at,d)?.let{return it}
 val surfaces=d.entities.mapNotNull{e->
  if(!visibleIn(e,d)||e.kind in setOf("plan-height","elevation"))null
  else planFootprint(e,d).takeIf{it.size>=3}?.let{PlanSurface(e,it)}
 }
 val start=surfaces.indexOfFirst{it.source.id==source.id}
 if(start<0)return null
 data class Node(val index:Int,val at:Vec,val height:Double,val depth:Int)
 val visited=mutableSetOf<Int>()
 val queue=ArrayDeque<Node>()
 // Each leader and explicit surface datum is a seed; propagation across each
 // contact accounts for both surfaces' longitudinal/cross slopes.
 for(i in surfaces.indices){
  val e=surfaces[i].source
  val datumPoint=surfaces[i].polygon.first()
  val explicit=declaredSurfaceHeight(e,datumPoint,d)
  if(explicit!=null)queue.add(Node(i,datumPoint,explicit,0))
  for(leader in d.entities.filter{it.kind=="plan-height"&&it.str("elevationRole")=="leader"}){
   val lp=leader.points.firstOrNull()?:continue
   val ref=leaderReferenceOnSurface(lp,surfaces[i])?:continue
   queue.add(Node(i,ref,leader.num("heightMm"),0))
  }
 }
 while(queue.isNotEmpty()){
  val n=queue.removeFirst()
  if(!visited.add(n.index))continue
  val current=surfaces[n.index]
  if(n.index==start)return n.height+planSlopeDifferenceMm(source,n.at,at,d)
  if(n.depth>=surfaces.size)continue
  for(i in surfaces.indices){
   if(i in visited||i==n.index)continue
   val next=surfaces[i]
   val contact=sharedSurfaceContact(current.polygon,next.polygon)?:continue
   val z=n.height+planSlopeDifferenceMm(current.source,n.at,contact.a,d)
    +connectionOffset(next.source)-connectionOffset(current.source)
   queue.add(Node(i,contact.b,z,n.depth+1))
  }
 }
 return null
}
/** A leader can sit on a neighbouring drain, but only within 150 mm of the surface edge. */
private fun leaderReferenceOnSurface(point:Vec,surface:PlanSurface):Vec? {
 if(insidePolygon(point,surface.polygon))return point
 val nearest=surface.polygon.indices.map{i->closestOnSegment(point,surface.polygon[i],surface.polygon[(i+1)%surface.polygon.size])}.minByOrNull{it.distance(point)}?:return null
 return nearest.takeIf{it.distance(point)<=150.0}
}
fun planRelativeHeightMm(marker:Entity,d:Drawing):Double? {
 val target=marker.points.firstOrNull()?:return null
 val surface=planSurfaceAt(target,d)?:return null
 val requested=marker.str("planLeaderId")
 val leaders=d.entities.filter{it.kind=="plan-height"&&it.str("elevationRole")=="leader"&&(requested.isBlank()||it.id==requested)}
 val match=leaders.mapNotNull{leader->
  val lp=leader.points.firstOrNull()?:return@mapNotNull null
  val reference=leaderReferenceOnSurface(lp,surface)?:return@mapNotNull null
  Triple(leader,reference,lp.distance(reference))
 }.minByOrNull{it.third}
 if(match!=null)return match.first.num("heightMm")+planSlopeDifferenceMm(surface.source,match.second,target,d)+marker.num("heightOffsetMm")
 // An explicit leader selection must never silently use a different datum.
 if(requested.isNotBlank())return null
 return connectedSurfaceHeightMm(surface.source,target,d)?.plus(marker.num("heightOffsetMm"))
}
