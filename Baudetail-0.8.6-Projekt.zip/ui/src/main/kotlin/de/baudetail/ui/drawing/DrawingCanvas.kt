package de.baudetail.ui.drawing

import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.background
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.export.CanvasRenderer
import java.io.File
import kotlin.math.*

@OptIn(ExperimentalComposeUiApi::class)
@Composable fun DrawingCanvas(
 d:Drawing,p:Project,asset:(String)->File,tool:String,selected:Set<String>,preview:List<Vec>,grid:Boolean,penMode:Boolean,fit:Int,
 modifier:Modifier=Modifier,onTap:(Vec,Boolean)->Unit,onFreehand:(List<Vec>)->Unit,onMove:(Vec,SnapResult?,Vec?,Double,String?)->Unit,onDeleteRequested:()->Unit={},onCoordinates:(Vec,Double)->Unit,onCreate:(Entity)->Unit,onChange:(Entity)->Unit
){
 var zoom by rememberSaveable(d.id){mutableDoubleStateOf(0.06)};var ox by rememberSaveable(d.id){mutableDoubleStateOf(60.0)};var oy by rememberSaveable(d.id){mutableDoubleStateOf(60.0)}
 var width by remember{mutableIntStateOf(1)};var height by remember{mutableIntStateOf(1)}
 val renderer=remember{CanvasRenderer(asset)}
 val density=LocalDensity.current
 val touchPx=24f*density.density
 val labelPx=14f*density.density*density.fontScale
 val gripPx=7f*density.density
 val rotationOffset=36f*density.density
 val input=d.input()
 var live by remember(d.id,tool){mutableStateOf<Entity?>(null)}
 var snapMark by remember(d.id,tool){mutableStateOf<SnapResult?>(null)}
 var angleHint by remember(d.id,tool){mutableStateOf<String?>(null)}
 var angleHintAt by remember(d.id,tool){mutableStateOf(Vec())}
 var handle by remember{mutableStateOf("")};var lockedDragId by remember{mutableStateOf<String?>(null)}
 var original by remember{mutableStateOf<Entity?>(null)}
 var inlineLegendId by remember{mutableStateOf<String?>(null)}
 var inlineLegendKey by remember{mutableStateOf<String?>(null)}
 var inlineLegendText by remember{mutableStateOf("")}
 var inlineLegendScreen by remember{mutableStateOf(Vec())}
 val inlineFocus=remember{FocusRequester()}
 fun caught(v:Vec,previous:Vec?=null,exclude:Set<String> = emptySet()):Vec {val result=snap(v,d.copy(entities=d.entities.filterNot{it.id in exclude}),input.options(touchPx/zoom),previous);snapMark=result.takeIf{it.reason.isNotEmpty()};return result.point}
 var down by remember{mutableStateOf(Vec())};var last by remember{mutableStateOf(Vec())};var downWorld by remember{mutableStateOf(Vec())};var moved by remember{mutableStateOf(false)};var pinch by remember{mutableStateOf(false)};var panMode by remember{mutableStateOf(false)};var dragSnap by remember{mutableStateOf<SnapResult?>(null)};var dragSourceOffset by remember{mutableStateOf<Vec?>(null)}
 var previousDistance by remember{mutableDoubleStateOf(1.0)};var previousCenter by remember{mutableStateOf(Vec())};var downTime by remember{mutableLongStateOf(0)};var stroke by remember{mutableStateOf<List<Vec>>(emptyList())};var dragDelta by remember{mutableStateOf(Vec())};var dragRotationDelta by remember{mutableDoubleStateOf(0.0)};var dragging by remember{mutableStateOf(false)}
 val scene=remember(d,p){Scene.drawing(d,p)}
 fun world(v:Vec)=Vec((v.x-ox)/zoom,(v.y-oy)/zoom)
 LaunchedEffect(d.id,fit,width,height){if(width>1&&height>1){val pts=d.entities.filter{visibleIn(it,d)}.flatMap{listOf(viewBounds(it,d).min,viewBounds(it,d).max)};val b=if(pts.isEmpty())Bounds(Vec(),Vec(10000.0,7000.0))else Bounds.of(pts);zoom=min((width-100).coerceAtLeast(100)/b.width.coerceAtLeast(200.0),(height-100).coerceAtLeast(100)/b.height.coerceAtLeast(200.0)).coerceIn(0.001,20.0);ox=width/2.0-b.center.x*zoom;oy=height/2.0-b.center.y*zoom}}
 LaunchedEffect(inlineLegendId,inlineLegendKey){if(inlineLegendId!=null)runCatching{inlineFocus.requestFocus()}}
 Box(modifier){
 Canvas(Modifier.fillMaxSize().testTag("drawing-canvas").clipToBounds().background(Color.White).onSizeChanged{width=it.width;height=it.height}.pointerInteropFilter{event->
  val pos=Vec(event.x.toDouble(),event.y.toDouble())
  when(event.actionMasked){
   MotionEvent.ACTION_DOWN->{
    down=pos;last=pos;downWorld=world(pos);moved=false;pinch=false;downTime=event.eventTime
    panMode=tool=="pan"||(penMode&&event.getToolType(0)!=MotionEvent.TOOL_TYPE_STYLUS)
    stroke=if(tool=="freehand"&&!panMode)listOf(downWorld)else emptyList();dragDelta=Vec();dragRotationDelta=0.0;dragSnap=null;dragSourceOffset=null;live=null;angleHint=null;handle="";original=null;lockedDragId=null
    val priority=d.entities.asReversed().firstOrNull{it.kind=="elevation"&&visibleIn(it,d)&&!it.locked&&hitTest(downWorld,it,d,10*density.density/zoom)}
     ?:d.entities.asReversed().firstOrNull{it.kind=="dimension"&&visibleIn(it,d)&&!it.locked&&hitTest(downWorld,it,d,10*density.density/zoom)}
     ?:d.entities.asReversed().firstOrNull{!it.locked&&visibleIn(it,d)&&labelTextBounds(it,d)?.contains(downWorld,12*density.density/zoom)==true}
    if(tool=="select"&&!panMode&&priority!=null&&priority.id !in selected)onTap(downWorld,false)
    val e=priority?:d.entities.singleOrNull{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true}
    if(tool=="select"&&!panMode&&e!=null){lockedDragId=e.id;val b=viewBounds(e,d);original=e
     val editing=e.str("editMode","false")=="true"
     val foundationHandle=if(editing&&isFoundation(e))foundationEditHandles(e,d).entries.minByOrNull{downWorld.distance(it.value)}?.takeIf{downWorld.distance(it.value)<touchPx*1.5/zoom}?.key else null
     handle=foundationHandle?:when{e.kind=="elevation"&&hitTest(downWorld,e,d,12*density.density/zoom)->"elevationLabel";labelTextBounds(e,d)?.contains(downWorld,12*density.density/zoom)==true->"label";editing&&downWorld.distance(Vec(b.center.x,b.min.y-rotationOffset/zoom))<touchPx/zoom->"rotate";editing&&downWorld.distance(b.max)<touchPx/zoom->"scale";else->""}

    }
    dragging=tool=="select"&&!panMode&&(priority!=null||handle.isNotEmpty()||d.entities.any{it.id in selected&&!it.locked&&d.layers.find{l->l.id==it.layerId}?.locked!=true&&visibleIn(it,d)&&hitTest(downWorld,it,d,touchPx/zoom)})
    if(tool in dragShapeTools&&!panMode)downWorld=caught(downWorld)
    true
   }
   MotionEvent.ACTION_POINTER_DOWN->{pinch=true;dragging=false;live=null;stroke=emptyList();snapMark=null;if(event.pointerCount>=2){previousDistance=hypot((event.getX(1)-event.getX(0)).toDouble(),(event.getY(1)-event.getY(0)).toDouble());previousCenter=Vec((event.getX(0)+event.getX(1))/2.0,(event.getY(0)+event.getY(1))/2.0)};true}
   MotionEvent.ACTION_MOVE->{
    if(event.pointerCount>=2){val center=Vec((event.getX(0)+event.getX(1))/2.0,(event.getY(0)+event.getY(1))/2.0);val dist=hypot((event.getX(1)-event.getX(0)).toDouble(),(event.getY(1)-event.getY(0)).toDouble());val anchor=world(previousCenter);zoom=(zoom*(dist/previousDistance.coerceAtLeast(1.0))).coerceIn(0.0005,50.0);ox=center.x-anchor.x*zoom;oy=center.y-anchor.y*zoom;previousCenter=center;previousDistance=dist;pinch=true}
    else if(!pinch){if(pos.distance(down)>8*density.density)moved=true;if(panMode){ox+=pos.x-last.x;oy+=pos.y-last.y}else if(tool=="freehand"&&pos.distance(last)>2){stroke=stroke+world(pos)}else if(dragging){
      val e=original
      if(e!=null&&handle.isNotEmpty()) {val bounds=viewBounds(e,d);val target=world(pos)
       live=when(handle){
        "foundationWidthLeft","foundationWidthRight"->{val source=d.entities.find{it.id==e.str("sourceId")};if(source==null)e else {val c=viewBounds(source,d).center.x;val w=(abs(target.x-c)*2).coerceAtLeast(viewBounds(source,d).width);angleHint="Breite ${fmt(w/10.0,1)} cm";angleHintAt=target;e.withNum("foundationWidthMm",w)}}
        "foundationThickness"->{val source=d.entities.find{it.id==e.str("sourceId")};if(source==null)e else {val top=viewBounds(source,d).max.y;val t=(target.y-top).coerceAtLeast(10.0);angleHint="Dicke ${fmt(t/10.0,1)} cm";angleHintAt=target;e.withNum("thicknessMm",t)}}
        "foundationEmbed"->{val source=d.entities.find{it.id==e.str("sourceId")};if(source==null)e else {val b=viewBounds(source,d);val em=(b.max.y-target.y).coerceIn(0.0,b.height);angleHint="Einbindung ${fmt(em/10.0,1)} cm";angleHintAt=target;e.withStr("embedMode","manual").withNum("embedMm",em)}}
        "elevationLabel"->{
         // Drag the measured tip, not the text insertion point. Preserve the
         // finger-to-tip offset so the marker never jumps under the thumb.
         val start=resolvedPoints(e,d).firstOrNull()?:e.points.firstOrNull()?:Vec()
         val proposed=start+(target-downWorld)
         val others=d.copy(entities=d.entities.filterNot{it.id==e.id})
         val snapped=elevationSurfaceSnap(proposed,others,24*density.density/zoom)
         val tip=snapped?.point?:proposed
         snapMark=snapped
         e.copy(points=listOf(tip),anchors=if(e.str("elevationRole","relative")=="manual")emptyList() else snapped?.anchor?.let{listOf(it)}?:emptyList())
          .withNum("${d.viewMode()}Dx",0.0).withNum("${d.viewMode()}Dy",0.0)
          .withNum("${d.viewMode()}LabelDx",0.0).withNum("${d.viewMode()}LabelDy",0.0)
        }
        "label"->{val center=bounds.center;if(d.viewMode()=="section")e.withNum("labelSectionDx",e.num("labelSectionDx",objectLabelPosition(e,d).x-center.x)+target.x-downWorld.x).withNum("labelSectionDy",e.num("labelSectionDy",objectLabelPosition(e,d).y-center.y)+target.y-downWorld.y) else e.withNum("labelTopDx",e.num("labelTopDx",objectLabelPosition(e,d).x-center.x)+target.x-downWorld.x).withNum("labelTopDy",e.num("labelTopDy",objectLabelPosition(e,d).y-center.y)+target.y-downWorld.y)}
        "rotate"->{val snapped=caught(target,exclude=selected);val center=smartPivot(e,d);val a=atan2(downWorld.y-center.y,downWorld.x-center.x);val b=atan2(snapped.y-center.y,snapped.x-center.x);val step=when{e.kind=="dimension"&&e.str("rotationMode","snap")=="free"->0.0;e.kind=="dimension"->e.num("angleSnapStep",15.0);e.kind=="component"||isStair(e)->15.0;input.ortho->90.0;else->input.angleStep};val degrees=Math.toDegrees(b-a);val delta=if(step>0)round(degrees/step)*step else degrees;angleHint="${fmt(((smartViewRotation(e,d.viewMode())+delta)%360+360)%360,1)}°";angleHintAt=target+Vec(60/zoom,-80/zoom);if(e.kind=="component"||isStair(e))rotateSmartInView(e,d.viewMode(),delta)else transform(e,angle=delta,center=center)}
        else->{val snapped=caught(target,exclude=selected);val anchor=bounds.min;val factor=(snapped.distance(anchor)/bounds.max.distance(anchor).coerceAtLeast(1e-9)).coerceIn(0.001,1000.0);transform(e,factor=factor,center=anchor)}
       }
      } else {
       val moving=d.entities.singleOrNull{it.id in selected};val raw=world(pos)-downWorld;val others=d.copy(entities=d.entities.filterNot{it.id in selected})
       if(moving!=null&&(moving.kind=="component"||isStair(moving))){
        val origin=smartViewOrigin(moving,d.viewMode())
        if(isKg2000(moving)){
         data class KgChoice(val source:PipeConnector,val target:PipeConnector,val targetEntity:Entity,val dist:Double,val rotation:Double,val rotatedSource:Vec)
         fun norm180(v:Double):Double{var x=(v+180.0)%360.0;if(x<0)x+=360.0;return x-180.0}
         val sourceCons=kg2000Connectors(moving,d);val targetCons=others.entities.filter{isKg2000(it)||isChannelBox(it)}.flatMap{te->(if(isKg2000(te))kg2000Connectors(te,others)else channelBoxPipeConnectors(te,others)).mapIndexed{index,tc->Triple(te,index,tc)}}
         val candidates=sourceCons.flatMap{sc->targetCons.mapNotNull{(te,index,tc)->if(kg2000Compatible(sc,tc)&&!kg2000ConnectorOccupied(tc,te.id,others,selected)){val rot=norm180(tc.direction+180.0-sc.direction);val rotatedSource=origin+(sc.at-origin).rotate(rot);val dist=(rotatedSource+raw).distance(tc.at);if(dist<=touchPx/zoom*2.5)KgChoice(sc,tc,te,dist,rot,rotatedSource)else null}else null}}
         // Nearest free compatible connector wins. Rotation is only the tie breaker; otherwise a distant straight connector could steal the snap from a nearby bend outlet.
         val best=candidates.minWithOrNull(compareBy<KgChoice>{it.dist}.thenBy{kotlin.math.abs(it.rotation)});if(best!=null){dragRotationDelta=best.rotation;dragDelta=raw+(best.target.at-(best.rotatedSource+raw));val idx=(if(isKg2000(best.targetEntity))kg2000Connectors(best.targetEntity,others)else channelBoxPipeConnectors(best.targetEntity,others)).indexOfFirst{it.at.distance(best.target.at)<1e-4};dragSnap=SnapResult(best.target.at,"KG2000 Anschluss",Anchor(best.targetEntity.id,idx.coerceAtLeast(0),"kg2000",d.viewMode()),best.targetEntity.str("snapPriority","normal"));dragSourceOffset=best.rotatedSource-origin;snapMark=dragSnap}
         else {dragRotationDelta=0.0;val r=snap(origin+raw,others,input.options(touchPx/zoom),origin);dragDelta=r.point-origin;dragSnap=r.takeIf{it.anchor!=null};dragSourceOffset=Vec();snapMark=r.takeIf{it.reason.isNotEmpty()}}
        } else {
        val refs=smartDragSnapReferencePoints(moving,d)
        val sourceSegments=smartDragSnapSegments(moving,d)
        // Curbs are deliberately more magnetic than ordinary smart objects.
        // Their installation edges are small on screen and should lock firmly
        // once they are close enough to another construction edge.
        val smartSnapTolerance=touchPx/zoom
        data class Choice(val result:SnapResult,val sourceAt:Vec,val offset:Vec,val correction:Double,val rank:Int,val sourceRank:Int,val curbBias:Int)
        fun targetIsCurb(r:SnapResult)=r.anchor?.entityId?.let{id->others.entities.find{it.id==id}}?.smartFamily()=="curb"
        val criticalSource=if(moving.smartFamily()=="curb")curbCriticalSnapPoints(moving,d)else emptyList()
        val pointChoices=refs.mapNotNull{ref->
         val tol=smartSnapTolerance*(if(criticalSource.any{it.distance(ref)<1e-5})2.4 else 1.0)
         val at=ref+raw;val r=snap(at,others,input.options(tol))
         if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else Choice(r,at,ref-origin,r.point.distance(at),when(r.priority){"high"->0;"low"->2;else->1},1,if(targetIsCurb(r)||moving.smartFamily()=="curb")1 else 0)
        }
        // Also snap the actual visible source edges. The point on the source edge
        // nearest the finger is used, so endpoint/phase targets correct only the
        // normal distance and do not drag the whole component along its edge.
        val pointer=world(pos)
        val edgeChoices=sourceSegments.mapNotNull{(a,b)->
         val aa=a+raw;val bb=b+raw;val at=closestOnSegment(pointer,aa,bb);val r=snap(at,others,input.options(smartSnapTolerance))
         if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else Choice(r,at,(at-raw)-origin,r.point.distance(at),when(r.priority){"high"->0;"low"->2;else->1},0,if(targetIsCurb(r)||moving.smartFamily()=="curb")0 else 0)
        }
        val best=(edgeChoices+pointChoices).minWithOrNull(compareBy<Choice>{it.rank}.thenBy{it.curbBias}.thenBy{it.correction}.thenBy{it.sourceRank})
        if(best!=null){dragDelta=raw+(best.result.point-best.sourceAt);dragSnap=best.result;dragSourceOffset=best.offset;snapMark=best.result}
        else {val r=snap(origin+raw,others,input.options(touchPx/zoom),origin);dragDelta=r.point-origin;dragSnap=r.takeIf{it.anchor!=null};dragSourceOffset=Vec();snapMark=r.takeIf{it.reason.isNotEmpty()}}
        }
       } else {
        val movingEntity=d.entities.firstOrNull{it.id==lockedDragId}?:d.entities.firstOrNull{it.id in selected}
        if(movingEntity?.kind=="dimension"){
         // Dimension placement has deliberately only two magnetic directions:
         // horizontal and vertical. No grid/angle/object snap is applied here.
         // The constrained preview is used during the drag, not just on release.
         val len=raw.length()
         dragDelta=if(len<1e-9)raw else {
          val a=((Math.toDegrees(kotlin.math.atan2(raw.y,raw.x))%180)+180)%180
          when{
           kotlin.math.min(a,kotlin.math.abs(180-a))<=8.0 -> Vec(raw.x,0.0)
           kotlin.math.abs(a-90.0)<=8.0 -> Vec(0.0,raw.y)
           else -> raw
          }
         }
         dragSnap=null;dragSourceOffset=Vec();snapMark=null
        } else if(selected.size>1){
         // Groups are a selection concept (shared groupId), not a synthetic
         // bounding-box entity.  Therefore keep the real snap geometry of all
         // children when the group is moved.  This also makes grouped curbs,
         // channel boxes, pipes, stairs, etc. snap exactly like their members.
         data class GroupChoice(val result:SnapResult,val correction:Double)
         fun sourceRefs(entity:Entity):List<Vec> = when {
          entity.kind=="component" || isStair(entity) -> smartDragSnapReferencePoints(entity,d)
          else -> {
           val pts=resolvedPoints(entity,d)
           if(pts.isNotEmpty()) pts else { val b=viewBounds(entity,d);rectangle(b.min,b.max) }
          }
         }
         val movingMembers=d.entities.filter{it.id in selected && visibleIn(it,d) && it.kind!="dimension"}
         val refs=movingMembers.flatMap(::sourceRefs).distinctBy{Pair(kotlin.math.round(it.x*1000),kotlin.math.round(it.y*1000))}
         val choices=refs.mapNotNull{ref->
          val r=snap(ref+raw,others,input.options(touchPx/zoom))
          if(r.reason.isEmpty()||r.reason=="Raster"||r.anchor==null)null else GroupChoice(r,r.point.distance(ref+raw))
         }
         val best=choices.minByOrNull{it.correction}
         if(best!=null){
          // All members receive one common correction, preserving the group.
          val source=refs.minByOrNull{(it+raw).distance(best.result.point)}?:downWorld
          dragDelta=raw+(best.result.point-(source+raw));dragSnap=best.result;dragSourceOffset=source-downWorld;snapMark=best.result
         }else{
          dragDelta=raw;dragSnap=null;dragSourceOffset=Vec();snapMark=null
         }
        } else {
         val moving=movingEntity
         val refs=when{
          moving==null->listOf(downWorld)
          moving.kind=="component"||isStair(moving)->smartDragSnapReferencePoints(moving,d)
          else->{val rp=resolvedPoints(moving,d);val b=viewBounds(moving,d);(rp+rectangle(b.min,b.max)+listOf(b.center)).distinct()}
         }
         data class MoveChoice(val source:Vec,val result:SnapResult,val correction:Double)
         val choices=refs.mapNotNull{ref->val r=snap(ref+raw,others,input.options(touchPx/zoom));if(r.anchor==null||r.reason.isEmpty()||r.reason=="Raster")null else MoveChoice(ref,r,r.point.distance(ref+raw))}
         val best=choices.minByOrNull{it.correction}
         if(best!=null){dragDelta=raw+(best.result.point-(best.source+raw));dragSnap=best.result;dragSourceOffset=best.source-(moving?.points?.firstOrNull()?:downWorld);snapMark=best.result}
         else {dragDelta=raw;dragSnap=null;dragSourceOffset=Vec();snapMark=null}
        }
       }
      }
     }else if(tool in dragShapeTools){val target=caught(world(pos),if(tool in setOf("rect","building","area"))null else downWorld);if(target.distance(downWorld)>1e-9&&(tool !in setOf("rect","building","area")||(abs(target.x-downWorld.x)>1e-9&&abs(target.y-downWorld.y)>1e-9)))live=shapeFromDrag(tool,downWorld,target)else live=null};last=pos}
    onCoordinates(world(pos),zoom);true
   }
   MotionEvent.ACTION_UP->{if(!pinch){if(!panMode){val deleteDrop=dragging&&moved&&handle.isEmpty()&&pos.x>width-110*density.density&&pos.y<125*density.density;if(deleteDrop)onDeleteRequested()else if(tool=="freehand"&&stroke.size>1)onFreehand(stroke)else if(moved&&live!=null){if(dragging)onChange(live!!)else onCreate(live!!)}else if(dragging&&moved)onMove(dragDelta,dragSnap,dragSourceOffset,dragRotationDelta,lockedDragId)else if(!moved){val wp=world(pos);val legend=d.entities.lastOrNull{it.kind=="legend"&&visibleIn(it,d)&&hitTest(wp,it,d,touchPx/zoom)};if(legend!=null){val base=legendItems(d,p.libraryEntries);val textSize=legend.style.textPaperMm*d.sheet.scale;val localY=wp.y-(legend.points.firstOrNull()?.y?:0.0);val titleRows=if(legend.text.isNotBlank())1 else 0;val row=kotlin.math.floor(localY/(textSize*1.7)).toInt()-titleRows;inlineLegendId=legend.id;inlineLegendKey=if(titleRows==1&&localY<textSize*1.7)"__title" else base.filter{legend.str("legendVisible:${it.key}","true")!="false"}.sortedBy{legend.num("legendOrder:${it.key}",base.indexOf(it).toDouble())}.getOrNull(row)?.key;if(inlineLegendKey!=null){inlineLegendText=if(inlineLegendKey=="__title")legend.text else {val item=base.find{it.key==inlineLegendKey};legend.str("legendLabel:${inlineLegendKey}").ifBlank{item?.label.orEmpty()}};inlineLegendScreen=pos}else onTap(wp,event.eventTime-downTime>500)}else onTap(wp,event.eventTime-downTime>500)}} };dragging=false;dragDelta=Vec();dragRotationDelta=0.0;stroke=emptyList();live=null;snapMark=null;angleHint=null;handle="";lockedDragId=null;pinch=false;true}
   MotionEvent.ACTION_CANCEL->{dragging=false;dragDelta=Vec();dragRotationDelta=0.0;stroke=emptyList();live=null;snapMark=null;angleHint=null;handle="";lockedDragId=null;pinch=false;true}
   else->true
  }
 }){
  val canvas=drawContext.canvas.nativeCanvas;canvas.save();canvas.clipRect(0f,0f,size.width,size.height);canvas.translate(ox.toFloat(),oy.toFloat());canvas.scale(zoom.toFloat(),zoom.toFloat())
  if(d.sheet.showPaper){val a=d.sheet.origin;val rect=android.graphics.RectF(a.x.toFloat(),a.y.toFloat(),(a.x+(d.sheet.widthMm-20)*d.sheet.scale).toFloat(),(a.y+(d.sheet.heightMm-42)*d.sheet.scale).toFloat());canvas.drawRect(rect,android.graphics.Paint().apply{color=android.graphics.Color.rgb(245,248,244)});canvas.drawRect(rect,android.graphics.Paint().apply{color=android.graphics.Color.LTGRAY;style=android.graphics.Paint.Style.STROKE;strokeWidth=(1/zoom).toFloat()})}
  if(grid){var spacing=d.gridMm;while(spacing*zoom<14)spacing*=5;val min=world(Vec());val max=world(Vec(width.toDouble(),height.toDouble()));val pen=android.graphics.Paint().apply{color=android.graphics.Color.rgb(217,226,222);strokeWidth=(1/zoom).toFloat()};var x=floor((min.x-d.origin.x)/spacing)*spacing+d.origin.x;var count=0;while(x<max.x&&count++<500){canvas.drawLine(x.toFloat(),min.y.toFloat(),x.toFloat(),max.y.toFloat(),pen);x+=spacing};var y=floor((min.y-d.origin.y)/spacing)*spacing+d.origin.y;count=0;while(y<max.y&&count++<500){canvas.drawLine(min.x.toFloat(),y.toFloat(),max.x.toFloat(),y.toFloat(),pen);y+=spacing}}
  renderer.draw(canvas,scene)
  val selectionStyle=Style(stroke="#D0802E",widthMm=2/zoom)
  selected.forEach{id->d.entities.find{it.id==id&&visibleIn(it,d)}?.let{e->val b=viewBounds(e,d);renderer.draw(canvas,listOf(Primitive.Path(rectangle(b.min,b.max),true,selectionStyle)));if(tool=="select"&&selected.size==1&&!e.locked&&d.layers.find{it.id==e.layerId}?.locked!=true){
    val rotation=Vec(b.center.x,b.min.y-rotationOffset/zoom)
    val editing=e.str("editMode","false")=="true"
    val grips=mutableListOf<Primitive>();if(editing){grips.add(Primitive.Path(listOf(Vec(b.center.x,b.min.y),rotation),style=selectionStyle));grips.add(Primitive.Circle(b.max,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")));grips.add(Primitive.Circle(rotation,gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))}
    if(labelActive(e,d))grips.add(Primitive.Circle(objectLabelPosition(e,d),gripPx/zoom,selectionStyle.copy(fill="#FFFFFF")))
    if(editing&&isFoundation(e))foundationEditHandles(e,d).values.forEach{grips.add(Primitive.Circle(it,gripPx/zoom,selectionStyle.copy(stroke="#2787A5",fill="#FFFFFF")))}
    renderer.draw(canvas,grips)
    if(editing&&(e.kind=="component"||isStair(e))){renderer.draw(canvas,smartSnapReferencePoints(e,d).map{Primitive.Circle(it,gripPx*.55/zoom,selectionStyle.copy(stroke="#2787A5",fill="#FFFFFF"))});val targetId=e.str("followTargetId");val target=d.entities.find{it.id==targetId};if(target!=null)renderer.draw(canvas,listOf(Primitive.Path(listOf(viewBounds(e,d).center,viewBounds(target,d).center),style=selectionStyle.copy(stroke="#2787A5",dashed=true))))}
   };if(dragging&&handle.isEmpty())renderer.draw(canvas,Scene.entity(when{e.kind=="component"||isStair(e)->{val r=if(kotlin.math.abs(dragRotationDelta)>1e-9)rotateSmartInView(e,d.viewMode(),dragRotationDelta)else e;moveSmartInView(r,d.viewMode(),dragDelta)};e.kind=="elevation"->moveAnnotationInView(e,d.viewMode(),dragDelta);else->transform(e,translation=dragDelta)},d,p))}}
  renderer.draw(canvas,listOf(Primitive.Path(preview+stroke,style=Style(stroke="#1879A2",widthMm=2/zoom))))
  live?.let{e->
   renderer.draw(canvas,Scene.entity(e.copy(style=e.style.copy(stroke="#1879A2",opacity=.7)),d,p))
   val b=viewBounds(e,d);val font=labelPx/zoom
   val labelStyle=Style(stroke="#12516A",background="#FFFFFF",align="center")
   val labels=if(e.kind in setOf("rect","building","area")&&e.points.size==4) {
    listOf(Primitive.Text(Vec(b.center.x,b.min.y-font*.7),"${fmt(e.points[0].distance(e.points[1]))} mm",font,labelStyle),Primitive.Text(Vec(b.max.x+font*.8,b.center.y),"${fmt(e.points[0].distance(e.points[3]))} mm",font,labelStyle.copy(align="left")))
   } else listOf(Primitive.Text(b.min-Vec(0.0,font*.7),if(e.kind in setOf("circle","arc"))"R ${fmt(e.num("radiusMm"))} mm"else "${fmt(length(e.points))} mm",font,labelStyle.copy(align="left")))
   renderer.draw(canvas,labels)
  }
  snapMark?.let{mark->renderer.draw(canvas,listOf(Primitive.Circle(mark.point,gripPx/zoom,selectionStyle.copy(stroke="#B63586")),Primitive.Text(mark.point+Vec(labelPx/zoom,-labelPx/zoom),mark.reason,labelPx/zoom,Style(stroke="#B63586",background="#FFFFFF"))))}
  angleHint?.let{renderer.draw(canvas,listOf(Primitive.Text(angleHintAt+Vec(labelPx/zoom,-labelPx/zoom),it,labelPx/zoom,Style(stroke="#12516A",background="#FFFFFF",bold=true))))}
  preview.forEach{renderer.draw(canvas,listOf(Primitive.Circle(it,4/zoom,selectionStyle.copy(fill="#D0802E"))))}
  renderer.draw(canvas,listOf(Primitive.Path(listOf(d.origin-Vec(60/zoom,0.0),d.origin+Vec(60/zoom,0.0)),style=Style(stroke="#B0BDB8",widthMm=1/zoom)),Primitive.Path(listOf(d.origin-Vec(0.0,60/zoom),d.origin+Vec(0.0,60/zoom)),style=Style(stroke="#B0BDB8",widthMm=1/zoom))))
  canvas.restore()
  if(dragging&&handle.isEmpty()&&selected.isNotEmpty()){
   val r=android.graphics.RectF(size.width-94*density.density,18*density.density,size.width-18*density.density,94*density.density)
   val over=last.x>size.width-110*density.density&&last.y<125*density.density
   val fill=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=if(over)android.graphics.Color.rgb(210,70,60)else android.graphics.Color.rgb(245,225,222);style=android.graphics.Paint.Style.FILL}
   val strokePaint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(150,45,40);style=android.graphics.Paint.Style.STROKE;strokeWidth=2*density.density}
   canvas.drawRoundRect(r,14*density.density,14*density.density,fill);canvas.drawRoundRect(r,14*density.density,14*density.density,strokePaint)
   val cx=r.centerX();val cy=r.centerY();canvas.drawRect(cx-14*density.density,cy-10*density.density,cx+14*density.density,cy+18*density.density,strokePaint);canvas.drawLine(cx-18*density.density,cy-16*density.density,cx+18*density.density,cy-16*density.density,strokePaint);canvas.drawLine(cx-7*density.density,cy-21*density.density,cx+7*density.density,cy-21*density.density,strokePaint)
  }
 }
 inlineLegendId?.let{id->inlineLegendKey?.let{key->
  BasicTextField(value=inlineLegendText,onValueChange={value->inlineLegendText=value;d.entities.find{it.id==id}?.let{legend->onChange(if(key=="__title")legend.copy(text=value)else legend.withStr("legendLabel:$key",value))}},singleLine=true,modifier=Modifier.offset{IntOffset(inlineLegendScreen.x.toInt(),inlineLegendScreen.y.toInt())}.width(220.dp).background(Color.White).focusRequester(inlineFocus))
 }}
 }
}
